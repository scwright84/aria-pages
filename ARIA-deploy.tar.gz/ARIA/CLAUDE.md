# ARIA Project Instructions

Read this fully before making changes. Last updated: 2026-03-23.

## What This Is
ARIA (Automated Routing & Intelligence Assistant) is an AI operating system that runs on local hardware. It ingests all communication channels, processes them with local AI, and delivers daily intelligence: Presidential Briefs, commitment tracking, draft responses, and mobile AI access.

**Three roles:**
1. **Sean's system:** Running daily as his executive assistant (reference deployment)
2. **Product:** Being packaged for deployment to small businesses, starting with dental practices
3. **Company:** ARIA is becoming its own entity (co-founded with Kelly Kelley, 47.5/47.5/5 split proposed)

Stage: Pre-product, company forming. Architecture locked. Design partner confirmed (Kelly's brother, prosthodontist, Forest Hills, Queens). Thursday discovery call scheduled.

## Project Location
- ARIA project: ~/Desktop/dev projects/ARIA/
- Docker stack: ~/self-hosted-ai-starter-kit/
- n8n UI: http://localhost:5678
- Config: config/aria.json

## Documents to Reference

| Document | Purpose |
|----------|---------|
| docs/PRODUCT_SPEC.md | Product definition, personas, GTM, pricing, build phases |
| docs/ARCHITECTURE.md | Sector map, data flow, security model, technical decisions |
| docs/BUG_TRACKER.md | All bugs, features, infrastructure items |
| docs/QA_CHECKLIST.md | Pre-deployment validation (must pass before any client deploy) |
| docs/AUTOMATION-ROADMAP.md | Module roadmap (Modules 1-6, Phases 3-4) |

## Key Architecture Decisions

### AI Stack (LOCKED 2026-03-23)
- **Inference engine:** oMLX (Apple-native MLX). Replaces Ollama. 2x faster, same API.
- **Hybrid model:** 85% local (oMLX) / 15% cloud (Claude API) for high-judgment tasks
- **Model stack (48GB Mac Mini M4 Pro):**
  - Qwen3-30B-A3B: Triage/routing (60-70 tok/s, MoE)
  - Qwen3-32B: Draft responses, summarization (15-22 tok/s)
  - Qwen2.5-VL-32B: Vision/document processing
  - Qwen3-8B + LoRA: Client-specific fine-tuned model
  - Claude API: Escalation for customer-facing content, strategy, complex reasoning
- **Fine-tuning:** MLX LoRA after ~6 months of client data. This is the moat.

### Deployment Model (LOCKED)
- Mac Mini in client's office (hardware they own)
- All data stored locally (HIPAA-friendly)
- oMLX processes 85-90% of AI tasks locally
- Claude API for 10-15% high-judgment escalation
- Remote monitoring by Sean

### Go-to-Market (UPDATED 2026-03-24)
- **Beachhead vertical:** Dental practices (prosthodontics + insurance claims). Second vertical: attorneys via workers comp network.
- **Design partner:** Kelly Kelley's brother (prosthodontist, Forest Hills, Queens). Free setup, customer covers hardware.
- **Pilot scope:** Email + Calendar + Presidential Brief + Telegram (Phase A). Practice management integration is now near-term (Phase B), not "someday" — Kelly gathering dental software list for integration assessment.
- **Partnership:** Kelly Kelley is co-founder (47.5/47.5/5 split proposed). Kelly handles BD, marketing, customer success. Sean handles technical development, solution architecture. Company formation in progress.
- **White-label requirement:** System must be brandable per client (onboarding wizard, dashboard, Telegram bot, briefings pull from client config, not hardcoded "ARIA").

### Deployment Models
1. **Shared Mac Studio hosting (PRIMARY ON-RAMP):** WA-owned Mac Studio serves 3-5 clients with repo-level isolation (separate data dirs, configs, Soul files). Zero upfront for client. Best for proving value before hardware commitment.
2. **Client-owned hardware:** Mac Mini M4 Pro in their office. Graduate from shared hosting once value is proven.
3. **Cloud-hosted:** Only for remote clients where physical hardware isn't practical.

### Hardware Options
- **Mac Mini M4 Pro, 48GB (~$1,200-1,600):** 85-90% local processing. Default recommendation.
- **Mac Studio M4 Ultra (~$8,500):** 100% offline capability. Used for shared hosting model (serves multiple clients).

## Current Ingestion Sources (Sean's System)
- **Email:** 6 Gmail (Personal, Conceivable, Hearthril, Joined, Pippa, MasterFi) + 1 Outlook (WrightAdvisors)
- **Slack:** Conceivable workspace (9 channels)
- **Calendar:** 4 Google Calendars (Personal, Pippa, Conceivable, MasterFi) + Calendly
- **Meetings:** Granola API (50+ documents, commitment extraction)
- **Notifications:** macOS notification center DB (iMessage, WhatsApp, Signal, Telegram, etc.)

## Output Generation
- **Morning briefing** (7:30am): All sources, AI analysis, HTML email
- **Evening debrief** (9:30pm): Plan vs. actuals comparison
- **Weekly rollup** (Sunday 7pm): Per-client cards
- **Conceivable weekly** (Sunday 6pm): Client-specific brief
- **Meeting prep** (5-min cron): 30 min before meetings, invitee context
- **Draft responses** (3x/day): AI drafts to Gmail Drafts
- **Telegram bot** (@Wrightariabot): Mobile access, free-form questions

## Inbox File Types
| Pattern | Source |
|---------|--------|
| emails-YYYY-MM-DD.json | Gmail + Outlook |
| slack-YYYY-MM-DD.json | Conceivable Slack |
| calendar-YYYY-MM-DD.json | 4 Google Calendars |
| calendly-YYYY-MM-DD.json | Calendly API |
| notifications-YYYY-MM-DD.json | macOS notifications |
| awaiting-YYYY-MM-DD.json | Granola meetings (commitments) |
| drafts-YYYY-MM-DD.json | Draft reply tracking |

## n8n Workflows
| ID | Name | Trigger | Status |
|----|------|---------|--------|
| BIJL6wRqndqODoQo | Notification Ingestion | Webhook | Active |
| GranolaIngest001 | Granola Meeting Ingestion | Webhook | Active |
| EmailIngest001 | Email Ingestion (Gmail) | Cron 7am/9pm | Active |
| OutlookIngest001 | Email Ingestion (Outlook) | Cron 7am/9pm | Active |
| SlackIngest001 | Slack Ingestion | Cron 7am/9pm | Active |
| CalendarSync001 | Google Calendar Sync | Cron 4x/day | Active |
| CalendlySync001 | Calendly Sync | Cron 4x/day | Active |
| BriefingEmail001 | Send Briefing Email | Webhook | Active |
| BriefingReply001 | Briefing Reply Handler | Every 15min | Active |
| MeetingPrep001 | Meeting Prep Brief | Every 5min | Active |
| DraftResponse001 | Draft Response Queue | Cron 3x/day | Active |
| NotionCommit001 | Notion Task CRUD | Webhook | Active |

## Credentials (n8n)
- 6 Gmail OAuth + 1 Outlook OAuth
- 4 Google Calendar OAuth
- 1 Slack API (Conceivable)
- 1 Calendly PAT
- 1 oMLX API (local, port 11434)

## Stack Commands
```bash
# Start stack
cd ~/self-hosted-ai-starter-kit && docker compose up postgres qdrant n8n-import n8n -d

# Stop stack
cd ~/self-hosted-ai-starter-kit && docker compose down

# Manual sync
cd ~/Desktop/dev\ projects/ARIA
.venv/bin/python3 scripts/notification-sync.py
.venv/bin/python3 scripts/granola-sync.py

# Generate outputs
.venv/bin/python3 scripts/generate-briefing.py
.venv/bin/python3 scripts/generate-debrief.py
.venv/bin/python3 scripts/generate-weekly.py
.venv/bin/python3 scripts/meeting-prep.py

# Import workflow to n8n
docker exec n8n n8n import:workflow --input=/data/aria/workflows/<file>.json
docker exec n8n n8n publish:workflow --id=<WorkflowID>
cd ~/self-hosted-ai-starter-kit && docker compose restart n8n
```

## launchd Jobs
- com.aria.notification-sync: 7am, 9pm
- com.aria.granola-sync: 7am, 9pm
- com.aria.morning-briefing: 7:30am
- com.aria.evening-debrief: 9:30pm
- com.aria.conceivable-weekly: Sunday 6pm
- com.aria.weekly-rollup: Sunday 7pm
- com.aria.telegram-bot: RunAtLoad + KeepAlive

## Development Notes
- Python venv at ARIA/.venv
- Sync scripts are one-shot (run, process, exit)
- State files in logs/ track last-seen IDs and content hashes
- Granola sync uses API at api.granola.ai (token from ~/Library/Application Support/Granola/supabase.json)
- Notification DB: ~/Library/Group Containers/group.com.apple.usernoted/db2/db
- Docker compose mounts: ARIA at /data/aria, WrightAdvisors at /data/clients
- Always restart n8n after import+publish for changes to take effect
- Briefing HTML files stored in briefings/ with 14-day retention

## Business Trajectory
- **Phase 1: Concierge (Now):** Sean deploys everything via shared Mac Studio. Design partner (free) then early customers.
- **Phase 2: Low-Touch:** Toolkit handles 90%. Sean does 1-hr onboarding + config. Clients graduate to own hardware.
- **Phase 3: Self-Serve:** Client runs installer. Hardware markup + monthly SaaS.
- **Pricing:** Still being determined. Do NOT hardcode pricing assumptions into docs or code.

**Critical design principles:**
1. Every piece of infrastructure should be architected with Phase 3 (self-serve) in mind. Config-driven, no hardcoded values, automated health checks, guided onboarding.
2. **White-label from day one.** All UI surfaces must pull branding from client config. No hardcoded "ARIA" in user-facing output.
3. **Multi-tenant isolation.** Shared Mac Studio means separate data dirs, separate configs, separate Soul files per client. No cross-contamination.

## Build Priorities (Current — Phase 1 Sprint)
1. **Week 1:** Swap to oMLX, run ARIA 24/7, fix BUG-001 through BUG-004
2. **Week 2:** FEAT-002 through FEAT-006 (health checks, auto-restart, setup script, SMTP fallback)
3. **Week 3:** FEAT-007 through FEAT-011 (config-driven, OAuth, dental template, per-client bot)
4. **Week 4:** Deploy to Kelly's brother's dental practice

## What NOT to Do
- **Don't expose architecture in sales conversations.** No model names, no oMLX, no LoRA. Say "AI engine" and "learns your practice."
- **Don't deploy without passing QA_CHECKLIST.md.** Every item in Section 1-4 must pass.
- **Don't claim HIPAA compliance.** Say "HIPAA-friendly." Full compliance requires BAAs and audits we don't have.
- **Don't fine-tune before 6 months of client data.** Premature fine-tuning produces worse models.
- **Don't promise practice management integration as Day 1.** It's Phase B. Deliver the brief first.
- **Don't amend Ollama references in existing scripts yet.** Swap to oMLX in Phase 1 as a coordinated migration, not piecemeal.
