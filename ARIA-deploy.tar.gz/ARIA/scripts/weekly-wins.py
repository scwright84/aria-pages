#!/usr/bin/env python3
"""
ARIA Weekly Wins Report
Auto-detects accomplishments from the week's activity.
Great for morale, investor updates, and board decks.

Detects wins from:
  - Completed commitments (promised and delivered)
  - Positive email signals (thank you, great work, approved)
  - Closed tasks
  - Meetings that resulted in decisions
  - Engagement improvements (scorecard grade went up)
  - New connections/leads

Output: briefings/YYYY-MM-DD-wins.json + HTML
Runs Sunday evening.
"""

import json
import re
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
TASKS_FILE = PROJECT_DIR / "config" / "tasks.json"
LOG_FILE = PROJECT_DIR / "logs" / "weekly-wins.log"

WIN_KEYWORDS = re.compile(
    r'(?:thank|congrat|approved|shipped|launched|closed|signed|completed|delivered|won|landed|secured|achieved|milestone|breakthrough|success)',
    re.IGNORECASE
)


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_inbox(prefix, days_back=7):
    all_data = []
    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        path = INBOX_DIR / f"{prefix}-{date.strftime('%Y-%m-%d')}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                all_data.extend(data if isinstance(data, list) else [data])
            except Exception:
                pass
    return all_data


def detect_email_wins(days_back=7):
    """Find emails with positive/win signals."""
    wins = []
    emails = load_inbox("emails", days_back)
    for e in emails:
        text = f"{e.get('subject', '')} {e.get('summary', '')} {e.get('snippet', '')}".lower()
        if WIN_KEYWORDS.search(text):
            wins.append({
                "source": "email",
                "text": e.get("subject", "")[:100],
                "detail": (e.get("summary") or e.get("snippet", ""))[:200],
                "project": e.get("detected_project"),
                "from": e.get("from", ""),
            })
    return wins


def detect_slack_wins(days_back=7):
    """Find positive signals in Slack."""
    wins = []
    slack = load_inbox("slack", days_back)
    for s in slack:
        text = f"{s.get('summary', '')} {' '.join(s.get('key_topics', []))}".lower()
        if WIN_KEYWORDS.search(text):
            wins.append({
                "source": "slack",
                "text": f"#{s.get('channel_name', '')}: {s.get('summary', '')[:80]}",
                "detail": s.get("summary", "")[:200],
                "project": s.get("project"),
            })
    return wins


def detect_commitment_wins(days_back=7):
    """Find commitments that appear to have been completed."""
    wins = []
    # Look for commitments from 2+ weeks ago that have email follow-through
    commitments = load_inbox("awaiting", days_back=30)
    recent_emails = load_inbox("emails", days_back)
    email_text = " ".join(f"{e.get('subject','')} {e.get('summary','')}" for e in recent_emails).lower()

    for c in commitments:
        task = c.get("task", "")
        if len(task) < 10:
            continue
        # Check if any key words from commitment appear in recent emails (evidence of completion)
        words = set(re.findall(r'\b[a-z]{4,}\b', task.lower()))
        matches = sum(1 for w in words if w in email_text)
        if matches >= 3:
            wins.append({
                "source": "commitment",
                "text": f"Commitment likely completed: {task[:80]}",
                "detail": f"From meeting: {c.get('meeting', '')}. Evidence found in recent emails.",
                "project": c.get("project"),
            })

    return wins


def detect_scorecard_improvements():
    """Check if any project grades improved."""
    wins = []
    # Compare this week's scorecard to last week's
    date_str = datetime.now().strftime("%Y-%m-%d")
    current_path = BRIEFINGS_DIR / f"{date_str}-scorecard.json"
    if not current_path.exists():
        return wins

    # Find last week's scorecard
    for d in range(7, 14):
        prev_date = (datetime.now() - timedelta(days=d)).strftime("%Y-%m-%d")
        prev_path = BRIEFINGS_DIR / f"{prev_date}-scorecard.json"
        if prev_path.exists():
            try:
                with open(current_path) as f:
                    current = json.load(f)
                with open(prev_path) as f:
                    previous = json.load(f)

                grade_order = {"A": 5, "B": 4, "C": 3, "D": 2, "F": 1}
                for project in current:
                    cur_grade = current[project].get("health_grade", "?")
                    prev_grade = previous.get(project, {}).get("health_grade", "?")
                    if grade_order.get(cur_grade, 0) > grade_order.get(prev_grade, 0):
                        wins.append({
                            "source": "scorecard",
                            "text": f"{project} engagement improved: {prev_grade} → {cur_grade}",
                            "detail": f"Health grade went up this week",
                            "project": project,
                        })
            except Exception:
                pass
            break

    return wins


def generate_html(wins, date_str):
    """Generate HTML wins report."""
    by_project = {}
    for w in wins:
        proj = w.get("project") or "General"
        if proj not in by_project:
            by_project[proj] = []
        by_project[proj].append(w)

    sections = ""
    for project, project_wins in sorted(by_project.items()):
        items = ""
        for w in project_wins:
            items += f'<li><strong>{w["text"]}</strong><br><span style="font-size:12px;color:#6b7280">{w["detail"][:100]}</span></li>'
        sections += f"""
        <div style="margin-bottom:16px">
            <h3 style="font-size:15px;color:#111827;margin-bottom:8px">{project}</h3>
            <ul style="margin:0;padding-left:20px;font-size:14px;line-height:1.8">{items}</ul>
        </div>"""

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>ARIA Weekly Wins - {date_str}</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 700px; margin: 0 auto; padding: 20px; background: #f9fafb; }}
  h1 {{ font-size: 22px; color: #111827; }}
  .subtitle {{ color: #6b7280; font-size: 14px; margin-bottom: 20px; }}
  .card {{ background: white; border-radius: 8px; padding: 16px; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }}
  .count {{ text-align: center; font-size: 48px; font-weight: 700; color: #22c55e; margin: 16px 0 8px; }}
  .count-label {{ text-align: center; font-size: 14px; color: #6b7280; margin-bottom: 20px; }}
</style>
</head>
<body>
<h1>Weekly Wins</h1>
<p class="subtitle">{date_str} | Celebrate what went right</p>
<div class="count">{len(wins)}</div>
<div class="count-label">wins this week</div>
<div class="card">{sections if sections else '<p style="color:#6b7280">Keep pushing. Wins are coming.</p>'}</div>
</body>
</html>"""
    return html


def main():
    log("Starting weekly wins detection")

    all_wins = []
    all_wins.extend(detect_email_wins())
    log(f"Email wins: {len(detect_email_wins())}")

    all_wins.extend(detect_slack_wins())
    log(f"Slack wins: {len(detect_slack_wins())}")

    all_wins.extend(detect_commitment_wins())
    log(f"Commitment wins: {len(detect_commitment_wins())}")

    all_wins.extend(detect_scorecard_improvements())
    log(f"Scorecard improvements: {len(detect_scorecard_improvements())}")

    # Deduplicate by text
    seen = set()
    unique = []
    for w in all_wins:
        key = w["text"][:50].lower()
        if key not in seen:
            seen.add(key)
            unique.append(w)

    date_str = datetime.now().strftime("%Y-%m-%d")
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)

    with open(BRIEFINGS_DIR / f"{date_str}-wins.json", "w") as f:
        json.dump({"date": date_str, "wins": unique, "count": len(unique)}, f, indent=2, default=str)

    html = generate_html(unique, date_str)
    with open(BRIEFINGS_DIR / f"{date_str}-wins.html", "w") as f:
        f.write(html)

    log(f"Total unique wins: {len(unique)}")
    for w in unique[:10]:
        log(f"  [{w['source']}] {w['text'][:70]}")
    log("Weekly wins complete")


if __name__ == "__main__":
    main()
