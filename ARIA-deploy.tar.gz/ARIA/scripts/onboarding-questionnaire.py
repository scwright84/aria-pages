#!/usr/bin/env python3
"""
ARIA Onboarding Questionnaire (FEAT-098)
Structured client intake. Generates a pre-filled aria.json from answers.

Questions:
  1. Business name and type (dental, legal, consulting, etc.)
  2. Primary contact name and email
  3. Timezone
  4. Email accounts to connect (Gmail, Outlook)
  5. Calendar accounts
  6. Slack workspace (if any)
  7. Meeting notes tool (Granola, Otter, Fireflies, none)
  8. Projects/clients to track
  9. Briefing schedule preferences
  10. Who else should receive briefings (multi-user, Phase 2)

Output: config/aria.json (generated from answers)
Can be run as CLI or served as a web form.
"""

import json
import sys
from datetime import datetime
from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent
CONFIG_DIR = PROJECT_DIR / "config"
SCHEMA_FILE = CONFIG_DIR / "client-schema.json"
LOG_FILE = PROJECT_DIR / "logs" / "onboarding-questionnaire.log"

QUESTIONS = [
    {
        "id": "business_name",
        "question": "What's the name of your business?",
        "type": "text",
        "required": True,
        "example": "Lakeway Dental Care",
    },
    {
        "id": "business_type",
        "question": "What type of business is this?",
        "type": "choice",
        "options": ["dental", "legal", "accounting", "consulting", "real_estate", "general"],
        "required": True,
    },
    {
        "id": "contact_name",
        "question": "Your name (primary contact)?",
        "type": "text",
        "required": True,
    },
    {
        "id": "contact_email",
        "question": "Your primary email address?",
        "type": "email",
        "required": True,
    },
    {
        "id": "timezone",
        "question": "Your timezone?",
        "type": "choice",
        "options": [
            "America/New_York", "America/Chicago", "America/Denver",
            "America/Los_Angeles", "America/Phoenix",
            "Pacific/Honolulu", "America/Anchorage",
        ],
        "default": "America/Chicago",
        "required": True,
    },
    {
        "id": "email_accounts",
        "question": "Which email accounts should ARIA monitor? (comma-separated)",
        "type": "text",
        "required": True,
        "example": "drsmith@gmail.com, office@lakewaydentalcare.com",
    },
    {
        "id": "calendar_accounts",
        "question": "Which calendar accounts? (comma-separated, or 'same as email')",
        "type": "text",
        "default": "same as email",
    },
    {
        "id": "slack_workspace",
        "question": "Do you use Slack? If yes, workspace name:",
        "type": "text",
        "default": "",
        "example": "lakeway-dental (or leave blank)",
    },
    {
        "id": "meeting_notes",
        "question": "Do you use a meeting notes tool?",
        "type": "choice",
        "options": ["granola", "otter", "fireflies", "none"],
        "default": "none",
    },
    {
        "id": "projects",
        "question": "What projects or clients should ARIA track? (comma-separated)",
        "type": "text",
        "required": True,
        "example": "Client A, Client B, Internal, Personal",
    },
    {
        "id": "briefing_time",
        "question": "When should your morning briefing arrive? (HH:MM, 24hr)",
        "type": "text",
        "default": "07:30",
    },
    {
        "id": "debrief_time",
        "question": "When should your evening debrief arrive? (HH:MM, 24hr)",
        "type": "text",
        "default": "21:30",
    },
]

TIMEZONE_ABBR = {
    "America/New_York": "ET",
    "America/Chicago": "CT",
    "America/Denver": "MT",
    "America/Los_Angeles": "PT",
    "America/Phoenix": "MST",
    "Pacific/Honolulu": "HST",
    "America/Anchorage": "AKT",
}


def run_cli_questionnaire():
    """Run the questionnaire interactively in the terminal."""
    print("\n" + "=" * 50)
    print("  ARIA Onboarding Questionnaire")
    print("=" * 50 + "\n")

    answers = {}
    for q in QUESTIONS:
        prompt = f"  {q['question']}"
        if q.get("options"):
            prompt += f"\n  Options: {', '.join(q['options'])}"
        if q.get("default"):
            prompt += f"\n  Default: {q['default']}"
        if q.get("example"):
            prompt += f"\n  Example: {q['example']}"
        prompt += "\n  > "

        while True:
            answer = input(prompt).strip()
            if not answer and q.get("default"):
                answer = q["default"]
            if not answer and q.get("required"):
                print("  This field is required.")
                continue
            if q.get("options") and answer and answer not in q["options"]:
                print(f"  Please choose from: {', '.join(q['options'])}")
                continue
            break

        answers[q["id"]] = answer
        print()

    return answers


def generate_config(answers):
    """Generate aria.json from questionnaire answers."""
    tz = answers.get("timezone", "America/Chicago")

    # Parse email accounts
    emails = [e.strip() for e in answers.get("email_accounts", "").split(",") if e.strip()]
    email_accounts = []
    for email in emails:
        provider = "outlook" if "outlook" in email.lower() or "hotmail" in email.lower() else "gmail"
        email_accounts.append({"address": email, "provider": provider, "credential_id": email})

    # Parse calendar accounts
    cal_input = answers.get("calendar_accounts", "same as email")
    if cal_input.lower() == "same as email":
        calendar_accounts = [{"name": e["address"], "provider": "google", "credential_id": e["address"]} for e in email_accounts if e["provider"] == "gmail"]
    else:
        calendar_accounts = [{"name": c.strip(), "provider": "google", "credential_id": c.strip()} for c in cal_input.split(",") if c.strip()]

    # Parse projects
    projects = [p.strip() for p in answers.get("projects", "").split(",") if p.strip()]

    config = {
        "client": {
            "name": answers.get("business_name", ""),
            "type": answers.get("business_type", "general"),
            "contact_name": answers.get("contact_name", ""),
            "contact_email": answers.get("contact_email", ""),
        },
        "timezone": tz,
        "timezone_abbr": TIMEZONE_ABBR.get(tz, ""),
        "email": answers.get("contact_email", ""),
        "n8n_base_url": "http://localhost:5678",
        "ai": {
            "inference_url": "http://localhost:11434/v1/chat/completions",
            "default_model": "qwen3:8b",
            "fast_model": "qwen3:4b",
            "timeout": 120,
            "cloud_model": "claude-sonnet-4-5-20241022",
            "cloud_url": "https://api.anthropic.com/v1/messages",
            "cloud_api_key_env": "ANTHROPIC_API_KEY",
            "cloud_timeout": 180,
            "cloud_max_tokens": 4096,
            "embedding_model": "nomic-embed-text",
            "embedding_dim": 768,
        },
        "memory": {
            "qdrant_url": "http://localhost:6333",
            "collection": "aria_memory",
            "index_days": 30,
        },
        "telegram": {
            "token_env": "ARIA_TELEGRAM_TOKEN",
            "authorized_users": [],
        },
        "channels": {
            "email_accounts": email_accounts,
            "calendar_accounts": calendar_accounts,
            "slack": {
                "enabled": bool(answers.get("slack_workspace")),
                "workspace_name": answers.get("slack_workspace", ""),
            },
            "meeting_notes": {
                "enabled": answers.get("meeting_notes", "none") != "none",
                "provider": answers.get("meeting_notes", "none"),
            },
        },
        "known_projects": projects,
        "client_tiers": {
            "active": projects[:5],
            "product": [],
            "on_hold": [],
        },
        "schedules": {
            "morning_briefing": answers.get("briefing_time", "07:30"),
            "evening_debrief": answers.get("debrief_time", "21:30"),
            "weekly_rollup": "Sunday 19:00",
        },
        "retention": {
            "inbox_days": 30,
            "briefings_days": 14,
        },
        "meeting_prep": {
            "lead_time_minutes": 30,
            "check_interval_minutes": 5,
        },
        "thresholds": {
            "outreach_active_client_days": 5,
            "outreach_key_contact_days": 10,
            "outreach_pipeline_days": 14,
        },
        "junk_filter": {
            "enabled": True,
            "ai_scoring": True,
            "threshold": 4,
            "junk_domains": [],
            "junk_subject_patterns": [],
        },
    }

    return config


def main():
    if "--web" in sys.argv:
        print("Web-based questionnaire: use the onboarding wizard at http://localhost:8642")
        return

    answers = run_cli_questionnaire()
    config = generate_config(answers)

    # Save
    output_path = CONFIG_DIR / "aria.json"
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    if output_path.exists():
        backup = CONFIG_DIR / f"aria.json.backup-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        output_path.rename(backup)
        print(f"  Existing config backed up to {backup.name}")

    with open(output_path, "w") as f:
        json.dump(config, f, indent=2)

    print(f"\n  Config generated: {output_path}")
    print(f"  Business: {answers.get('business_name')}")
    print(f"  Email accounts: {len(config['channels']['email_accounts'])}")
    print(f"  Projects: {len(config['known_projects'])}")
    print(f"  Briefing: {config['schedules']['morning_briefing']}")
    print(f"\n  Next: Run the OAuth onboarding to connect your accounts.")
    print(f"  Command: .venv/bin/python3 scripts/onboarding-server.py")


if __name__ == "__main__":
    main()
