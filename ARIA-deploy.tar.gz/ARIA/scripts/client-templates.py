#!/usr/bin/env python3
"""
ARIA Per-Client Communication Templates
Learns how you communicate with each client/project and generates
tone-matched templates for common email types.

For each active client, generates:
  - Status update template (weekly update email)
  - Follow-up template (after meeting or missed deadline)
  - Request template (asking for something)
  - Check-in template (proactive outreach)
  - Good news template (sharing wins)

Learns from:
  - Your sent emails to this client
  - Email thread patterns (how formal, how long, what structure)
  - Subject line patterns

Output: config/client-templates.json
        Used by draft generators and weekly client update emails.
"""

import json
import re
import sys
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import aria_ai

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
STYLE_FILE = PROJECT_DIR / "config" / "writing-style.json"
TEMPLATES_FILE = PROJECT_DIR / "config" / "client-templates.json"
LOG_FILE = PROJECT_DIR / "logs" / "client-templates.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def load_style():
    if STYLE_FILE.exists():
        with open(STYLE_FILE) as f:
            return json.load(f)
    return {}


def get_client_emails(project, days_back=60):
    """Get all emails related to a project."""
    emails = []
    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        date_str = date.strftime("%Y-%m-%d")
        path = INBOX_DIR / f"emails-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                for e in data:
                    if e.get("detected_project") == project:
                        emails.append(e)
            except Exception:
                pass
    return emails


def analyze_client_tone(emails, user_email):
    """Analyze the communication tone with a specific client."""
    sent = [e for e in emails if user_email.lower() in e.get("from", "").lower()]
    received = [e for e in emails if user_email.lower() not in e.get("from", "").lower()]

    # Subject patterns
    subjects = [e.get("subject", "") for e in sent]
    re_count = sum(1 for s in subjects if s.lower().startswith("re:"))

    # Key contacts at this client
    contacts = Counter()
    for e in received:
        sender = e.get("from", "")
        if "<" in sender:
            name = sender.split("<")[0].strip().strip('"')
        else:
            name = sender
        if name:
            contacts[name] += 1

    return {
        "total_emails": len(emails),
        "sent": len(sent),
        "received": len(received),
        "reply_rate": round(re_count / max(len(sent), 1) * 100),
        "top_contacts": dict(contacts.most_common(5)),
        "sample_subjects": [s for s in subjects if not s.lower().startswith("re:")][:5],
    }


def generate_templates(project, tone_analysis, global_style):
    """Generate communication templates for a client."""
    style_instructions = global_style.get("draft_instructions", "Professional but approachable.")
    top_contact = list(tone_analysis.get("top_contacts", {}).keys())[0] if tone_analysis.get("top_contacts") else "[Name]"

    templates = {
        "status_update": {
            "subject": f"{project} - Weekly Update",
            "body": f"""{top_contact},

Quick update on where things stand this week:

[KEY PROGRESS POINT 1]
[KEY PROGRESS POINT 2]

Next steps:
- [NEXT STEP 1]
- [NEXT STEP 2]

Let me know if you have questions or want to adjust priorities.

Sean""",
            "when_to_use": "Weekly proactive update to keep client informed",
        },
        "follow_up": {
            "subject": f"Re: Following up - {project}",
            "body": f"""{top_contact},

Following up on [TOPIC FROM LAST CONVERSATION].

[STATUS/QUESTION/UPDATE]

What's the best path forward from your side?

Sean""",
            "when_to_use": "After a meeting or when something needs a nudge",
        },
        "request": {
            "subject": f"{project} - Need [THING] from your end",
            "body": f"""{top_contact},

To keep things moving on [PROJECT AREA], I need [SPECIFIC REQUEST].

Context: [WHY THIS MATTERS / WHAT IT UNBLOCKS]

Can you get this to me by [DATE]?

Sean""",
            "when_to_use": "When you need something from the client",
        },
        "check_in": {
            "subject": f"Checking in - {project}",
            "body": f"""{top_contact},

Haven't connected in a bit. Wanted to check in and see how things are going on your end.

[SPECIFIC QUESTION OR OBSERVATION ABOUT THEIR BUSINESS]

Happy to jump on a quick call if that's easier.

Sean""",
            "when_to_use": "Proactive outreach when client has gone quiet",
        },
        "good_news": {
            "subject": f"{project} - Good news",
            "body": f"""{top_contact},

Wanted to share a quick win: [THE WIN].

[CONTEXT ON WHY THIS MATTERS]

[WHAT'S NEXT]

Sean""",
            "when_to_use": "When there's something positive to share",
        },
    }

    return templates


def main():
    log("Starting client template generation")
    config = load_config()
    global_style = load_style()
    user_email = config.get("email", "")

    active_clients = config.get("client_tiers", {}).get("active", [])
    product_projects = config.get("client_tiers", {}).get("product", [])
    all_projects = active_clients + product_projects

    all_templates = {}

    for project in all_projects:
        log(f"Analyzing: {project}")
        emails = get_client_emails(project)
        tone = analyze_client_tone(emails, user_email)
        templates = generate_templates(project, tone, global_style)

        all_templates[project] = {
            "tone_analysis": tone,
            "templates": templates,
            "generated": datetime.now().isoformat(),
        }

        log(f"  Emails: {tone['total_emails']} ({tone['sent']} sent, {tone['received']} received)")
        log(f"  Top contacts: {list(tone['top_contacts'].keys())[:3]}")

    TEMPLATES_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(TEMPLATES_FILE, "w") as f:
        json.dump(all_templates, f, indent=2, default=str)

    log(f"Generated templates for {len(all_templates)} clients/projects")
    log(f"Saved to {TEMPLATES_FILE}")
    log("Client templates complete")


if __name__ == "__main__":
    main()
