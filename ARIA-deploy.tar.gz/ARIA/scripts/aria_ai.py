"""
ARIA AI Client — Single source of truth for all inference calls.

Reads config from config/aria.json. Routes between local AI (oMLX/Ollama)
and cloud AI (Claude API) based on task requirements.

Routing tiers:
  - fast=True  → Local fast model (triage, classification, scoring)
  - default    → Local default model (summarization, drafting, Q&A)
  - cloud=True → Cloud API (customer-facing, complex reasoning, long context)
  - escalate=True → Try local first, retry on cloud if local fails

All ARIA scripts import from here. No other file needs to change.
"""

import json
import logging
import os
import re
import requests
from pathlib import Path

logger = logging.getLogger("aria_ai")

PROJECT_DIR = Path(__file__).parent.parent
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
ENV_FILE = PROJECT_DIR / ".env"

# Module-level config cache
_config = None


def _load_env():
    """Load environment variables from ARIA/.env if it exists."""
    if ENV_FILE.exists():
        with open(ENV_FILE) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, value = line.partition("=")
                    key = key.strip()
                    value = value.strip().strip("'\"")
                    if key and key not in os.environ:
                        os.environ[key] = value


def _load_config():
    """Load AI config from aria.json."""
    global _config
    _load_env()
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            full = json.load(f)
        _config = full.get("ai", {})
    else:
        _config = {}
    return _config


def get_config():
    """Get cached config, loading on first access."""
    if _config is None:
        _load_config()
    return _config


def reload_config():
    """Force reload config from disk. Use in long-running processes."""
    global _config
    _config = None
    return get_config()


def get_full_config():
    """Get the full aria.json config (not just ai section)."""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def get_inference_url():
    """Get the local inference endpoint URL."""
    return get_config().get("inference_url", "http://localhost:11434/v1/chat/completions")


def get_model(model=None, fast=False, cloud=False):
    """Resolve model name based on routing tier."""
    cfg = get_config()
    if model:
        return model
    if cloud:
        return cfg.get("cloud_model", "claude-sonnet-4-5-20241022")
    if fast:
        return cfg.get("fast_model", "qwen3:4b")
    return cfg.get("default_model", "qwen3:8b")


def get_timeout(timeout=None, cloud=False):
    """Resolve timeout. Cloud calls get a longer default."""
    if timeout is not None:
        return timeout
    if cloud:
        return get_config().get("cloud_timeout", 180)
    return get_config().get("timeout", 120)


def _get_cloud_api_key():
    """Get Anthropic API key from environment."""
    _load_env()
    cfg = get_config()
    key_env = cfg.get("cloud_api_key_env", "ANTHROPIC_API_KEY")
    key = os.environ.get(key_env)
    if not key:
        logger.error(f"Cloud API key not found in env var {key_env}. Check ARIA/.env")
    return key


def _strip_think_tags(text):
    """Remove <think>...</think> blocks from qwen3 model output."""
    return re.sub(r'<think>[\s\S]*?</think>', '', text).strip()


def _call_local(system_prompt, user_message, model, timeout):
    """Send a chat completion to the local inference endpoint (oMLX/Ollama)."""
    url = get_inference_url()

    try:
        resp = requests.post(url, json={
            "model": model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message},
            ]
        }, timeout=timeout)

        if resp.status_code == 200:
            data = resp.json()
            if "choices" in data:
                content = data["choices"][0]["message"]["content"]
            elif "message" in data:
                content = data["message"].get("content", "")
            else:
                logger.warning(f"Unexpected response format: {list(data.keys())}")
                return None
            return _strip_think_tags(content)
        else:
            logger.error(f"Local inference error {resp.status_code}: {resp.text[:200]}")
            return None
    except requests.exceptions.Timeout:
        logger.error(f"Local inference timeout after {timeout}s (model={model})")
        return None
    except requests.exceptions.ConnectionError:
        logger.error(f"Local inference unavailable at {url}. Is oMLX/Ollama running?")
        return None
    except Exception as e:
        logger.error(f"Local inference call failed: {e}")
        return None


def _call_cloud(system_prompt, user_message, model, timeout):
    """Send a chat completion to the configured cloud provider (Anthropic or OpenAI)."""
    api_key = _get_cloud_api_key()
    if not api_key:
        return None

    cfg = get_config()
    cloud_url = cfg.get("cloud_url", "https://api.anthropic.com/v1/messages")
    max_tokens = cfg.get("cloud_max_tokens", 4096)

    # Route to the right API format based on URL
    if "openai.com" in cloud_url:
        return _call_openai(system_prompt, user_message, model, timeout, api_key, cloud_url, max_tokens)
    else:
        return _call_anthropic(system_prompt, user_message, model, timeout, api_key, cloud_url, max_tokens)


def _call_anthropic(system_prompt, user_message, model, timeout, api_key, cloud_url, max_tokens):
    """Send a chat completion to the Anthropic Claude API."""
    try:
        resp = requests.post(cloud_url, json={
            "model": model,
            "max_tokens": max_tokens,
            "system": system_prompt,
            "messages": [
                {"role": "user", "content": user_message},
            ]
        }, headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }, timeout=timeout)

        if resp.status_code == 200:
            data = resp.json()
            if "content" in data and len(data["content"]) > 0:
                return data["content"][0].get("text", "")
            else:
                logger.warning(f"Unexpected Anthropic response format: {list(data.keys())}")
                return None
        else:
            logger.error(f"Anthropic API error {resp.status_code}: {resp.text[:300]}")
            return None
    except requests.exceptions.Timeout:
        logger.error(f"Anthropic API timeout after {timeout}s (model={model})")
        return None
    except Exception as e:
        logger.error(f"Anthropic API call failed: {e}")
        return None


def _call_openai(system_prompt, user_message, model, timeout, api_key, cloud_url, max_tokens):
    """Send a chat completion to the OpenAI API."""
    try:
        resp = requests.post(cloud_url, json={
            "model": model,
            "max_tokens": max_tokens,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message},
            ]
        }, headers={
            "Authorization": f"Bearer {api_key}",
            "content-type": "application/json",
        }, timeout=timeout)

        if resp.status_code == 200:
            data = resp.json()
            if "choices" in data and len(data["choices"]) > 0:
                return data["choices"][0]["message"]["content"]
            else:
                logger.warning(f"Unexpected OpenAI response format: {list(data.keys())}")
                return None
        else:
            logger.error(f"OpenAI API error {resp.status_code}: {resp.text[:300]}")
            return None
    except requests.exceptions.Timeout:
        logger.error(f"OpenAI API timeout after {timeout}s (model={model})")
        return None
    except Exception as e:
        logger.error(f"OpenAI API call failed: {e}")
        return None


def chat(system_prompt, user_message, model=None, fast=False, cloud=False,
         escalate=False, timeout=None):
    """
    Send a chat completion request, routed to the appropriate backend.

    Routing:
        cloud=True    → Send directly to Claude API (Anthropic)
        escalate=True → Try local first, fall back to cloud on failure
        fast=True     → Use fast local model (classification, scoring)
        default       → Use default local model (summarization, drafting)

    Args:
        system_prompt: System message setting context/instructions
        user_message: User message with the actual query/data
        model: Override model name (default: from config based on tier)
        fast: Use the fast/lightweight local model
        cloud: Send directly to cloud API
        escalate: Try local first, retry on cloud if local fails
        timeout: Override timeout in seconds

    Returns:
        Response content string, or None on failure.
    """
    resolved_model = get_model(model, fast=fast, cloud=cloud)
    resolved_timeout = get_timeout(timeout, cloud=cloud)

    # Direct cloud call
    if cloud and not model:
        logger.info(f"Routing to cloud: {resolved_model}")
        return _call_cloud(system_prompt, user_message, resolved_model, resolved_timeout)

    # Try local first
    result = _call_local(system_prompt, user_message, resolved_model, resolved_timeout)

    # Escalate to cloud if local failed and escalation is enabled
    if result is None and escalate:
        cloud_model = get_model(cloud=True)
        cloud_timeout = get_timeout(cloud=True)
        logger.info(f"Local failed, escalating to cloud: {cloud_model}")
        return _call_cloud(system_prompt, user_message, cloud_model, cloud_timeout)

    return result


def chat_json(system_prompt, user_message, model=None, fast=False, cloud=False,
              escalate=False, timeout=None):
    """
    Like chat() but attempts to parse the response as JSON.

    Supports all the same routing parameters as chat().
    Strips markdown code fences and finds JSON array or object.
    Returns parsed JSON (dict or list), or None on failure.
    """
    content = chat(system_prompt, user_message, model=model, fast=fast,
                   cloud=cloud, escalate=escalate, timeout=timeout)
    if content is None:
        return None

    # Strip markdown code fences
    content = re.sub(r'^```(?:json)?\s*\n?', '', content, flags=re.MULTILINE)
    content = re.sub(r'\n?```\s*$', '', content, flags=re.MULTILINE)
    content = content.strip()

    # Find JSON array or object
    for start_char, end_char in [('[', ']'), ('{', '}')]:
        start = content.find(start_char)
        if start == -1:
            continue
        end = content.rfind(end_char)
        if end == -1 or end <= start:
            continue
        try:
            return json.loads(content[start:end + 1])
        except json.JSONDecodeError:
            continue

    # Last resort: try parsing the whole thing
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        logger.warning(f"Could not parse JSON from response: {content[:200]}")
        return None


def get_telegram_token():
    """Get Telegram bot token from environment variable specified in config."""
    _load_env()
    cfg = get_full_config()
    token_env = cfg.get("telegram", {}).get("token_env", "ARIA_TELEGRAM_TOKEN")
    token = os.environ.get(token_env)
    if not token:
        logger.error(f"Telegram token not found in env var {token_env}. Check ARIA/.env")
    return token


def get_telegram_authorized_users():
    """Get list of authorized Telegram user IDs from config."""
    cfg = get_full_config()
    return cfg.get("telegram", {}).get("authorized_users", [])
