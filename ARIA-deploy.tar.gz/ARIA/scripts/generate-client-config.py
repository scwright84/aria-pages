#!/usr/bin/env python3
"""
ARIA Client Config Generator
Interactive script to create a new client configuration from the schema.
Generates config/aria.json and .env for a specific client deployment.

Usage: python3 generate-client-config.py [--output-dir /path/to/output]
"""

import json
import sys
from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent
SCHEMA_FILE = PROJECT_DIR / "config" / "client-schema.json"

# Sean's monitoring Telegram ID (hardcoded - this is always Sean)
SEAN_TELEGRAM_ID = 7958794313


def ask(prompt, default=None, required=True):
    """Ask for input with optional default."""
    if default:
        display = f"{prompt} [{default}]: "
    else:
        display = f"{prompt}: "

    value = input(display).strip()
    if not value and default:
        return default
    if not value and required:
        print("  This field is required.")
        return ask(prompt, default, required)
    return value


def ask_choice(prompt, choices):
    """Ask for a choice from a list."""
    print(f"\n{prompt}")
    for i, choice in enumerate(choices, 1):
        print(f"  {i}. {choice}")
    while True:
        val = input(f"Choose [1-{len(choices)}]: ").strip()
        try:
            idx = int(val) - 1
            if 0 <= idx < len(choices):
                return choices[idx]
        except ValueError:
            pass
        print(f"  Please enter a number between 1 and {len(choices)}")


def ask_yn(prompt, default=True):
    """Ask yes/no question."""
    suffix = "[Y/n]" if default else "[y/N]"
    val = input(f"{prompt} {suffix}: ").strip().lower()
    if not val:
        return default
    return val in ("y", "yes")


def ask_list(prompt):
    """Ask for a comma-separated list."""
    val = input(f"{prompt} (comma-separated): ").strip()
    if not val:
        return []
    return [item.strip() for item in val.split(",") if item.strip()]


def generate():
    print()
    print("╔══════════════════════════════════════╗")
    print("║   ARIA Client Configuration Setup    ║")
    print("╚══════════════════════════════════════╝")
    print()

    # --- Client Identity ---
    print("━━━ Client Information ━━━")
    client_name = ask("Business name")
    client_type = ask_choice("Business type:", ["dental", "legal", "accounting", "consulting", "general"])
    contact_name = ask("Primary contact name")
    contact_email = ask("Primary contact email")

    # --- Location ---
    print("\n━━━ Location & Timezone ━━━")
    tz = ask("Timezone (IANA format)", "America/Chicago")
    tz_abbr = ask("Timezone abbreviation", "CT")

    # --- Schedules ---
    print("\n━━━ Briefing Schedule ━━━")
    briefing_time = ask("Morning briefing time (HH:MM)", "07:30")
    debrief_time = ask("Evening debrief time (HH:MM)", "21:30")
    weekly_day_time = ask("Weekly rollup (Day HH:MM)", "Sunday 19:00")

    # --- Channels ---
    print("\n━━━ Communication Channels ━━━")
    email_accounts = []
    print("\nEmail accounts to monitor:")
    while True:
        addr = input("  Email address (blank to stop): ").strip()
        if not addr:
            break
        provider = ask_choice("  Provider:", ["gmail", "outlook", "imap"])
        email_accounts.append({"address": addr, "provider": provider, "credential_id": ""})

    calendar_accounts = []
    if ask_yn("\nConnect Google Calendar?"):
        cal_name = ask("  Calendar name", "Primary")
        calendar_accounts.append({"name": cal_name, "provider": "google", "credential_id": ""})

    use_slack = ask_yn("\nConnect Slack?", default=False)
    slack_config = {"enabled": False}
    if use_slack:
        ws = ask("  Slack workspace name")
        slack_config = {"enabled": True, "workspace_name": ws, "credential_id": ""}

    use_meetings = ask_yn("\nConnect meeting notes (Granola)?", default=False)
    meeting_config = {"enabled": False, "provider": "none"}
    if use_meetings:
        meeting_config = {"enabled": True, "provider": "granola", "api_token_env": "ARIA_GRANOLA_TOKEN"}

    # --- Projects ---
    print("\n━━━ Projects / Clients to Track ━━━")
    projects = ask_list("Project or department names")

    # --- Telegram ---
    print("\n━━━ Telegram Bot ━━━")
    print("You'll need to create a bot via @BotFather on Telegram.")
    bot_username = ask("Bot username (e.g., @LakewayDentalBot)", required=False)
    print("To find your Telegram user ID, message @userinfobot on Telegram.")
    user_ids_raw = ask_list("Authorized Telegram user IDs")
    authorized_users = []
    for uid in user_ids_raw:
        try:
            authorized_users.append(int(uid))
        except ValueError:
            print(f"  Skipping invalid ID: {uid}")

    # --- Build Config ---
    config = {
        "client": {
            "name": client_name,
            "type": client_type,
            "contact_name": contact_name,
            "contact_email": contact_email,
        },
        "timezone": tz,
        "timezone_abbr": tz_abbr,
        "email": contact_email,
        "n8n_base_url": "http://localhost:5678",
        "ai": {
            "inference_url": "http://localhost:11434/v1/chat/completions",
            "default_model": "qwen3:8b",
            "fast_model": "qwen3:4b",
            "timeout": 120,
        },
        "telegram": {
            "token_env": "ARIA_TELEGRAM_TOKEN",
            "bot_username": bot_username or "",
            "authorized_users": authorized_users,
        },
        "channels": {
            "email_accounts": email_accounts,
            "calendar_accounts": calendar_accounts,
            "slack": slack_config,
            "meeting_notes": meeting_config,
        },
        "projects": projects,
        "schedules": {
            "morning_briefing": briefing_time,
            "evening_debrief": debrief_time,
            "weekly_rollup": weekly_day_time,
        },
        "retention": {
            "inbox_days": 30,
            "briefings_days": 14,
        },
        "monitoring": {
            "alert_telegram_user": SEAN_TELEGRAM_ID,
            "alert_telegram_token_env": "ARIA_MONITOR_TELEGRAM_TOKEN",
        },
    }

    # --- Build .env ---
    env_lines = [
        "# ARIA Environment Variables",
        f"# Client: {client_name}",
        f"# Generated: {__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M')}",
        "",
        "# Telegram Bot Token (from @BotFather)",
        "ARIA_TELEGRAM_TOKEN=CHANGE_ME",
        "",
        "# Monitoring Bot Token (Sean's alert channel)",
        "ARIA_MONITOR_TELEGRAM_TOKEN=CHANGE_ME",
        "",
        "# SMTP Fallback (for briefing delivery if n8n is down)",
        "# ARIA_SMTP_HOST=smtp.gmail.com",
        "# ARIA_SMTP_PORT=587",
        "# ARIA_SMTP_USER=CHANGE_ME",
        "# ARIA_SMTP_PASS=CHANGE_ME",
    ]

    if meeting_config.get("enabled"):
        env_lines.extend(["", "# Granola API Token", "ARIA_GRANOLA_TOKEN=CHANGE_ME"])

    # --- Output ---
    output_dir = PROJECT_DIR
    if len(sys.argv) > 2 and sys.argv[1] == "--output-dir":
        output_dir = Path(sys.argv[2])
        output_dir.mkdir(parents=True, exist_ok=True)

    config_path = output_dir / "config" / "aria.json"
    env_path = output_dir / ".env"

    config_path.parent.mkdir(parents=True, exist_ok=True)
    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)

    with open(env_path, "w") as f:
        f.write("\n".join(env_lines) + "\n")

    print()
    print("╔══════════════════════════════════════╗")
    print("║      Configuration Generated!        ║")
    print("╚══════════════════════════════════════╝")
    print()
    print(f"  Config: {config_path}")
    print(f"  Secrets: {env_path}")
    print()
    print("  Next steps:")
    print(f"  1. Edit {env_path} with real tokens")
    print("  2. Set up OAuth credentials in n8n for email/calendar")
    print("  3. Run health check: python3 scripts/health-check.py")
    print()

    return config


if __name__ == "__main__":
    generate()
