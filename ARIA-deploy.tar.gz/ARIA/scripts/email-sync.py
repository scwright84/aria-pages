#!/usr/bin/env python3
"""
ARIA Email Sync (Direct)
Fetches email from connected Gmail accounts using stored OAuth credentials.
No dependency on n8n for email ingestion.

Reads credentials from config/credentials.json (created by onboarding server).
Saves triaged data to inbox/emails-YYYY-MM-DD.json.

Runs via launchd or manually.
"""

import json
import os
import sys
import base64
import re
from datetime import datetime, timedelta
from pathlib import Path
from email.utils import parsedate_to_datetime

from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build

import aria_ai

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
CREDENTIALS_FILE = PROJECT_DIR / "config" / "credentials.json"
LOG_FILE = PROJECT_DIR / "logs" / "email-sync.log"
STATE_FILE = PROJECT_DIR / "logs" / "email-sync-state.json"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_credentials():
    if CREDENTIALS_FILE.exists():
        with open(CREDENTIALS_FILE) as f:
            return json.load(f)
    return {"accounts": []}


def save_credentials(creds_data):
    with open(CREDENTIALS_FILE, "w") as f:
        json.dump(creds_data, f, indent=2)


def load_state():
    if STATE_FILE.exists():
        try:
            with open(STATE_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"last_sync": {}, "seen_ids": {}}


def save_state(state):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def get_gmail_credentials(account):
    """Build Google credentials object from stored account data."""
    creds = Credentials(
        token=account.get("access_token"),
        refresh_token=account.get("refresh_token"),
        token_uri=account.get("token_uri", "https://oauth2.googleapis.com/token"),
        client_id=account.get("client_id"),
        client_secret=account.get("client_secret"),
        scopes=account.get("scopes", []),
    )
    # Refresh if expired
    if creds.expired and creds.refresh_token:
        try:
            creds.refresh(Request())
            # Update stored token
            account["access_token"] = creds.token
            return creds, True  # True = credentials were refreshed
        except Exception as e:
            log(f"  Token refresh failed for {account.get('email')}: {e}")
            return None, False
    return creds, False


def fetch_emails(account, days_back=30, max_results=200):
    """Fetch recent emails from a Gmail account."""
    creds, refreshed = get_gmail_credentials(account)
    if creds is None:
        return [], refreshed

    try:
        service = build("gmail", "v1", credentials=creds)
        after_date = (datetime.now() - timedelta(days=days_back)).strftime("%Y/%m/%d")
        query = f"after:{after_date} in:anywhere"

        results = service.users().messages().list(
            userId="me", q=query, maxResults=max_results
        ).execute()

        messages = results.get("messages", [])
        emails = []

        for msg_ref in messages:
            try:
                msg = service.users().messages().get(
                    userId="me", id=msg_ref["id"], format="metadata",
                    metadataHeaders=["From", "To", "Subject", "Date"]
                ).execute()

                headers = {h["name"]: h["value"] for h in msg.get("payload", {}).get("headers", [])}
                snippet = msg.get("snippet", "")

                emails.append({
                    "id": msg_ref["id"],
                    "account": account.get("email"),
                    "from": headers.get("From", ""),
                    "to": headers.get("To", ""),
                    "subject": headers.get("Subject", "(no subject)"),
                    "date": headers.get("Date", ""),
                    "snippet": snippet,
                    "labels": msg.get("labelIds", []),
                })
            except Exception as e:
                log(f"  Error fetching message {msg_ref['id']}: {e}")

        return emails, refreshed
    except Exception as e:
        log(f"  Gmail API error for {account.get('email')}: {e}")
        return [], refreshed


def triage_emails(emails):
    """Use AI to triage emails (priority, action needed, project detection)."""
    if not emails:
        return emails

    # Build context for AI
    email_summaries = []
    for i, email in enumerate(emails):
        email_summaries.append(
            f"[{i+1}] From: {email['from']}\n"
            f"    Subject: {email['subject']}\n"
            f"    Snippet: {email['snippet'][:150]}"
        )

    full_config = aria_ai.get_full_config()
    projects = full_config.get("projects", full_config.get("known_projects", []))
    projects_str = ", ".join(projects) if projects else "unknown"

    # Load learned preferences
    prefs_context = ""
    prefs_file = PROJECT_DIR / "config" / "email-preferences.json"
    if prefs_file.exists():
        try:
            with open(prefs_file) as f:
                prefs = json.load(f)
            parts = []
            if prefs.get("important_senders"):
                parts.append(f"ALWAYS mark as high priority: {', '.join(prefs['important_senders'][:15])}")
            if prefs.get("junk_senders"):
                parts.append(f"ALWAYS mark as ignore/junk: {', '.join(prefs['junk_senders'][:15])}")
            if prefs.get("junk_domains"):
                parts.append(f"Junk domains (mark as ignore): {', '.join(prefs['junk_domains'][:15])}")
            prefs_context = "\n".join(parts)
        except Exception:
            pass

    system_prompt = f"""You are ARIA, an email triage assistant. Classify each email.

Known projects: {projects_str}.
{('User preferences (OVERRIDE defaults):' + chr(10) + prefs_context) if prefs_context else ''}

For action_type, also include "draft_reply" if the email clearly needs a response.

Respond with ONLY a valid JSON array. No markdown.
Format: [{{"item": 1, "priority": "high/medium/low", "action_needed": true/false, "action_type": "reply/draft_reply/review/fyi/ignore", "project": "project name or null", "summary": "one sentence", "suggested_reply": "brief reply text or null"}}]"""

    results = aria_ai.chat_json(
        system_prompt,
        f"Triage these {len(emails)} emails:\n" + "\n".join(email_summaries),
        fast=True,
    )

    if results and isinstance(results, list):
        for entry in results:
            idx = entry.get("item", 0) - 1
            if 0 <= idx < len(emails):
                emails[idx]["triage"] = {
                    "priority": entry.get("priority", "medium"),
                    "action_needed": entry.get("action_needed", False),
                    "action_type": entry.get("action_type", "fyi"),
                    "project": entry.get("project"),
                    "summary": entry.get("summary", ""),
                }
    else:
        # Fallback: assign defaults
        for email in emails:
            email["triage"] = {
                "priority": "medium",
                "action_needed": False,
                "action_type": "fyi",
                "project": None,
                "summary": email.get("subject", ""),
            }

    return emails


def main():
    log("Starting email sync (direct)...")
    INBOX_DIR.mkdir(parents=True, exist_ok=True)

    creds_data = load_credentials()
    state = load_state()
    all_emails = []
    creds_updated = False

    # Find all Gmail accounts
    gmail_accounts = [a for a in creds_data.get("accounts", []) if "gmail" in a.get("services", [])]

    if not gmail_accounts:
        log("No Gmail accounts connected. Run the onboarding server to connect accounts.")
        return

    for account in gmail_accounts:
        email_addr = account.get("email", "unknown")
        log(f"Fetching from {email_addr}...")

        # Check for seen IDs to avoid reprocessing
        seen = set(state.get("seen_ids", {}).get(email_addr, []))
        emails, refreshed = fetch_emails(account, days_back=30)
        if refreshed:
            creds_updated = True

        # Filter out already-seen emails
        new_emails = [e for e in emails if e["id"] not in seen]
        log(f"  {len(emails)} total, {len(new_emails)} new")

        # Update seen IDs (keep last 500)
        new_seen = list(seen | {e["id"] for e in emails})[-500:]
        if email_addr not in state.get("seen_ids", {}):
            state.setdefault("seen_ids", {})[email_addr] = []
        state["seen_ids"][email_addr] = new_seen

        all_emails.extend(new_emails)

    if all_emails:
        log(f"Triaging {len(all_emails)} emails...")
        all_emails = triage_emails(all_emails)

    # Save to inbox
    date_str = datetime.now().strftime("%Y-%m-%d")
    output_path = INBOX_DIR / f"emails-{date_str}.json"

    # Merge with existing file for today
    existing = []
    if output_path.exists():
        try:
            with open(output_path) as f:
                existing = json.load(f)
        except Exception:
            pass

    # Merge by ID (avoid duplicates)
    existing_ids = {e.get("id") for e in existing}
    for email in all_emails:
        if email["id"] not in existing_ids:
            existing.append(email)

    with open(output_path, "w") as f:
        json.dump(existing, f, indent=2)
    log(f"Saved {len(existing)} emails to {output_path.name}")

    # Save state
    state["last_sync"] = {
        "timestamp": datetime.now().isoformat(),
        "accounts": len(gmail_accounts),
        "new_emails": len(all_emails),
    }
    save_state(state)

    # Save updated credentials if tokens were refreshed
    if creds_updated:
        save_credentials(creds_data)
        log("Credentials refreshed and saved")

    log("Email sync complete")


if __name__ == "__main__":
    main()
