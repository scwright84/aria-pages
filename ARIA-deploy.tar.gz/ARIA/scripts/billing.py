#!/usr/bin/env python3
"""
ARIA Billing Module (Stripe Integration)
Handles setup fees and monthly subscriptions for client deployments.

Products:
  - ARIA Setup Fee (one-time): Phase 1 = $5,000, Phase 2 = $2,500
  - ARIA Monthly Retainer (subscription): $750/mo (all phases)
  - Hardware Markup (one-time, Phase 3 only): $500-700

Features:
  - Create Stripe Checkout sessions for new clients
  - Manage subscriptions (create, update, cancel)
  - Track payment status per client
  - Generate billing reports
  - Webhook handler for payment events

Requires:
  - STRIPE_SECRET_KEY in .env
  - STRIPE_WEBHOOK_SECRET in .env (for webhook verification)
  - stripe Python package (pip install stripe)

Runs as part of the admin dashboard or standalone on port 8647.
"""

import json
import os
import sys
from datetime import datetime
from pathlib import Path

from flask import Flask, Response, request, abort, redirect

PROJECT_DIR = Path(__file__).parent.parent
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
BILLING_DIR = PROJECT_DIR / "config" / "billing"
ENV_FILE = PROJECT_DIR / ".env"

app = Flask(__name__)

# Pricing (cents for Stripe)
PRICING = {
    "setup_phase1": {
        "name": "ARIA Setup (Concierge)",
        "amount": 500000,  # $5,000
        "type": "one_time",
    },
    "setup_phase2": {
        "name": "ARIA Setup (Low-Touch)",
        "amount": 250000,  # $2,500
        "type": "one_time",
    },
    "monthly_retainer": {
        "name": "ARIA Monthly Retainer",
        "amount": 75000,  # $750/mo
        "type": "recurring",
        "interval": "month",
    },
    "hardware_markup": {
        "name": "Pre-Configured Hardware",
        "amount": 60000,  # $600
        "type": "one_time",
    },
}


def load_env():
    if ENV_FILE.exists():
        with open(ENV_FILE) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, value = line.partition("=")
                    key = key.strip()
                    value = value.strip().strip("'\"")
                    if key and key not in os.environ:
                        os.environ[key] = value


def get_stripe():
    """Import and configure Stripe. Returns None if not configured."""
    load_env()
    key = os.environ.get("STRIPE_SECRET_KEY")
    if not key:
        return None
    try:
        import stripe
        stripe.api_key = key
        return stripe
    except ImportError:
        print("stripe package not installed. Run: pip install stripe")
        return None


def load_billing_data():
    """Load billing records for all clients."""
    BILLING_DIR.mkdir(parents=True, exist_ok=True)
    data_file = BILLING_DIR / "billing.json"
    if data_file.exists():
        with open(data_file) as f:
            return json.load(f)
    return {"clients": {}}


def save_billing_data(data):
    BILLING_DIR.mkdir(parents=True, exist_ok=True)
    with open(BILLING_DIR / "billing.json", "w") as f:
        json.dump(data, f, indent=2)


def create_checkout_session(client_id, client_name, client_email, product_key,
                           success_url="http://localhost:8646?payment=success",
                           cancel_url="http://localhost:8646?payment=cancelled"):
    """Create a Stripe Checkout session for a client."""
    stripe = get_stripe()
    if not stripe:
        return {"error": "Stripe not configured. Set STRIPE_SECRET_KEY in .env"}

    product = PRICING.get(product_key)
    if not product:
        return {"error": f"Unknown product: {product_key}"}

    try:
        if product["type"] == "one_time":
            session = stripe.checkout.Session.create(
                payment_method_types=["card"],
                line_items=[{
                    "price_data": {
                        "currency": "usd",
                        "product_data": {"name": product["name"]},
                        "unit_amount": product["amount"],
                    },
                    "quantity": 1,
                }],
                mode="payment",
                success_url=success_url,
                cancel_url=cancel_url,
                client_reference_id=client_id,
                customer_email=client_email,
                metadata={"client_name": client_name, "product": product_key},
            )
        else:  # recurring
            session = stripe.checkout.Session.create(
                payment_method_types=["card"],
                line_items=[{
                    "price_data": {
                        "currency": "usd",
                        "product_data": {"name": product["name"]},
                        "unit_amount": product["amount"],
                        "recurring": {"interval": product["interval"]},
                    },
                    "quantity": 1,
                }],
                mode="subscription",
                success_url=success_url,
                cancel_url=cancel_url,
                client_reference_id=client_id,
                customer_email=client_email,
                metadata={"client_name": client_name, "product": product_key},
            )

        # Record the session
        billing = load_billing_data()
        if client_id not in billing["clients"]:
            billing["clients"][client_id] = {
                "name": client_name,
                "email": client_email,
                "sessions": [],
                "payments": [],
                "subscription_id": None,
            }
        billing["clients"][client_id]["sessions"].append({
            "session_id": session.id,
            "product": product_key,
            "amount": product["amount"],
            "created": datetime.now().isoformat(),
            "status": "pending",
        })
        save_billing_data(billing)

        return {"url": session.url, "session_id": session.id}

    except Exception as e:
        return {"error": str(e)}


def cancel_subscription(client_id):
    """Cancel a client's subscription."""
    stripe = get_stripe()
    if not stripe:
        return {"error": "Stripe not configured"}

    billing = load_billing_data()
    client = billing.get("clients", {}).get(client_id)
    if not client:
        return {"error": f"Client {client_id} not found"}

    sub_id = client.get("subscription_id")
    if not sub_id:
        return {"error": "No active subscription"}

    try:
        stripe.Subscription.modify(sub_id, cancel_at_period_end=True)
        client["subscription_status"] = "canceling"
        save_billing_data(billing)
        return {"status": "canceling", "message": "Subscription will cancel at end of billing period"}
    except Exception as e:
        return {"error": str(e)}


def get_billing_summary():
    """Get billing summary across all clients."""
    billing = load_billing_data()
    summary = {
        "total_clients": len(billing.get("clients", {})),
        "total_mrr": 0,
        "total_collected": 0,
        "active_subscriptions": 0,
        "clients": [],
    }

    for client_id, client in billing.get("clients", {}).items():
        paid = sum(p.get("amount", 0) for p in client.get("payments", []) if p.get("status") == "succeeded")
        has_sub = client.get("subscription_id") is not None
        summary["clients"].append({
            "id": client_id,
            "name": client.get("name"),
            "total_paid": paid / 100,  # Convert cents to dollars
            "has_subscription": has_sub,
        })
        summary["total_collected"] += paid
        if has_sub and client.get("subscription_status") != "canceled":
            summary["active_subscriptions"] += 1
            summary["total_mrr"] += 75000  # $750/mo in cents

    summary["total_collected"] /= 100
    summary["total_mrr"] /= 100

    return summary


# --- Webhook Handler ---

@app.route("/webhook", methods=["POST"])
def stripe_webhook():
    """Handle Stripe webhook events."""
    stripe = get_stripe()
    if not stripe:
        abort(500)

    payload = request.get_data()
    sig_header = request.headers.get("Stripe-Signature")
    webhook_secret = os.environ.get("STRIPE_WEBHOOK_SECRET")

    try:
        if webhook_secret:
            event = stripe.Webhook.construct_event(payload, sig_header, webhook_secret)
        else:
            event = json.loads(payload)
    except Exception as e:
        abort(400)

    event_type = event.get("type", "")
    data = event.get("data", {}).get("object", {})

    billing = load_billing_data()

    if event_type == "checkout.session.completed":
        client_id = data.get("client_reference_id")
        if client_id and client_id in billing.get("clients", {}):
            client = billing["clients"][client_id]
            client["payments"].append({
                "amount": data.get("amount_total", 0),
                "status": "succeeded",
                "date": datetime.now().isoformat(),
                "stripe_session": data.get("id"),
            })
            if data.get("subscription"):
                client["subscription_id"] = data["subscription"]
                client["subscription_status"] = "active"
            save_billing_data(billing)

    elif event_type == "customer.subscription.deleted":
        sub_id = data.get("id")
        for client_id, client in billing.get("clients", {}).items():
            if client.get("subscription_id") == sub_id:
                client["subscription_status"] = "canceled"
                save_billing_data(billing)
                break

    return "", 200


# --- API Routes ---

@app.route("/")
def index():
    summary = get_billing_summary()
    return json.dumps(summary, indent=2, default=str), 200, {"Content-Type": "application/json"}


@app.route("/create-session", methods=["POST"])
def create_session():
    data = request.json or {}
    result = create_checkout_session(
        client_id=data.get("client_id"),
        client_name=data.get("client_name"),
        client_email=data.get("client_email"),
        product_key=data.get("product", "monthly_retainer"),
    )
    return json.dumps(result), 200, {"Content-Type": "application/json"}


@app.route("/cancel/<client_id>", methods=["POST"])
def cancel(client_id):
    result = cancel_subscription(client_id)
    return json.dumps(result), 200, {"Content-Type": "application/json"}


@app.route("/pricing")
def pricing():
    display = {}
    for key, p in PRICING.items():
        display[key] = {
            "name": p["name"],
            "price": f"${p['amount']/100:,.0f}" + ("/mo" if p["type"] == "recurring" else ""),
            "type": p["type"],
        }
    return json.dumps(display, indent=2), 200, {"Content-Type": "application/json"}


@app.route("/healthz")
def healthz():
    return "ok", 200


def main():
    stripe = get_stripe()
    if stripe:
        print("ARIA Billing running at http://localhost:8647")
        print("Stripe configured and ready.")
    else:
        print("ARIA Billing running at http://localhost:8647")
        print("WARNING: Stripe not configured. Set STRIPE_SECRET_KEY in .env")
        print("Billing API will return errors until Stripe is configured.")
    app.run(host="127.0.0.1", port=8647, debug=False)


if __name__ == "__main__":
    main()
