#!/usr/bin/env python3
"""
ARIA Meeting Debrief Auto-Capture
After each meeting ends, generates a structured debrief combining:
  - Calendar event details (who, what, when)
  - Granola meeting notes (if available)
  - Recent email threads with attendees
  - Pre-meeting context from meeting-prep
  - Extracted action items and commitments

Output: briefings/YYYY-MM-DD-meeting-<slug>.json per meeting
Runs every 15 minutes, checks for recently ended meetings.
"""

import json
import re
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import aria_ai

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
CONTACTS_FILE = PROJECT_DIR / "config" / "contacts.json"
STATE_FILE = PROJECT_DIR / "logs" / "meeting-debrief-state.json"
LOG_FILE = PROJECT_DIR / "logs" / "meeting-debrief.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_state():
    if STATE_FILE.exists():
        try:
            with open(STATE_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"debriefed_events": []}


def save_state(state):
    state["debriefed_events"] = state.get("debriefed_events", [])[-100:]
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def load_contacts():
    if CONTACTS_FILE.exists():
        with open(CONTACTS_FILE) as f:
            return json.load(f)
    return {}


def get_recently_ended_meetings(lookback_minutes=30):
    """Find meetings that ended in the last N minutes."""
    now = datetime.now()
    cutoff = now - timedelta(minutes=lookback_minutes)
    meetings = []

    date_str = now.strftime("%Y-%m-%d")
    for prefix in ["calendar", "calendly"]:
        path = INBOX_DIR / f"{prefix}-{date_str}.json"
        if not path.exists():
            continue
        try:
            with open(path) as f:
                data = json.load(f)
            for item in (data if isinstance(data, list) else [data]):
                end_str = item.get("end") or item.get("end_time") or ""
                try:
                    end = datetime.fromisoformat(end_str.replace("Z", "+00:00")).replace(tzinfo=None)
                except (ValueError, TypeError):
                    continue
                # Meeting ended between cutoff and now
                if cutoff <= end <= now:
                    start_str = item.get("start") or item.get("start_time") or ""
                    try:
                        start = datetime.fromisoformat(start_str.replace("Z", "+00:00")).replace(tzinfo=None)
                    except (ValueError, TypeError):
                        start = end - timedelta(hours=1)

                    attendees = item.get("attendees") or item.get("invitee_names") or []
                    if isinstance(attendees, list) and attendees and isinstance(attendees[0], dict):
                        attendees = [a.get("name") or a.get("email", "?") for a in attendees]

                    meetings.append({
                        "summary": item.get("summary") or item.get("name", "Untitled Meeting"),
                        "start": start,
                        "end": end,
                        "duration_min": (end - start).total_seconds() / 60,
                        "attendees": attendees,
                        "location": item.get("location") or item.get("join_url", ""),
                        "description": item.get("description", ""),
                        "id": item.get("id") or item.get("uri", ""),
                    })
        except Exception:
            pass

    return meetings


def find_related_notes(meeting_summary, meeting_date):
    """Search Granola notes for matching meeting."""
    notes = []
    date_str = meeting_date.strftime("%Y-%m-%d")
    path = INBOX_DIR / f"notes-{date_str}.json"
    if path.exists():
        try:
            with open(path) as f:
                data = json.load(f)
            for note in (data if isinstance(data, list) else [data]):
                note_title = (note.get("title") or note.get("meeting", "")).lower()
                if any(word in note_title for word in meeting_summary.lower().split() if len(word) > 3):
                    notes.append(note)
        except Exception:
            pass

    # Also check awaiting/commitments
    path = INBOX_DIR / f"awaiting-{date_str}.json"
    if path.exists():
        try:
            with open(path) as f:
                data = json.load(f)
            for item in (data if isinstance(data, list) else [data]):
                meeting_name = (item.get("meeting") or "").lower()
                if any(word in meeting_name for word in meeting_summary.lower().split() if len(word) > 3):
                    notes.append({"type": "commitment", **item})
        except Exception:
            pass

    return notes


def find_related_emails(attendees, days_back=3):
    """Find recent emails from/to meeting attendees."""
    related = []
    attendee_names = [a.lower() for a in attendees if isinstance(a, str)]

    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        date_str = date.strftime("%Y-%m-%d")
        path = INBOX_DIR / f"emails-{date_str}.json"
        if not path.exists():
            continue
        try:
            with open(path) as f:
                emails = json.load(f)
            for e in emails:
                sender = (e.get("from") or "").lower()
                if any(name in sender for name in attendee_names if len(name) > 2):
                    related.append({
                        "subject": e.get("subject", ""),
                        "from": e.get("from", ""),
                        "summary": e.get("summary", "")[:200],
                        "date": e.get("date"),
                    })
        except Exception:
            pass

    return related[:10]


def get_attendee_context(attendees, contacts):
    """Pull context about each attendee from contact profiles."""
    context = []
    for attendee in attendees:
        name = attendee if isinstance(attendee, str) else str(attendee)
        for key, contact in contacts.items():
            contact_name = (contact.get("name") or "").lower()
            if contact_name and contact_name in name.lower():
                context.append({
                    "name": contact.get("name"),
                    "projects": contact.get("projects", []),
                    "relationship_score": contact.get("relationship_score"),
                    "email_count": contact.get("email_count", 0),
                })
                break
    return context


def generate_debrief(meeting, notes, emails, attendee_context):
    """Generate a structured meeting debrief."""
    # Extract commitments from notes
    commitments = [n for n in notes if n.get("type") == "commitment"]
    meeting_notes = [n for n in notes if n.get("type") != "commitment"]

    slug = re.sub(r'[^a-z0-9]+', '-', meeting["summary"].lower())[:40]

    debrief = {
        "meeting": meeting["summary"],
        "date": meeting["start"].strftime("%Y-%m-%d"),
        "time": f"{meeting['start'].strftime('%I:%M %p')} - {meeting['end'].strftime('%I:%M %p')}",
        "duration_min": round(meeting["duration_min"]),
        "attendees": meeting["attendees"],
        "attendee_context": attendee_context,
        "location": meeting["location"],
        "notes_found": len(meeting_notes),
        "commitments_found": len(commitments),
        "related_emails": len(emails),
        "commitments": [
            {"task": c.get("task", ""), "owner": c.get("owner", ""), "deadline": c.get("deadline", "")}
            for c in commitments
        ],
        "recent_email_threads": [
            {"subject": e["subject"], "from": e["from"]}
            for e in emails[:5]
        ],
        "slug": slug,
        "generated": datetime.now().isoformat(),
    }

    # Use AI to generate a summary if we have notes
    if meeting_notes or commitments or emails:
        context_parts = []
        if meeting_notes:
            context_parts.append(f"Meeting notes: {json.dumps(meeting_notes[:3], default=str)[:500]}")
        if commitments:
            context_parts.append(f"Commitments: {json.dumps([c.get('task','') for c in commitments])[:300]}")
        if emails:
            context_parts.append(f"Recent email threads: {json.dumps([e['subject'] for e in emails[:5]])[:300]}")

        context_str = "\n".join(context_parts)

        summary = aria_ai.chat(
            "You are a meeting assistant. Generate a 2-3 sentence summary of this meeting based on the available context. Focus on outcomes, decisions, and next steps.",
            f"Meeting: {meeting['summary']}\nAttendees: {', '.join(meeting['attendees'][:5])}\n{context_str}",
            fast=True, timeout=30
        )

        if summary:
            debrief["ai_summary"] = summary

    return debrief


def main():
    log("Checking for recently ended meetings")
    state = load_state()
    contacts = load_contacts()

    meetings = get_recently_ended_meetings(lookback_minutes=60)
    debriefed = set(state.get("debriefed_events", []))

    new_debriefs = 0
    for meeting in meetings:
        event_id = meeting.get("id") or f"{meeting['summary']}:{meeting['start']}"
        if event_id in debriefed:
            continue

        log(f"Generating debrief for: {meeting['summary']}")

        notes = find_related_notes(meeting["summary"], meeting["start"])
        emails = find_related_emails(meeting["attendees"])
        attendee_ctx = get_attendee_context(meeting["attendees"], contacts)

        debrief = generate_debrief(meeting, notes, emails, attendee_ctx)

        # Save
        date_str = meeting["start"].strftime("%Y-%m-%d")
        BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
        output_path = BRIEFINGS_DIR / f"{date_str}-meeting-{debrief['slug']}.json"
        with open(output_path, "w") as f:
            json.dump(debrief, f, indent=2, default=str)

        log(f"  Saved: {output_path.name}")
        log(f"  Attendees: {len(meeting['attendees'])}, Notes: {debrief['notes_found']}, Commitments: {debrief['commitments_found']}")
        if debrief.get("ai_summary"):
            log(f"  Summary: {debrief['ai_summary'][:100]}")

        debriefed.add(event_id)
        new_debriefs += 1

    state["debriefed_events"] = list(debriefed)
    save_state(state)

    if new_debriefs:
        log(f"Generated {new_debriefs} meeting debrief(s)")
    else:
        log("No recently ended meetings to debrief")


if __name__ == "__main__":
    main()
