#!/usr/bin/env python3
"""
ARIA Install Email Generator
Creates a ready-to-send email with the installer attached.

Usage:
  python3 scripts/generate-install-email.py \
    --name "Dr. Smith" \
    --email "drsmith@lakewaydentalcare.com" \
    --business "Lakeway Dental Care"

Outputs:
  1. install/outgoing/<business-slug>/email.html (the email body)
  2. install/outgoing/<business-slug>/ARIA-QuickStart.command (the installer)
  3. install/outgoing/<business-slug>/ARIA-deploy.tar.gz (the package)
  4. install/outgoing/<business-slug>/README.txt (instructions for Kelly)

Kelly can then:
  - Email the HTML + attachments manually
  - Or use the --send flag to auto-send via SMTP
"""

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent
INSTALL_DIR = PROJECT_DIR / "install"
OUTGOING_DIR = INSTALL_DIR / "outgoing"


def slugify(text):
    return re.sub(r'[^a-z0-9]+', '-', text.lower()).strip('-')


def build_package():
    """Build the deployment package."""
    pkg_path = "/tmp/ARIA-deploy.tar.gz"
    script = PROJECT_DIR / "scripts" / "package-deploy.sh"
    if script.exists():
        subprocess.run([str(script), pkg_path], capture_output=True, timeout=30)
        if os.path.exists(pkg_path):
            return pkg_path
    return None


def generate_email_html(name, business, from_name="Kelly Kelley"):
    first = name.split()[0] if name else "there"

    return f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family:-apple-system,sans-serif;max-width:600px;margin:0 auto;padding:20px;color:#374151">

<div style="text-align:center;padding:24px;background:#0f172a;border-radius:10px 10px 0 0">
  <h1 style="color:white;font-size:22px;margin:0">Welcome to ARIA</h1>
  <p style="color:#94a3b8;margin:4px 0 0;font-size:14px">Your AI Operating System is Ready</p>
</div>

<div style="background:white;padding:24px;border:1px solid #e5e7eb;border-top:none;border-radius:0 0 10px 10px">

<p>Hi {first},</p>

<p>Your ARIA system is ready to install. Everything you need is attached to this email. The whole process takes about 15 minutes, and most of that is just downloading.</p>

<h2 style="font-size:16px;color:#111827;margin:20px 0 8px">What to do:</h2>

<ol style="line-height:2;font-size:15px">
  <li><strong>Save both attachments</strong> to your Desktop</li>
  <li><strong>Right-click</strong> the file called <code>ARIA-QuickStart.command</code></li>
  <li>Select <strong>Open</strong> (not double-click the first time)</li>
  <li>If you see a security warning, click <strong>Open</strong> again</li>
  <li>Type <strong>y</strong> and press Enter when asked</li>
  <li>Wait about 10-15 minutes while it downloads and installs</li>
  <li>When it says "connect your accounts", follow the steps in your browser</li>
</ol>

<div style="background:#f0fdf4;border-left:4px solid #22c55e;padding:12px 16px;margin:16px 0;border-radius:4px">
  <strong>Your first morning briefing will arrive tomorrow.</strong> It will summarize everything important from your email, calendar, and communications.
</div>

<h2 style="font-size:16px;color:#111827;margin:20px 0 8px">What's attached:</h2>
<ul style="line-height:1.8">
  <li><code>ARIA-QuickStart.command</code> - The installer (right-click, Open)</li>
  <li><code>ARIA-deploy.tar.gz</code> - The ARIA software package</li>
</ul>

<p>Both files should be in the same folder (your Desktop works great).</p>

<div style="background:#eff6ff;border-left:4px solid #3b82f6;padding:12px 16px;margin:16px 0;border-radius:4px">
  <strong>Need help?</strong> After the installer runs, it will set up a secure connection so I can help you remotely. Just reply to this email and I'll hop on.
</div>

<p>Looking forward to getting you set up!</p>

<p>{from_name}<br>
<span style="color:#6b7280">ARIA</span></p>

</div>

<div style="text-align:center;padding:16px;font-size:11px;color:#9ca3af">
  Your data stays on your computer. Nothing is sent to the cloud.<br>
  ARIA | Wright Advisors
</div>

</body>
</html>"""


def main():
    parser = argparse.ArgumentParser(description="Generate ARIA install email")
    parser.add_argument("--name", required=True, help="Client contact name")
    parser.add_argument("--email", required=True, help="Client email")
    parser.add_argument("--business", required=True, help="Business name")
    parser.add_argument("--from-name", default="Kelly Kelley", help="Sender name")
    args = parser.parse_args()

    slug = slugify(args.business)
    out_dir = OUTGOING_DIR / slug
    out_dir.mkdir(parents=True, exist_ok=True)

    # Generate email HTML
    html = generate_email_html(args.name, args.business, args.from_name)
    email_path = out_dir / "email.html"
    with open(email_path, "w") as f:
        f.write(html)

    # Copy installer
    installer_src = INSTALL_DIR / "ARIA-QuickStart.command"
    installer_dst = out_dir / "ARIA-QuickStart.command"
    if installer_src.exists():
        shutil.copy2(installer_src, installer_dst)
        os.chmod(str(installer_dst), 0o755)

    # Build deployment package
    print("Building deployment package...")
    pkg = build_package()
    if pkg and os.path.exists(pkg):
        shutil.move(pkg, str(out_dir / "ARIA-deploy.tar.gz"))

    # Generate README for Kelly
    readme = f"""ARIA Install Package for {args.business}
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}

Client: {args.name} ({args.email})
Business: {args.business}

Files to send:
  1. email.html - Open in browser, copy/paste into email body
  2. ARIA-QuickStart.command - Attach to the email
  3. ARIA-deploy.tar.gz - Attach to the email

The client saves both attachments to their Desktop,
right-clicks the .command file, and follows the steps.

Total attachment size: ~400KB (well under email limits)
"""
    with open(out_dir / "README.txt", "w") as f:
        f.write(readme)

    print(f"\nInstall package ready: {out_dir}/")
    print(f"  email.html              - Email body (open in browser, copy to email)")
    print(f"  ARIA-QuickStart.command - Attachment 1 (the installer)")
    print(f"  ARIA-deploy.tar.gz      - Attachment 2 (the software)")
    print(f"  README.txt              - Instructions for Kelly")
    print(f"\nTo: {args.email}")
    print(f"Subject: Welcome to ARIA - {args.business}")
    print(f"\nAttach both files and send the email HTML as the body.")


if __name__ == "__main__":
    main()
