#!/usr/bin/env python3
"""
ARIA Junk Mail Filter
Three-layer defense against unwanted email that Gmail/Outlook don't catch.

Layer 1: Known Junk List
  - Configurable domains and patterns in aria.json under "junk_filter"
  - Instant match, no AI needed

Layer 2: AI Junk Scoring
  - Fast model scores each email: "Would the user want to read this?"
  - Score 0-10. Below threshold = junk.
  - Catches cold sales emails, recruiter spam, irrelevant notifications

Layer 3: Learned Patterns
  - Tracks domains/senders the user has junked before
  - Auto-junks future emails from repeat offenders
  - Stored in config/junk-learned.json

Usage:
  # Score emails (standalone)
  python3 scripts/junk-filter.py

  # As a module (called by email-organizer.py)
  from junk_filter import is_junk, score_email

Output:
  - Adds junk_score and is_junk fields to email data
  - Junk emails get labeled ARIA/Junk and archived
"""

import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import aria_ai

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
LEARNED_FILE = PROJECT_DIR / "config" / "junk-learned.json"
LOG_FILE = PROJECT_DIR / "logs" / "junk-filter.log"

# Default known junk patterns (augmented by config)
DEFAULT_JUNK_DOMAINS = [
    # Survey/research spam
    "glgroup.com", "gerson-lehrman.com", "alphasights.com", "guidepoint.com",
    # Social media notifications
    "facebookmail.com", "mail.instagram.com", "is.email.nextdoor.com",
    "linkedinmail.com", "tiktok.com",
    # Marketplace/listing alerts
    "flippa.com", "bizbuysell.com", "loopnet.com",
    # Recruitment cold email
    "hired.com", "angel.co", "wellfound.com",
    # Generic marketing platforms
    "mailchimp.com", "sendgrid.net", "constantcontact.com", "hubspot.com",
    "mailgun.org", "amazonses.com",
]

DEFAULT_JUNK_SUBJECT_PATTERNS = [
    r"unsubscribe",
    r"take this.*survey",
    r"paid survey",
    r"your? (?:weekly|daily|monthly) (?:digest|roundup|update|newsletter)",
    r"(?:new|top) listings? matching",
    r"you(?:'re| are) invited to (?:connect|join)",
    r"see who viewed your profile",
    r"people you may know",
    r"your order.*(?:shipped|delivered|confirmed)",
]

# Junk score threshold (0-10, below this = junk)
JUNK_THRESHOLD = 4


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def load_learned():
    """Load learned junk patterns from past user actions."""
    if LEARNED_FILE.exists():
        try:
            with open(LEARNED_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"junk_domains": [], "junk_senders": [], "safe_senders": []}


def save_learned(data):
    LEARNED_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LEARNED_FILE, "w") as f:
        json.dump(data, f, indent=2)


def extract_domain(from_field):
    """Extract domain from email 'from' field."""
    if not from_field:
        return None
    match = re.search(r'<([^>]+)>', from_field)
    email = match.group(1) if match else from_field
    if "@" in email:
        return email.split("@")[-1].strip().lower()
    return None


def extract_email_address(from_field):
    """Extract full email address from 'from' field."""
    if not from_field:
        return None
    match = re.search(r'<([^>]+)>', from_field)
    return (match.group(1) if match else from_field).strip().lower()


# ============================================================
# Layer 1: Known Junk List
# ============================================================

def check_known_junk(email, config):
    """Check against known junk domains and patterns. Instant, no AI."""
    sender = email.get("from", "")
    subject = email.get("subject", "")
    domain = extract_domain(sender)

    # Config-defined junk domains
    config_domains = config.get("junk_filter", {}).get("junk_domains", [])
    all_junk_domains = set(DEFAULT_JUNK_DOMAINS + config_domains)

    if domain and domain in all_junk_domains:
        return True, f"Known junk domain: {domain}"

    # Subject pattern matching
    config_patterns = config.get("junk_filter", {}).get("junk_subject_patterns", [])
    all_patterns = DEFAULT_JUNK_SUBJECT_PATTERNS + config_patterns

    for pattern in all_patterns:
        if re.search(pattern, subject, re.IGNORECASE):
            return True, f"Subject matches junk pattern: {pattern}"

    return False, None


# ============================================================
# Layer 2: AI Junk Scoring
# ============================================================

def ai_score_email(email):
    """
    Use the fast AI model to score email relevance.
    Returns a score from 0-10:
      0-3: Almost certainly junk
      4-6: Borderline (might be useful)
      7-10: Definitely relevant
    """
    sender = email.get("from", "")
    subject = email.get("subject", "")
    snippet = email.get("snippet", "")
    summary = email.get("summary", "")
    project = email.get("detected_project")

    # If already classified to a real project, likely not junk
    if project and project not in ("Unknown", None, "Personal"):
        return 8, "Classified to a known project"

    prompt = """Score this email 0-10 on relevance to a busy founder/consultant.
0 = junk/spam/irrelevant. 10 = critical business email they must see.

Consider:
- Is this from a real person they'd know, or automated/marketing?
- Is this about active business, or unsolicited outreach?
- Would a busy person want this in their inbox, or is it noise?

Respond with ONLY a JSON object: {"score": <number>, "reason": "<one sentence>"}"""

    context = f"From: {sender}\nSubject: {subject}\nPreview: {(summary or snippet)[:300]}"

    result = aria_ai.chat_json(prompt, context, fast=True, timeout=15)

    if result and isinstance(result, dict) and "score" in result:
        return int(result["score"]), result.get("reason", "")

    # If AI fails, default to keeping it (don't junk things we're unsure about)
    return 7, "AI scoring unavailable, defaulting to keep"


# ============================================================
# Layer 3: Learned Patterns
# ============================================================

def check_learned(email, learned):
    """Check against patterns learned from user behavior."""
    domain = extract_domain(email.get("from", ""))
    address = extract_email_address(email.get("from", ""))

    # Safe sender override (user explicitly whitelisted)
    if address and address in learned.get("safe_senders", []):
        return False, "Whitelisted sender"

    # Learned junk senders
    if address and address in learned.get("junk_senders", []):
        return True, f"Previously junked sender: {address}"

    # Learned junk domains
    if domain and domain in learned.get("junk_domains", []):
        return True, f"Previously junked domain: {domain}"

    return False, None


def learn_junk(email):
    """Mark an email's sender as junk. Future emails from them will be auto-junked."""
    learned = load_learned()
    domain = extract_domain(email.get("from", ""))
    address = extract_email_address(email.get("from", ""))

    if address and address not in learned["junk_senders"]:
        learned["junk_senders"].append(address)
    if domain and domain not in learned["junk_domains"]:
        learned["junk_domains"].append(domain)

    # Remove from safe list if present
    if address and address in learned.get("safe_senders", []):
        learned["safe_senders"].remove(address)

    save_learned(learned)
    return True


def learn_safe(email):
    """Mark an email's sender as safe. Won't be junked even if domain matches."""
    learned = load_learned()
    address = extract_email_address(email.get("from", ""))

    if address and address not in learned["safe_senders"]:
        learned["safe_senders"].append(address)

    # Remove from junk lists if present
    if address and address in learned.get("junk_senders", []):
        learned["junk_senders"].remove(address)

    save_learned(learned)
    return True


# ============================================================
# Main Classification
# ============================================================

def is_junk(email, config=None, use_ai=True):
    """
    Run all three layers to determine if an email is junk.

    Returns: (is_junk: bool, score: int, reason: str)
    """
    if config is None:
        config = load_config()
    learned = load_learned()

    # Layer 3 first: learned safe senders bypass everything
    is_learned_junk, reason = check_learned(email, learned)
    if reason and "Whitelisted" in reason:
        return False, 10, reason

    # Layer 1: known junk list (instant)
    known_junk, reason = check_known_junk(email, config)
    if known_junk:
        return True, 0, reason

    # Layer 3: learned junk patterns
    if is_learned_junk:
        return True, 1, reason

    # Layer 2: AI scoring (only if enabled and layers 1/3 didn't decide)
    if use_ai:
        score, reason = ai_score_email(email)
        if score < JUNK_THRESHOLD:
            return True, score, f"AI score {score}/10: {reason}"
        return False, score, f"AI score {score}/10: {reason}"

    # Default: not junk
    return False, 5, "No junk signals detected"


def process_emails(days_back=1, use_ai=True):
    """Score all emails and report junk detection results."""
    from datetime import timedelta

    config = load_config()
    all_results = []

    for day_offset in range(days_back):
        date = datetime.now() - timedelta(days=day_offset)
        date_str = date.strftime("%Y-%m-%d")
        path = INBOX_DIR / f"emails-{date_str}.json"
        if not path.exists():
            continue

        with open(path) as f:
            emails = json.load(f)

        for email in emails:
            junk, score, reason = is_junk(email, config, use_ai=use_ai)
            all_results.append({
                "from": email.get("from", "?")[:50],
                "subject": email.get("subject", "?")[:60],
                "is_junk": junk,
                "score": score,
                "reason": reason,
                "project": email.get("detected_project"),
            })

    return all_results


def main():
    log("Starting junk filter analysis")
    results = process_emails(days_back=3, use_ai=True)

    junk = [r for r in results if r["is_junk"]]
    clean = [r for r in results if not r["is_junk"]]

    log(f"Total emails analyzed: {len(results)}")
    log(f"Junk detected: {len(junk)}")
    log(f"Clean: {len(clean)}")

    if junk:
        log("Junk emails:")
        for j in junk:
            log(f"  JUNK (score {j['score']}): {j['from']} — {j['subject']}")
            log(f"    Reason: {j['reason']}")

    log("")
    log("Clean emails (sample):")
    for c in clean[:5]:
        log(f"  OK (score {c['score']}): {c['from']} — {c['subject']}")

    log("Junk filter complete")


if __name__ == "__main__":
    main()
