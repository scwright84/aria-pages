#!/usr/bin/env python3
"""
ARIA Email Writing Style Learner
Analyzes the user's sent emails to build a writing style profile.
Draft generators use this profile to produce emails that sound like the user.

Learns:
  - Average email length (short/medium/long)
  - Formality level (casual, professional, formal)
  - Greeting patterns ("Hi X", "Hey", "Hello", none)
  - Closing patterns ("Best", "Thanks", "Sean", "Sent from iPhone")
  - Punctuation habits (exclamation marks, ellipsis, emojis)
  - Response speed patterns (quick responder vs deliberate)
  - Sentence structure (short/punchy vs long/complex)
  - Tone keywords (direct, friendly, warm, terse)

Output: config/writing-style.json (used by draft generators)
Run periodically to update as style evolves.
"""

import json
import re
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import aria_ai

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
STYLE_FILE = PROJECT_DIR / "config" / "writing-style.json"
LOG_FILE = PROJECT_DIR / "logs" / "style-learner.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_config():
    config_path = PROJECT_DIR / "config" / "aria.json"
    if config_path.exists():
        with open(config_path) as f:
            return json.load(f)
    return {}


def get_user_emails():
    """Find all emails sent by the user."""
    config = load_config()
    user_email = config.get("email", "").lower()
    user_patterns = [user_email] if user_email else []

    # Also match common patterns
    if user_email:
        name_part = user_email.split("@")[0]
        user_patterns.append(name_part)

    all_sent = []
    for f in sorted(INBOX_DIR.glob("emails-*.json")):
        try:
            with open(f) as fh:
                emails = json.load(fh)
            for e in emails:
                sender = e.get("from", "").lower()
                if any(p in sender for p in user_patterns):
                    all_sent.append(e)
        except Exception:
            pass

    return all_sent


def analyze_style(emails):
    """Analyze writing patterns from sent emails."""
    if not emails:
        return {"error": "No sent emails found", "sample_size": 0}

    snippets = [e.get("snippet", "") for e in emails if e.get("snippet")]
    subjects = [e.get("subject", "") for e in emails if e.get("subject")]

    # Length analysis
    lengths = [len(s) for s in snippets if s]
    avg_length = sum(lengths) / len(lengths) if lengths else 0

    if avg_length < 50:
        length_style = "very_short"
    elif avg_length < 150:
        length_style = "short"
    elif avg_length < 400:
        length_style = "medium"
    else:
        length_style = "long"

    # Greeting patterns
    greetings = Counter()
    for s in snippets:
        lower = s.lower().strip()
        if lower.startswith("hi "):
            greetings["Hi [Name]"] += 1
        elif lower.startswith("hey"):
            greetings["Hey"] += 1
        elif lower.startswith("hello"):
            greetings["Hello"] += 1
        elif lower.startswith("good morning") or lower.startswith("good afternoon"):
            greetings["Good [time]"] += 1
        elif lower.startswith("dear"):
            greetings["Dear [Name]"] += 1
        else:
            greetings["No greeting (direct)"] += 1

    # Closing patterns
    closings = Counter()
    for s in snippets:
        lower = s.lower()
        if "sent from my iphone" in lower or "sent from my" in lower:
            closings["Mobile (Sent from iPhone)"] += 1
        elif "best" in lower[-50:]:
            closings["Best"] += 1
        elif "thanks" in lower[-50:] or "thank you" in lower[-50:]:
            closings["Thanks"] += 1
        elif "cheers" in lower[-50:]:
            closings["Cheers"] += 1
        else:
            closings["No closing / name only"] += 1

    # Punctuation habits
    exclamation_rate = sum(s.count("!") for s in snippets) / max(len(snippets), 1)
    question_rate = sum(s.count("?") for s in snippets) / max(len(snippets), 1)
    emoji_count = sum(len(re.findall(r'[\U0001F600-\U0001F9FF]', s)) for s in snippets)

    # Formality detection
    informal_markers = sum(1 for s in snippets if any(w in s.lower() for w in ["hey", "gonna", "wanna", "lol", "haha", "cool", "awesome", "yeah"]))
    formal_markers = sum(1 for s in snippets if any(w in s.lower() for w in ["regarding", "pursuant", "kindly", "dear", "sincerely", "cordially"]))

    if formal_markers > informal_markers:
        formality = "formal"
    elif informal_markers > len(snippets) * 0.3:
        formality = "casual"
    else:
        formality = "professional"

    # Sentence structure
    sentence_lengths = []
    for s in snippets:
        sentences = re.split(r'[.!?]+', s)
        for sent in sentences:
            words = sent.split()
            if len(words) > 2:
                sentence_lengths.append(len(words))

    avg_sentence_length = sum(sentence_lengths) / max(len(sentence_lengths), 1)

    if avg_sentence_length < 8:
        sentence_style = "short_punchy"
    elif avg_sentence_length < 15:
        sentence_style = "moderate"
    else:
        sentence_style = "complex"

    # Subject line patterns
    subject_lengths = [len(s) for s in subjects]
    avg_subject_length = sum(subject_lengths) / max(len(subject_lengths), 1)
    re_rate = sum(1 for s in subjects if s.lower().startswith("re:")) / max(len(subjects), 1)

    style = {
        "sample_size": len(emails),
        "analyzed_at": datetime.now().isoformat(),
        "length": {
            "style": length_style,
            "avg_chars": round(avg_length),
            "description": f"Tends to write {length_style} emails (~{round(avg_length)} chars)",
        },
        "formality": {
            "level": formality,
            "informal_signals": informal_markers,
            "formal_signals": formal_markers,
        },
        "greeting": {
            "preferred": greetings.most_common(1)[0][0] if greetings else "None",
            "distribution": dict(greetings.most_common()),
        },
        "closing": {
            "preferred": closings.most_common(1)[0][0] if closings else "None",
            "distribution": dict(closings.most_common()),
        },
        "punctuation": {
            "exclamation_per_email": round(exclamation_rate, 2),
            "question_per_email": round(question_rate, 2),
            "uses_emoji": emoji_count > 0,
        },
        "sentence_structure": {
            "style": sentence_style,
            "avg_words_per_sentence": round(avg_sentence_length, 1),
        },
        "subject_lines": {
            "avg_length": round(avg_subject_length),
            "reply_rate": round(re_rate * 100),
        },
        "draft_instructions": _generate_draft_instructions(
            length_style, formality, greetings, closings,
            exclamation_rate, sentence_style, avg_length
        ),
    }

    return style


def _generate_draft_instructions(length_style, formality, greetings, closings,
                                  exclamation_rate, sentence_style, avg_length):
    """Generate natural language instructions for draft generation."""
    instructions = []

    # Length
    if length_style == "very_short":
        instructions.append("Keep emails very short. 1-3 sentences max. Get to the point immediately.")
    elif length_style == "short":
        instructions.append("Keep emails concise. 2-4 sentences. No unnecessary padding.")
    elif length_style == "medium":
        instructions.append("Moderate length emails are fine. Include context but don't ramble.")

    # Formality
    if formality == "casual":
        instructions.append("Use a casual, friendly tone. First names. Contractions are fine.")
    elif formality == "formal":
        instructions.append("Maintain a formal, professional tone. Full sentences. Proper salutations.")
    else:
        instructions.append("Professional but approachable. Not stiff, not too casual.")

    # Greeting
    top_greeting = greetings.most_common(1)[0][0] if greetings else "None"
    if "No greeting" in top_greeting:
        instructions.append("Skip the greeting. Jump straight into the content.")
    elif "Hi" in top_greeting:
        instructions.append("Start with 'Hi [Name],' as the greeting.")
    elif "Hey" in top_greeting:
        instructions.append("Start with 'Hey' or 'Hey [Name]' as the greeting.")

    # Closing
    top_closing = closings.most_common(1)[0][0] if closings else "None"
    if "Mobile" in top_closing:
        instructions.append("Keep it mobile-friendly. No formal closing needed.")
    elif "Thanks" in top_closing:
        instructions.append("End with 'Thanks' or 'Thank you' before the name.")
    elif "Best" in top_closing:
        instructions.append("End with 'Best,' followed by the name.")

    # Sentences
    if sentence_style == "short_punchy":
        instructions.append("Use short, direct sentences. No compound sentences. Punchy.")
    elif sentence_style == "complex":
        instructions.append("Longer sentences with context are acceptable.")

    # Exclamation
    if exclamation_rate < 0.3:
        instructions.append("Avoid exclamation marks. Keep tone measured.")
    elif exclamation_rate > 1.0:
        instructions.append("Occasional exclamation marks are fine for enthusiasm.")

    return " ".join(instructions)


def main():
    log("Starting email writing style analysis")

    emails = get_user_emails()
    log(f"Found {len(emails)} sent emails to analyze")

    if not emails:
        log("No sent emails found. Style profile will use defaults.")
        style = {
            "sample_size": 0,
            "draft_instructions": "Professional but approachable. Concise. Get to the point. Use 'Hi [Name]' greeting. End with name only.",
        }
    else:
        style = analyze_style(emails)

    STYLE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STYLE_FILE, "w") as f:
        json.dump(style, f, indent=2)

    log(f"Style profile saved to {STYLE_FILE}")
    log(f"Length: {style.get('length', {}).get('style', 'unknown')}")
    log(f"Formality: {style.get('formality', {}).get('level', 'unknown')}")
    log(f"Greeting: {style.get('greeting', {}).get('preferred', 'unknown')}")
    log(f"Closing: {style.get('closing', {}).get('preferred', 'unknown')}")
    log(f"Draft instructions: {style.get('draft_instructions', '')[:200]}")
    log("Style analysis complete")


if __name__ == "__main__":
    main()
