"""
ARIA Telegram Command Extensions
Additional commands for the Telegram bot. Import and register these
with the bot's Application.

Commands:
  /drafts       - Show pending email drafts
  /approve <n>  - Approve draft #n
  /reject <n>   - Reject draft #n
  /edit <n> <text> - Edit and approve draft #n
  /approveall   - Approve all pending drafts
  /tasks        - Show open tasks
  /plan         - Show this week's plan
  /scorecard    - Show engagement scorecard
  /outreach     - Show outreach alerts
  /digest       - Show today's comms digest
  /search <query> - Semantic search across all communications
  /memory <query> - Alias for /search

Register with:
  from telegram_commands import register_commands
  register_commands(application)
"""

import json
import sys
from datetime import datetime
from pathlib import Path

from telegram import Update
from telegram.ext import CommandHandler, ContextTypes

sys.path.insert(0, str(Path(__file__).parent))
import draft_manager

PROJECT_DIR = Path(__file__).parent.parent
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
TASKS_FILE = PROJECT_DIR / "config" / "tasks.json"


def _load_json(filename):
    """Load a JSON file from briefings, trying today then yesterday."""
    for offset in range(2):
        date = datetime.now()
        if offset:
            from datetime import timedelta
            date = date - timedelta(days=1)
        path = BRIEFINGS_DIR / f"{date.strftime('%Y-%m-%d')}-{filename}.json"
        if path.exists():
            with open(path) as f:
                return json.load(f)
    return None


async def cmd_drafts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show pending email drafts."""
    drafts = draft_manager.list_pending()
    msg = draft_manager.format_drafts_for_telegram(drafts)
    await update.message.reply_text(msg, parse_mode="Markdown")


async def cmd_approve(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Approve a draft: /approve <id>"""
    if not context.args:
        await update.message.reply_text("Usage: `/approve <draft_id>`", parse_mode="Markdown")
        return
    try:
        draft_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("Invalid draft ID. Use a number.")
        return

    draft = draft_manager.approve_draft(draft_id)
    if draft:
        await update.message.reply_text(f"Draft #{draft_id} approved.\nTo: {draft['to']}\nRe: {draft['subject'][:60]}")
    else:
        await update.message.reply_text(f"Draft #{draft_id} not found or already processed.")


async def cmd_reject(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Reject a draft: /reject <id>"""
    if not context.args:
        await update.message.reply_text("Usage: `/reject <draft_id>`", parse_mode="Markdown")
        return
    try:
        draft_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("Invalid draft ID.")
        return

    draft = draft_manager.reject_draft(draft_id)
    if draft:
        await update.message.reply_text(f"Draft #{draft_id} rejected and deleted.")
    else:
        await update.message.reply_text(f"Draft #{draft_id} not found or already processed.")


async def cmd_edit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Edit a draft: /edit <id> <new body text>"""
    if not context.args or len(context.args) < 2:
        await update.message.reply_text("Usage: `/edit <draft_id> <new body text>`", parse_mode="Markdown")
        return
    try:
        draft_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("Invalid draft ID.")
        return

    new_body = " ".join(context.args[1:])
    draft = draft_manager.edit_draft(draft_id, new_body)
    if draft:
        # Auto-approve after edit
        draft_manager.approve_draft(draft_id)
        await update.message.reply_text(f"Draft #{draft_id} edited and approved.\nNew text: {new_body[:200]}")
    else:
        await update.message.reply_text(f"Draft #{draft_id} not found.")


async def cmd_approveall(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Approve all pending drafts."""
    approved = draft_manager.approve_all()
    if approved:
        lines = [f"Approved {len(approved)} draft(s):"]
        for d in approved:
            lines.append(f"  #{d['id']} → {d['to']}: {d['subject'][:50]}")
        await update.message.reply_text("\n".join(lines))
    else:
        await update.message.reply_text("No pending drafts to approve.")


async def cmd_tasks(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show open tasks."""
    if TASKS_FILE.exists():
        with open(TASKS_FILE) as f:
            data = json.load(f)
        tasks = [t for t in data.get("tasks", []) if t.get("status") == "open"]
    else:
        tasks = []

    if not tasks:
        await update.message.reply_text("No open tasks.")
        return

    lines = [f"*{len(tasks)} Open Tasks*\n"]
    for t in sorted(tasks, key=lambda x: {"high": 0, "urgent": 0, "medium": 1, "normal": 2, "low": 3}.get(x.get("priority", "normal"), 2))[:10]:
        priority = t.get("priority", "normal").upper()
        lines.append(f"[{priority}] {t.get('title', '?')[:70]}")
        if t.get("project"):
            lines.append(f"  _{t['project']}_")
    if len(tasks) > 10:
        lines.append(f"\n...and {len(tasks) - 10} more")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def cmd_plan(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show this week's plan summary."""
    plan = _load_json("plan")
    if not plan:
        await update.message.reply_text("No weekly plan found. Run `weekly-planner.py` first.")
        return

    s = plan["summary"]
    lines = [
        f"*Weekly Plan: {plan['week']}*\n",
        f"Meetings: {s['meetings']}",
        f"Open tasks: {s['open_tasks']}",
        f"Commitments: {s['open_commitments']}",
        f"High priority: {s['high_priority_items']}",
    ]

    if plan.get("recommendations"):
        lines.append("\n*Recommendations:*")
        for r in plan["recommendations"]:
            lines.append(f"  {r}")

    if plan.get("high_priority"):
        lines.append(f"\n*Top Priority:*")
        for item in plan["high_priority"][:5]:
            lines.append(f"  {item['text'][:70]}")

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def cmd_scorecard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show engagement scorecard."""
    scorecard = _load_json("scorecard")
    if not scorecard:
        await update.message.reply_text("No scorecard found. Run `engagement-scorecard.py` first.")
        return

    lines = ["*Engagement Scorecard*\n"]
    for name, m in sorted(scorecard.items(), key=lambda x: x[1].get("health_score", 100)):
        if m.get("email_count", 0) > 0 or m.get("tier") in ("active", "product"):
            flags = ", ".join(m.get("health_flags", [])) if m.get("health_flags") else "OK"
            lines.append(f"*{m['health_grade']}* | {name} ({m['tier']}) | {m['email_count']} emails | {flags}")

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def cmd_outreach(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show outreach alerts."""
    alerts = _load_json("outreach")
    if not alerts:
        await update.message.reply_text("No outreach alerts found.")
        return

    project_alerts = alerts.get("project_alerts", [])
    if not project_alerts:
        await update.message.reply_text("No outreach needed. All clients are engaged.")
        return

    lines = [f"*{len(project_alerts)} Outreach Alert(s)*\n"]
    for a in project_alerts:
        lines.append(f"*{a['project']}* ({a['tier']}): {a['days_silent']}d silent")
        lines.append(f"  _{a.get('suggestion', '')[:80]}_")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def cmd_digest(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show today's comms digest."""
    digest = _load_json("digest")
    if not digest:
        await update.message.reply_text("No digest found. Run `comms-digest.py` first.")
        return

    lines = [f"*Daily Digest*\n"]
    lines.append(f"_{digest.get('headline', '')}_\n")
    lines.append(f"Emails: {digest['email']['count']} (yesterday: {digest['email']['yesterday']})")
    lines.append(f"Slack: {digest['slack']['messages']} messages")
    lines.append(f"Actions needed: {digest['email']['actions_needed']}")

    if digest.get("anomalies"):
        lines.append("\n*Anomalies:*")
        for a in digest["anomalies"]:
            lines.append(f"  {a}")

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def cmd_search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Semantic search: /search <query>"""
    if not context.args:
        await update.message.reply_text("Usage: `/search <your question>`\nExample: `/search What did Kirsten say about the fundraise?`", parse_mode="Markdown")
        return

    query = " ".join(context.args)
    await update.message.reply_text(f"Searching for: _{query}_...", parse_mode="Markdown")

    try:
        import aria_memory
        results = aria_memory.search(query, limit=5)
    except Exception as e:
        await update.message.reply_text(f"Search error: {str(e)[:200]}")
        return

    if not results:
        await update.message.reply_text("No results found.")
        return

    lines = [f"*Search: \"{query}\"*\n"]
    for i, r in enumerate(results, 1):
        score_pct = int(r["score"] * 100)
        lines.append(f"*{i}.* [{r['source']}] {score_pct}% match")
        if r.get("subject"):
            lines.append(f"  {r['subject'][:60]}")
        if r.get("from"):
            lines.append(f"  From: {r['from']}")
        text_preview = r["text"][:150].replace("\n", " ")
        lines.append(f"  _{text_preview}_")
        lines.append("")

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


def register_commands(application):
    """Register all extended commands with the Telegram bot application."""
    commands = [
        ("drafts", cmd_drafts),
        ("approve", cmd_approve),
        ("reject", cmd_reject),
        ("edit", cmd_edit),
        ("approveall", cmd_approveall),
        ("tasks", cmd_tasks),
        ("plan", cmd_plan),
        ("scorecard", cmd_scorecard),
        ("outreach", cmd_outreach),
        ("digest", cmd_digest),
        ("search", cmd_search),
        ("memory", cmd_search),  # Alias
    ]

    for name, handler in commands:
        application.add_handler(CommandHandler(name, handler))

    return [name for name, _ in commands]
