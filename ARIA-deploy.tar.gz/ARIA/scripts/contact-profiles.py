#!/usr/bin/env python3
"""
ARIA Contact Profiles
Builds per-person relationship data from email, Slack, calendar, and commitments.

For each contact, tracks:
  - Name and email
  - Associated projects
  - Communication frequency (emails per week)
  - Last contact date
  - Relationship type (client, team, vendor, personal)
  - Open commitments they owe or are owed
  - Key topics discussed
  - Meeting frequency

Outputs:
  - config/contacts.json (persistent, updated incrementally)
  - briefings/YYYY-MM-DD-contacts.html (snapshot for review)

Runs weekly or manually. Merges new data into existing profiles.
"""

import json
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
CONFIG_DIR = PROJECT_DIR / "config"
CONTACTS_FILE = CONFIG_DIR / "contacts.json"
LOG_FILE = PROJECT_DIR / "logs" / "contact-profiles.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_config():
    config_path = PROJECT_DIR / "config" / "aria.json"
    if config_path.exists():
        with open(config_path) as f:
            return json.load(f)
    return {}


def load_existing_contacts():
    if CONTACTS_FILE.exists():
        with open(CONTACTS_FILE) as f:
            return json.load(f)
    return {}


def load_inbox_files(prefix, days_back=30):
    all_data = []
    for day_offset in range(days_back):
        date = datetime.now() - timedelta(days=day_offset)
        date_str = date.strftime("%Y-%m-%d")
        path = INBOX_DIR / f"{prefix}-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                if isinstance(data, list):
                    all_data.extend(data)
            except (json.JSONDecodeError, IOError):
                pass
    return all_data


def parse_email_address(from_field):
    """Extract name and email from 'Name <email>' format."""
    if not from_field:
        return None, None

    match = re.match(r'"?([^"<]+?)"?\s*<([^>]+)>', from_field)
    if match:
        return match.group(1).strip(), match.group(2).strip().lower()

    # Bare email
    if "@" in from_field:
        return None, from_field.strip().lower()

    return from_field.strip(), None


def is_noise_sender(email):
    """Filter out automated/marketing senders."""
    if not email:
        return True
    noise_domains = [
        "noreply", "no-reply", "notifications", "mailer", "updates",
        "info@", "support@", "hello@", "team@", "billing@",
        "servicetitanmail", "stripe.com", "github.com", "google.com",
        "linkedin.com", "slack.com", "notion.so", "calendly.com",
    ]
    return any(n in email for n in noise_domains)


def normalize_name(name):
    """Clean up name for matching."""
    if not name:
        return None
    name = name.strip().strip('"').strip("'")
    # Remove common suffixes
    for suffix in [" via Gmail", " via Outlook", " (via Slack)"]:
        name = name.replace(suffix, "")
    return name.strip() if name.strip() else None


def build_contact_key(name, email):
    """Create a stable key for deduplication. Prefer email, fall back to name."""
    if email:
        return email
    if name:
        return name.lower().replace(" ", "_")
    return None


def extract_contacts(config, days_back=30):
    """Extract contact data from all inbox sources."""
    contacts = defaultdict(lambda: {
        "name": None,
        "emails": set(),
        "projects": set(),
        "email_count": 0,
        "last_contact": None,
        "first_seen": None,
        "topics": [],
        "commitments_from": [],
        "commitments_to": [],
        "slack_mentions": 0,
        "meetings": 0,
    })

    known_projects = set(config.get("known_projects", []))

    # Process emails
    emails = load_inbox_files("emails", days_back)
    for e in emails:
        name, email = parse_email_address(e.get("from", ""))
        if is_noise_sender(email):
            continue

        key = build_contact_key(name, email)
        if not key:
            continue

        c = contacts[key]
        if name:
            c["name"] = normalize_name(name) or c["name"]
        if email:
            c["emails"].add(email)
        c["email_count"] += 1

        project = e.get("detected_project")
        if project and project in known_projects:
            c["projects"].add(project)

        date_str = e.get("date", "")
        if date_str:
            try:
                d = datetime.fromisoformat(date_str.replace("Z", "+00:00")).replace(tzinfo=None)
                if c["last_contact"] is None or d > c["last_contact"]:
                    c["last_contact"] = d
                if c["first_seen"] is None or d < c["first_seen"]:
                    c["first_seen"] = d
            except (ValueError, TypeError):
                pass

        subject = e.get("subject", "")
        if subject and len(subject) > 5:
            c["topics"].append(subject)

    # Process Slack key_people
    slack = load_inbox_files("slack", days_back)
    for s in slack:
        project = s.get("project")
        for person in s.get("key_people", []):
            name = normalize_name(person)
            if not name:
                continue
            key = build_contact_key(name, None)
            if not key:
                continue
            c = contacts[key]
            c["name"] = name
            c["slack_mentions"] += 1
            if project and project in known_projects:
                c["projects"].add(project)

    # Process commitments (awaiting)
    awaiting = load_inbox_files("awaiting", days_back)
    for a in awaiting:
        owner = a.get("owner", "")
        project = a.get("project")
        task = a.get("task", "")

        # Try to extract a person name from the owner field
        # Awaiting data has messy owner fields, extract first name-like token
        if owner and len(owner) < 50:
            name = normalize_name(owner.split(",")[0].split(":")[0].strip())
            if name and len(name.split()) <= 3:
                key = build_contact_key(name, None)
                if key:
                    c = contacts[key]
                    c["name"] = name
                    if project and project in known_projects:
                        c["projects"].add(project)
                    c["commitments_from"].append(task[:100])

    # Process calendar/meetings
    calendar = load_inbox_files("calendar", days_back)
    meetings = load_inbox_files("meetings", days_back)
    for m in calendar + meetings:
        attendees = m.get("attendees", [])
        for att in attendees:
            if isinstance(att, str):
                name, email = parse_email_address(att)
            elif isinstance(att, dict):
                name = att.get("name")
                email = att.get("email")
            else:
                continue

            if is_noise_sender(email):
                continue
            key = build_contact_key(name, email)
            if not key:
                continue
            c = contacts[key]
            if name:
                c["name"] = normalize_name(name) or c["name"]
            if email:
                c["emails"].add(email)
            c["meetings"] += 1

    return contacts


def merge_contacts(existing, new_data):
    """Merge new contact data into existing profiles."""
    for key, new in new_data.items():
        if key in existing:
            old = existing[key]
            old["name"] = new["name"] or old.get("name")
            old["emails"] = list(set(old.get("emails", []) + list(new["emails"])))
            old["projects"] = list(set(old.get("projects", []) + list(new["projects"])))
            old["email_count"] = new["email_count"]  # Replace with current period count
            old["slack_mentions"] = new["slack_mentions"]
            old["meetings"] = new["meetings"]

            if new["last_contact"]:
                new_lc = new["last_contact"].isoformat() if isinstance(new["last_contact"], datetime) else new["last_contact"]
                old_lc = old.get("last_contact")
                if old_lc is None or new_lc > old_lc:
                    old["last_contact"] = new_lc

            if new["first_seen"]:
                new_fs = new["first_seen"].isoformat() if isinstance(new["first_seen"], datetime) else new["first_seen"]
                old_fs = old.get("first_seen")
                if old_fs is None or new_fs < old_fs:
                    old["first_seen"] = new_fs

            # Keep latest topics (last 10)
            old["topics"] = (new["topics"] + old.get("topics", []))[:10]
            old["commitments_from"] = new["commitments_from"]
            old["commitments_to"] = new.get("commitments_to", [])
            old["updated"] = datetime.now().isoformat()
        else:
            existing[key] = {
                "name": new["name"],
                "emails": list(new["emails"]),
                "projects": list(new["projects"]),
                "email_count": new["email_count"],
                "slack_mentions": new["slack_mentions"],
                "meetings": new["meetings"],
                "last_contact": new["last_contact"].isoformat() if isinstance(new["last_contact"], datetime) else new["last_contact"],
                "first_seen": new["first_seen"].isoformat() if isinstance(new["first_seen"], datetime) else new["first_seen"],
                "topics": new["topics"][:10],
                "commitments_from": new["commitments_from"],
                "commitments_to": new.get("commitments_to", []),
                "created": datetime.now().isoformat(),
                "updated": datetime.now().isoformat(),
            }

    return existing


def generate_html(contacts, date_str):
    """Generate HTML contact directory."""
    # Sort by email count descending (most active first), filter out low-signal
    sorted_contacts = sorted(
        [(k, v) for k, v in contacts.items() if v.get("email_count", 0) > 0 or v.get("slack_mentions", 0) > 0],
        key=lambda x: x[1].get("email_count", 0) + x[1].get("slack_mentions", 0),
        reverse=True
    )

    rows = ""
    for key, c in sorted_contacts[:50]:  # Top 50
        name = c.get("name", key)
        email = ", ".join(c.get("emails", [])[:2])
        projects = ", ".join(c.get("projects", []))
        last = c.get("last_contact", "-")
        if last and len(str(last)) > 10:
            last = str(last)[:10]

        rows += f"""
        <tr>
            <td style="font-weight:600">{name}</td>
            <td style="font-size:12px;color:#6b7280">{email}</td>
            <td>{projects or '-'}</td>
            <td style="text-align:center">{c.get('email_count', 0)}</td>
            <td style="text-align:center">{c.get('slack_mentions', 0)}</td>
            <td style="text-align:center">{c.get('meetings', 0)}</td>
            <td style="font-size:12px">{last}</td>
        </tr>"""

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>ARIA Contact Profiles - {date_str}</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 1100px; margin: 0 auto; padding: 20px; background: #f9fafb; }}
  h1 {{ font-size: 20px; color: #111827; margin-bottom: 4px; }}
  .subtitle {{ color: #6b7280; font-size: 14px; margin-bottom: 20px; }}
  .stats {{ color: #6b7280; font-size: 13px; margin-bottom: 16px; }}
  table {{ width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }}
  th {{ background: #111827; color: white; padding: 10px 12px; text-align: left; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; }}
  td {{ padding: 8px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px; }}
  tr:last-child td {{ border-bottom: none; }}
  tr:hover {{ background: #f3f4f6; }}
</style>
</head>
<body>
<h1>Contact Profiles</h1>
<p class="subtitle">Updated {date_str} | Generated by ARIA</p>
<p class="stats">{len(contacts)} total contacts | Showing top {min(50, len(sorted_contacts))} by activity</p>
<table>
  <thead>
    <tr>
      <th>Name</th>
      <th>Email</th>
      <th>Projects</th>
      <th>Emails</th>
      <th>Slack</th>
      <th>Meetings</th>
      <th>Last Contact</th>
    </tr>
  </thead>
  <tbody>
    {rows}
  </tbody>
</table>
</body>
</html>"""
    return html


def main():
    log("Starting contact profile generation")
    config = load_config()
    date_str = datetime.now().strftime("%Y-%m-%d")

    # Extract contacts from inbox data
    new_contacts = extract_contacts(config, days_back=30)
    log(f"Extracted {len(new_contacts)} contacts from inbox data")

    # Merge with existing profiles
    existing = load_existing_contacts()
    merged = merge_contacts(existing, new_contacts)
    log(f"Merged into {len(merged)} total profiles")

    # Save persistent contacts file
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONTACTS_FILE, "w") as f:
        json.dump(merged, f, indent=2, default=str)
    log(f"Saved contacts: {CONTACTS_FILE}")

    # Save HTML snapshot
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    html_path = BRIEFINGS_DIR / f"{date_str}-contacts.html"
    html = generate_html(merged, date_str)
    with open(html_path, "w") as f:
        f.write(html)
    log(f"Saved HTML: {html_path}")

    # Print summary
    active = [(k, v) for k, v in merged.items() if v.get("email_count", 0) > 0]
    log(f"Active contacts (sent email this period): {len(active)}")
    for key, c in sorted(active, key=lambda x: x[1].get("email_count", 0), reverse=True)[:10]:
        name = c.get("name", key)
        projects = ", ".join(c.get("projects", []))
        log(f"  {name}: {c.get('email_count', 0)} emails | {projects or 'no project'}")

    log("Contact profiles complete")


if __name__ == "__main__":
    main()
