#!/usr/bin/env python3
"""
ARIA Health Check Monitor
Checks all critical services and alerts Sean via Telegram when something is down.
Designed to run every 5 minutes via launchd.

Checks:
1. Inference engine (oMLX/Ollama) responding
2. n8n running and reachable
3. Docker stack healthy
4. Morning briefing generated today (after briefing time)
5. Telegram bot process running

Alerts via Telegram DM to Sean. Falls back to local log if Telegram is down.
"""

import json
import os
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path

import requests

# Paths
PROJECT_DIR = Path(__file__).parent.parent
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
LOG_FILE = PROJECT_DIR / "logs" / "health-check.log"
STATE_FILE = PROJECT_DIR / "logs" / "health-check-state.json"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
ENV_FILE = PROJECT_DIR / ".env"

# Alert cooldown: don't spam the same alert more than once per hour
ALERT_COOLDOWN_MINUTES = 60


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def load_env():
    """Load env vars from .env file."""
    if ENV_FILE.exists():
        with open(ENV_FILE) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, value = line.partition("=")
                    key = key.strip()
                    value = value.strip().strip("'\"")
                    if key and key not in os.environ:
                        os.environ[key] = value


def load_state():
    if STATE_FILE.exists():
        try:
            with open(STATE_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"last_alerts": {}, "last_all_clear": None}


def save_state(state):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def should_alert(state, check_name):
    """Check if we should send an alert (respecting cooldown)."""
    last = state.get("last_alerts", {}).get(check_name)
    if last is None:
        return True
    try:
        last_time = datetime.fromisoformat(last)
        return (datetime.now() - last_time) > timedelta(minutes=ALERT_COOLDOWN_MINUTES)
    except Exception:
        return True


def record_alert(state, check_name):
    if "last_alerts" not in state:
        state["last_alerts"] = {}
    state["last_alerts"][check_name] = datetime.now().isoformat()


def clear_alert(state, check_name):
    """Clear a previous alert when the service recovers."""
    if "last_alerts" in state and check_name in state["last_alerts"]:
        del state["last_alerts"][check_name]


def send_telegram_alert(message, config):
    """Send alert to Sean via Telegram."""
    load_env()
    token_env = config.get("telegram", {}).get("token_env", "ARIA_TELEGRAM_TOKEN")
    token = os.environ.get(token_env)
    users = config.get("telegram", {}).get("authorized_users", [])

    if not token or not users:
        log(f"Cannot send Telegram alert: token={'set' if token else 'missing'}, users={users}")
        return False

    sent = False
    for user_id in users:
        try:
            resp = requests.post(
                f"https://api.telegram.org/bot{token}/sendMessage",
                json={
                    "chat_id": user_id,
                    "text": message,
                    "parse_mode": "Markdown",
                },
                timeout=10,
            )
            if resp.status_code == 200:
                sent = True
            else:
                log(f"Telegram send failed for {user_id}: {resp.status_code}")
        except Exception as e:
            log(f"Telegram send error for {user_id}: {e}")

    return sent


# --- Health Checks ---

def check_inference():
    """Check if the inference engine is responding."""
    config = load_config()
    url = config.get("ai", {}).get("inference_url", "http://localhost:11434/v1/chat/completions")
    # Extract base URL (everything before /v1/) for a lightweight models check
    base = url.split("/v1/")[0] if "/v1/" in url else url.rsplit("/", 1)[0]
    models_url = base + "/v1/models"

    try:
        resp = requests.get(models_url, timeout=5)
        if resp.status_code == 200:
            return {"ok": True, "detail": "Inference engine responding"}
        return {"ok": False, "detail": f"Inference engine returned {resp.status_code}"}
    except requests.exceptions.ConnectionError:
        return {"ok": False, "detail": "Inference engine not reachable (connection refused)"}
    except requests.exceptions.Timeout:
        return {"ok": False, "detail": "Inference engine not responding (timeout)"}
    except Exception as e:
        return {"ok": False, "detail": f"Inference check error: {e}"}


def check_n8n():
    """Check if n8n is running."""
    try:
        resp = requests.get("http://localhost:5678/healthz", timeout=5)
        if resp.status_code == 200:
            return {"ok": True, "detail": "n8n healthy"}
        return {"ok": False, "detail": f"n8n returned {resp.status_code}"}
    except requests.exceptions.ConnectionError:
        return {"ok": False, "detail": "n8n not reachable (connection refused)"}
    except requests.exceptions.Timeout:
        return {"ok": False, "detail": "n8n not responding (timeout)"}
    except Exception as e:
        return {"ok": False, "detail": f"n8n check error: {e}"}


def check_docker():
    """Check if Docker containers are running."""
    try:
        result = subprocess.run(
            ["docker", "ps", "--format", "{{.Names}}\t{{.Status}}"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode != 0:
            return {"ok": False, "detail": "Docker not running or not accessible"}

        containers = result.stdout.strip().split("\n")
        required = {"n8n", "self-hosted-ai-starter-kit-postgres-1"}
        running = set()
        for line in containers:
            if "\t" in line:
                name, status = line.split("\t", 1)
                if "Up" in status:
                    running.add(name)

        missing = required - running
        if missing:
            return {"ok": False, "detail": f"Missing containers: {', '.join(missing)}"}
        return {"ok": True, "detail": f"{len(running)} containers running"}
    except subprocess.TimeoutExpired:
        return {"ok": False, "detail": "Docker check timed out"}
    except FileNotFoundError:
        return {"ok": False, "detail": "Docker CLI not found"}
    except Exception as e:
        return {"ok": False, "detail": f"Docker check error: {e}"}


def check_briefing():
    """Check if today's morning briefing was generated (only after briefing time)."""
    config = load_config()
    briefing_time = config.get("schedules", {}).get("morning_briefing", "07:30")
    hour, minute = map(int, briefing_time.split(":"))

    now = datetime.now()
    # Only check after briefing time + 30 min grace period
    briefing_deadline = now.replace(hour=hour, minute=minute, second=0) + timedelta(minutes=30)
    if now < briefing_deadline:
        return {"ok": True, "detail": "Before briefing deadline, skipping check"}

    date_str = now.strftime("%Y-%m-%d")
    html_path = BRIEFINGS_DIR / f"{date_str}.html"
    json_path = BRIEFINGS_DIR / f"{date_str}.json"

    if html_path.exists() or json_path.exists():
        return {"ok": True, "detail": f"Briefing for {date_str} exists"}
    return {"ok": False, "detail": f"No briefing generated for {date_str} (past deadline)"}


def check_telegram_bot():
    """Check if the Telegram bot process is running."""
    try:
        result = subprocess.run(
            ["pgrep", "-f", "aria-telegram-bot"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            pids = result.stdout.strip().split("\n")
            return {"ok": True, "detail": f"Telegram bot running (PID {pids[0]})"}
        return {"ok": False, "detail": "Telegram bot process not found"}
    except Exception as e:
        return {"ok": False, "detail": f"Telegram bot check error: {e}"}


def main():
    log("Running health checks...")
    config = load_config()
    state = load_state()

    checks = {
        "inference": check_inference,
        "n8n": check_n8n,
        "docker": check_docker,
        "briefing": check_briefing,
        "telegram_bot": check_telegram_bot,
    }

    failures = []
    all_failures = []
    recoveries = []

    for name, check_fn in checks.items():
        result = check_fn()
        if result["ok"]:
            log(f"  OK: {name} — {result['detail']}")
            if name in state.get("last_alerts", {}):
                recoveries.append(name)
                clear_alert(state, name)
        else:
            log(f"  FAIL: {name} — {result['detail']}")
            all_failures.append(name)
            if should_alert(state, name):
                failures.append({"name": name, "detail": result["detail"]})
                record_alert(state, name)

    # Send alerts for failures
    if failures:
        lines = ["🚨 *ARIA Health Alert*\n"]
        for f in failures:
            lines.append(f"❌ *{f['name']}*: {f['detail']}")
        lines.append(f"\n_Checked at {datetime.now().strftime('%H:%M')}_")
        message = "\n".join(lines)
        sent = send_telegram_alert(message, config)
        if sent:
            log(f"Alert sent for: {', '.join(f['name'] for f in failures)}")
        else:
            log(f"ALERT FAILED TO SEND: {', '.join(f['name'] for f in failures)}")

    # Send recovery notifications
    if recoveries:
        lines = ["✅ *ARIA Recovery*\n"]
        for r in recoveries:
            lines.append(f"🟢 *{r}* is back online")
        lines.append(f"\n_Checked at {datetime.now().strftime('%H:%M')}_")
        message = "\n".join(lines)
        send_telegram_alert(message, config)
        log(f"Recovery notification sent for: {', '.join(recoveries)}")

    # Update state
    if not failures and not state.get("last_alerts"):
        state["last_all_clear"] = datetime.now().isoformat()

    save_state(state)

    total = len(checks)
    passed = total - len(all_failures)
    log(f"Health check complete: {passed}/{total} passed")

    return 0 if not all_failures else 1


if __name__ == "__main__":
    sys.exit(main())
