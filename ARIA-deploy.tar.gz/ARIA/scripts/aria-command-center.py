#!/usr/bin/env python3
"""
ARIA Command Center
Unified web UI: dashboard, integrations, health, preferences, briefings.
Replaces separate onboarding-server.py (8642) and aria-dashboard.py (8643).

Runs on port 8642 (preserves OAuth redirect URIs).
Access at http://localhost:8642
"""

import base64
import json
import os
import secrets
import subprocess
import sys
import webbrowser
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import urlencode

import requests as http_requests
from flask import Flask, redirect, request, render_template, url_for, flash, session
from google_auth_oauthlib.flow import Flow
from google.oauth2.credentials import Credentials
import msal

# Allow HTTP for localhost OAuth (Google requires this flag for non-HTTPS)
os.environ["OAUTHLIB_INSECURE_TRANSPORT"] = "1"

PROJECT_DIR = Path(__file__).parent.parent
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
CREDENTIALS_FILE = PROJECT_DIR / "config" / "credentials.json"
GOOGLE_CLIENT_FILE = PROJECT_DIR / "config" / "google-oauth-client.json"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
INBOX_DIR = PROJECT_DIR / "inbox"
LOG_DIR = PROJECT_DIR / "logs"
ENV_FILE = PROJECT_DIR / ".env"

PORT = 8642
REDIRECT_URI = f"http://localhost:{PORT}/oauth/google/callback"
MS_REDIRECT_URI = f"http://localhost:{PORT}/oauth/microsoft/callback"

# Google API scopes
GMAIL_SCOPES = [
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/gmail.labels",
]
CALENDAR_SCOPES = [
    "https://www.googleapis.com/auth/calendar.readonly",
]
ALL_SCOPES = GMAIL_SCOPES + CALENDAR_SCOPES

# Microsoft scopes
MS_SCOPES = [
    "Mail.Read", "Mail.ReadWrite", "Mail.Send",
    "Calendars.Read", "Calendars.ReadWrite",
    "User.Read", "Chat.Read", "ChannelMessage.Read.All", "Team.ReadBasic.All",
]
MS_CLIENT_FILE = PROJECT_DIR / "config" / "microsoft-oauth-client.json"
MS_AUTHORITY = "https://login.microsoftonline.com/common"

# Slack OAuth
SLACK_CLIENT_FILE = PROJECT_DIR / "config" / "slack-oauth-client.json"
SLACK_REDIRECT_URI = "https://scwright84.github.io/aria-pages/slack-callback.html"
SLACK_SCOPES = "channels:history,channels:read,groups:read,groups:history,users:read,team:read,im:history,im:read,mpim:history,mpim:read"

# Zoom OAuth
ZOOM_CLIENT_FILE = PROJECT_DIR / "config" / "zoom-oauth-client.json"
ZOOM_REDIRECT_URI = "https://scwright84.github.io/aria-pages/zoom-callback.html"

# Notion OAuth
NOTION_CLIENT_FILE = PROJECT_DIR / "config" / "notion-oauth-client.json"
NOTION_REDIRECT_URI = "https://scwright84.github.io/aria-pages/notion-callback.html"

app = Flask(__name__, template_folder=str(PROJECT_DIR / "templates"))
app.secret_key = secrets.token_hex(32)

# ============================================================
# Navigation Config
# ============================================================

NAV_ICONS = {
    "dashboard": '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>',
    "integrations": '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v6m0 8v6M4.93 4.93l4.24 4.24m5.66 5.66l4.24 4.24M2 12h6m8 0h6M4.93 19.07l4.24-4.24m5.66-5.66l4.24-4.24"/></svg>',
    "briefings": '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>',
    "health": '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>',
    "preferences": '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>',
    # Dental vertical
    "calendar": '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>',
    "file": '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>',
    "package": '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="16.5" y1="9.4" x2="7.5" y2="4.21"/><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 002 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>',
    # Legal vertical
    "briefcase": '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>',
}

BASE_NAV = [
    {"id": "dashboard", "label": "Dashboard", "url": "/", "icon": "dashboard"},
    {"id": "integrations", "label": "Integrations", "url": "/integrations", "icon": "integrations"},
    {"id": "briefings", "label": "Briefings", "url": "/briefings", "icon": "briefings"},
    {"id": "health", "label": "Health", "url": "/health", "icon": "health"},
    {"id": "preferences", "label": "Preferences", "url": "/preferences", "icon": "preferences"},
]

VERTICAL_NAV = {
    "dental": {
        "label": "Dental Practice",
        "items": [
            {"id": "dental-schedule", "label": "Patient Schedule", "url": "/dental/schedule", "icon": "calendar"},
            {"id": "dental-claims", "label": "Claims Tracker", "url": "/dental/claims", "icon": "file"},
            {"id": "dental-lab", "label": "Lab Cases", "url": "/dental/lab-cases", "icon": "package"},
        ],
    },
    "legal": {
        "label": "Legal Practice",
        "items": [
            {"id": "legal-cases", "label": "Case Tracker", "url": "/legal/cases", "icon": "briefcase"},
        ],
    },
}

# ============================================================
# Detect hardware at startup
# ============================================================

try:
    import importlib.util as _ilu
    _spec = _ilu.spec_from_file_location("hw", str(PROJECT_DIR / "scripts" / "detect-hardware.py"))
    _hw_mod = _ilu.module_from_spec(_spec)
    _spec.loader.exec_module(_hw_mod)
    _hw_result = _hw_mod.detect()
    _hw_info = _hw_result["hardware"]
    _hw_rec = _hw_result["recommendation"]
except Exception:
    _hw_info = {"mac_model": "Unknown", "chip": "Unknown", "ram_gb": 0}
    _hw_rec = {"tier_name": "Unknown", "local_percentage": 0, "cloud_percentage": 0}

# ============================================================
# Helpers (merged from both apps)
# ============================================================

def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def save_config(config):
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)


def load_credentials():
    if CREDENTIALS_FILE.exists():
        with open(CREDENTIALS_FILE) as f:
            return json.load(f)
    return {"accounts": []}


def save_credentials(creds):
    CREDENTIALS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CREDENTIALS_FILE, "w") as f:
        json.dump(creds, f, indent=2)
    os.chmod(CREDENTIALS_FILE, 0o600)


def get_connected_accounts():
    creds = load_credentials()
    return [
        {
            "email": a.get("email", "Unknown"),
            "type": a.get("type", "google"),
            "services": a.get("services", []),
            "connected_at": a.get("connected_at", ""),
            "status": "connected" if a.get("refresh_token") else "expired",
        }
        for a in creds.get("accounts", [])
    ]


def _check_tailscale():
    try:
        result = subprocess.run(["tailscale", "status", "--json"],
                                capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            data = json.loads(result.stdout)
            return data.get("BackendState") == "Running"
    except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError):
        pass
    return False


def google_client_exists():
    return GOOGLE_CLIENT_FILE.exists()


def ms_client_exists():
    return MS_CLIENT_FILE.exists()


def slack_client_exists():
    return SLACK_CLIENT_FILE.exists()


def zoom_client_exists():
    return ZOOM_CLIENT_FILE.exists()


def notion_client_exists():
    return NOTION_CLIENT_FILE.exists()


def get_slack_client_config():
    if SLACK_CLIENT_FILE.exists():
        with open(SLACK_CLIENT_FILE) as f:
            return json.load(f)
    return None


def get_ms_client_config():
    if MS_CLIENT_FILE.exists():
        with open(MS_CLIENT_FILE) as f:
            return json.load(f)
    return None


def get_ms_app():
    config = get_ms_client_config()
    if not config:
        return None
    return msal.ConfidentialClientApplication(
        config["client_id"],
        authority=MS_AUTHORITY,
        client_credential=config.get("client_secret"),
    )


def get_zoom_client_config():
    if ZOOM_CLIENT_FILE.exists():
        with open(ZOOM_CLIENT_FILE) as f:
            return json.load(f)
    return None


def get_notion_client_config():
    if NOTION_CLIENT_FILE.exists():
        with open(NOTION_CLIENT_FILE) as f:
            return json.load(f)
    return None


def get_todays_briefing():
    date_str = datetime.now().strftime("%Y-%m-%d")
    html_path = BRIEFINGS_DIR / f"{date_str}.html"
    if html_path.exists():
        with open(html_path) as f:
            return f.read()
    return None


def get_briefing_dates():
    dates = []
    if BRIEFINGS_DIR.exists():
        for f in sorted(BRIEFINGS_DIR.glob("*.html"), reverse=True):
            date_str = f.stem
            try:
                dt = datetime.strptime(date_str, "%Y-%m-%d")
                dates.append({"date": date_str, "display": dt.strftime("%A, %B %d")})
            except ValueError:
                pass
    return dates[:14]


def get_inbox_stats():
    date_str = datetime.now().strftime("%Y-%m-%d")
    stats = {}
    for source in ["emails", "calendar", "slack", "notifications", "awaiting"]:
        path = INBOX_DIR / f"{source}-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                stats[source] = len(data) if isinstance(data, list) else 1
            except Exception:
                stats[source] = 0
        else:
            stats[source] = 0
    return stats


def get_health_status():
    state_file = LOG_DIR / "health-check-state.json"
    if state_file.exists():
        try:
            with open(state_file) as f:
                state = json.load(f)
            active_alerts = state.get("last_alerts", {})
            last_clear = state.get("last_all_clear")
            if active_alerts:
                return {"status": "warning", "issues": list(active_alerts.keys()), "last_clear": last_clear}
            return {"status": "healthy", "issues": [], "last_clear": last_clear}
        except Exception:
            pass
    return {"status": "unknown", "issues": [], "last_clear": None}


def get_recent_logs(n=10):
    log_file = LOG_DIR / "briefing.log"
    if log_file.exists():
        with open(log_file) as f:
            lines = f.readlines()
        return [l.strip() for l in lines[-n:]]
    return []


def _is_telegram_set():
    if ENV_FILE.exists():
        with open(ENV_FILE) as f:
            for line in f:
                if line.strip().startswith("ARIA_TELEGRAM_TOKEN=") and "CHANGE_ME" not in line:
                    return True
    return False


def _is_notifications_enabled():
    notif_db = Path.home() / "Library" / "Group Containers" / "group.com.apple.usernoted" / "db2" / "db"
    if notif_db.exists():
        try:
            import sqlite3
            conn = sqlite3.connect(str(notif_db))
            conn.execute("SELECT COUNT(*) FROM record")
            conn.close()
            return True
        except Exception:
            pass
    return False


def _get_client_type():
    config = load_config()
    return config.get("client", {}).get("type", "general")


# ============================================================
# Context Processor — injects nav + shared vars into all templates
# ============================================================

@app.context_processor
def inject_globals():
    config = load_config()
    client_type = config.get("client", {}).get("type", "general")
    client_name = config.get("client", {}).get("name") or "ARIA"

    # Build nav items with SVG icons
    nav_items = []
    for item in BASE_NAV:
        nav_items.append({**item, "icon_svg": NAV_ICONS.get(item["icon"], "")})

    vertical_nav = []
    vertical_label = ""
    vert_config = VERTICAL_NAV.get(client_type)
    if vert_config:
        vertical_label = vert_config["label"]
        for item in vert_config["items"]:
            vertical_nav.append({**item, "icon_svg": NAV_ICONS.get(item["icon"], "")})

    demo_mode = config.get("_demo_mode")

    return {
        "nav_items": nav_items,
        "vertical_nav": vertical_nav,
        "vertical_label": vertical_label,
        "client_name": client_name,
        "client_type": client_type,
        "demo_mode": demo_mode,
    }


# ============================================================
# Dashboard (home page)
# ============================================================

@app.route("/")
def dashboard():
    # First-time user: redirect to integrations if no accounts connected
    accounts = get_connected_accounts()
    if not accounts:
        return redirect(url_for("integrations"))

    config = load_config()
    date_param = request.args.get("date")
    date_str = date_param or datetime.now().strftime("%Y-%m-%d")

    briefing_html = None
    html_path = BRIEFINGS_DIR / f"{date_str}.html"
    if html_path.exists():
        with open(html_path) as f:
            briefing_html = f.read()

    now = datetime.now()

    # Load briefing intelligence from JSON
    briefing = None
    meta = {}
    briefing_json = BRIEFINGS_DIR / f"{date_str}.json"
    if briefing_json.exists():
        try:
            with open(briefing_json) as f:
                bdata = json.load(f)
            briefing = bdata.get("sections", {})
            meta = {
                "email_count": bdata.get("email_count", 0),
                "notification_count": bdata.get("notification_count", 0),
                "slack_channel_count": bdata.get("slack_channel_count", 0),
                "calendar_event_count": bdata.get("calendar_event_count", 0),
                "meeting_count": bdata.get("meeting_count", 0),
            }
        except Exception:
            pass

    return render_template("pages/dashboard.html",
        active_page="dashboard",
        health=get_health_status(),
        accounts=get_connected_accounts(),
        briefing=briefing,
        meta=meta,
        briefing_dates=get_briefing_dates(),
        current_date=date_str,
        current_date_display=now.strftime("%A, %B %d, %Y"),
        briefing_time=config.get("schedules", {}).get("morning_briefing", "07:30"),
        hour=now.hour,
    )


# ============================================================
# Integrations
# ============================================================

@app.route("/integrations")
def integrations():
    config = load_config()
    accounts = get_connected_accounts()

    # Get uploaded context files
    context_files = []
    context_websites = []
    context_dir = PROJECT_DIR / "config" / "context"
    if context_dir.exists():
        for f in sorted(context_dir.iterdir()):
            if f.name == "websites.txt":
                context_websites = [line.strip() for line in f.read_text().splitlines() if line.strip()]
            elif f.is_file():
                size = f.stat().st_size
                if size > 1024 * 1024:
                    size_str = f"{size / (1024*1024):.1f} MB"
                elif size > 1024:
                    size_str = f"{size / 1024:.0f} KB"
                else:
                    size_str = f"{size} bytes"
                context_files.append({"name": f.name, "size": size_str})

    return render_template("pages/integrations.html",
        active_page="integrations",
        accounts=accounts,
        context_files=context_files,
        context_websites=context_websites,
        google_client=google_client_exists(),
        ms_client=ms_client_exists(),
        slack_client=slack_client_exists(),
        zoom_client=zoom_client_exists(),
        granola_connected=any(a.get("type") == "granola" for a in accounts),
        tailscale_connected=_check_tailscale(),
        ms_connected=any(a.get("type") == "microsoft" for a in accounts),
        cloud_ai_set=bool(os.environ.get(config.get("ai", {}).get("cloud_api_key_env", "ANTHROPIC_API_KEY"))),
        email_connected=any("gmail" in a.get("services", []) or "outlook_email" in a.get("services", []) for a in accounts),
        calendar_connected=any("calendar" in a.get("services", []) or "outlook_calendar" in a.get("services", []) for a in accounts),
        telegram_set=_is_telegram_set(),
        notifications_enabled=_is_notifications_enabled(),
        ai_email=config.get("ai_email", ""),
        briefing_time=config.get("schedules", {}).get("morning_briefing", "07:30"),
        hw_local=_hw_rec.get("local_percentage", 0),
        hw_cloud=_hw_rec.get("cloud_percentage", 0),
        hw_ram=_hw_info.get("ram_gb", 0),
        hw_requires_cloud=_hw_rec.get("requires_api_key", False),
        hw_tier_name=_hw_rec.get("tier_name", "Unknown"),
    )


# ============================================================
# Briefings
# ============================================================

@app.route("/briefings")
@app.route("/briefings/<date>")
def briefings(date=None):
    dates = get_briefing_dates()
    current_date = date or (dates[0]["date"] if dates else datetime.now().strftime("%Y-%m-%d"))

    briefing_html = None
    selected_display = ""
    html_path = BRIEFINGS_DIR / f"{current_date}.html"
    if html_path.exists():
        with open(html_path) as f:
            briefing_html = f.read()
        try:
            dt = datetime.strptime(current_date, "%Y-%m-%d")
            selected_display = dt.strftime("%A, %B %d, %Y")
        except ValueError:
            selected_display = current_date

    return render_template("pages/briefings.html",
        active_page="briefings",
        briefing_dates=dates,
        briefing_html=briefing_html,
        current_date=current_date,
        selected_display=selected_display,
    )


# ============================================================
# Health Check
# ============================================================

@app.route("/health")
def health():
    config = load_config()
    refresh = request.args.get("refresh")

    checks = []
    all_healthy = True
    last_check = None

    try:
        result = subprocess.run(
            [str(PROJECT_DIR / ".venv" / "bin" / "python3"), str(PROJECT_DIR / "scripts" / "health-check.py")],
            capture_output=True, text=True, timeout=30,
        )
        lines = (result.stdout + result.stderr).strip().split("\n")
        last_check = datetime.now().strftime("%H:%M:%S")

        for line in lines:
            if "OK:" in line:
                name = line.split("OK:")[1].split("—")[0].strip() if "OK:" in line else ""
                detail = line.split("—")[1].strip() if "—" in line else ""
                checks.append({"name": name, "status": "ok", "detail": detail})
            elif "FAIL:" in line:
                name = line.split("FAIL:")[1].split("—")[0].strip() if "FAIL:" in line else ""
                detail = line.split("—")[1].strip() if "—" in line else ""
                checks.append({"name": name, "status": "fail", "detail": detail})
                all_healthy = False
    except Exception as e:
        checks.append({"name": "Health Check Script", "status": "fail", "detail": str(e)})
        all_healthy = False

    schedules = config.get("schedules", {})

    return render_template("pages/health.html",
        active_page="health",
        checks=checks,
        all_healthy=all_healthy,
        last_check=last_check,
        briefing_time=schedules.get("morning_briefing", "07:30"),
        debrief_time=schedules.get("evening_debrief", "21:30"),
        weekly_time=schedules.get("weekly_rollup", "Sunday 19:00"),
    )


# ============================================================
# Preferences
# ============================================================

@app.route("/preferences")
def preferences():
    config = load_config()

    return render_template("pages/preferences.html",
        active_page="preferences",
        hw_model=_hw_info.get("mac_model", "Unknown"),
        hw_chip=_hw_info.get("chip", "Unknown"),
        hw_ram=_hw_info.get("ram_gb", 0),
        hw_tier=_hw_rec.get("tier_name", "Unknown"),
        hw_local=_hw_rec.get("local_percentage", 0),
        hw_cloud=_hw_rec.get("cloud_percentage", 0),
        briefing_time=config.get("schedules", {}).get("morning_briefing", "07:30"),
        debrief_time=config.get("schedules", {}).get("evening_debrief", "21:30"),
        weekly_time=config.get("schedules", {}).get("weekly_rollup", "Sunday 19:00"),
        timezone=config.get("timezone", "Not set"),
        ai_email=config.get("ai_email", ""),
        notifications_enabled=_is_notifications_enabled(),
        inference_url=config.get("ai", {}).get("inference_url", "Not configured"),
        cloud_ai_set=bool(os.environ.get(config.get("ai", {}).get("cloud_api_key_env", "ANTHROPIC_API_KEY"))),
    )


# ============================================================
# Dental Vertical
# ============================================================

@app.route("/dental/schedule")
def dental_schedule():
    return render_template("verticals/dental/schedule.html", active_page="dental-schedule")


@app.route("/dental/claims")
def dental_claims():
    return render_template("verticals/dental/claims.html", active_page="dental-claims")


@app.route("/dental/lab-cases")
def dental_lab_cases():
    return render_template("verticals/dental/lab-cases.html", active_page="dental-lab")


@app.route("/dental/briefing-demo")
def dental_briefing_demo():
    """Serve the dental demo briefing as a standalone page."""
    demo_path = BRIEFINGS_DIR / "dental-demo.html"
    if demo_path.exists():
        with open(demo_path) as f:
            return f.read()
    return "Demo briefing not found. Generate it first.", 404


# ============================================================
# Demo Mode Toggle
# ============================================================

DENTAL_DEMO_CONFIG = PROJECT_DIR / "config" / "dental-demo.json"

@app.route("/demo/dental")
def demo_dental_on():
    """Switch command center to dental demo mode."""
    if DENTAL_DEMO_CONFIG.exists():
        with open(DENTAL_DEMO_CONFIG) as f:
            dental_config = json.load(f)
        # Preserve existing AI and credential settings, overlay client/dental config
        config = load_config()
        config["client"] = dental_config["client"]
        config["dental"] = dental_config.get("dental", {})
        config["priorities"] = dental_config.get("priorities", config.get("priorities", []))
        config["watch_for"] = dental_config.get("watch_for", config.get("watch_for", []))
        config["_demo_mode"] = "dental"
        config["_original_client"] = config.get("_original_client") or {
            "name": "consultant",
            "type": "general"
        }
        save_config(config)
    return redirect("/")


@app.route("/demo/off")
def demo_off():
    """Switch back to normal mode."""
    config = load_config()
    original = config.pop("_original_client", {"name": "consultant", "type": "general"})
    config["client"] = original
    config.pop("_demo_mode", None)
    config.pop("dental", None)
    save_config(config)
    return redirect("/")


# ============================================================
# Setup Sub-Pages (all render templates now)
# ============================================================

@app.route("/setup/google-client")
def google_client_guide():
    return render_template("pages/setup/google-client.html", active_page="integrations", port=PORT)


@app.route("/setup/google-client/upload", methods=["POST"])
def upload_google_client():
    if "client_file" not in request.files:
        flash("No file uploaded", "error")
        return redirect(url_for("google_client_guide"))
    file = request.files["client_file"]
    if file.filename == "":
        flash("No file selected", "error")
        return redirect(url_for("google_client_guide"))
    try:
        content = json.loads(file.read())
        if "web" not in content and "installed" not in content:
            flash("Invalid Google OAuth client file. Expected 'web' or 'installed' key.", "error")
            return redirect(url_for("google_client_guide"))
        GOOGLE_CLIENT_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(GOOGLE_CLIENT_FILE, "w") as f:
            json.dump(content, f, indent=2)
        os.chmod(GOOGLE_CLIENT_FILE, 0o600)
        flash("Google OAuth client saved. You can now connect accounts.", "success")
        return redirect(url_for("integrations"))
    except json.JSONDecodeError:
        flash("Invalid JSON file", "error")
        return redirect(url_for("google_client_guide"))


@app.route("/setup/telegram")
def telegram_setup():
    return render_template("pages/setup/telegram.html", active_page="integrations")


@app.route("/setup/telegram/save", methods=["POST"])
def telegram_save():
    token = request.form.get("token", "").strip()
    user_id = request.form.get("user_id", "").strip()
    bot_username = request.form.get("bot_username", "").strip()
    if not token or ":" not in token:
        flash("Invalid bot token. It should look like 123456789:ABCdef...", "error")
        return redirect(url_for("telegram_setup"))
    if not user_id or not user_id.isdigit():
        flash("Invalid user ID. It should be a number.", "error")
        return redirect(url_for("telegram_setup"))
    # Save token to .env
    env_path = PROJECT_DIR / ".env"
    env_lines = []
    token_written = False
    if env_path.exists():
        with open(env_path) as f:
            for line in f:
                if line.strip().startswith("ARIA_TELEGRAM_TOKEN="):
                    env_lines.append(f"ARIA_TELEGRAM_TOKEN={token}\n")
                    token_written = True
                else:
                    env_lines.append(line)
    if not token_written:
        env_lines.append(f"\nARIA_TELEGRAM_TOKEN={token}\n")
    with open(env_path, "w") as f:
        f.writelines(env_lines)
    config = load_config()
    if "telegram" not in config:
        config["telegram"] = {}
    config["telegram"]["authorized_users"] = [int(user_id)]
    config["telegram"]["token_env"] = "ARIA_TELEGRAM_TOKEN"
    if bot_username:
        config["telegram"]["bot_username"] = bot_username
    save_config(config)
    subprocess.run(["pkill", "-f", "aria-telegram-bot"], capture_output=True)
    flash(f"Telegram bot configured! Bot will restart automatically.", "success")
    return redirect(url_for("integrations"))


@app.route("/setup/slack")
def slack_setup():
    return render_template("pages/setup/slack.html",
        active_page="integrations",
        slack_client=slack_client_exists(),
        SLACK_REDIRECT_URI=SLACK_REDIRECT_URI,
    )


@app.route("/setup/slack/save-client", methods=["POST"])
def slack_save_client():
    client_id = request.form.get("client_id", "").strip()
    client_secret = request.form.get("client_secret", "").strip()
    if not client_id or not client_secret:
        flash("Both Client ID and Client Secret are required", "error")
        return redirect(url_for("slack_setup"))
    slack_config = {
        "client_id": client_id,
        "client_secret": client_secret,
        "scopes": SLACK_SCOPES,
        "redirect_uri": SLACK_REDIRECT_URI,
    }
    SLACK_CLIENT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(SLACK_CLIENT_FILE, "w") as f:
        json.dump(slack_config, f, indent=2)
    os.chmod(SLACK_CLIENT_FILE, 0o600)
    flash("Slack credentials saved! Users can now connect with one click.", "success")
    return redirect(url_for("slack_setup"))


@app.route("/setup/outlook")
def outlook_setup():
    return render_template("pages/setup/outlook.html",
        active_page="integrations",
        ms_client=ms_client_exists(),
    )


@app.route("/setup/outlook/save", methods=["POST"])
def outlook_save_client():
    client_id = request.form.get("client_id", "").strip()
    client_secret = request.form.get("client_secret", "").strip()
    if not client_id or not client_secret:
        flash("Both Client ID and Client Secret are required", "error")
        return redirect(url_for("outlook_setup"))
    ms_config = {
        "client_id": client_id,
        "client_secret": client_secret,
        "authority": MS_AUTHORITY,
        "redirect_uri": MS_REDIRECT_URI,
        "scopes": MS_SCOPES,
    }
    MS_CLIENT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(MS_CLIENT_FILE, "w") as f:
        json.dump(ms_config, f, indent=2)
    os.chmod(MS_CLIENT_FILE, 0o600)
    flash("Microsoft OAuth credentials saved. You can now connect Outlook accounts.", "success")
    return redirect(url_for("outlook_setup"))


@app.route("/setup/zoom")
def zoom_setup():
    return render_template("pages/setup/zoom.html",
        active_page="integrations",
        zoom_client=zoom_client_exists(),
        ZOOM_REDIRECT_URI=ZOOM_REDIRECT_URI,
    )


@app.route("/setup/zoom/save-client", methods=["POST"])
def zoom_save_client():
    client_id = request.form.get("client_id", "").strip()
    client_secret = request.form.get("client_secret", "").strip()
    if not client_id or not client_secret:
        flash("Both Client ID and Client Secret are required", "error")
        return redirect(url_for("zoom_setup"))
    zoom_config = {"client_id": client_id, "client_secret": client_secret, "redirect_uri": ZOOM_REDIRECT_URI}
    ZOOM_CLIENT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(ZOOM_CLIENT_FILE, "w") as f:
        json.dump(zoom_config, f, indent=2)
    os.chmod(ZOOM_CLIENT_FILE, 0o600)
    flash("Zoom credentials saved!", "success")
    return redirect(url_for("zoom_setup"))


@app.route("/setup/granola")
def granola_setup():
    granola_cache = Path.home() / "Library" / "Application Support" / "Granola"
    return render_template("pages/setup/granola.html",
        active_page="integrations",
        granola_installed=granola_cache.exists(),
    )


@app.route("/setup/granola/save", methods=["POST"])
def granola_save():
    config = load_config()
    if "channels" not in config:
        config["channels"] = {}
    config["channels"]["meeting_notes"] = {"enabled": True, "provider": "granola"}
    save_config(config)
    creds = load_credentials()
    creds["accounts"] = [a for a in creds["accounts"] if a.get("type") != "granola"]
    creds["accounts"].append({
        "email": "Granola", "type": "granola", "services": ["meeting_notes"],
        "connected_at": datetime.now().isoformat(), "refresh_token": "local",
    })
    save_credentials(creds)
    flash("Granola connected! Meeting notes will be included in your briefings.", "success")
    return redirect(url_for("integrations"))


@app.route("/setup/calendly")
def calendly_setup():
    return render_template("pages/setup/calendly.html", active_page="integrations")


@app.route("/setup/calendly/save", methods=["POST"])
def calendly_save():
    token = request.form.get("token", "").strip()
    if not token:
        flash("Token is required", "error")
        return redirect(url_for("calendly_setup"))
    env_path = PROJECT_DIR / ".env"
    lines = []
    written = False
    if env_path.exists():
        with open(env_path) as f:
            for line in f:
                if line.strip().startswith("ARIA_CALENDLY_TOKEN="):
                    lines.append(f"ARIA_CALENDLY_TOKEN={token}\n")
                    written = True
                else:
                    lines.append(line)
    if not written:
        lines.append(f"\n# Calendly Personal Access Token\nARIA_CALENDLY_TOKEN={token}\n")
    with open(env_path, "w") as f:
        f.writelines(lines)
    config = load_config()
    if "channels" not in config:
        config["channels"] = {}
    config["channels"]["calendly"] = {"enabled": True, "token_env": "ARIA_CALENDLY_TOKEN"}
    save_config(config)
    creds = load_credentials()
    creds["accounts"].append({
        "email": "Calendly", "type": "calendly", "services": ["calendly"],
        "connected_at": datetime.now().isoformat(), "refresh_token": "configured",
    })
    save_credentials(creds)
    flash("Calendly connected!", "success")
    return redirect(url_for("integrations"))


@app.route("/setup/notion")
def notion_setup():
    return render_template("pages/setup/notion.html",
        active_page="integrations",
        notion_client=notion_client_exists(),
        NOTION_REDIRECT_URI=NOTION_REDIRECT_URI,
    )


@app.route("/setup/notion/save-client", methods=["POST"])
def notion_save_client():
    client_id = request.form.get("client_id", "").strip()
    client_secret = request.form.get("client_secret", "").strip()
    if not client_id or not client_secret:
        flash("Both OAuth Client ID and OAuth Client Secret are required", "error")
        return redirect(url_for("notion_setup"))
    notion_config = {"client_id": client_id, "client_secret": client_secret, "redirect_uri": NOTION_REDIRECT_URI}
    NOTION_CLIENT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(NOTION_CLIENT_FILE, "w") as f:
        json.dump(notion_config, f, indent=2)
    os.chmod(NOTION_CLIENT_FILE, 0o600)
    flash("Notion credentials saved! You can now connect with one click.", "success")
    return redirect(url_for("notion_setup"))


@app.route("/connect/notion")
def connect_notion():
    config = get_notion_client_config()
    if not config:
        flash("Set up Notion app credentials first", "error")
        return redirect(url_for("notion_setup"))
    import secrets as sec
    state = f"{PORT}_{sec.token_hex(8)}"
    session["notion_state"] = state
    params = {
        "client_id": config["client_id"],
        "redirect_uri": NOTION_REDIRECT_URI,
        "response_type": "code",
        "owner": "user",
        "state": state,
    }
    return redirect(f"https://api.notion.com/v1/oauth/authorize?{urlencode(params)}")


@app.route("/oauth/notion/complete")
def notion_complete():
    try:
        code = request.args.get("code")
        if not code:
            flash("No authorization code received from Notion", "error")
            return redirect(url_for("integrations"))
        config = get_notion_client_config()
        if not config:
            flash("Notion app not configured", "error")
            return redirect(url_for("integrations"))
        credentials = base64.b64encode(f"{config['client_id']}:{config['client_secret']}".encode()).decode()
        resp = http_requests.post("https://api.notion.com/v1/oauth/token", json={
            "grant_type": "authorization_code", "code": code, "redirect_uri": NOTION_REDIRECT_URI,
        }, headers={"Authorization": f"Basic {credentials}", "Content-Type": "application/json"}, timeout=15)
        data = resp.json()
        if "access_token" not in data:
            flash(f"Notion token error: {data.get('error', data.get('message', 'unknown'))}", "error")
            return redirect(url_for("integrations"))
        access_token = data["access_token"]
        workspace_name = data.get("workspace_name", "Unknown")
        workspace_id = data.get("workspace_id", "")
        # Save token to .env
        env_path = PROJECT_DIR / ".env"
        env_key = "ARIA_NOTION_TOKEN"
        lines = []
        written = False
        if env_path.exists():
            with open(env_path) as f:
                for line in f:
                    if line.strip().startswith(f"{env_key}="):
                        lines.append(f"{env_key}={access_token}\n")
                        written = True
                    else:
                        lines.append(line)
        if not written:
            lines.append(f"\n# Notion: {workspace_name}\n{env_key}={access_token}\n")
        with open(env_path, "w") as f:
            f.writelines(lines)
        # Update aria config
        aria_config = load_config()
        if "notion" not in aria_config:
            aria_config["notion"] = {}
        aria_config["notion"]["workspace_name"] = workspace_name
        aria_config["notion"]["workspace_id"] = workspace_id
        aria_config["notion"]["token_env"] = env_key
        save_config(aria_config)
        # Update credentials
        creds = load_credentials()
        creds["accounts"] = [a for a in creds["accounts"] if a.get("type") != "notion"]
        creds["accounts"].append({
            "email": f"Notion: {workspace_name}", "type": "notion", "services": ["notion"],
            "connected_at": datetime.now().isoformat(), "refresh_token": access_token,
        })
        save_credentials(creds)
        flash(f"Connected Notion workspace: {workspace_name}", "success")
        return redirect(url_for("integrations"))
    except Exception as e:
        flash(f"Notion connection error: {e}", "error")
        return redirect(url_for("integrations"))


@app.route("/setup/teams")
def teams_setup():
    return render_template("pages/setup/teams.html", active_page="integrations")


@app.route("/setup/teams/save", methods=["POST"])
def teams_save():
    config = load_config()
    if "channels" not in config:
        config["channels"] = {}
    config["channels"]["teams"] = {"enabled": True, "note": "Uses Microsoft OAuth connection"}
    save_config(config)
    flash("Teams monitoring enabled.", "success")
    return redirect(url_for("integrations"))


@app.route("/setup/cloud-ai")
def cloud_ai_setup():
    # Reload env
    if ENV_FILE.exists():
        with open(ENV_FILE) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, value = line.partition("=")
                    os.environ[key.strip()] = value.strip().strip("'\"")
    config = load_config()
    cloud_key_env = config.get("ai", {}).get("cloud_api_key_env", "ANTHROPIC_API_KEY")
    is_set = bool(os.environ.get(cloud_key_env))
    # Determine current provider from config
    cloud_url = config.get("ai", {}).get("cloud_url", "")
    if "openai.com" in cloud_url:
        cloud_provider = "openai"
    else:
        cloud_provider = "anthropic"
    return render_template("pages/setup/cloud-ai.html",
        active_page="integrations",
        cloud_ai_set=is_set,
        cloud_provider=cloud_provider,
        hw_ram=_hw_info.get("ram_gb", 0),
        hw_requires_cloud=_hw_rec.get("requires_api_key", False),
        hw_cloud=_hw_rec.get("cloud_percentage", 0),
        hw_tier_name=_hw_rec.get("tier_name", "Unknown"),
    )


CLOUD_PROVIDERS = {
    "anthropic": {
        "env_key": "ANTHROPIC_API_KEY",
        "cloud_url": "https://api.anthropic.com/v1/messages",
        "cloud_model": "claude-sonnet-4-5-20241022",
        "prefix": "sk-ant-",
        "label": "Anthropic (Claude)",
    },
    "openai": {
        "env_key": "OPENAI_API_KEY",
        "cloud_url": "https://api.openai.com/v1/chat/completions",
        "cloud_model": "gpt-4o",
        "prefix": "sk-",
        "label": "OpenAI (GPT)",
    },
}


@app.route("/setup/cloud-ai/save", methods=["POST"])
def cloud_ai_save():
    api_key = request.form.get("api_key", "").strip()
    provider = request.form.get("provider", "anthropic").strip()
    if provider not in CLOUD_PROVIDERS:
        provider = "anthropic"
    prov = CLOUD_PROVIDERS[provider]

    if not api_key or api_key == "configured":
        flash("Please enter a valid API key", "error")
        return redirect(url_for("cloud_ai_setup"))
    if not api_key.startswith(prov["prefix"]):
        flash(f"Invalid key format. {prov['label']} keys start with {prov['prefix']}", "error")
        return redirect(url_for("cloud_ai_setup"))

    env_key = prov["env_key"]
    env_path = PROJECT_DIR / ".env"
    lines = []
    written = False
    # Remove both old keys, write the new one
    if env_path.exists():
        with open(env_path) as f:
            for line in f:
                if line.strip().startswith("ANTHROPIC_API_KEY=") or line.strip().startswith("OPENAI_API_KEY="):
                    if line.strip().startswith(f"{env_key}="):
                        lines.append(f"{env_key}={api_key}\n")
                        written = True
                    # else: skip the other provider's old key
                else:
                    lines.append(line)
    if not written:
        lines.append(f"\n# {prov['label']} API Key (Enhanced AI)\n{env_key}={api_key}\n")
    with open(env_path, "w") as f:
        f.writelines(lines)
    os.environ[env_key] = api_key

    # Update aria.json with provider config
    config = load_config()
    if "ai" not in config:
        config["ai"] = {
            "inference_url": "http://localhost:11434/v1/chat/completions",
            "default_model": "qwen3:8b",
            "fast_model": "qwen3:4b",
            "timeout": 120,
        }
    config["ai"]["cloud_url"] = prov["cloud_url"]
    config["ai"]["cloud_model"] = prov["cloud_model"]
    config["ai"]["cloud_api_key_env"] = env_key
    config["ai"]["cloud_provider"] = provider
    save_config(config)

    flash(f"Enhanced AI enabled with {prov['label']}!", "success")
    return redirect(url_for("integrations"))


@app.route("/setup/ai-email")
def ai_email_setup():
    return render_template("pages/setup/ai-email.html", active_page="integrations")


@app.route("/setup/ai-email/save", methods=["POST"])
def ai_email_save():
    ai_email = request.form.get("ai_email", "").strip()
    if not ai_email or "@" not in ai_email:
        flash("Please enter a valid email address", "error")
        return redirect(url_for("ai_email_setup"))
    config = load_config()
    config["ai_email"] = ai_email
    save_config(config)
    env_path = PROJECT_DIR / ".env"
    lines = []
    smtp_set = False
    if env_path.exists():
        with open(env_path) as f:
            for line in f:
                if line.strip().startswith("ARIA_SMTP_USER="):
                    smtp_set = True
                lines.append(line)
    if not smtp_set:
        lines.append(f"\n# ARIA's sending email address\nARIA_SMTP_USER={ai_email}\n")
        with open(env_path, "w") as f:
            f.writelines(lines)
    flash(f"ARIA will send briefings from {ai_email}.", "success")
    return redirect(url_for("integrations"))


@app.route("/setup/remote-support")
def remote_support_setup():
    is_connected = _check_tailscale()
    tailscale_installed = False
    try:
        subprocess.run(["tailscale", "version"], capture_output=True, timeout=5)
        tailscale_installed = True
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    tailscale_ip = ""
    hostname = ""
    if is_connected:
        try:
            result = subprocess.run(["tailscale", "ip", "-4"], capture_output=True, text=True, timeout=5)
            tailscale_ip = result.stdout.strip()
            result2 = subprocess.run(["tailscale", "status", "--json"], capture_output=True, text=True, timeout=5)
            data = json.loads(result2.stdout)
            hostname = data.get("Self", {}).get("HostName", "")
        except Exception:
            pass
    return render_template("pages/setup/remote-support.html",
        active_page="integrations",
        is_connected=is_connected,
        tailscale_installed=tailscale_installed,
        tailscale_ip=tailscale_ip,
        hostname=hostname,
    )


@app.route("/setup/notifications")
def notifications_setup():
    can_read = _is_notifications_enabled()
    python_path = str(PROJECT_DIR / ".venv" / "bin" / "python3")
    real_python = os.path.realpath(python_path)
    return render_template("pages/setup/notifications.html",
        active_page="integrations",
        can_read=can_read,
        real_python=real_python,
    )


# ============================================================
# OAuth Flows (unchanged logic, just redirect to /integrations)
# ============================================================

@app.route("/connect/google")
def connect_google():
    if not google_client_exists():
        flash("Set up Google OAuth client first", "error")
        return redirect(url_for("google_client_guide"))
    scope_param = request.args.get("scope", "all")
    scopes = GMAIL_SCOPES if scope_param == "email" else CALENDAR_SCOPES if scope_param == "calendar" else ALL_SCOPES
    try:
        flow = Flow.from_client_secrets_file(str(GOOGLE_CLIENT_FILE), scopes=ALL_SCOPES, redirect_uri=REDIRECT_URI)
        auth_url, state = flow.authorization_url(access_type="offline", include_granted_scopes="true", prompt="consent")
        session["oauth_state"] = state
        session["oauth_scopes"] = scopes
        session["oauth_code_verifier"] = flow.code_verifier
        return redirect(auth_url)
    except Exception as e:
        flash(f"OAuth error: {e}", "error")
        return redirect(url_for("integrations"))


@app.route("/oauth/google/callback")
def google_callback():
    try:
        scopes = session.get("oauth_scopes", ALL_SCOPES)
        code_verifier = session.get("oauth_code_verifier")
        flow = Flow.from_client_secrets_file(str(GOOGLE_CLIENT_FILE), scopes=ALL_SCOPES, redirect_uri=REDIRECT_URI)
        flow.code_verifier = code_verifier
        flow.fetch_token(authorization_response=request.url)
        credentials = flow.credentials

        email = "unknown"
        if credentials.id_token:
            import google.auth.transport.requests
            from google.oauth2 import id_token as id_token_module
            try:
                info = id_token_module.verify_oauth2_token(
                    credentials.id_token, google.auth.transport.requests.Request(), credentials.client_id)
                email = info.get("email", "unknown")
            except Exception:
                pass
        if email == "unknown":
            try:
                from googleapiclient.discovery import build
                service = build("gmail", "v1", credentials=credentials)
                profile = service.users().getProfile(userId="me").execute()
                email = profile.get("emailAddress", "unknown")
            except Exception:
                pass

        services = []
        granted = credentials.scopes or scopes
        if any("gmail" in s for s in granted):
            services.append("gmail")
        if any("calendar" in s for s in granted):
            services.append("calendar")

        creds_data = load_credentials()
        existing = next((a for a in creds_data["accounts"] if a.get("email") == email), None)
        if existing:
            existing["access_token"] = credentials.token
            existing["refresh_token"] = credentials.refresh_token or existing.get("refresh_token")
            existing["token_uri"] = credentials.token_uri
            existing["client_id"] = credentials.client_id
            existing["client_secret"] = credentials.client_secret
            existing["scopes"] = list(credentials.scopes or scopes)
            for s in services:
                if s not in existing["services"]:
                    existing["services"].append(s)
            existing["updated_at"] = datetime.now().isoformat()
        else:
            creds_data["accounts"].append({
                "email": email, "type": "google", "services": services,
                "access_token": credentials.token, "refresh_token": credentials.refresh_token,
                "token_uri": credentials.token_uri, "client_id": credentials.client_id,
                "client_secret": credentials.client_secret,
                "scopes": list(credentials.scopes or scopes),
                "connected_at": datetime.now().isoformat(),
            })
        save_credentials(creds_data)

        config = load_config()
        if "channels" not in config:
            config["channels"] = {}
        if "email_accounts" not in config["channels"]:
            config["channels"]["email_accounts"] = []
        if "calendar_accounts" not in config["channels"]:
            config["channels"]["calendar_accounts"] = []
        if "gmail" in services:
            if not any(a["address"] == email for a in config["channels"]["email_accounts"]):
                config["channels"]["email_accounts"].append({"address": email, "provider": "gmail", "credential_id": email})
        if "calendar" in services:
            if not any(a["name"] == email for a in config["channels"]["calendar_accounts"]):
                config["channels"]["calendar_accounts"].append({"name": email, "provider": "google", "credential_id": email})
        save_config(config)

        flash(f"Connected {email} ({', '.join(services)})", "success")
        return redirect(url_for("integrations"))
    except Exception as e:
        flash(f"OAuth callback error: {e}", "error")
        return redirect(url_for("integrations"))


@app.route("/disconnect/<int:index>")
def disconnect(index):
    creds = load_credentials()
    if 0 <= index < len(creds.get("accounts", [])):
        removed = creds["accounts"].pop(index)
        save_credentials(creds)
        flash(f"Disconnected {removed.get('email', 'account')}", "info")
    return redirect(url_for("integrations"))


@app.route("/connect/microsoft")
def connect_microsoft():
    ms_app = get_ms_app()
    if not ms_app:
        flash("Set up Microsoft OAuth credentials first", "error")
        return redirect(url_for("outlook_setup"))
    auth_url = ms_app.get_authorization_request_url(scopes=MS_SCOPES, redirect_uri=MS_REDIRECT_URI)
    return redirect(auth_url)


@app.route("/oauth/microsoft/callback")
def microsoft_callback():
    try:
        code = request.args.get("code")
        if not code:
            error = request.args.get("error_description", request.args.get("error", "Unknown error"))
            flash(f"Microsoft OAuth error: {error}", "error")
            return redirect(url_for("integrations"))
        ms_app = get_ms_app()
        if not ms_app:
            flash("Microsoft OAuth not configured", "error")
            return redirect(url_for("integrations"))
        result = ms_app.acquire_token_by_authorization_code(code, scopes=MS_SCOPES, redirect_uri=MS_REDIRECT_URI)
        if "error" in result:
            flash(f"Microsoft token error: {result.get('error_description', result['error'])}", "error")
            return redirect(url_for("integrations"))
        email = result.get("id_token_claims", {}).get("preferred_username", "unknown")
        services = ["outlook_email", "outlook_calendar"]
        creds_data = load_credentials()
        ms_config = get_ms_client_config()
        existing = next((a for a in creds_data["accounts"] if a.get("email") == email and a.get("type") == "microsoft"), None)
        if existing:
            existing["access_token"] = result.get("access_token")
            existing["refresh_token"] = result.get("refresh_token", existing.get("refresh_token"))
            existing["updated_at"] = datetime.now().isoformat()
        else:
            creds_data["accounts"].append({
                "email": email, "type": "microsoft", "services": services,
                "access_token": result.get("access_token"), "refresh_token": result.get("refresh_token"),
                "client_id": ms_config["client_id"], "client_secret": ms_config["client_secret"],
                "authority": MS_AUTHORITY, "scopes": MS_SCOPES,
                "connected_at": datetime.now().isoformat(),
            })
        save_credentials(creds_data)
        config = load_config()
        if "channels" not in config:
            config["channels"] = {}
        if "email_accounts" not in config["channels"]:
            config["channels"]["email_accounts"] = []
        if not any(a["address"] == email for a in config["channels"]["email_accounts"]):
            config["channels"]["email_accounts"].append({"address": email, "provider": "outlook", "credential_id": email})
        save_config(config)
        flash(f"Connected {email} (Outlook email + calendar)", "success")
        return redirect(url_for("integrations"))
    except Exception as e:
        flash(f"Microsoft OAuth error: {e}", "error")
        return redirect(url_for("integrations"))


@app.route("/connect/slack")
def connect_slack():
    config = get_slack_client_config()
    if not config:
        flash("Set up Slack app credentials first", "error")
        return redirect(url_for("slack_setup"))
    import secrets as sec
    state = f"{PORT}_{sec.token_hex(8)}"
    session["slack_state"] = state
    params = {"client_id": config["client_id"], "scope": SLACK_SCOPES, "redirect_uri": SLACK_REDIRECT_URI, "state": state}
    return redirect(f"https://slack.com/oauth/v2/authorize?{urlencode(params)}")


@app.route("/oauth/slack/complete")
def slack_complete():
    try:
        code = request.args.get("code")
        if not code:
            flash("No authorization code received from Slack", "error")
            return redirect(url_for("integrations"))
        config = get_slack_client_config()
        if not config:
            flash("Slack app not configured", "error")
            return redirect(url_for("integrations"))
        resp = http_requests.post("https://slack.com/api/oauth.v2.access", data={
            "client_id": config["client_id"], "client_secret": config["client_secret"],
            "code": code, "redirect_uri": SLACK_REDIRECT_URI,
        }, timeout=15)
        data = resp.json()
        if not data.get("ok"):
            flash(f"Slack error: {data.get('error', 'unknown')}", "error")
            return redirect(url_for("integrations"))
        bot_token = data.get("access_token", "")
        team_name = data.get("team", {}).get("name", "Unknown")
        team_id = data.get("team", {}).get("id", "")
        env_path = PROJECT_DIR / ".env"
        safe_name = team_name.lower().replace(" ", "_").replace("-", "_")
        env_key = f"ARIA_SLACK_TOKEN_{safe_name}"
        lines = []
        written = False
        if env_path.exists():
            with open(env_path) as f:
                for line in f:
                    if line.strip().startswith(f"{env_key}="):
                        lines.append(f"{env_key}={bot_token}\n")
                        written = True
                    else:
                        lines.append(line)
        if not written:
            lines.append(f"\n# Slack: {team_name}\n{env_key}={bot_token}\n")
        with open(env_path, "w") as f:
            f.writelines(lines)
        aria_config = load_config()
        if "channels" not in aria_config:
            aria_config["channels"] = {}
        aria_config["channels"]["slack"] = {"enabled": True, "workspace_name": team_name, "team_id": team_id, "token_env": env_key}
        save_config(aria_config)
        creds = load_credentials()
        creds["accounts"] = [a for a in creds["accounts"] if not (a.get("type") == "slack" and a.get("team_id") == team_id)]
        creds["accounts"].append({
            "email": f"Slack: {team_name}", "type": "slack", "services": ["slack"],
            "team_id": team_id, "connected_at": datetime.now().isoformat(), "refresh_token": bot_token,
        })
        save_credentials(creds)
        flash(f"Connected Slack workspace: {team_name}", "success")
        return redirect(url_for("integrations"))
    except Exception as e:
        flash(f"Slack connection error: {e}", "error")
        return redirect(url_for("integrations"))


@app.route("/connect/zoom")
def connect_zoom():
    config = get_zoom_client_config()
    if not config:
        flash("Set up Zoom app credentials first", "error")
        return redirect(url_for("zoom_setup"))
    import secrets as sec
    state = f"{PORT}_{sec.token_hex(8)}"
    session["zoom_state"] = state
    params = {"response_type": "code", "client_id": config["client_id"], "redirect_uri": ZOOM_REDIRECT_URI, "state": state}
    return redirect(f"https://zoom.us/oauth/authorize?{urlencode(params)}")


@app.route("/oauth/zoom/complete")
def zoom_complete():
    try:
        code = request.args.get("code")
        if not code:
            flash("No authorization code received from Zoom", "error")
            return redirect(url_for("integrations"))
        config = get_zoom_client_config()
        if not config:
            flash("Zoom app not configured", "error")
            return redirect(url_for("integrations"))
        credentials = base64.b64encode(f"{config['client_id']}:{config['client_secret']}".encode()).decode()
        resp = http_requests.post("https://zoom.us/oauth/token", data={
            "grant_type": "authorization_code", "code": code, "redirect_uri": ZOOM_REDIRECT_URI,
        }, headers={"Authorization": f"Basic {credentials}"}, timeout=15)
        data = resp.json()
        if "access_token" not in data:
            flash(f"Zoom token error: {data.get('reason', data.get('error', 'unknown'))}", "error")
            return redirect(url_for("integrations"))
        access_token = data["access_token"]
        refresh_token = data.get("refresh_token", "")
        user_resp = http_requests.get("https://api.zoom.us/v2/users/me",
            headers={"Authorization": f"Bearer {access_token}"}, timeout=10)
        email = "Zoom User"
        if user_resp.status_code == 200:
            email = user_resp.json().get("email", "Zoom User")
        creds = load_credentials()
        creds["accounts"] = [a for a in creds["accounts"] if a.get("type") != "zoom"]
        creds["accounts"].append({
            "email": f"Zoom: {email}", "type": "zoom", "services": ["zoom"],
            "access_token": access_token, "refresh_token": refresh_token,
            "client_id": config["client_id"], "client_secret": config["client_secret"],
            "connected_at": datetime.now().isoformat(),
        })
        save_credentials(creds)
        aria_config = load_config()
        if "channels" not in aria_config:
            aria_config["channels"] = {}
        aria_config["channels"]["zoom"] = {"enabled": True, "email": email}
        save_config(aria_config)
        flash(f"Connected Zoom: {email}", "success")
        return redirect(url_for("integrations"))
    except Exception as e:
        flash(f"Zoom connection error: {e}", "error")
        return redirect(url_for("integrations"))


# ============================================================
# Chat API
# ============================================================

# Import the AI module
try:
    import importlib.util as _ilu
    _ai_spec = _ilu.spec_from_file_location("aria_ai", str(PROJECT_DIR / "scripts" / "aria_ai.py"))
    _ai_mod = _ilu.module_from_spec(_ai_spec)
    _ai_spec.loader.exec_module(_ai_mod)
    aria_ai_chat = _ai_mod.chat
except Exception as _e:
    print(f"Warning: Could not load aria_ai module: {_e}")
    aria_ai_chat = None


CHAT_SYSTEM_PROMPT = """You are ARIA, an AI assistant running locally on the user's computer. You help them understand their daily briefing, emails, calendar, and commitments.

Keep responses concise and actionable. Use short paragraphs. If asked about something in their briefing or inbox, reference specific items. If asked to do something you can't (like send an email), say so clearly and suggest what they can do instead.

Context about today:
- Date: {date}
- Emails ingested: {email_count}
- Calendar events: {event_count}
- Slack messages: {slack_count}
- Notifications: {notif_count}
"""


@app.route("/api/chat", methods=["POST"])
def api_chat():
    """Chat endpoint for the dashboard AI assistant."""
    if not aria_ai_chat:
        return json.dumps({"error": "AI module not available"}), 500, {"Content-Type": "application/json"}

    data = request.get_json()
    message = data.get("message", "").strip()
    if not message:
        return json.dumps({"error": "Empty message"}), 400, {"Content-Type": "application/json"}

    # Build context
    stats = get_inbox_stats()
    now = datetime.now()
    system = CHAT_SYSTEM_PROMPT.format(
        date=now.strftime("%A, %B %d, %Y"),
        email_count=stats.get("emails", 0),
        event_count=stats.get("calendar", 0),
        slack_count=stats.get("slack", 0),
        notif_count=stats.get("notifications", 0),
    )

    # Include today's briefing JSON for context if available
    briefing_json = BRIEFINGS_DIR / f"{now.strftime('%Y-%m-%d')}.json"
    if briefing_json.exists():
        try:
            with open(briefing_json) as f:
                bdata = json.load(f)
            sections = bdata.get("sections", {})
            system += f"\n\nToday's briefing summary:\n- BLUF: {sections.get('bluf', 'N/A')}\n"
            for key in ["decisions_needed", "commitments_you_owe", "waiting_on_others", "project_pulse"]:
                items = sections.get(key, [])
                if items:
                    system += f"- {key.replace('_', ' ').title()}: {'; '.join(items[:5])}\n"
        except Exception:
            pass

    try:
        response = aria_ai_chat(system, message, escalate=True, timeout=30)
        if response:
            return json.dumps({"response": response}), 200, {"Content-Type": "application/json"}
        else:
            return json.dumps({"response": "I couldn't generate a response. The local AI may be offline. Check the Health page."}), 200, {"Content-Type": "application/json"}
    except Exception as e:
        return json.dumps({"error": str(e)}), 500, {"Content-Type": "application/json"}


# ============================================================
# Initial Data Sync (onboarding processing step)
# ============================================================

import threading

_sync_state = {"running": False, "done": False, "tasks": {}, "summary": ""}

SYNC_SCRIPTS = [
    {"key": "email", "name": "Gmail & Outlook", "scripts": [
        {"path": "scripts/email-sync.py", "label": "Gmail"},
        {"path": "scripts/outlook-sync.py", "label": "Outlook"},
    ]},
    {"key": "calendar", "name": "Calendar", "scripts": [
        {"path": "scripts/calendar-sync.py", "label": "Google Calendar"},
    ]},
    {"key": "slack", "name": "Slack", "scripts": []},  # Handled by n8n
    {"key": "notifications", "name": "Messages", "scripts": [
        {"path": "scripts/notification-sync.py", "label": "Notifications"},
    ]},
    {"key": "granola", "name": "Meeting Notes", "scripts": [
        {"path": "scripts/granola-sync.py", "label": "Granola"},
    ]},
    {"key": "teams", "name": "Teams", "scripts": [
        {"path": "scripts/teams-sync.py", "label": "Microsoft Teams"},
    ]},
    {"key": "analyze", "name": "AI Analysis", "scripts": [
        {"path": "scripts/generate-briefing.py", "label": "Briefing"},
    ]},
]


def _run_sync_task(key, scripts):
    """Run sync scripts for a task, updating state as we go."""
    global _sync_state
    if not scripts:
        _sync_state["tasks"][key] = {"status": "skipped", "result": "Not connected"}
        return

    _sync_state["tasks"][key] = {"status": "running", "detail": "Starting..."}
    results = []
    for script_info in scripts:
        script_path = PROJECT_DIR / script_info["path"]
        if not script_path.exists():
            results.append(f"{script_info['label']}: script not found")
            continue
        _sync_state["tasks"][key]["detail"] = f"Running {script_info['label']}..."
        try:
            result = subprocess.run(
                [str(PROJECT_DIR / ".venv" / "bin" / "python3"), str(script_path)],
                capture_output=True, text=True, timeout=300,
                cwd=str(PROJECT_DIR),
            )
            # Extract counts from output
            output = result.stdout + result.stderr
            for line in output.split("\n"):
                if any(word in line.lower() for word in ["saved", "synced", "processed", "fetched", "found"]):
                    results.append(line.strip().split("]")[-1].strip() if "]" in line else line.strip())
                    break
            else:
                if result.returncode == 0:
                    results.append(f"{script_info['label']}: done")
                else:
                    results.append(f"{script_info['label']}: error")
        except subprocess.TimeoutExpired:
            results.append(f"{script_info['label']}: timeout")
        except Exception as e:
            results.append(f"{script_info['label']}: {str(e)[:50]}")

    result_text = "; ".join(results) if results else "Done"
    has_error = any("error" in r.lower() or "timeout" in r.lower() for r in results)
    _sync_state["tasks"][key] = {
        "status": "error" if has_error else "done",
        "result": result_text,
    }


def _run_full_sync():
    """Run all sync tasks sequentially in a background thread."""
    global _sync_state
    _sync_state = {"running": True, "done": False, "tasks": {}, "summary": ""}

    # Initialize all tasks
    for task in SYNC_SCRIPTS:
        _sync_state["tasks"][task["key"]] = {"status": "pending", "detail": "Waiting..."}

    # Check which services are connected
    config = load_config()
    creds = load_credentials()
    accounts = creds.get("accounts", [])
    channels = config.get("channels", {})

    has_google = any(a.get("type") == "google" for a in accounts)
    has_microsoft = any(a.get("type") == "microsoft" for a in accounts)
    has_slack = channels.get("slack", {}).get("enabled", False)
    has_granola = channels.get("meeting_notes", {}).get("enabled", False)
    has_teams = channels.get("teams", {}).get("enabled", False)

    # Run each task
    for task in SYNC_SCRIPTS:
        key = task["key"]
        scripts = task["scripts"]

        # Skip tasks where the service isn't connected
        if key == "email" and not has_google and not has_microsoft:
            scripts = []
        elif key == "email" and not has_microsoft:
            scripts = [s for s in scripts if "outlook" not in s["path"]]
        elif key == "email" and not has_google:
            scripts = [s for s in scripts if "email-sync" not in s["path"]]
        elif key == "calendar" and not has_google:
            scripts = []
        elif key == "slack":
            if has_slack:
                _sync_state["tasks"][key] = {"status": "done", "result": "Synced via n8n"}
            else:
                _sync_state["tasks"][key] = {"status": "skipped", "result": "Not connected"}
            continue
        elif key == "granola" and not has_granola:
            scripts = []
        elif key == "teams" and not has_teams:
            scripts = []
        elif key == "notifications":
            pass  # Always try — depends on Full Disk Access, not a connection

        _run_sync_task(key, scripts)

    # Build summary
    done_count = sum(1 for t in _sync_state["tasks"].values() if t["status"] == "done")
    skip_count = sum(1 for t in _sync_state["tasks"].values() if t["status"] == "skipped")
    err_count = sum(1 for t in _sync_state["tasks"].values() if t["status"] == "error")

    parts = []
    if done_count:
        parts.append(f"{done_count} sources synced")
    if skip_count:
        parts.append(f"{skip_count} skipped (not connected)")
    if err_count:
        parts.append(f"{err_count} had errors")
    _sync_state["summary"] = ". ".join(parts) + ". Ready for your interview."
    _sync_state["done"] = True
    _sync_state["running"] = False


@app.route("/setup/initial-sync")
def initial_sync_page():
    return render_template("pages/setup/initial-sync.html", active_page="integrations")


@app.route("/api/initial-sync", methods=["POST"])
def api_initial_sync():
    global _sync_state
    if _sync_state.get("running"):
        return json.dumps({"status": "already_running"}), 200, {"Content-Type": "application/json"}
    thread = threading.Thread(target=_run_full_sync, daemon=True)
    thread.start()
    return json.dumps({"status": "started"}), 200, {"Content-Type": "application/json"}


@app.route("/api/sync-status")
def api_sync_status():
    done_count = sum(1 for t in _sync_state.get("tasks", {}).values() if t.get("status") in ("done", "skipped", "error"))
    total = len(_sync_state.get("tasks", {})) or 1
    return json.dumps({
        "tasks": _sync_state.get("tasks", {}),
        "done": _sync_state.get("done", False),
        "overall": f"Processing... {done_count}/{total} complete",
        "summary": _sync_state.get("summary", ""),
    }), 200, {"Content-Type": "application/json"}


# ============================================================
# Onboarding Interview
# ============================================================

@app.route("/setup/context/upload", methods=["POST"])
def context_upload():
    """Handle document and website uploads for onboarding context."""
    context_dir = PROJECT_DIR / "config" / "context"
    context_dir.mkdir(parents=True, exist_ok=True)

    uploaded = []

    # Handle file uploads
    files = request.files.getlist("files")
    for f in files:
        if f.filename:
            safe_name = f.filename.replace("/", "_").replace("\\", "_")
            save_path = context_dir / safe_name
            f.save(str(save_path))
            uploaded.append(safe_name)

    # Handle website URLs
    websites = request.form.get("websites", "").strip()
    if websites:
        urls = [u.strip() for u in websites.split("\n") if u.strip()]
        if urls:
            urls_file = context_dir / "websites.txt"
            with open(urls_file, "a") as wf:
                for url in urls:
                    wf.write(url + "\n")
            uploaded.append(f"{len(urls)} website(s)")

    if uploaded:
        flash(f"Uploaded: {', '.join(uploaded)}. ARIA will use this context in your briefings.", "success")
    else:
        flash("No files or URLs provided.", "info")

    return redirect(url_for("integrations"))


@app.route("/setup/context/remove/<filename>")
def context_remove(filename):
    """Remove an uploaded context file."""
    safe_name = filename.replace("/", "").replace("\\", "").replace("..", "")
    context_path = PROJECT_DIR / "config" / "context" / safe_name
    if context_path.exists() and context_path.is_file():
        context_path.unlink()
        flash(f"Removed {safe_name}", "info")
    return redirect(url_for("integrations"))


@app.route("/setup/interview")
def onboard_interview():
    context = _get_inbox_context()
    return render_template("pages/setup/onboard-interview.html",
        active_page="integrations",
        inbox_context=context,
    )


@app.route("/api/interview-context")
def api_interview_context():
    """Return what ARIA has already ingested, for the interview to reference."""
    context = {"senders": [], "projects": [], "slack_channels": [], "calendar_events": [], "email_count": 0}

    for days_ago in range(7):
        d = (datetime.now() - timedelta(days=days_ago)).strftime("%Y-%m-%d")
        # Emails
        path = INBOX_DIR / f"emails-{d}.json"
        if path.exists():
            try:
                with open(path) as f:
                    emails = json.load(f)
                context["email_count"] += len(emails)
                for e in emails:
                    sender = e.get("from", "").split("<")[0].strip().strip('"')
                    proj = e.get("detected_project")
                    if sender and sender not in context["senders"]:
                        context["senders"].append(sender)
                    if proj and proj != "None" and proj not in context["projects"]:
                        context["projects"].append(proj)
            except Exception:
                pass
        # Slack
        path = INBOX_DIR / f"slack-{d}.json"
        if path.exists():
            try:
                with open(path) as f:
                    slack = json.load(f)
                for ch in slack:
                    name = ch.get("channel", "")
                    if name and name not in context["slack_channels"]:
                        context["slack_channels"].append(name)
            except Exception:
                pass
        # Calendar
        path = INBOX_DIR / f"calendar-{d}.json"
        if path.exists():
            try:
                with open(path) as f:
                    cal = json.load(f)
                for event in cal:
                    title = event.get("summary", event.get("title", ""))
                    if title and title not in context["calendar_events"]:
                        context["calendar_events"].append(title)
            except Exception:
                pass

    # Trim to reasonable sizes
    context["senders"] = context["senders"][:20]
    context["calendar_events"] = context["calendar_events"][:10]
    return json.dumps(context), 200, {"Content-Type": "application/json"}


INTERVIEW_SYSTEM = """You are ARIA, setting up for a new user. You have already ingested their recent communications. Based on what you found AND their answers to onboarding questions, generate a structured profile.

Return ONLY valid JSON with these fields:
{
  "client_name": "Their name",
  "client_type": "dental|legal|accounting|consulting|general",
  "known_projects": ["Project1", "Project2"],
  "client_tiers": {"active": ["Client1"], "product": [], "on_hold": []},
  "priorities": ["Priority 1", "Priority 2"],
  "watch_for": ["Thing to flag 1", "Thing to flag 2"],
  "key_contacts": [{"name": "Name", "role": "Their role", "project": "Related project"}],
  "communication_style": "Brief description of how they communicate",
  "summary": "2-3 sentence summary of who they are and what ARIA should focus on. Written directly to them."
}

Infer client_type from their description. If they mention dental/teeth/patients use "dental". If they mention law/cases/legal use "legal". Otherwise "general" or "consulting"."""


def _get_inbox_context():
    """Build a summary of what ARIA has already ingested for the interview."""
    context_parts = []
    date_str = datetime.now().strftime("%Y-%m-%d")

    # Check recent emails (today and yesterday)
    senders = set()
    projects = set()
    for d in [date_str, (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")]:
        path = INBOX_DIR / f"emails-{d}.json"
        if path.exists():
            try:
                with open(path) as f:
                    emails = json.load(f)
                for e in emails:
                    sender = e.get("from", "").split("<")[0].strip().strip('"')
                    if sender:
                        senders.add(sender)
                    proj = e.get("detected_project")
                    if proj and proj != "None":
                        projects.add(proj)
            except Exception:
                pass

    # Check Slack
    for d in [date_str, (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")]:
        path = INBOX_DIR / f"slack-{d}.json"
        if path.exists():
            try:
                with open(path) as f:
                    slack = json.load(f)
                for ch in slack:
                    channel = ch.get("channel", "")
                    if channel:
                        context_parts.append(f"Slack channel: #{channel}")
            except Exception:
                pass

    # Check calendar
    for d in [date_str, (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")]:
        path = INBOX_DIR / f"calendar-{d}.json"
        if path.exists():
            try:
                with open(path) as f:
                    cal = json.load(f)
                for event in cal[:5]:
                    title = event.get("summary", event.get("title", ""))
                    if title:
                        context_parts.append(f"Calendar event: {title}")
            except Exception:
                pass

    if senders:
        context_parts.append(f"Email contacts seen: {', '.join(list(senders)[:15])}")
    if projects:
        context_parts.append(f"Projects detected in emails: {', '.join(projects)}")

    return "\n".join(context_parts) if context_parts else "No data ingested yet."


@app.route("/api/onboard-interview", methods=["POST"])
def api_onboard_interview():
    data = request.get_json()
    if not data:
        return json.dumps({"error": "No data"}), 400, {"Content-Type": "application/json"}

    inbox_context = _get_inbox_context()

    # Build the user's answers into a prompt
    user_msg = f"""Data ARIA has already ingested:
{inbox_context}

User's onboarding answers:
1. Role: {data.get('role', 'Not provided')}
2. Projects/Clients: {data.get('projects', 'Not provided')}
3. Priorities this week: {data.get('priorities', 'Not provided')}
4. Communication style: {data.get('channels', 'Not provided')}
5. Watch for: {data.get('preferences', 'Not provided')}

Generate their ARIA profile. Cross-reference their answers with the ingested data to build accurate project and contact lists."""

    profile = None
    if aria_ai_chat:
        try:
            response = aria_ai_chat(INTERVIEW_SYSTEM, user_msg, escalate=True, timeout=45)
            if response:
                json_match = __import__('re').search(r'\{[\s\S]*\}', response)
                if json_match:
                    profile = json.loads(json_match.group(0))
        except Exception:
            pass

    # Fallback: extract basics manually
    if not profile:
        profile = {
            "client_name": data.get("role", "").split(",")[0].strip().split(" ")[-1] if data.get("role") else "User",
            "client_type": "general",
            "known_projects": [p.strip() for p in data.get("projects", "").split(",") if p.strip()][:10],
            "client_tiers": {"active": [], "product": [], "on_hold": []},
            "priorities": [data.get("priorities", "")],
            "watch_for": [data.get("preferences", "")],
            "communication_style": data.get("channels", ""),
            "summary": "Profile created from onboarding. ARIA will learn more as it processes your communications.",
        }

    # Write to config
    config = load_config()
    if "client" not in config:
        config["client"] = {}
    config["client"]["name"] = profile.get("client_name", config.get("client", {}).get("name", ""))
    config["client"]["type"] = profile.get("client_type", "general")
    config["known_projects"] = profile.get("known_projects", config.get("known_projects", []))
    if profile.get("client_tiers"):
        config["client_tiers"] = profile["client_tiers"]
    if profile.get("priorities"):
        config["priorities"] = profile["priorities"]
    if profile.get("watch_for"):
        config["watch_for"] = profile["watch_for"]
    save_config(config)

    # Write Soul file
    soul_path = PROJECT_DIR / "config" / "soul.md"
    soul_content = f"""# ARIA Soul File
## Who You Are
{data.get('role', 'Not provided')}

## Projects & Clients
{data.get('projects', 'Not provided')}

## Priorities
{data.get('priorities', 'Not provided')}

## Communication Style
{data.get('channels', 'Not provided')}

## Watch For
{data.get('preferences', 'Not provided')}

---
*Generated during onboarding on {datetime.now().strftime('%Y-%m-%d')}. ARIA will update this as it learns.*
"""
    with open(soul_path, "w") as f:
        f.write(soul_content)

    return json.dumps({
        "summary": profile.get("summary", "Profile saved. ARIA is ready to start."),
        "client_type": profile.get("client_type", "general"),
    }), 200, {"Content-Type": "application/json"}


# ============================================================
# Inbox Detail API (for clickable stat cards)
# ============================================================

@app.route("/api/inbox/<source>")
def api_inbox(source):
    """Return today's inbox data for a given source."""
    date_str = request.args.get("date", datetime.now().strftime("%Y-%m-%d"))
    valid_sources = ["emails", "calendar", "slack", "notifications", "awaiting"]
    if source not in valid_sources:
        return json.dumps({"error": "Invalid source"}), 400, {"Content-Type": "application/json"}

    path = INBOX_DIR / f"{source}-{date_str}.json"
    if path.exists():
        try:
            with open(path) as f:
                data = json.load(f)
            return json.dumps({"source": source, "date": date_str, "count": len(data) if isinstance(data, list) else 1, "items": data}), 200, {"Content-Type": "application/json"}
        except Exception as e:
            return json.dumps({"error": str(e)}), 500, {"Content-Type": "application/json"}
    return json.dumps({"source": source, "date": date_str, "count": 0, "items": []}), 200, {"Content-Type": "application/json"}


# ============================================================
# Auto-Update API
# ============================================================
# Heartbeat / Remote Monitoring API
# ============================================================

try:
    _hb_spec = _ilu.spec_from_file_location("heartbeat", str(PROJECT_DIR / "scripts" / "heartbeat.py"))
    _hb_mod = _ilu.module_from_spec(_hb_spec)
    _hb_spec.loader.exec_module(_hb_mod)
    heartbeat_mod = _hb_mod
except Exception as _e:
    print(f"Warning: Could not load heartbeat module: {_e}")
    heartbeat_mod = None


@app.route("/api/heartbeat")
def api_heartbeat():
    """Returns current heartbeat status — for admin access via Tailscale."""
    if not heartbeat_mod:
        return json.dumps({"error": "Heartbeat module not available"}), 500, {"Content-Type": "application/json"}
    payload = heartbeat_mod.build_heartbeat()
    return json.dumps(payload, indent=2), 200, {"Content-Type": "application/json"}


@app.route("/api/heartbeat/send", methods=["POST"])
def api_heartbeat_send():
    """Trigger a heartbeat send manually."""
    if not heartbeat_mod:
        return json.dumps({"error": "Heartbeat module not available"}), 500, {"Content-Type": "application/json"}
    heartbeat_mod.send_heartbeat()
    return json.dumps({"status": "sent"}), 200, {"Content-Type": "application/json"}


# ============================================================
# Auto-Update API
# ============================================================

try:
    _upd_spec = _ilu.spec_from_file_location("auto_update", str(PROJECT_DIR / "scripts" / "auto-update.py"))
    _upd_mod = _ilu.module_from_spec(_upd_spec)
    _upd_spec.loader.exec_module(_upd_mod)
    auto_update = _upd_mod
except Exception as _e:
    print(f"Warning: Could not load auto_update module: {_e}")
    auto_update = None


@app.route("/api/update/check", methods=["POST"])
def api_update_check():
    if not auto_update:
        return json.dumps({"error": "Update module not available"}), 500, {"Content-Type": "application/json"}
    state = auto_update.check_for_updates()
    return json.dumps(state), 200, {"Content-Type": "application/json"}


@app.route("/api/update/apply", methods=["POST"])
def api_update_apply():
    if not auto_update:
        return json.dumps({"error": "Update module not available"}), 500, {"Content-Type": "application/json"}
    result = auto_update.apply_update()
    return json.dumps(result), 200, {"Content-Type": "application/json"}


@app.route("/api/update/status")
def api_update_status():
    if not auto_update:
        return json.dumps({}), 200, {"Content-Type": "application/json"}
    state = auto_update.load_state()
    return json.dumps(state), 200, {"Content-Type": "application/json"}


# ============================================================
# Email Actions API
# ============================================================

try:
    _ea_spec = _ilu.spec_from_file_location("email_actions", str(PROJECT_DIR / "scripts" / "email-actions.py"))
    _ea_mod = _ilu.module_from_spec(_ea_spec)
    _ea_spec.loader.exec_module(_ea_mod)
    email_actions = _ea_mod
except Exception as _e:
    print(f"Warning: Could not load email_actions module: {_e}")
    email_actions = None


@app.route("/api/email/archive", methods=["POST"])
def api_email_archive():
    if not email_actions:
        return json.dumps({"error": "Email actions not available"}), 500, {"Content-Type": "application/json"}
    data = request.get_json()
    result = email_actions.archive_email(data.get("message_id"), data.get("account"))
    return json.dumps(result), 200, {"Content-Type": "application/json"}


@app.route("/api/email/trash", methods=["POST"])
def api_email_trash():
    if not email_actions:
        return json.dumps({"error": "Email actions not available"}), 500, {"Content-Type": "application/json"}
    data = request.get_json()
    result = email_actions.trash_email(data.get("message_id"), data.get("account"))
    return json.dumps(result), 200, {"Content-Type": "application/json"}


@app.route("/api/email/label", methods=["POST"])
def api_email_label():
    if not email_actions:
        return json.dumps({"error": "Email actions not available"}), 500, {"Content-Type": "application/json"}
    data = request.get_json()
    result = email_actions.label_email(data.get("message_id"), data.get("label"), data.get("account"))
    return json.dumps(result), 200, {"Content-Type": "application/json"}


@app.route("/api/email/draft-reply", methods=["POST"])
def api_email_draft_reply():
    if not email_actions:
        return json.dumps({"error": "Email actions not available"}), 500, {"Content-Type": "application/json"}
    data = request.get_json()
    result = email_actions.generate_draft_reply(data.get("message_id"), data.get("account"))
    return json.dumps(result), 200, {"Content-Type": "application/json"}


@app.route("/api/email/feedback", methods=["POST"])
def api_email_feedback():
    if not email_actions:
        return json.dumps({"error": "Email actions not available"}), 500, {"Content-Type": "application/json"}
    data = request.get_json()
    result = email_actions.record_feedback(
        data.get("sender", ""),
        data.get("subject", ""),
        data.get("feedback", "not_important"),
        data.get("details", ""),
    )
    return json.dumps(result), 200, {"Content-Type": "application/json"}


@app.route("/api/email/preferences")
def api_email_preferences():
    if not email_actions:
        return json.dumps({"error": "Email actions not available"}), 500, {"Content-Type": "application/json"}
    prefs = email_actions.load_preferences()
    return json.dumps(prefs), 200, {"Content-Type": "application/json"}


# ============================================================
# Main
# ============================================================

if __name__ == "__main__":
    print(f"\n  ARIA Command Center")
    print(f"  Open: http://localhost:{PORT}\n")
    webbrowser.open(f"http://localhost:{PORT}")
    app.run(host="127.0.0.1", port=PORT, debug=False)
