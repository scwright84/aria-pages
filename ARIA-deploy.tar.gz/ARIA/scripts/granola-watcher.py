#!/usr/bin/env python3
"""
ARIA Granola Watcher
Watches the Granola cache file for new or updated meeting notes and transcripts.
Forwards them to n8n via webhook for processing.

Requires: Granola desktop app installed and logged in.
"""

import json
import time
import os
import sys
import hashlib
import requests
from datetime import datetime
from pathlib import Path

# --- Configuration ---

GRANOLA_CACHE = os.path.expanduser(
    "~/Library/Application Support/Granola/cache-v6.json"
)

N8N_WEBHOOK_URL = os.environ.get(
    "ARIA_GRANOLA_WEBHOOK_URL",
    "http://localhost:5678/webhook/aria-granola"
)

POLL_INTERVAL = int(os.environ.get("ARIA_GRANOLA_POLL_INTERVAL", "15"))

STATE_FILE = Path(__file__).parent.parent / "logs" / "granola-state.json"
LOG_FILE = Path(__file__).parent.parent / "logs" / "granola-watcher.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_state():
    if STATE_FILE.exists():
        with open(STATE_FILE) as f:
            return json.load(f)
    return {"known_documents": {}, "last_cache_mtime": 0}


def save_state(state):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def extract_plain_text(notes):
    """Extract plain text from ProseMirror-style notes JSON."""
    texts = []

    def walk(node):
        if isinstance(node, dict):
            if "text" in node:
                texts.append(node["text"])
            for child in node.get("content", []):
                walk(child)
        elif isinstance(node, list):
            for item in node:
                walk(item)

    walk(notes)
    return " ".join(texts).strip()


def build_transcript_text(segments):
    """Build readable transcript from timestamped segments."""
    lines = []
    for seg in segments:
        text = seg.get("text", "").strip()
        if not text:
            continue
        start = seg.get("start_timestamp", "")
        source = seg.get("source", "")
        if start:
            # Extract just the time portion
            try:
                t = datetime.fromisoformat(start.replace("Z", "+00:00"))
                time_str = t.strftime("%H:%M:%S")
            except (ValueError, TypeError):
                time_str = ""
            lines.append(f"[{time_str}] {text}")
        else:
            lines.append(text)
    return "\n".join(lines)


def process_document(doc, transcripts):
    """Extract all useful data from a Granola document."""
    doc_id = doc.get("id", "")
    title = doc.get("title", "Untitled")
    created = doc.get("created_at", "")
    updated = doc.get("updated_at", "")
    doc_type = doc.get("type", "")
    overview = doc.get("overview", "")

    # Get notes content - try markdown first, then plain, then extract from JSON
    notes_text = ""
    if doc.get("notes_markdown"):
        notes_text = doc["notes_markdown"]
    elif doc.get("notes_plain"):
        notes_text = doc["notes_plain"]
    elif doc.get("notes"):
        notes_text = extract_plain_text(doc["notes"])

    # Get people/attendees
    people = []
    raw_people = doc.get("people", {})
    if isinstance(raw_people, dict):
        for person_id, person in raw_people.items():
            if isinstance(person, dict):
                name = person.get("name", person.get("email", person_id))
                people.append(name)
            elif isinstance(person, str):
                people.append(person)
    elif isinstance(raw_people, list):
        people = raw_people

    # Get calendar event info
    cal_event = doc.get("google_calendar_event", {})
    event_title = ""
    if isinstance(cal_event, dict):
        event_title = cal_event.get("summary", cal_event.get("title", ""))

    # Get transcript if available
    transcript_text = ""
    transcript_segments = transcripts.get(doc_id, [])
    if isinstance(transcript_segments, list) and transcript_segments:
        transcript_text = build_transcript_text(transcript_segments)

    return {
        "document_id": doc_id,
        "title": title,
        "created_at": created,
        "updated_at": updated,
        "type": doc_type,
        "overview": overview,
        "notes": notes_text,
        "people": people,
        "calendar_event_title": event_title,
        "transcript": transcript_text,
        "transcript_segment_count": len(transcript_segments) if isinstance(transcript_segments, list) else 0,
        "source": "granola",
    }


def content_hash(doc_data):
    """Hash the meaningful content to detect real changes."""
    content = f"{doc_data['title']}|{doc_data['notes']}|{doc_data['transcript']}|{doc_data['updated_at']}"
    return hashlib.md5(content.encode()).hexdigest()


def forward_to_n8n(payload, event_type):
    """Send document data to n8n webhook."""
    payload["event_type"] = event_type
    payload["forwarded_at"] = datetime.now().isoformat()
    try:
        resp = requests.post(N8N_WEBHOOK_URL, json=payload, timeout=10)
        if resp.status_code == 200:
            log(f"  -> Forwarded to n8n (200 OK)")
        else:
            log(f"  -> n8n responded {resp.status_code}: {resp.text[:100]}")
    except requests.exceptions.ConnectionError:
        log(f"  -> n8n not reachable (is the granola webhook workflow active?)")
    except Exception as e:
        log(f"  -> Error forwarding: {e}")


def read_granola_cache():
    """Read and parse the Granola cache file."""
    with open(GRANOLA_CACHE) as f:
        data = json.load(f)
    state = data.get("cache", {}).get("state", {})
    return state.get("documents", {}), state.get("transcripts", {})


def main():
    log("ARIA Granola Watcher starting...")
    log(f"Cache: {GRANOLA_CACHE}")
    log(f"Webhook: {N8N_WEBHOOK_URL}")
    log(f"Polling every {POLL_INTERVAL}s")

    if not os.path.exists(GRANOLA_CACHE):
        log(f"FATAL: Granola cache not found at {GRANOLA_CACHE}")
        log("Make sure Granola is installed and has been opened at least once.")
        sys.exit(1)

    state = load_state()
    log(f"Tracking {len(state['known_documents'])} known documents")

    # First run: catalog existing documents without forwarding
    if not state["known_documents"]:
        log("First run: cataloging existing documents...")
        documents, transcripts = read_granola_cache()
        for doc_id, doc in documents.items():
            if isinstance(doc, dict):
                doc_data = process_document(doc, transcripts)
                state["known_documents"][doc_id] = {
                    "hash": content_hash(doc_data),
                    "title": doc_data["title"],
                    "updated_at": doc_data["updated_at"],
                }
        save_state(state)
        log(f"Cataloged {len(state['known_documents'])} existing documents. Watching for changes...")

    try:
        while True:
            cache_mtime = os.path.getmtime(GRANOLA_CACHE)

            if cache_mtime != state["last_cache_mtime"]:
                state["last_cache_mtime"] = cache_mtime

                try:
                    documents, transcripts = read_granola_cache()
                except (json.JSONDecodeError, IOError) as e:
                    log(f"Cache read error (file may be mid-write): {e}")
                    time.sleep(2)
                    continue

                for doc_id, doc in documents.items():
                    if not isinstance(doc, dict):
                        continue

                    doc_data = process_document(doc, transcripts)
                    new_hash = content_hash(doc_data)

                    if doc_id not in state["known_documents"]:
                        # New document
                        log(f"NEW: {doc_data['title']} ({doc_data['transcript_segment_count']} transcript segments)")
                        forward_to_n8n(doc_data, "new_meeting")
                        state["known_documents"][doc_id] = {
                            "hash": new_hash,
                            "title": doc_data["title"],
                            "updated_at": doc_data["updated_at"],
                        }
                        save_state(state)

                    elif state["known_documents"][doc_id]["hash"] != new_hash:
                        # Updated document
                        log(f"UPDATED: {doc_data['title']}")
                        forward_to_n8n(doc_data, "meeting_updated")
                        state["known_documents"][doc_id] = {
                            "hash": new_hash,
                            "title": doc_data["title"],
                            "updated_at": doc_data["updated_at"],
                        }
                        save_state(state)

            time.sleep(POLL_INTERVAL)

    except KeyboardInterrupt:
        log("Granola watcher stopped by user")
        save_state(state)


if __name__ == "__main__":
    main()
