"""
ARIA Audit Log
Centralized logging of everything ARIA does. Every script imports this module
and calls aria_audit.log_action() to record what happened.

Records:
  - Timestamp
  - Action type (sync, classify, draft, alert, organize, search, etc.)
  - Script that performed it
  - Details (what was done)
  - Affected data (email ID, contact name, project, etc.)
  - Result (success, failure, skipped)

Storage: logs/audit.jsonl (JSON Lines format, one entry per line)
Queryable via: scripts/audit-query.py or Telegram /audit command

This is NOT for debugging (that's in individual script logs).
This is for trust: "What did ARIA do while I wasn't looking?"
"""

import json
import os
import sys
from datetime import datetime
from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent
AUDIT_FILE = PROJECT_DIR / "logs" / "audit.jsonl"


def log_action(action, script, details="", affected="", project=None, result="success"):
    """
    Log an auditable action.

    Args:
        action: Action type (sync, classify, draft, alert, organize, search, backup, etc.)
        script: Which script performed it (e.g., "email-organizer")
        details: What happened (e.g., "Applied label ARIA/Projects/Conceivable")
        affected: What was affected (e.g., email subject, contact name, file path)
        project: Related project (optional)
        result: success, failure, skipped
    """
    entry = {
        "timestamp": datetime.now().isoformat(),
        "action": action,
        "script": script,
        "details": details[:500],
        "affected": affected[:200],
        "project": project,
        "result": result,
    }

    AUDIT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(AUDIT_FILE, "a") as f:
        f.write(json.dumps(entry) + "\n")


def get_recent(count=50, action_filter=None, script_filter=None, project_filter=None):
    """Query recent audit entries."""
    if not AUDIT_FILE.exists():
        return []

    entries = []
    with open(AUDIT_FILE) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
                if action_filter and entry.get("action") != action_filter:
                    continue
                if script_filter and entry.get("script") != script_filter:
                    continue
                if project_filter and entry.get("project") != project_filter:
                    continue
                entries.append(entry)
            except json.JSONDecodeError:
                continue

    return entries[-count:]


def get_stats(hours_back=24):
    """Get audit statistics for the past N hours."""
    if not AUDIT_FILE.exists():
        return {}

    from collections import Counter
    cutoff = datetime.now().isoformat()[:10]  # Simplified: today's date

    actions = Counter()
    scripts = Counter()
    results = Counter()
    total = 0

    with open(AUDIT_FILE) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
                if entry.get("timestamp", "")[:10] >= cutoff:
                    actions[entry.get("action", "unknown")] += 1
                    scripts[entry.get("script", "unknown")] += 1
                    results[entry.get("result", "unknown")] += 1
                    total += 1
            except json.JSONDecodeError:
                continue

    return {
        "total_actions": total,
        "by_action": dict(actions.most_common()),
        "by_script": dict(scripts.most_common()),
        "by_result": dict(results),
    }


def format_for_telegram(entries):
    """Format audit entries for Telegram display."""
    if not entries:
        return "No audit entries found."

    lines = [f"*Last {len(entries)} ARIA Actions*\n"]
    for e in entries[-10:]:
        time = e.get("timestamp", "")[-8:]  # HH:MM:SS
        action = e.get("action", "?")
        script = e.get("script", "?")
        details = e.get("details", "")[:60]
        result_icon = "+" if e.get("result") == "success" else "-" if e.get("result") == "failure" else "~"
        lines.append(f"`{time}` [{result_icon}] {action} ({script})")
        if details:
            lines.append(f"  _{details}_")

    return "\n".join(lines)
