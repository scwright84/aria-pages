#!/usr/bin/env python3
"""
ARIA Competitive Intelligence
Monitors news feeds and emails for competitor mentions, market shifts,
and industry trends relevant to each project.

Sources:
  - News feeds (from config/news-feeds.json, already ingested by news-sync.py)
  - Email content (mentions of competitors in email threads)
  - Slack discussions (competitor/market mentions)

Tracks:
  - Competitor mentions and sentiment
  - Market trend signals
  - Industry news relevant to client verticals
  - Technology shifts that affect the business

Output: briefings/YYYY-MM-DD-intel.json (weekly intelligence report)
        Surfaced in the weekly rollup.
"""

import json
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
INTEL_FILE = PROJECT_DIR / "config" / "competitive-intel.json"
LOG_FILE = PROJECT_DIR / "logs" / "competitive-intel.log"

# Default competitor/market tracking keywords per industry
# Users can extend this via config
DEFAULT_TRACKING = {
    "ai_assistants": {
        "competitors": ["notion ai", "clickup ai", "monday ai", "asana ai", "copilot", "chatgpt", "claude", "gemini", "perplexity"],
        "trends": ["ai agent", "autonomous agent", "agentic", "local ai", "on-premise ai", "ai operating system", "ai automation"],
    },
    "dental": {
        "competitors": ["dentrix", "eaglesoft", "open dental", "curve dental", "pearl ai", "overjet"],
        "trends": ["dental ai", "practice management", "patient engagement", "dental automation", "teledentistry"],
    },
    "consulting": {
        "competitors": ["fractional coo", "fractional cto", "virtual coo", "upwork", "toptal"],
        "trends": ["fractional executive", "ai consulting", "operations automation", "ai adoption"],
    },
}


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def load_intel():
    if INTEL_FILE.exists():
        try:
            with open(INTEL_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"mentions": [], "trends": []}


def save_intel(data):
    INTEL_FILE.parent.mkdir(parents=True, exist_ok=True)
    # Keep only last 500 entries
    data["mentions"] = data.get("mentions", [])[-500:]
    data["trends"] = data.get("trends", [])[-200:]
    with open(INTEL_FILE, "w") as f:
        json.dump(data, f, indent=2, default=str)


def load_inbox(prefix, days_back=7):
    all_data = []
    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        path = INBOX_DIR / f"{prefix}-{date.strftime('%Y-%m-%d')}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                all_data.extend(data if isinstance(data, list) else [data])
            except Exception:
                pass
    return all_data


def get_tracking_keywords(config):
    """Get all tracking keywords from config and defaults."""
    tracking = dict(DEFAULT_TRACKING)

    # Allow user-defined tracking in config
    custom = config.get("competitive_tracking", {})
    for category, keywords in custom.items():
        if category in tracking:
            tracking[category]["competitors"].extend(keywords.get("competitors", []))
            tracking[category]["trends"].extend(keywords.get("trends", []))
        else:
            tracking[category] = keywords

    return tracking


def scan_source(items, text_fields, tracking, source_name):
    """Scan a list of items for keyword mentions."""
    mentions = []
    all_competitors = set()
    all_trends = set()

    for category, keywords in tracking.items():
        all_competitors.update(k.lower() for k in keywords.get("competitors", []))
        all_trends.update(k.lower() for k in keywords.get("trends", []))

    for item in items:
        text = " ".join(str(item.get(f, "")) for f in text_fields).lower()
        if len(text) < 10:
            continue

        # Check competitors
        for keyword in all_competitors:
            if keyword in text:
                mentions.append({
                    "type": "competitor",
                    "keyword": keyword,
                    "source": source_name,
                    "context": text[:200],
                    "date": item.get("date") or item.get("processed_at") or item.get("_file_date", ""),
                    "title": item.get("subject") or item.get("summary", "")[:80],
                })

        # Check trends
        for keyword in all_trends:
            if keyword in text:
                mentions.append({
                    "type": "trend",
                    "keyword": keyword,
                    "source": source_name,
                    "context": text[:200],
                    "date": item.get("date") or item.get("processed_at") or item.get("_file_date", ""),
                    "title": item.get("subject") or item.get("summary", "")[:80],
                })

    return mentions


def generate_report(all_mentions):
    """Generate structured intelligence report."""
    competitor_counts = Counter()
    trend_counts = Counter()
    by_source = Counter()

    for m in all_mentions:
        if m["type"] == "competitor":
            competitor_counts[m["keyword"]] += 1
        else:
            trend_counts[m["keyword"]] += 1
        by_source[m["source"]] += 1

    return {
        "generated": datetime.now().isoformat(),
        "total_signals": len(all_mentions),
        "competitor_mentions": dict(competitor_counts.most_common()),
        "trend_signals": dict(trend_counts.most_common()),
        "by_source": dict(by_source),
        "top_signals": all_mentions[:20],
        "insights": _generate_insights(competitor_counts, trend_counts, all_mentions),
    }


def _generate_insights(competitors, trends, mentions):
    """Generate plain-language insights from the data."""
    insights = []

    if competitors:
        top = competitors.most_common(1)[0]
        insights.append(f"Most mentioned competitor: {top[0]} ({top[1]} mentions)")

    if trends:
        top = trends.most_common(1)[0]
        insights.append(f"Top trend signal: '{top[0]}' ({top[1]} mentions)")

    # Detect spikes (a keyword with multiple mentions in one week)
    for keyword, count in competitors.most_common(5):
        if count >= 3:
            insights.append(f"Competitor spike: '{keyword}' appeared {count} times this week")

    for keyword, count in trends.most_common(5):
        if count >= 3:
            insights.append(f"Trend momentum: '{keyword}' appeared {count} times this week")

    return insights


def main():
    log("Starting competitive intelligence scan")
    config = load_config()
    tracking = get_tracking_keywords(config)

    all_mentions = []

    # Scan emails
    emails = load_inbox("emails", days_back=7)
    email_mentions = scan_source(emails, ["subject", "summary", "snippet"], tracking, "email")
    all_mentions.extend(email_mentions)
    log(f"Emails: {len(email_mentions)} signals from {len(emails)} emails")

    # Scan Slack
    slack = load_inbox("slack", days_back=7)
    slack_mentions = scan_source(slack, ["summary", "key_topics"], tracking, "slack")
    all_mentions.extend(slack_mentions)
    log(f"Slack: {len(slack_mentions)} signals from {len(slack)} channels")

    # Scan news (if available)
    news = load_inbox("news", days_back=7)
    if news:
        news_mentions = scan_source(news, ["title", "summary", "content"], tracking, "news")
        all_mentions.extend(news_mentions)
        log(f"News: {len(news_mentions)} signals from {len(news)} articles")

    # Deduplicate (same keyword + same title = same mention)
    seen = set()
    unique = []
    for m in all_mentions:
        key = f"{m['keyword']}:{m['title'][:30]}"
        if key not in seen:
            seen.add(key)
            unique.append(m)
    all_mentions = unique

    # Save persistent data
    intel_data = load_intel()
    intel_data["mentions"].extend(all_mentions)
    save_intel(intel_data)

    # Generate report
    report = generate_report(all_mentions)

    date_str = datetime.now().strftime("%Y-%m-%d")
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    with open(BRIEFINGS_DIR / f"{date_str}-intel.json", "w") as f:
        json.dump(report, f, indent=2, default=str)

    log(f"Total signals: {report['total_signals']}")
    if report["competitor_mentions"]:
        log(f"Competitors: {json.dumps(report['competitor_mentions'])}")
    if report["trend_signals"]:
        log(f"Trends: {json.dumps(report['trend_signals'])}")
    for insight in report.get("insights", []):
        log(f"  INSIGHT: {insight}")

    log("Competitive intelligence complete")


if __name__ == "__main__":
    main()
