#!/usr/bin/env python3
"""
ARIA Client Status Page
Simple web page showing system health for the client.

Shows:
  - Overall system status (green/yellow/red)
  - Last briefing time
  - Connected accounts and their status
  - Data freshness per source
  - Recent activity summary
  - Next scheduled events

Runs as a lightweight Flask app on port 8644.
Designed to be bookmarked by the client. No login required (local network only).

Different from aria-dashboard.py (port 8643) which is the full admin view.
This is the simplified client view: "Is my system working? Yes."
"""

import json
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

from flask import Flask, Response

PROJECT_DIR = Path(__file__).parent.parent
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
LOGS_DIR = PROJECT_DIR / "logs"

app = Flask(__name__)


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def get_system_status():
    """Compute overall system status from health indicators."""
    issues = []
    warnings = []
    stats = {}

    # Check inference engine
    try:
        import requests
        resp = requests.get("http://localhost:11434/v1/models", timeout=3)
        stats["inference"] = {"ok": resp.status_code == 200, "label": "AI Engine"}
    except Exception:
        stats["inference"] = {"ok": False, "label": "AI Engine"}
        issues.append("AI engine is not responding")

    # Check n8n
    try:
        import requests
        resp = requests.get("http://localhost:5678/healthz", timeout=3)
        stats["n8n"] = {"ok": resp.status_code == 200, "label": "Workflow Engine"}
    except Exception:
        stats["n8n"] = {"ok": False, "label": "Workflow Engine"}
        issues.append("Workflow engine is not responding")

    # Check last briefing
    today = datetime.now().strftime("%Y-%m-%d")
    briefing_html = BRIEFINGS_DIR / f"{today}.html"
    briefing_json = BRIEFINGS_DIR / f"{today}.json"
    if briefing_html.exists() or briefing_json.exists():
        bf = briefing_html if briefing_html.exists() else briefing_json
        mtime = datetime.fromtimestamp(bf.stat().st_mtime)
        stats["briefing"] = {
            "ok": True,
            "label": "Today's Briefing",
            "detail": f"Generated at {mtime.strftime('%I:%M %p')}"
        }
    else:
        config = load_config()
        bt = config.get("schedules", {}).get("morning_briefing", "07:30")
        hour, minute = map(int, bt.split(":"))
        deadline = datetime.now().replace(hour=hour, minute=minute) + timedelta(minutes=30)
        if datetime.now() < deadline:
            stats["briefing"] = {"ok": True, "label": "Today's Briefing", "detail": f"Scheduled for {bt}"}
        else:
            stats["briefing"] = {"ok": False, "label": "Today's Briefing", "detail": "Not generated yet"}
            warnings.append("Today's briefing hasn't been generated yet")

    # Check data freshness
    data_sources = {}
    for prefix in ["emails", "slack", "calendar", "calendly", "awaiting", "notifications"]:
        latest = None
        for f in INBOX_DIR.glob(f"{prefix}-*.json"):
            mtime = datetime.fromtimestamp(f.stat().st_mtime)
            if latest is None or mtime > latest:
                latest = mtime
        if latest:
            hours_old = (datetime.now() - latest).total_seconds() / 3600
            data_sources[prefix] = {
                "last_update": latest.strftime("%b %d, %I:%M %p"),
                "hours_old": round(hours_old, 1),
                "fresh": hours_old < 24,
            }
            if hours_old > 48:
                warnings.append(f"{prefix} data is {hours_old:.0f} hours old")

    stats["data_sources"] = data_sources

    # Check Telegram bot
    try:
        import subprocess
        result = subprocess.run(["pgrep", "-f", "aria-telegram-bot"],
                              capture_output=True, text=True, timeout=5)
        stats["telegram"] = {"ok": result.returncode == 0, "label": "Mobile Access (Telegram)"}
    except Exception:
        stats["telegram"] = {"ok": False, "label": "Mobile Access (Telegram)"}

    # Overall status
    if issues:
        overall = "red"
        overall_text = "System needs attention"
    elif warnings:
        overall = "yellow"
        overall_text = "System running with warnings"
    else:
        overall = "green"
        overall_text = "All systems operational"

    return {
        "overall": overall,
        "overall_text": overall_text,
        "stats": stats,
        "issues": issues,
        "warnings": warnings,
        "checked_at": datetime.now().strftime("%I:%M %p"),
    }


def render_status_page(status):
    """Render the status page HTML."""
    config = load_config()
    tz = config.get("timezone_abbr", "")

    colors = {"green": "#22c55e", "yellow": "#eab308", "red": "#ef4444"}
    bg_colors = {"green": "#f0fdf4", "yellow": "#fefce8", "red": "#fef2f2"}
    icons = {"green": "&#x2714;", "yellow": "&#x26A0;", "red": "&#x2718;"}

    overall_color = colors[status["overall"]]
    overall_bg = bg_colors[status["overall"]]
    overall_icon = icons[status["overall"]]

    # Service rows
    service_rows = ""
    for key in ["inference", "n8n", "briefing", "telegram"]:
        s = status["stats"].get(key, {})
        ok = s.get("ok", False)
        label = s.get("label", key)
        detail = s.get("detail", "")
        dot = f'<span style="color:{colors["green"] if ok else colors["red"]};font-size:18px">{"&#x25CF;" if ok else "&#x25CF;"}</span>'
        service_rows += f'<tr><td>{dot}</td><td>{label}</td><td style="color:#6b7280;font-size:13px">{detail}</td></tr>\n'

    # Data freshness rows
    data_rows = ""
    source_labels = {
        "emails": "Email", "slack": "Slack", "calendar": "Calendar",
        "calendly": "Calendly", "awaiting": "Commitments", "notifications": "Notifications"
    }
    for prefix, info in status["stats"].get("data_sources", {}).items():
        label = source_labels.get(prefix, prefix)
        fresh = info.get("fresh", False)
        dot = f'<span style="color:{colors["green"] if fresh else colors["yellow"]};font-size:18px">&#x25CF;</span>'
        data_rows += f'<tr><td>{dot}</td><td>{label}</td><td style="color:#6b7280;font-size:13px">{info["last_update"]}</td></tr>\n'

    # Issues/warnings
    alerts_html = ""
    for issue in status.get("issues", []):
        alerts_html += f'<div style="background:#fef2f2;border-left:4px solid #ef4444;padding:8px 12px;margin:4px 0;border-radius:4px;font-size:14px">{issue}</div>'
    for warn in status.get("warnings", []):
        alerts_html += f'<div style="background:#fefce8;border-left:4px solid #eab308;padding:8px 12px;margin:4px 0;border-radius:4px;font-size:14px">{warn}</div>'

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="60">
<title>ARIA System Status</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #f9fafb; min-height: 100vh; }}
  .container {{ max-width: 600px; margin: 0 auto; padding: 24px 16px; }}
  .header {{ text-align: center; margin-bottom: 24px; }}
  .header h1 {{ font-size: 18px; color: #111827; font-weight: 600; }}
  .status-banner {{ background: {overall_bg}; border: 2px solid {overall_color}; border-radius: 12px; padding: 20px; text-align: center; margin-bottom: 24px; }}
  .status-icon {{ font-size: 48px; color: {overall_color}; }}
  .status-text {{ font-size: 18px; font-weight: 600; color: #111827; margin-top: 8px; }}
  .status-time {{ font-size: 12px; color: #6b7280; margin-top: 4px; }}
  .section {{ background: white; border-radius: 8px; padding: 16px; margin-bottom: 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }}
  .section h2 {{ font-size: 14px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 12px; }}
  table {{ width: 100%; }}
  td {{ padding: 6px 8px; font-size: 14px; }}
  .footer {{ text-align: center; font-size: 11px; color: #9ca3af; margin-top: 24px; }}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>ARIA System Status</h1>
  </div>

  <div class="status-banner">
    <div class="status-icon">{overall_icon}</div>
    <div class="status-text">{status["overall_text"]}</div>
    <div class="status-time">Last checked: {status["checked_at"]} {tz} &middot; Auto-refreshes every minute</div>
  </div>

  {"<div class='section'>" + alerts_html + "</div>" if alerts_html else ""}

  <div class="section">
    <h2>Services</h2>
    <table>{service_rows}</table>
  </div>

  <div class="section">
    <h2>Data Sources</h2>
    <table>{data_rows}</table>
  </div>

  <div class="footer">
    Powered by ARIA &middot; Your data stays on this computer
  </div>
</div>
</body>
</html>"""
    return html


@app.route("/")
def index():
    status = get_system_status()
    html = render_status_page(status)
    return Response(html, mimetype="text/html")


@app.route("/api/status")
def api_status():
    status = get_system_status()
    return json.dumps(status, default=str), 200, {"Content-Type": "application/json"}


@app.route("/healthz")
def healthz():
    return "ok", 200


def main():
    print(f"ARIA Status Page running at http://localhost:8644")
    print(f"Client-friendly view. Auto-refreshes every 60 seconds.")
    app.run(host="127.0.0.1", port=8644, debug=False)


if __name__ == "__main__":
    main()
