#!/usr/bin/env python3
"""
ARIA Telegram Bot
Mobile interface to ARIA via Telegram. Connects to local AI inference.
Loads recent ARIA data as context for on-the-go questions and note capture.
Captures notes, ideas, and action items back into ARIA's inbox system.

Commands:
  /brief - Get today's briefing summary
  /status - Project pulse across all projects
  /conceivable - Conceivable-specific update
  /commitments - What you owe and what others owe you
  /notes - Show today's captured notes
  (any message) - Auto-detected as question or note
"""

import json
import os
import re
import logging
import requests
from datetime import datetime, timedelta
from pathlib import Path
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

# Config (loaded from aria.json and .env via aria_ai module)
import aria_ai
TELEGRAM_TOKEN = aria_ai.get_telegram_token()
AUTHORIZED_USERS = aria_ai.get_telegram_authorized_users()

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
LOG_FILE = PROJECT_DIR / "logs" / "telegram-bot.log"

# Load client config for project detection
_full_config = aria_ai.get_full_config()
NOTION_WEBHOOK = _full_config.get("n8n_base_url", "http://localhost:5678") + "/webhook/aria-create-task"

# Build project keywords from config (auto-generates lowercase variants)
KNOWN_PROJECTS = _full_config.get("projects", _full_config.get("known_projects", []))
PROJECT_KEYWORDS = {}
for project in KNOWN_PROJECTS:
    PROJECT_KEYWORDS[project.lower()] = project
    # Add common abbreviations (split on spaces, use first letters)
    words = project.split()
    if len(words) > 1:
        abbrev = "".join(w[0].lower() for w in words)
        PROJECT_KEYWORDS[abbrev] = project

NOTE_PREFIXES = ["note:", "idea:", "reminder:", "todo:", "action:"]
ACTION_KEYWORDS = ["follow up", "follow-up", "need to", "remind me", "ask about",
                    "send to", "schedule", "set up", "reach out", "check on",
                    "get back to", "respond to", "review", "prepare", "draft"]

# Logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger("aria-telegram")

LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
file_handler = logging.FileHandler(LOG_FILE)
file_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
logger.addHandler(file_handler)


# --- Note-Taking Functions ---

def detect_intent(text):
    """Determine if a message is a question or a note.
    Returns: 'question', 'note', or 'ambiguous'
    """
    stripped = text.strip()

    # Explicit question
    if stripped.endswith("?"):
        return "question"

    # Explicit note prefix
    lower = stripped.lower()
    for prefix in NOTE_PREFIXES:
        if lower.startswith(prefix):
            return "note"

    # Explicit project prefix (e.g., "Conceivable: ...")
    for project in KNOWN_PROJECTS:
        if lower.startswith(project.lower() + ":"):
            return "note"

    # Action keywords
    for kw in ACTION_KEYWORDS:
        if kw in lower:
            return "note"

    # Short ambiguous messages (< 8 words, no clear signal)
    words = stripped.split()
    if len(words) < 5:
        return "ambiguous"

    # Default: statements are notes
    return "note"


def detect_project(text):
    """Detect which project a note relates to.
    Returns project name or 'Personal'.
    """
    lower = text.lower()

    # Check for explicit project prefix first
    for project in KNOWN_PROJECTS:
        if lower.startswith(project.lower() + ":"):
            return project

    # Check keywords
    for keyword, project in PROJECT_KEYWORDS.items():
        if keyword in lower:
            return project

    return "Personal"


def detect_note_type(text):
    """Classify the note type: idea, action, reminder, or note."""
    lower = text.lower()

    if any(kw in lower for kw in ["remind me", "reminder", "don't forget", "remember to"]):
        return "reminder"

    if any(kw in lower for kw in ACTION_KEYWORDS):
        return "action"

    if any(lower.startswith(p) for p in ["idea:", "what if", "we should", "we could", "consider"]):
        return "idea"

    return "note"


def extract_due_date(text):
    """Try to extract a due date from the text.
    Handles: 'by Thursday', 'before Friday', 'end of week', 'tomorrow', 'by March 28'
    Returns ISO date string or None.
    """
    lower = text.lower()
    today = datetime.now()

    day_names = {
        "monday": 0, "tuesday": 1, "wednesday": 2, "thursday": 3,
        "friday": 4, "saturday": 5, "sunday": 6
    }

    # "tomorrow"
    if "tomorrow" in lower:
        return (today + timedelta(days=1)).strftime("%Y-%m-%d")

    # "end of week" / "eow"
    if "end of week" in lower or "eow" in lower:
        days_until_friday = (4 - today.weekday()) % 7
        if days_until_friday == 0:
            days_until_friday = 7
        return (today + timedelta(days=days_until_friday)).strftime("%Y-%m-%d")

    # "by [day]" or "before [day]"
    for pattern in [r'by (\w+)', r'before (\w+)', r'on (\w+)']:
        match = re.search(pattern, lower)
        if match:
            day = match.group(1)
            if day in day_names:
                target = day_names[day]
                days_ahead = (target - today.weekday()) % 7
                if days_ahead == 0:
                    days_ahead = 7
                return (today + timedelta(days=days_ahead)).strftime("%Y-%m-%d")

    return None


def strip_prefix(text):
    """Remove note/project prefix from the content."""
    stripped = text.strip()

    # Remove note-type prefixes
    for prefix in NOTE_PREFIXES:
        if stripped.lower().startswith(prefix):
            return stripped[len(prefix):].strip()

    # Remove project prefixes
    for project in KNOWN_PROJECTS:
        if stripped.lower().startswith(project.lower() + ":"):
            return stripped[len(project) + 1:].strip()

    return stripped


def save_note(project, content, note_type, action_due=None, username=""):
    """Save a note to inbox/notes-YYYY-MM-DD.json"""
    today = datetime.now().strftime("%Y-%m-%d")
    notes_path = INBOX_DIR / f"notes-{today}.json"

    existing = []
    if notes_path.exists():
        try:
            with open(notes_path) as f:
                existing = json.load(f)
        except Exception:
            existing = []

    note = {
        "source": "telegram",
        "project": project,
        "content": content,
        "type": note_type,
        "action_due": action_due,
        "timestamp": datetime.now().isoformat(),
        "telegram_user": username,
    }

    existing.append(note)

    with open(notes_path, "w") as f:
        json.dump(existing, f, indent=2)

    logger.info(f"Note saved: [{project}] {note_type}: {content[:80]}")
    return note, len(existing)


def push_to_notion(note):
    """Push an action item to Notion via n8n webhook."""
    try:
        resp = requests.post(NOTION_WEBHOOK, json={
            "task": note["content"],
            "project": note["project"],
            "priority": "medium",
            "source": "ARIA Telegram",
        }, timeout=10)
        if resp.status_code == 200:
            logger.info(f"Notion task created: {note['content'][:50]}")
            return True
        else:
            logger.warning(f"Notion push failed: {resp.status_code}")
            return False
    except Exception as e:
        logger.warning(f"Notion push error: {e}")
        return False


def get_todays_notes():
    """Load today's notes."""
    today = datetime.now().strftime("%Y-%m-%d")
    notes_path = INBOX_DIR / f"notes-{today}.json"
    if notes_path.exists():
        try:
            with open(notes_path) as f:
                return json.load(f)
        except Exception:
            return []
    return []


# --- Existing Functions ---

def load_recent_data(days=2):
    """Load recent ARIA inbox data for context."""
    context = {}

    for source in ["emails", "slack", "awaiting", "meetings", "calendly", "calendar", "notes"]:
        items = []
        for d in range(days):
            date_str = (datetime.now() - timedelta(days=d)).strftime("%Y-%m-%d")
            path = INBOX_DIR / f"{source}-{date_str}.json"
            if path.exists():
                try:
                    with open(path) as f:
                        data = json.load(f)
                    if isinstance(data, list):
                        items.extend(data)
                except Exception:
                    continue
        if items:
            context[source] = items

    # Load latest briefing
    today = datetime.now().strftime("%Y-%m-%d")
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    for date_str in [today, yesterday]:
        brief_path = BRIEFINGS_DIR / f"{date_str}.json"
        if brief_path.exists():
            try:
                with open(brief_path) as f:
                    context["latest_briefing"] = json.load(f)
                break
            except Exception:
                continue

    return context


def build_context_string(data, max_chars=6000):
    """Build a concise context string from ARIA data."""
    parts = []

    # Latest briefing sections
    briefing = data.get("latest_briefing", {})
    sections = briefing.get("sections", {})
    if sections:
        bluf = sections.get("bluf", "")
        if bluf:
            parts.append(f"TODAY'S BLUF: {bluf}")

        decisions = sections.get("decisions_needed", [])
        if decisions:
            parts.append("DECISIONS NEEDED:")
            for d in decisions[:5]:
                parts.append(f"  - {d if isinstance(d, str) else json.dumps(d)}"[:200])

        commitments = sections.get("commitments_you_owe", [])
        if commitments:
            parts.append("YOU OWE:")
            for c in commitments[:5]:
                parts.append(f"  - {c if isinstance(c, str) else json.dumps(c)}"[:200])

        waiting = sections.get("waiting_on_others", [])
        if waiting:
            parts.append("WAITING ON OTHERS:")
            for w in waiting[:5]:
                parts.append(f"  - {w if isinstance(w, str) else json.dumps(w)}"[:200])

        pulse = sections.get("project_pulse", [])
        if pulse:
            parts.append("PROJECT PULSE:")
            for p in pulse[:8]:
                parts.append(f"  - {p if isinstance(p, str) else json.dumps(p)}"[:200])

    # Slack summaries
    slack = data.get("slack", [])
    if slack:
        parts.append(f"\nSLACK ({len(slack)} channels):")
        for ch in slack[:5]:
            name = ch.get("channel_name", "")
            summary = ch.get("summary", "")
            parts.append(f"  #{name}: {summary}"[:200])

    # Emails by account
    emails = data.get("emails", [])
    if emails:
        by_acct = {}
        for e in emails:
            acct = e.get("account", "?")
            by_acct[acct] = by_acct.get(acct, 0) + 1
        parts.append(f"\nEMAILS: {', '.join(f'{a}: {c}' for a, c in by_acct.items())}")

    # Awaiting items
    awaiting = data.get("awaiting", [])
    if awaiting:
        parts.append(f"\nAWAITING ({len(awaiting)} items):")
        for a in awaiting[:5]:
            parts.append(f"  - {a.get('owner', '?')}: {a.get('task', '')}"[:200])

    # Meetings
    meetings = data.get("meetings", [])
    if meetings:
        parts.append(f"\nRECENT MEETINGS ({len(meetings)}):")
        for m in meetings[:5]:
            parts.append(f"  - [{m.get('project', '?')}] {m.get('title', '')}"[:150])

    # Today's notes
    notes = data.get("notes", [])
    if notes:
        parts.append(f"\nSEAN'S NOTES TODAY ({len(notes)}):")
        for n in notes:
            parts.append(f"  - [{n.get('project', '?')}] {n.get('content', '')}"[:200])

    result = "\n".join(parts)
    return result[:max_chars]


def call_ai(system_prompt, user_message):
    """Call AI inference and return response. Returns error string on failure (for user-facing messages)."""
    result = aria_ai.chat(system_prompt, user_message)
    if result is not None:
        return result
    return "AI is not available right now. Make sure the inference engine is running."


def get_system_prompt(context_str):
    """Build the ARIA system prompt with context."""
    full_config = aria_ai.get_full_config()
    user_name = full_config.get("client", {}).get("contact_name", "the user")
    client_name = full_config.get("client", {}).get("name", "")
    projects = full_config.get("projects", full_config.get("known_projects", []))
    projects_str = ", ".join(projects) if projects else "various projects"

    identity = f"You are ARIA, the AI assistant for {client_name}." if client_name else "You are ARIA, an executive assistant AI."

    return f"""{identity} {user_name} is messaging you via Telegram on the go.

Keep responses SHORT and mobile-friendly. Use bullet points. No walls of text.

Tracked projects: {projects_str}.

CURRENT CONTEXT (from ARIA's data):
{context_str}

RULES:
- Be direct and concise. {user_name} is reading on a phone.
- Only reference data you actually have. Don't invent details.
- If asked about something not in your context, say so.
- Use bullet points for lists.
- No em dashes. No fluff.
- If asked to draft something, match a direct builder tone."""


# --- Message Handlers ---

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle any text message. Routes between Q&A and note-taking."""
    if AUTHORIZED_USERS and update.effective_user.id not in AUTHORIZED_USERS:
        await update.message.reply_text("Not authorized.")
        return

    user_msg = update.message.text
    username = update.effective_user.username or str(update.effective_user.id)
    logger.info(f"Message from {username}: {user_msg[:100]}")

    intent = detect_intent(user_msg)

    if intent == "question":
        # Route to Q&A
        await handle_question(update, user_msg)
    elif intent == "note":
        # Route to note-saving
        await handle_note(update, user_msg, username)
    else:
        # Ambiguous - ask for clarification
        await update.message.reply_text(
            "Save as a note, or asking a question?\n\n"
            "Reply with:\n"
            "• \"save\" to capture as a note\n"
            "• Or rephrase as a question (end with ?)"
        )
        # Store the pending message for follow-up
        context.user_data["pending_message"] = user_msg


async def handle_question(update: Update, user_msg: str):
    """Handle a question via Ollama Q&A."""
    await update.message.chat.send_action("typing")

    data = load_recent_data()
    context_str = build_context_string(data)
    system_prompt = get_system_prompt(context_str)

    response = call_ai(system_prompt, user_msg)

    if len(response) > 4000:
        for i in range(0, len(response), 4000):
            await update.message.reply_text(response[i:i+4000])
    else:
        await update.message.reply_text(response)


async def handle_note(update: Update, user_msg: str, username: str):
    """Handle saving a note."""
    content = strip_prefix(user_msg)
    project = detect_project(user_msg)
    note_type = detect_note_type(user_msg)
    due_date = extract_due_date(user_msg)

    note, count = save_note(project, content, note_type, due_date, username)

    # Build confirmation
    response = f"Saved to {project}."

    if note_type == "action":
        response += " Tagged as action item"
        if due_date:
            due_dt = datetime.strptime(due_date, "%Y-%m-%d")
            response += f", due {due_dt.strftime('%A %b %d')}"
        response += "."

        # Push to Notion
        if push_to_notion(note):
            response += " Created Notion task."
    elif note_type == "reminder":
        response += " Tagged as reminder"
        if due_date:
            due_dt = datetime.strptime(due_date, "%Y-%m-%d")
            response += f", due {due_dt.strftime('%A %b %d')}"
        response += "."

        # Reminders also go to Notion
        if push_to_notion(note):
            response += " Created Notion task."
    elif note_type == "idea":
        response += " Tagged as idea."

    response += f" (note #{count} today)"

    await update.message.reply_text(response)


async def handle_save_confirmation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle 'save' reply to ambiguous message prompt."""
    if AUTHORIZED_USERS and update.effective_user.id not in AUTHORIZED_USERS:
        return

    user_msg = update.message.text.strip().lower()
    pending = context.user_data.get("pending_message")

    if pending and user_msg == "save":
        username = update.effective_user.username or str(update.effective_user.id)
        await handle_note(update, pending, username)
        context.user_data.pop("pending_message", None)
        return True
    return False


# --- Command Handlers ---

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Welcome message."""
    user_id = update.effective_user.id
    logger.info(f"Start command from user ID: {user_id}, username: {update.effective_user.username}")

    await update.message.reply_text(
        "ARIA is online.\n\n"
        "Commands:\n"
        "/brief - Today's briefing\n"
        "/status - Project pulse\n"
        "/conceivable - Conceivable update\n"
        "/commitments - What's owed\n"
        "/notes - Today's captured notes\n\n"
        "Ask a question (end with ?) or capture a note:\n"
        "• \"Conceivable: test individual pill sales\"\n"
        "• \"Reminder: follow up with Kirsten by Thursday\"\n"
        "• \"We should add HSA messaging to the app\""
    )


async def cmd_brief(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send today's briefing summary."""
    if AUTHORIZED_USERS and update.effective_user.id not in AUTHORIZED_USERS:
        return

    await update.message.chat.send_action("typing")

    data = load_recent_data()
    briefing = data.get("latest_briefing", {})
    sections = briefing.get("sections", {})

    if not sections:
        await update.message.reply_text("No briefing available yet. Run generate-briefing.py first.")
        return

    bluf = sections.get("bluf", "No BLUF available.")
    parts = [f"*ARIA Daily Brief*\n\n{bluf}"]

    decisions = sections.get("decisions_needed", [])
    if decisions:
        parts.append("\n*Decisions Needed:*")
        for d in decisions[:5]:
            item = d if isinstance(d, str) else d.get("decision", json.dumps(d))
            parts.append(f"  • {item}"[:200])

    commitments = sections.get("commitments_you_owe", [])
    if commitments:
        parts.append("\n*You Owe:*")
        for c in commitments[:5]:
            item = c if isinstance(c, str) else f"{c.get('what', '')} to {c.get('to_whom', '')}"
            parts.append(f"  • {item}"[:200])

    pulse = sections.get("project_pulse", [])
    if pulse:
        parts.append("\n*Project Pulse:*")
        for p in pulse[:8]:
            item = p if isinstance(p, str) else f"{p.get('project', '')}: {p.get('status', '')}"
            parts.append(f"  • {item}"[:200])

    await update.message.reply_text("\n".join(parts), parse_mode="Markdown")


async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Quick project status."""
    if AUTHORIZED_USERS and update.effective_user.id not in AUTHORIZED_USERS:
        return
    await update.message.chat.send_action("typing")
    data = load_recent_data()
    context_str = build_context_string(data)
    system_prompt = get_system_prompt(context_str)
    response = call_ai(system_prompt,
        "Give me a quick project pulse. One line per project. Status: on track / needs attention / blocked. Only the active ones.")
    await update.message.reply_text(response)


async def cmd_conceivable(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Conceivable-specific update."""
    if AUTHORIZED_USERS and update.effective_user.id not in AUTHORIZED_USERS:
        return
    await update.message.chat.send_action("typing")
    data = load_recent_data()
    context_str = build_context_string(data)
    system_prompt = get_system_prompt(context_str)
    response = call_ai(system_prompt,
        "Give me a focused Conceivable update. What's the current state, what are the blockers, what needs my attention, and what's the team working on?")
    await update.message.reply_text(response)


async def cmd_commitments(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show commitments tracker."""
    if AUTHORIZED_USERS and update.effective_user.id not in AUTHORIZED_USERS:
        return
    await update.message.chat.send_action("typing")
    data = load_recent_data()
    context_str = build_context_string(data)
    system_prompt = get_system_prompt(context_str)
    response = call_ai(system_prompt,
        "Show me my commitments. What do I owe people and what do they owe me? Flag anything overdue.")
    await update.message.reply_text(response)


async def cmd_notes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show today's captured notes."""
    if AUTHORIZED_USERS and update.effective_user.id not in AUTHORIZED_USERS:
        return

    notes = get_todays_notes()

    if not notes:
        await update.message.reply_text("No notes captured today yet.")
        return

    parts = [f"*Today's Notes ({len(notes)})*\n"]

    for i, n in enumerate(notes, 1):
        project = n.get("project", "?")
        content = n.get("content", "")[:100]
        ntype = n.get("type", "note")
        due = n.get("action_due", "")
        time_str = ""
        try:
            ts = datetime.fromisoformat(n.get("timestamp", ""))
            time_str = ts.strftime("%I:%M %p")
        except Exception:
            pass

        line = f"{i}. [{project}] {content}"
        if ntype in ("action", "reminder") and due:
            line += f" (due {due})"
        if time_str:
            line += f" - {time_str}"
        parts.append(line)

    await update.message.reply_text("\n".join(parts), parse_mode="Markdown")


# --- Main ---

def main():
    logger.info("Starting ARIA Telegram bot...")

    app = Application.builder().token(TELEGRAM_TOKEN).build()

    # Commands
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("brief", cmd_brief))
    app.add_handler(CommandHandler("status", cmd_status))
    app.add_handler(CommandHandler("conceivable", cmd_conceivable))
    app.add_handler(CommandHandler("commitments", cmd_commitments))
    app.add_handler(CommandHandler("notes", cmd_notes))

    # Free-form messages (handles both Q&A and notes)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    logger.info("Bot is running. Polling for messages...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
