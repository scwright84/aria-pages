#!/usr/bin/env python3
"""
ARIA Daily Communication Digest
Quick daily summary: email counts, project distribution, who's active,
who's quiet, anomalies, and trends.

Different from the Presidential Brief (which is comprehensive).
This is a 30-second glance at your communication patterns.

Output: briefings/YYYY-MM-DD-digest.json + HTML
Runs daily after inbox sync.
"""

import json
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
LOG_FILE = PROJECT_DIR / "logs" / "comms-digest.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_config():
    config_path = PROJECT_DIR / "config" / "aria.json"
    if config_path.exists():
        with open(config_path) as f:
            return json.load(f)
    return {}


def load_today_files(prefix):
    """Load today's inbox file for a given prefix."""
    date_str = datetime.now().strftime("%Y-%m-%d")
    path = INBOX_DIR / f"{prefix}-{date_str}.json"
    if path.exists():
        try:
            with open(path) as f:
                data = json.load(f)
            return data if isinstance(data, list) else [data]
        except (json.JSONDecodeError, IOError):
            pass
    return []


def load_yesterday_files(prefix):
    """Load yesterday's inbox file for comparison."""
    date_str = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    path = INBOX_DIR / f"{prefix}-{date_str}.json"
    if path.exists():
        try:
            with open(path) as f:
                data = json.load(f)
            return data if isinstance(data, list) else [data]
        except (json.JSONDecodeError, IOError):
            pass
    return []


def build_digest(config):
    """Build the daily communication digest."""
    today = datetime.now()

    # Email stats
    emails_today = load_today_files("emails")
    emails_yesterday = load_yesterday_files("emails")

    email_count = len(emails_today)
    email_count_yesterday = len(emails_yesterday)

    # Project distribution
    project_counts = Counter()
    priority_counts = Counter()
    action_count = 0
    senders = Counter()

    for e in emails_today:
        project = e.get("detected_project") or "Unclassified"
        project_counts[project] += 1
        priority_counts[e.get("priority", "normal")] += 1
        if e.get("action_needed"):
            action_count += 1
        sender = e.get("from", "")
        if sender:
            # Extract just the name
            if "<" in sender:
                sender = sender.split("<")[0].strip().strip('"')
            senders[sender] += 1

    # Slack stats
    slack_today = load_today_files("slack")
    slack_messages = sum(s.get("message_count", 0) for s in slack_today)
    slack_channels = len(slack_today)
    slack_actions = sum(len(s.get("action_items", [])) for s in slack_today)

    # Calendar
    calendar_today = load_today_files("calendar")
    meeting_count = len(calendar_today)

    # Notifications
    notifications = load_today_files("notifications")
    notification_count = len(notifications)

    # Anomalies
    anomalies = []
    if email_count_yesterday > 0:
        ratio = email_count / email_count_yesterday
        if ratio > 2:
            anomalies.append(f"Email volume is {ratio:.1f}x yesterday ({email_count} vs {email_count_yesterday})")
        elif ratio < 0.3 and email_count_yesterday > 5:
            anomalies.append(f"Email volume dropped to {email_count} (yesterday: {email_count_yesterday})")

    if action_count > 5:
        anomalies.append(f"{action_count} emails need action — higher than typical")

    # Top project
    top_project = project_counts.most_common(1)[0] if project_counts else ("None", 0)

    # Quiet projects (active clients with no emails today)
    active_clients = set(config.get("client_tiers", {}).get("active", []))
    active_with_email = set(p for p in project_counts if p in active_clients)
    quiet_actives = active_clients - active_with_email

    if quiet_actives:
        anomalies.append(f"No emails from active clients: {', '.join(quiet_actives)}")

    digest = {
        "date": today.strftime("%Y-%m-%d"),
        "generated": today.isoformat(),
        "email": {
            "count": email_count,
            "yesterday": email_count_yesterday,
            "change": email_count - email_count_yesterday,
            "actions_needed": action_count,
            "by_project": dict(project_counts.most_common()),
            "by_priority": dict(priority_counts),
            "top_senders": dict(senders.most_common(5)),
        },
        "slack": {
            "messages": slack_messages,
            "channels_active": slack_channels,
            "action_items": slack_actions,
        },
        "meetings": meeting_count,
        "notifications": notification_count,
        "top_project": {"name": top_project[0], "count": top_project[1]},
        "quiet_active_clients": list(quiet_actives),
        "anomalies": anomalies,
        "headline": _generate_headline(email_count, slack_messages, action_count, top_project, anomalies),
    }

    return digest


def _generate_headline(email_count, slack_messages, action_count, top_project, anomalies):
    """Generate a one-line headline for the digest."""
    parts = []
    parts.append(f"{email_count} emails")
    if slack_messages > 0:
        parts.append(f"{slack_messages} Slack messages")
    if action_count > 0:
        parts.append(f"{action_count} need action")

    headline = ", ".join(parts) + "."

    if top_project[1] > 0:
        headline += f" {top_project[0]} dominated."

    if anomalies:
        headline += f" {anomalies[0]}"

    return headline


def generate_html(digest):
    """Generate HTML digest."""
    date_str = digest["date"]
    email = digest["email"]
    slack = digest["slack"]

    # Change indicator
    change = email["change"]
    if change > 0:
        change_html = f'<span style="color:#22c55e">+{change} vs yesterday</span>'
    elif change < 0:
        change_html = f'<span style="color:#ef4444">{change} vs yesterday</span>'
    else:
        change_html = '<span style="color:#6b7280">Same as yesterday</span>'

    # Project bars
    project_bars = ""
    max_count = max(email["by_project"].values()) if email["by_project"] else 1
    colors = ["#3b82f6", "#22c55e", "#f97316", "#8b5cf6", "#ec4899", "#14b8a6", "#f59e0b", "#6366f1"]
    for i, (project, count) in enumerate(email["by_project"].items()):
        width = max(5, int(count / max_count * 100))
        color = colors[i % len(colors)]
        project_bars += f'<div style="margin:4px 0"><span style="display:inline-block;width:120px;font-size:13px">{project}</span><span style="display:inline-block;width:{width}%;background:{color};height:20px;border-radius:3px;vertical-align:middle"></span> <span style="font-size:12px;color:#6b7280">{count}</span></div>'

    # Anomalies
    anomalies_html = ""
    for a in digest["anomalies"]:
        anomalies_html += f'<div style="background:#fefce8;border-left:3px solid #eab308;padding:6px 12px;margin:4px 0;border-radius:3px;font-size:13px">{a}</div>'

    # Top senders
    senders_html = ""
    for name, count in email["top_senders"].items():
        senders_html += f'<div style="font-size:13px;padding:2px 0">{name}: {count}</div>'

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>ARIA Comms Digest - {date_str}</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 700px; margin: 0 auto; padding: 20px; background: #f9fafb; }}
  h1 {{ font-size: 20px; color: #111827; margin-bottom: 4px; }}
  .headline {{ font-size: 15px; color: #374151; margin-bottom: 20px; font-style: italic; }}
  .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 12px; margin-bottom: 20px; }}
  .metric {{ background: white; border-radius: 8px; padding: 14px; text-align: center; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }}
  .metric .value {{ font-size: 28px; font-weight: 700; color: #111827; }}
  .metric .label {{ font-size: 12px; color: #6b7280; margin-top: 2px; }}
  .card {{ background: white; border-radius: 8px; padding: 16px; margin-bottom: 12px; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }}
  .card h2 {{ font-size: 13px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 10px; }}
</style>
</head>
<body>
<h1>Daily Comms Digest</h1>
<p class="headline">{digest["headline"]}</p>

<div class="grid">
  <div class="metric"><div class="value">{email["count"]}</div><div class="label">Emails {change_html}</div></div>
  <div class="metric"><div class="value">{slack["messages"]}</div><div class="label">Slack Messages</div></div>
  <div class="metric"><div class="value">{email["actions_needed"]}</div><div class="label">Need Action</div></div>
  <div class="metric"><div class="value">{digest["meetings"]}</div><div class="label">Meetings</div></div>
</div>

{f'<div style="margin-bottom:16px">{anomalies_html}</div>' if anomalies_html else ''}

<div class="card">
  <h2>Emails by Project</h2>
  {project_bars if project_bars else '<p style="color:#6b7280;font-size:13px">No emails today</p>'}
</div>

<div class="card">
  <h2>Top Senders</h2>
  {senders_html if senders_html else '<p style="color:#6b7280;font-size:13px">No senders</p>'}
</div>

<p style="text-align:center;font-size:11px;color:#9ca3af;margin-top:20px">Generated by ARIA | {date_str}</p>
</body>
</html>"""
    return html


def main():
    log("Starting daily communication digest")
    config = load_config()
    date_str = datetime.now().strftime("%Y-%m-%d")

    digest = build_digest(config)
    log(f"Headline: {digest['headline']}")

    # Save JSON
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    json_path = BRIEFINGS_DIR / f"{date_str}-digest.json"
    with open(json_path, "w") as f:
        json.dump(digest, f, indent=2, default=str)
    log(f"Saved: {json_path}")

    # Save HTML
    html_path = BRIEFINGS_DIR / f"{date_str}-digest.html"
    html = generate_html(digest)
    with open(html_path, "w") as f:
        f.write(html)
    log(f"Saved: {html_path}")

    # Summary
    log(f"Emails: {digest['email']['count']} (yesterday: {digest['email']['yesterday']})")
    log(f"Slack: {digest['slack']['messages']} messages, {digest['slack']['action_items']} action items")
    log(f"Actions needed: {digest['email']['actions_needed']}")
    if digest['anomalies']:
        for a in digest['anomalies']:
            log(f"  ANOMALY: {a}")

    log("Comms digest complete")


if __name__ == "__main__":
    main()
