#!/bin/bash
# ARIA - Local Backup Script
# Creates timestamped backups of ARIA data (inbox, briefings, config, contacts).
# Excludes: logs (regenerable), venv, node_modules, Docker volumes (separate backup).
#
# Backup location: ~/ARIA-backups/ (or set ARIA_BACKUP_DIR)
# Retention: keeps last 7 daily backups, deletes older ones.
#
# Run manually: ./scripts/backup.sh
# Or via launchd/cron: daily at midnight
#   */daily cron: 0 0 * * * /path/to/ARIA/scripts/backup.sh >> /tmp/aria-backup.log 2>&1

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
BACKUP_BASE="${ARIA_BACKUP_DIR:-$HOME/ARIA-backups}"
RETENTION_DAYS=7

TIMESTAMP=$(date '+%Y-%m-%d_%H%M%S')
BACKUP_DIR="$BACKUP_BASE/aria-$TIMESTAMP"

GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${GREEN}[BACKUP $(date '+%H:%M:%S')]${NC} $1"; }
warn() { echo -e "${YELLOW}[BACKUP $(date '+%H:%M:%S')]${NC} $1"; }
err()  { echo -e "${RED}[BACKUP $(date '+%H:%M:%S')]${NC} $1"; }

log "Starting ARIA backup"
log "Source: $PROJECT_DIR"
log "Destination: $BACKUP_DIR"

mkdir -p "$BACKUP_DIR"

# Backup inbox (emails, slack, calendar, awaiting, etc.)
if [ -d "$PROJECT_DIR/inbox" ]; then
    rsync -a "$PROJECT_DIR/inbox/" "$BACKUP_DIR/inbox/"
    COUNT=$(ls "$BACKUP_DIR/inbox/" 2>/dev/null | wc -l | tr -d ' ')
    log "Inbox: $COUNT files"
fi

# Backup briefings (morning briefs, debriefs, scorecards, contact snapshots)
if [ -d "$PROJECT_DIR/briefings" ]; then
    rsync -a "$PROJECT_DIR/briefings/" "$BACKUP_DIR/briefings/"
    COUNT=$(ls "$BACKUP_DIR/briefings/" 2>/dev/null | wc -l | tr -d ' ')
    log "Briefings: $COUNT files"
fi

# Backup config (aria.json, contacts.json, client-schema, model-tracker)
if [ -d "$PROJECT_DIR/config" ]; then
    rsync -a --exclude='credentials.json' "$PROJECT_DIR/config/" "$BACKUP_DIR/config/"
    log "Config: backed up (credentials excluded)"
fi

# Backup state files from logs (granola-state, email-sync-state, etc.)
if [ -d "$PROJECT_DIR/logs" ]; then
    mkdir -p "$BACKUP_DIR/state"
    for f in "$PROJECT_DIR/logs/"*-state.json; do
        [ -f "$f" ] && cp "$f" "$BACKUP_DIR/state/"
    done
    STATE_COUNT=$(ls "$BACKUP_DIR/state/" 2>/dev/null | wc -l | tr -d ' ')
    log "State files: $STATE_COUNT files"
fi

# Backup templates
if [ -d "$PROJECT_DIR/templates" ]; then
    rsync -a "$PROJECT_DIR/templates/" "$BACKUP_DIR/templates/"
    log "Templates: backed up"
fi

# Backup n8n workflows
if [ -d "$PROJECT_DIR/workflows" ]; then
    rsync -a "$PROJECT_DIR/workflows/" "$BACKUP_DIR/workflows/"
    COUNT=$(ls "$BACKUP_DIR/workflows/" 2>/dev/null | wc -l | tr -d ' ')
    log "Workflows: $COUNT files"
fi

# Calculate backup size
BACKUP_SIZE=$(du -sh "$BACKUP_DIR" | cut -f1)
log "Backup complete: $BACKUP_SIZE"

# Enforce retention (delete backups older than N days)
log "Enforcing retention: keeping last $RETENTION_DAYS days"
DELETED=0
find "$BACKUP_BASE" -maxdepth 1 -name "aria-*" -type d -mtime +$RETENTION_DAYS | while read -r old; do
    rm -rf "$old"
    log "Deleted old backup: $(basename "$old")"
    DELETED=$((DELETED + 1))
done

# Summary
TOTAL_BACKUPS=$(ls -d "$BACKUP_BASE"/aria-* 2>/dev/null | wc -l | tr -d ' ')
TOTAL_SIZE=$(du -sh "$BACKUP_BASE" 2>/dev/null | cut -f1)
log "Total backups: $TOTAL_BACKUPS ($TOTAL_SIZE)"
log "Done."
