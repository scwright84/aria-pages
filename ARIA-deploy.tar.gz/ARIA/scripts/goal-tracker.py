#!/usr/bin/env python3
"""
ARIA Goal Tracker
Set goals, track progress, flag when daily activity doesn't align.

Goal types:
  - Weekly: "Ship Conceivable OAuth this week"
  - Monthly: "Close 2 new ARIA clients"
  - Quarterly: "Launch FounderOS cohort 1"

Tracking:
  - Correlates calendar events with goals (are you meeting about this?)
  - Correlates email activity with goals (are you communicating about this?)
  - Correlates tasks with goals (are tasks moving toward this?)
  - Flags misalignment: "You set 'close 2 clients' as a goal but 0% of your
    meetings this week were about sales"

Output: config/goals.json (persistent)
        briefings/YYYY-MM-DD-goals.json (progress snapshot)
"""

import json
import re
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
GOALS_FILE = PROJECT_DIR / "config" / "goals.json"
TASKS_FILE = PROJECT_DIR / "config" / "tasks.json"
LOG_FILE = PROJECT_DIR / "logs" / "goal-tracker.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_goals():
    if GOALS_FILE.exists():
        try:
            with open(GOALS_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"goals": [], "archived": []}


def save_goals(data):
    GOALS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(GOALS_FILE, "w") as f:
        json.dump(data, f, indent=2, default=str)


def create_default_goals():
    """Create starter goals based on current projects and priorities."""
    config_path = PROJECT_DIR / "config" / "aria.json"
    config = {}
    if config_path.exists():
        with open(config_path) as f:
            config = json.load(f)

    goals = []
    now = datetime.now()

    active_clients = config.get("client_tiers", {}).get("active", [])
    for client in active_clients:
        goals.append({
            "id": f"auto-{client.lower()}-weekly",
            "title": f"Advance {client} this week",
            "type": "weekly",
            "project": client,
            "keywords": [client.lower()],
            "created": now.isoformat(),
            "target_date": (now + timedelta(days=7 - now.weekday())).strftime("%Y-%m-%d"),
            "status": "active",
            "progress": 0,
            "notes": f"Auto-generated: keep {client} moving forward",
        })

    product_projects = config.get("client_tiers", {}).get("product", [])
    for proj in product_projects:
        goals.append({
            "id": f"auto-{proj.lower()}-monthly",
            "title": f"Ship key {proj} feature this month",
            "type": "monthly",
            "project": proj,
            "keywords": [proj.lower()],
            "created": now.isoformat(),
            "target_date": (now.replace(day=28) + timedelta(days=4)).replace(day=1).strftime("%Y-%m-%d"),
            "status": "active",
            "progress": 0,
            "notes": f"Auto-generated: monthly {proj} milestone",
        })

    return goals


def measure_progress(goal, days_back=7):
    """Measure how much activity aligns with a goal."""
    keywords = [k.lower() for k in goal.get("keywords", [])]
    project = goal.get("project", "")
    if project:
        keywords.append(project.lower())

    if not keywords:
        return {"score": 0, "signals": []}

    signals = []
    score = 0

    # Check emails
    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        date_str = date.strftime("%Y-%m-%d")
        path = INBOX_DIR / f"emails-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    emails = json.load(f)
                matches = [e for e in emails if any(k in f"{e.get('subject','')} {e.get('summary','')}".lower() for k in keywords)]
                if matches:
                    score += len(matches) * 5
                    signals.append(f"{len(matches)} related emails")
            except Exception:
                pass

    # Check calendar
    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        date_str = date.strftime("%Y-%m-%d")
        for prefix in ["calendar", "calendly"]:
            path = INBOX_DIR / f"{prefix}-{date_str}.json"
            if path.exists():
                try:
                    with open(path) as f:
                        events = json.load(f)
                    matches = [e for e in (events if isinstance(events, list) else [events])
                              if any(k in (e.get("summary", "") or e.get("name", "")).lower() for k in keywords)]
                    if matches:
                        score += len(matches) * 15  # Meetings are high signal
                        signals.append(f"{len(matches)} related meetings")
                except Exception:
                    pass

    # Check tasks
    if TASKS_FILE.exists():
        try:
            with open(TASKS_FILE) as f:
                tasks = json.load(f).get("tasks", [])
            matches = [t for t in tasks if t.get("project", "").lower() in [k for k in keywords] or
                       any(k in t.get("title", "").lower() for k in keywords)]
            if matches:
                score += len(matches) * 3
                signals.append(f"{len(matches)} related tasks")
        except Exception:
            pass

    # Check Slack
    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        date_str = date.strftime("%Y-%m-%d")
        path = INBOX_DIR / f"slack-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    slack = json.load(f)
                matches = [s for s in slack if any(k in (s.get("project", "") or s.get("summary", "")).lower() for k in keywords)]
                if matches:
                    score += sum(s.get("message_count", 0) for s in matches)
                    signals.append(f"Slack activity in related channels")
            except Exception:
                pass

    # Normalize to 0-100
    progress = min(100, score)

    return {"score": progress, "signals": signals}


def check_alignment(goals_data):
    """Check if current activity aligns with stated goals."""
    misalignments = []
    progress_updates = []

    for goal in goals_data.get("goals", []):
        if goal.get("status") != "active":
            continue

        progress = measure_progress(goal)
        old_progress = goal.get("progress", 0)
        goal["progress"] = progress["score"]
        goal["signals"] = progress["signals"]
        goal["last_checked"] = datetime.now().isoformat()

        progress_updates.append({
            "goal": goal["title"],
            "progress": progress["score"],
            "change": progress["score"] - old_progress,
            "signals": progress["signals"],
        })

        # Flag misalignment
        if progress["score"] < 10 and goal["type"] in ("weekly", "monthly"):
            misalignments.append({
                "goal": goal["title"],
                "issue": f"Goal set but almost no activity detected ({progress['score']}% progress)",
                "suggestion": f"Schedule time for '{goal['title']}' or reconsider if this is still a priority",
            })

    return progress_updates, misalignments


def main():
    log("Starting goal tracker")
    data = load_goals()

    # Create default goals if none exist
    if not data["goals"]:
        log("No goals found. Creating defaults from project config.")
        data["goals"] = create_default_goals()
        save_goals(data)
        log(f"Created {len(data['goals'])} default goals")

    # Check progress and alignment
    updates, misalignments = check_alignment(data)
    save_goals(data)

    # Save snapshot
    date_str = datetime.now().strftime("%Y-%m-%d")
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    snapshot = {
        "date": date_str,
        "goals": [g for g in data["goals"] if g.get("status") == "active"],
        "progress_updates": updates,
        "misalignments": misalignments,
    }
    with open(BRIEFINGS_DIR / f"{date_str}-goals.json", "w") as f:
        json.dump(snapshot, f, indent=2, default=str)

    log(f"Active goals: {len([g for g in data['goals'] if g.get('status') == 'active'])}")
    for u in updates:
        change = f"+{u['change']}" if u['change'] > 0 else str(u['change'])
        log(f"  {u['goal'][:50]}: {u['progress']}% ({change}) | {', '.join(u['signals']) or 'no signals'}")

    if misalignments:
        log(f"MISALIGNMENTS: {len(misalignments)}")
        for m in misalignments:
            log(f"  {m['goal']}: {m['issue']}")

    log("Goal tracker complete")


if __name__ == "__main__":
    main()
