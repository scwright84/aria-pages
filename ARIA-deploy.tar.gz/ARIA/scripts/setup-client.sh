#!/bin/bash
#
# ARIA Client Setup Script
# Takes a fresh Mac Mini from zero to fully configured ARIA installation.
# Run as: ./setup-client.sh
#
# Prerequisites:
#   - macOS (Apple Silicon)
#   - Internet connection
#   - Admin user account
#
# What this script does:
#   1. Installs Homebrew (if needed)
#   2. Installs Docker Desktop (if needed)
#   3. Installs Python 3 (if needed)
#   4. Installs Ollama (inference engine)
#   5. Pulls AI models
#   6. Clones/copies ARIA project
#   7. Sets up Python venv and dependencies
#   8. Creates client config from template
#   9. Sets up launchd jobs
#  10. Runs health check to verify
#
# Phase 3 note: This script becomes the self-serve installer.
# Keep it idempotent (safe to run multiple times).

set -e

# --- Colors ---
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log() { echo -e "${GREEN}[ARIA]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }
step() { echo -e "\n${BLUE}━━━ Step $1: $2 ━━━${NC}"; }

# --- Config ---
ARIA_DIR="$HOME/ARIA"
ARIA_REPO_SOURCE=""  # Will be set during deployment (rsync from Sean's machine or git clone)
VENV_DIR="$ARIA_DIR/.venv"
PYTHON_MIN_VERSION="3.11"

echo ""
echo "╔══════════════════════════════════════╗"
echo "║       ARIA Setup Script v1.0         ║"
echo "║   AI Operating System for Business   ║"
echo "╚══════════════════════════════════════╝"
echo ""

# --- Step 1: Homebrew ---
step 1 "Checking Homebrew"
if command -v brew &>/dev/null; then
    log "Homebrew already installed ($(brew --version | head -1))"
else
    log "Installing Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    # Add to PATH for Apple Silicon
    if [[ -f /opt/homebrew/bin/brew ]]; then
        eval "$(/opt/homebrew/bin/brew shellenv)"
        echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> "$HOME/.zprofile"
    fi
fi

# --- Step 2: Python ---
step 2 "Checking Python"
if command -v python3 &>/dev/null; then
    PY_VERSION=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
    log "Python $PY_VERSION found"
else
    log "Installing Python via Homebrew..."
    brew install python3
fi

# --- Step 3: Docker ---
step 3 "Checking Docker"
if command -v docker &>/dev/null && docker info &>/dev/null 2>&1; then
    log "Docker is running"
else
    if command -v docker &>/dev/null; then
        warn "Docker is installed but not running. Please start Docker Desktop."
        echo "Waiting for Docker to start..."
        for i in $(seq 1 30); do
            if docker info &>/dev/null 2>&1; then
                log "Docker is now running"
                break
            fi
            sleep 2
        done
        docker info &>/dev/null 2>&1 || error "Docker failed to start. Please start Docker Desktop manually and re-run this script."
    else
        log "Installing Docker Desktop via Homebrew..."
        brew install --cask docker
        log "Please open Docker Desktop to complete installation, then re-run this script."
        open /Applications/Docker.app
        exit 0
    fi
fi

# --- Step 4: Ollama ---
step 4 "Checking Ollama"
if command -v ollama &>/dev/null; then
    log "Ollama already installed"
else
    log "Installing Ollama..."
    brew install ollama
fi

# Start Ollama if not running
if ! curl -s http://localhost:11434/v1/models &>/dev/null; then
    log "Starting Ollama..."
    ollama serve &>/dev/null &
    sleep 3
fi

# --- Step 5: Pull AI Models ---
step 5 "Pulling AI Models"
log "Pulling qwen3:8b (default model, ~5GB)..."
ollama pull qwen3:8b

log "Pulling qwen3:4b (fast model, ~2.5GB)..."
ollama pull qwen3:4b

log "Models ready:"
ollama list

# --- Step 6: ARIA Project ---
step 6 "Setting up ARIA project"
if [[ -d "$ARIA_DIR" ]]; then
    log "ARIA directory already exists at $ARIA_DIR"
else
    if [[ -n "$ARIA_REPO_SOURCE" ]]; then
        log "Copying ARIA from $ARIA_REPO_SOURCE..."
        rsync -av --exclude='.venv' --exclude='inbox/' --exclude='briefings/' --exclude='logs/' "$ARIA_REPO_SOURCE/" "$ARIA_DIR/"
    else
        log "Creating ARIA directory structure..."
        mkdir -p "$ARIA_DIR"/{scripts,config,workflows,templates,inbox,briefings,logs,docs}
        warn "ARIA source files not found. You'll need to copy them manually or set ARIA_REPO_SOURCE."
    fi
fi

# --- Step 7: Python Virtual Environment ---
step 7 "Setting up Python environment"
if [[ -d "$VENV_DIR" ]]; then
    log "Virtual environment already exists"
else
    log "Creating virtual environment..."
    python3 -m venv "$VENV_DIR"
fi

log "Installing Python dependencies..."
"$VENV_DIR/bin/pip" install --quiet --upgrade pip
"$VENV_DIR/bin/pip" install --quiet requests python-telegram-bot

# --- Step 8: Client Configuration ---
step 8 "Configuring for this client"
CONFIG_FILE="$ARIA_DIR/config/aria.json"
ENV_FILE="$ARIA_DIR/.env"

if [[ -f "$CONFIG_FILE" ]]; then
    log "Config file already exists. Skipping."
else
    warn "No config file found. Creating template..."
    cat > "$CONFIG_FILE" << 'TEMPLATE'
{
  "timezone": "CHANGE_ME",
  "timezone_abbr": "CHANGE_ME",
  "email": "CHANGE_ME",
  "n8n_base_url": "http://localhost:5678",
  "ai": {
    "inference_url": "http://localhost:11434/v1/chat/completions",
    "default_model": "qwen3:8b",
    "fast_model": "qwen3:4b",
    "timeout": 120
  },
  "telegram": {
    "token_env": "ARIA_TELEGRAM_TOKEN",
    "authorized_users": []
  },
  "known_projects": [],
  "schedules": {
    "morning_briefing": "07:30",
    "evening_debrief": "21:30",
    "weekly_rollup": "Sunday 19:00"
  },
  "retention": {
    "inbox_days": 30,
    "briefings_days": 14
  }
}
TEMPLATE
    warn "⚠️  Edit $CONFIG_FILE with client-specific values before running ARIA."
fi

if [[ ! -f "$ENV_FILE" ]]; then
    cat > "$ENV_FILE" << 'TEMPLATE'
# ARIA Environment Variables
# Get a Telegram bot token from @BotFather on Telegram
ARIA_TELEGRAM_TOKEN=CHANGE_ME
TEMPLATE
    warn "⚠️  Edit $ENV_FILE with the Telegram bot token."
fi

# --- Step 9: Docker Stack ---
step 9 "Setting up Docker stack"
DOCKER_DIR="$ARIA_DIR/docker"
if [[ -d "$DOCKER_DIR" ]]; then
    log "Docker stack directory exists"
else
    mkdir -p "$DOCKER_DIR"
    warn "Docker compose files need to be copied. Set up n8n + Postgres stack in $DOCKER_DIR"
fi

# --- Step 10: launchd Jobs ---
step 10 "Setting up scheduled jobs"
AGENTS_DIR="$HOME/Library/LaunchAgents"
mkdir -p "$AGENTS_DIR"

# Create the health check job
cat > "$AGENTS_DIR/com.aria.health-check.plist" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.aria.health-check</string>
    <key>ProgramArguments</key>
    <array>
        <string>${VENV_DIR}/bin/python3</string>
        <string>${ARIA_DIR}/scripts/health-check.py</string>
    </array>
    <key>StartInterval</key>
    <integer>300</integer>
    <key>RunAtLoad</key>
    <true/>
    <key>StandardOutPath</key>
    <string>${ARIA_DIR}/logs/launchd-health-check.log</string>
    <key>StandardErrorPath</key>
    <string>${ARIA_DIR}/logs/launchd-health-check.log</string>
</dict>
</plist>
EOF

log "Loading health check job..."
launchctl bootstrap gui/$(id -u) "$AGENTS_DIR/com.aria.health-check.plist" 2>/dev/null || true

# Create email sync job (twice daily)
cat > "$AGENTS_DIR/com.aria.email-sync.plist" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.aria.email-sync</string>
    <key>ProgramArguments</key>
    <array>
        <string>${VENV_DIR}/bin/python3</string>
        <string>${ARIA_DIR}/scripts/email-sync.py</string>
    </array>
    <key>StartCalendarInterval</key>
    <array>
        <dict><key>Hour</key><integer>7</integer><key>Minute</key><integer>0</integer></dict>
        <dict><key>Hour</key><integer>12</integer><key>Minute</key><integer>0</integer></dict>
        <dict><key>Hour</key><integer>17</integer><key>Minute</key><integer>0</integer></dict>
        <dict><key>Hour</key><integer>21</integer><key>Minute</key><integer>0</integer></dict>
    </array>
    <key>StandardOutPath</key>
    <string>${ARIA_DIR}/logs/launchd-email-sync.log</string>
    <key>StandardErrorPath</key>
    <string>${ARIA_DIR}/logs/launchd-email-sync.log</string>
</dict>
</plist>
EOF

# Create calendar sync job (4x daily)
cat > "$AGENTS_DIR/com.aria.calendar-sync.plist" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.aria.calendar-sync</string>
    <key>ProgramArguments</key>
    <array>
        <string>${VENV_DIR}/bin/python3</string>
        <string>${ARIA_DIR}/scripts/calendar-sync.py</string>
    </array>
    <key>StartCalendarInterval</key>
    <array>
        <dict><key>Hour</key><integer>7</integer><key>Minute</key><integer>0</integer></dict>
        <dict><key>Hour</key><integer>12</integer><key>Minute</key><integer>0</integer></dict>
        <dict><key>Hour</key><integer>17</integer><key>Minute</key><integer>0</integer></dict>
        <dict><key>Hour</key><integer>21</integer><key>Minute</key><integer>0</integer></dict>
    </array>
    <key>StandardOutPath</key>
    <string>${ARIA_DIR}/logs/launchd-calendar-sync.log</string>
    <key>StandardErrorPath</key>
    <string>${ARIA_DIR}/logs/launchd-calendar-sync.log</string>
</dict>
</plist>
EOF

# Create morning briefing job
cat > "$AGENTS_DIR/com.aria.morning-briefing.plist" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.aria.morning-briefing</string>
    <key>ProgramArguments</key>
    <array>
        <string>${VENV_DIR}/bin/python3</string>
        <string>${ARIA_DIR}/scripts/generate-briefing.py</string>
    </array>
    <key>StartCalendarInterval</key>
    <dict>
        <key>Hour</key><integer>7</integer>
        <key>Minute</key><integer>30</integer>
    </dict>
    <key>StandardOutPath</key>
    <string>${ARIA_DIR}/logs/launchd-briefing.log</string>
    <key>StandardErrorPath</key>
    <string>${ARIA_DIR}/logs/launchd-briefing.log</string>
</dict>
</plist>
EOF

# Create evening debrief job
cat > "$AGENTS_DIR/com.aria.evening-debrief.plist" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.aria.evening-debrief</string>
    <key>ProgramArguments</key>
    <array>
        <string>${VENV_DIR}/bin/python3</string>
        <string>${ARIA_DIR}/scripts/generate-debrief.py</string>
    </array>
    <key>StartCalendarInterval</key>
    <dict>
        <key>Hour</key><integer>21</integer>
        <key>Minute</key><integer>30</integer>
    </dict>
    <key>StandardOutPath</key>
    <string>${ARIA_DIR}/logs/launchd-debrief.log</string>
    <key>StandardErrorPath</key>
    <string>${ARIA_DIR}/logs/launchd-debrief.log</string>
</dict>
</plist>
EOF

# Create Telegram bot job (persistent)
cat > "$AGENTS_DIR/com.aria.telegram-bot.plist" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.aria.telegram-bot</string>
    <key>ProgramArguments</key>
    <array>
        <string>${VENV_DIR}/bin/python3</string>
        <string>${ARIA_DIR}/scripts/aria-telegram-bot.py</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>${ARIA_DIR}/logs/launchd-telegram-bot.log</string>
    <key>StandardErrorPath</key>
    <string>${ARIA_DIR}/logs/launchd-telegram-bot.log</string>
</dict>
</plist>
EOF

log "Loading scheduled jobs..."
for job in health-check email-sync calendar-sync morning-briefing evening-debrief telegram-bot; do
    launchctl bootstrap gui/$(id -u) "$AGENTS_DIR/com.aria.${job}.plist" 2>/dev/null || true
done

# --- Step 11: Verify ---
step 11 "Running health check"
"$VENV_DIR/bin/python3" "$ARIA_DIR/scripts/health-check.py" 2>&1 || true

# --- Step 12: Launch Onboarding ---
step 12 "Opening account connection wizard"
log "Starting onboarding server..."
echo ""
echo "╔══════════════════════════════════════╗"
echo "║        ARIA Setup Complete!          ║"
echo "║  Opening account connection wizard.  ║"
echo "╚══════════════════════════════════════╝"
echo ""
echo "The onboarding wizard will open in your browser."
echo "Use it to connect your Gmail, Calendar, and set up Telegram."
echo "Close the wizard when you're done."
echo ""
"$VENV_DIR/bin/python3" "$ARIA_DIR/scripts/onboarding-server.py"
echo "  6. Start n8n: cd $DOCKER_DIR && docker compose up -d"
echo ""
log "Setup complete. Run health check anytime: $VENV_DIR/bin/python3 $ARIA_DIR/scripts/health-check.py"
