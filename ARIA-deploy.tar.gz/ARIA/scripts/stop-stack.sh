#!/bin/bash
# Stop the ARIA Docker stack
cd "$HOME/self-hosted-ai-starter-kit"
docker compose down 2>&1
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Stack stopped" >> "$HOME/Desktop/dev projects/ARIA/logs/stack.log"
