#!/usr/bin/env python3
"""
ARIA Microsoft Teams Sync (Direct)
Fetches team channel messages and chat messages via Microsoft Graph API.
Uses stored OAuth credentials from config/credentials.json.

Saves to inbox/teams-YYYY-MM-DD.json.
Runs via launchd or manually.
"""

import json
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

import msal
import requests

import aria_ai

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
CREDENTIALS_FILE = PROJECT_DIR / "config" / "credentials.json"
MS_CLIENT_FILE = PROJECT_DIR / "config" / "microsoft-oauth-client.json"
LOG_FILE = PROJECT_DIR / "logs" / "teams-sync.log"

GRAPH_BASE = "https://graph.microsoft.com/v1.0"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_credentials():
    if CREDENTIALS_FILE.exists():
        with open(CREDENTIALS_FILE) as f:
            return json.load(f)
    return {"accounts": []}


def save_credentials(creds_data):
    with open(CREDENTIALS_FILE, "w") as f:
        json.dump(creds_data, f, indent=2)


def load_ms_client():
    if MS_CLIENT_FILE.exists():
        with open(MS_CLIENT_FILE) as f:
            return json.load(f)
    return None


def get_access_token(account, ms_config):
    """Get a valid access token, refreshing if needed."""
    app = msal.ConfidentialClientApplication(
        ms_config["client_id"],
        authority="https://login.microsoftonline.com/common",
        client_credential=ms_config["client_secret"],
    )

    refresh_token = account.get("refresh_token")
    if refresh_token:
        scopes = ["Chat.Read", "ChannelMessage.Read.All", "Team.ReadBasic.All", "User.Read"]
        result = app.acquire_token_by_refresh_token(refresh_token, scopes=scopes)
        if "access_token" in result:
            account["access_token"] = result["access_token"]
            if "refresh_token" in result:
                account["refresh_token"] = result["refresh_token"]
            return result["access_token"], True
        else:
            log(f"  Token refresh failed: {result.get('error_description', 'unknown')}")
            return None, False

    return account.get("access_token"), False


def graph_get(url, access_token, params=None):
    """Make a GET request to Microsoft Graph API."""
    headers = {"Authorization": f"Bearer {access_token}"}
    resp = requests.get(url, headers=headers, params=params, timeout=30)
    if resp.status_code == 200:
        return resp.json()
    elif resp.status_code == 403:
        log(f"  Graph API 403: Insufficient permissions. May need ChannelMessage.Read.All or Chat.Read scopes.")
        return None
    elif resp.status_code == 401:
        log(f"  Graph API 401: Token expired or invalid")
        return None
    else:
        log(f"  Graph API {resp.status_code}: {resp.text[:200]}")
        return None


def fetch_chats(access_token, hours_back=720):
    """Fetch recent 1:1 and group chat messages."""
    messages = []

    # Get list of chats
    data = graph_get(f"{GRAPH_BASE}/me/chats", access_token, {"$top": 50})
    if not data:
        return messages

    after_time = (datetime.utcnow() - timedelta(hours=hours_back)).strftime("%Y-%m-%dT%H:%M:%SZ")

    for chat in data.get("value", []):
        chat_id = chat.get("id")
        chat_type = chat.get("chatType", "oneOnOne")
        topic = chat.get("topic", "")

        # Get recent messages in this chat
        msg_data = graph_get(
            f"{GRAPH_BASE}/me/chats/{chat_id}/messages",
            access_token,
            {"$top": 20, "$orderby": "createdDateTime desc"}
        )
        if not msg_data:
            continue

        for msg in msg_data.get("value", []):
            created = msg.get("createdDateTime", "")
            if created < after_time:
                continue

            sender = msg.get("from", {})
            sender_name = ""
            if sender and sender.get("user"):
                sender_name = sender["user"].get("displayName", "")

            body = msg.get("body", {})
            content = body.get("content", "")
            # Strip HTML tags for plain text
            import re
            content = re.sub(r'<[^>]+>', '', content).strip()

            if content and sender_name:
                messages.append({
                    "chat_id": chat_id,
                    "chat_type": chat_type,
                    "topic": topic,
                    "sender": sender_name,
                    "content": content[:500],
                    "timestamp": created,
                    "message_id": msg.get("id", ""),
                })

    return messages


def fetch_team_channels(access_token, hours_back=720):
    """Fetch recent messages from Teams channels."""
    messages = []

    # Get teams the user is a member of
    teams_data = graph_get(f"{GRAPH_BASE}/me/joinedTeams", access_token)
    if not teams_data:
        return messages

    after_time = (datetime.utcnow() - timedelta(hours=hours_back)).strftime("%Y-%m-%dT%H:%M:%SZ")

    for team in teams_data.get("value", []):
        team_id = team.get("id")
        team_name = team.get("displayName", "Unknown Team")

        # Get channels
        channels_data = graph_get(f"{GRAPH_BASE}/teams/{team_id}/channels", access_token)
        if not channels_data:
            continue

        for channel in channels_data.get("value", []):
            channel_id = channel.get("id")
            channel_name = channel.get("displayName", "General")

            # Get recent messages
            msg_data = graph_get(
                f"{GRAPH_BASE}/teams/{team_id}/channels/{channel_id}/messages",
                access_token,
                {"$top": 20}
            )
            if not msg_data:
                continue

            for msg in msg_data.get("value", []):
                created = msg.get("createdDateTime", "")
                if created < after_time:
                    continue

                sender = msg.get("from", {})
                sender_name = ""
                if sender and sender.get("user"):
                    sender_name = sender["user"].get("displayName", "")

                body = msg.get("body", {})
                content = body.get("content", "")
                import re
                content = re.sub(r'<[^>]+>', '', content).strip()

                if content and sender_name:
                    messages.append({
                        "team": team_name,
                        "channel": channel_name,
                        "sender": sender_name,
                        "content": content[:500],
                        "timestamp": created,
                        "message_id": msg.get("id", ""),
                    })

    return messages


def main():
    log("Starting Teams sync...")
    INBOX_DIR.mkdir(parents=True, exist_ok=True)

    ms_config = load_ms_client()
    if not ms_config:
        log("No Microsoft OAuth config found. Run onboarding wizard.")
        return

    creds_data = load_credentials()
    ms_accounts = [a for a in creds_data.get("accounts", []) if a.get("type") == "microsoft"]

    if not ms_accounts:
        log("No Microsoft accounts connected.")
        return

    all_messages = []
    creds_updated = False

    for account in ms_accounts:
        email_addr = account.get("email", "unknown")
        log(f"Processing {email_addr}...")

        access_token, refreshed = get_access_token(account, ms_config)
        if refreshed:
            creds_updated = True

        if not access_token:
            log(f"  No valid token for {email_addr}")
            continue

        # Fetch chats (DMs and group chats)
        log("  Fetching chats...")
        chats = fetch_chats(access_token, hours_back=720)
        log(f"  {len(chats)} chat messages")
        all_messages.extend(chats)

        # Fetch team channel messages
        log("  Fetching team channels...")
        channels = fetch_team_channels(access_token, hours_back=720)
        log(f"  {len(channels)} channel messages")
        all_messages.extend(channels)

    # Save to inbox
    date_str = datetime.now().strftime("%Y-%m-%d")
    output_path = INBOX_DIR / f"teams-{date_str}.json"

    with open(output_path, "w") as f:
        json.dump(all_messages, f, indent=2)
    log(f"Saved {len(all_messages)} Teams messages to {output_path.name}")

    if creds_updated:
        save_credentials(creds_data)
        log("Credentials refreshed")

    log("Teams sync complete")


if __name__ == "__main__":
    main()
