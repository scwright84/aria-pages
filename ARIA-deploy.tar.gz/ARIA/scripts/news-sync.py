#!/usr/bin/env python3
"""
ARIA News Intelligence Feed
Fetches RSS feeds across client verticals, scores relevance with Ollama,
and saves top items to inbox/news-YYYY-MM-DD.json for briefing integration.

Runs via n8n cron or manually.
"""

import json
import re
import hashlib
import xml.etree.ElementTree as ET
import requests
from datetime import datetime, timedelta
from pathlib import Path
from html import unescape

import aria_ai

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
CONFIG_DIR = PROJECT_DIR / "config"
LOG_FILE = PROJECT_DIR / "logs" / "news-sync.log"
STATE_FILE = PROJECT_DIR / "logs" / "news-state.json"

# Common RSS date formats
DATE_FORMATS = [
    "%a, %d %b %Y %H:%M:%S %z",
    "%a, %d %b %Y %H:%M:%S %Z",
    "%Y-%m-%dT%H:%M:%S%z",
    "%Y-%m-%dT%H:%M:%SZ",
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%d",
]


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_config():
    path = CONFIG_DIR / "news-feeds.json"
    if path.exists():
        with open(path) as f:
            return json.load(f)
    return {"verticals": {}, "scoring": {"min_score": 60, "max_items_per_briefing": 8}}


def load_state():
    if STATE_FILE.exists():
        try:
            with open(STATE_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"seen_hashes": []}


def save_state(state):
    # Keep only last 500 hashes to prevent unbounded growth
    state["seen_hashes"] = state["seen_hashes"][-500:]
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def strip_html(text):
    """Remove HTML tags and decode entities."""
    text = re.sub(r'<[^>]+>', '', text)
    text = unescape(text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def parse_date(date_str):
    """Try multiple date formats."""
    if not date_str:
        return None
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(date_str.strip(), fmt)
        except (ValueError, TypeError):
            continue
    return None


def fetch_rss(url, timeout=15):
    """Fetch and parse an RSS feed, returning list of items."""
    items = []
    try:
        resp = requests.get(url, timeout=timeout, headers={
            "User-Agent": "ARIA/1.0 (Wright Advisors Intelligence Feed)"
        })
        if resp.status_code != 200:
            log(f"  HTTP {resp.status_code} from {url}")
            return items

        root = ET.fromstring(resp.content)

        # Handle both RSS 2.0 and Atom feeds
        ns = {"atom": "http://www.w3.org/2005/Atom"}

        # RSS 2.0
        for item in root.findall(".//item"):
            title = item.findtext("title", "")
            link = item.findtext("link", "")
            desc = item.findtext("description", "")
            pub_date = item.findtext("pubDate", "")
            items.append({
                "title": strip_html(title),
                "link": link.strip() if link else "",
                "description": strip_html(desc)[:500],
                "pub_date": pub_date,
            })

        # Atom
        for entry in root.findall("atom:entry", ns):
            title = entry.findtext("atom:title", "", ns)
            link_el = entry.find("atom:link[@rel='alternate']", ns)
            if link_el is None:
                link_el = entry.find("atom:link", ns)
            link = link_el.get("href", "") if link_el is not None else ""
            desc = entry.findtext("atom:summary", "", ns) or entry.findtext("atom:content", "", ns)
            pub_date = entry.findtext("atom:published", "", ns) or entry.findtext("atom:updated", "", ns)
            items.append({
                "title": strip_html(title),
                "link": link.strip(),
                "description": strip_html(desc)[:500],
                "pub_date": pub_date,
            })

    except ET.ParseError as e:
        log(f"  XML parse error from {url}: {e}")
    except requests.exceptions.RequestException as e:
        log(f"  Request error from {url}: {e}")
    except Exception as e:
        log(f"  Unexpected error from {url}: {e}")

    return items


def item_hash(item):
    """Generate a hash for dedup."""
    content = f"{item['title']}|{item['link']}"
    return hashlib.md5(content.encode()).hexdigest()


def is_recent(item, max_hours=48):
    """Check if an item is within the time window."""
    date = parse_date(item.get("pub_date", ""))
    if date is None:
        return True  # Include items with no date (can't filter)
    # Strip timezone for comparison
    if date.tzinfo:
        date = date.replace(tzinfo=None)
    cutoff = datetime.now() - timedelta(hours=max_hours)
    return date > cutoff


def keyword_match(text, keywords):
    """Check if any keyword appears in the text (case insensitive)."""
    text_lower = text.lower()
    matches = []
    for kw in keywords:
        if kw.lower() in text_lower:
            matches.append(kw)
    return matches


def score_batch_with_ollama(items_with_context):
    """Score a batch of news items for relevance using Ollama."""
    if not items_with_context:
        return []

    # Build batch prompt (score up to 10 at a time to stay within context)
    batch = items_with_context[:10]
    items_text = ""
    for i, item in enumerate(batch):
        items_text += f"\n[{i+1}] VERTICAL: {item['vertical_label']}\n"
        items_text += f"    CLIENTS: {', '.join(item['clients'])}\n"
        items_text += f"    TITLE: {item['title']}\n"
        items_text += f"    KEYWORDS HIT: {', '.join(item['keyword_matches'])}\n"
        items_text += f"    SNIPPET: {item['description'][:200]}\n"

    system_prompt = """You are ARIA, a news intelligence assistant. Score each news item for relevance to the user's work.

Consider:
- Direct relevance to the named client/vertical
- Actionability (can this be used in a conversation or decision?)
- Timeliness and urgency
- Strategic value (market shifts, regulatory changes, competitor moves)

Respond with ONLY a valid JSON array. No markdown, no explanation.
Format: [{"item": 1, "score": 75, "why": "one sentence reason", "urgency": "fyi" or "action"}, ...]

Score guide:
- 80+: Must see today. Direct impact or major market shift.
- 60-79: Relevant context for upcoming calls. Worth including in briefing.
- 40-59: Tangentially relevant. Skip unless slow news day.
- <40: Not relevant. Skip."""

    try:
        scores = aria_ai.chat_json(
            system_prompt,
            f"Score these {len(batch)} news items:{items_text}",
            fast=True
        )
        if scores and isinstance(scores, list):
            for score_entry in scores:
                idx = score_entry.get("item", 0) - 1
                if 0 <= idx < len(batch):
                    batch[idx]["score"] = score_entry.get("score", 0)
                    batch[idx]["score_reason"] = score_entry.get("why", "")
                    batch[idx]["urgency"] = score_entry.get("urgency", "fyi")
            return batch
        else:
            log("  AI scoring returned no results")
    except Exception as e:
        log(f"  AI scoring failed: {e}")

    # Fallback: use keyword match count as rough score
    for item in batch:
        item["score"] = min(40 + len(item.get("keyword_matches", [])) * 15, 80)
        item["score_reason"] = "Scored by keyword match (AI unavailable)"
        item["urgency"] = "fyi"
    return batch


def main():
    log("Starting news intelligence sync...")
    INBOX_DIR.mkdir(parents=True, exist_ok=True)

    config = load_config()
    state = load_state()
    seen = set(state.get("seen_hashes", []))
    verticals = config.get("verticals", {})
    scoring_config = config.get("scoring", {})
    min_score = scoring_config.get("min_score", 60)
    max_items = scoring_config.get("max_items_per_briefing", 8)
    max_per_vertical = scoring_config.get("max_items_per_vertical", 3)

    all_candidates = []

    for vertical_key, vertical in verticals.items():
        label = vertical.get("label", vertical_key)
        clients = vertical.get("clients", [])
        feeds = vertical.get("rss_feeds", [])
        keywords = vertical.get("keywords", [])

        log(f"Processing vertical: {label} ({len(feeds)} feeds)")

        for feed_url in feeds:
            items = fetch_rss(feed_url)
            log(f"  {feed_url}: {len(items)} items")

            for item in items:
                h = item_hash(item)
                if h in seen:
                    continue
                if not is_recent(item):
                    continue
                if not item.get("title"):
                    continue

                # Check keyword relevance
                full_text = f"{item['title']} {item['description']}"
                matches = keyword_match(full_text, keywords)

                if matches:
                    all_candidates.append({
                        "hash": h,
                        "title": item["title"],
                        "link": item["link"],
                        "description": item["description"],
                        "pub_date": item["pub_date"],
                        "vertical": vertical_key,
                        "vertical_label": label,
                        "clients": clients,
                        "keyword_matches": matches,
                        "feed_url": feed_url,
                        "score": 0,
                        "score_reason": "",
                        "urgency": "fyi",
                    })

    log(f"Found {len(all_candidates)} keyword-matched candidates")

    if not all_candidates:
        log("No new relevant items found.")
        save_state(state)
        return

    # Score in batches of 10
    scored = []
    for i in range(0, len(all_candidates), 10):
        batch = all_candidates[i:i+10]
        scored_batch = score_batch_with_ollama(batch)
        scored.extend(scored_batch)

    # Filter by score
    passing = [s for s in scored if s.get("score", 0) >= min_score]
    passing.sort(key=lambda x: x.get("score", 0), reverse=True)

    # Limit per vertical
    by_vertical = {}
    final_items = []
    for item in passing:
        v = item["vertical"]
        if v not in by_vertical:
            by_vertical[v] = 0
        if by_vertical[v] < max_per_vertical:
            by_vertical[v] += 1
            final_items.append(item)
        if len(final_items) >= max_items:
            break

    log(f"Scored: {len(passing)} passed threshold, {len(final_items)} selected for briefing")

    # Mark all candidates as seen
    for c in all_candidates:
        seen.add(c["hash"])
    state["seen_hashes"] = list(seen)
    save_state(state)

    if not final_items:
        log("No items passed scoring threshold.")
        return

    # Save to inbox
    today = datetime.now().strftime("%Y-%m-%d")
    news_path = INBOX_DIR / f"news-{today}.json"

    existing = []
    if news_path.exists():
        try:
            with open(news_path) as f:
                existing = json.load(f)
        except Exception:
            existing = []

    # Dedup by hash
    existing_hashes = {e.get("hash", "") for e in existing}
    for item in final_items:
        if item["hash"] not in existing_hashes:
            existing.append({
                "source": "news",
                "hash": item["hash"],
                "title": item["title"],
                "link": item["link"],
                "description": item["description"],
                "pub_date": item["pub_date"],
                "vertical": item["vertical"],
                "vertical_label": item["vertical_label"],
                "clients": item["clients"],
                "keyword_matches": item["keyword_matches"],
                "score": item["score"],
                "score_reason": item["score_reason"],
                "urgency": item["urgency"],
                "synced_at": datetime.now().isoformat(),
            })

    with open(news_path, "w") as f:
        json.dump(existing, f, indent=2)
    log(f"Saved {len(final_items)} items to {news_path}")

    log("News sync complete!")


if __name__ == "__main__":
    main()
