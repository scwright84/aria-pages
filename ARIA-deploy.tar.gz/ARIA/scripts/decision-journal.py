#!/usr/bin/env python3
"""
ARIA Decision Journal
Extracts and tracks decisions from briefings, emails, and meetings.
Over time, builds a searchable decision log with outcomes.

Captures:
  - What was decided
  - When
  - Context (what prompted the decision)
  - Who was involved
  - Expected outcome
  - Actual outcome (updated later)

Also detects patterns:
  - Recurring decision types (hiring, spending, strategy)
  - Decision velocity (how quickly do you decide?)
  - Reversal rate (how often do decisions get changed?)

Output: config/decisions.json (persistent log)
        briefings/YYYY-MM-DD-decisions.json (new decisions today)
Runs daily after briefing generation.
"""

import json
import re
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import aria_ai

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
DECISIONS_FILE = PROJECT_DIR / "config" / "decisions.json"
LOG_FILE = PROJECT_DIR / "logs" / "decision-journal.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_decisions():
    if DECISIONS_FILE.exists():
        try:
            with open(DECISIONS_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"decisions": [], "patterns": {}}


def save_decisions(data):
    DECISIONS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(DECISIONS_FILE, "w") as f:
        json.dump(data, f, indent=2, default=str)


def extract_from_briefings(days_back=1):
    """Extract decisions from briefing JSON files."""
    decisions = []
    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        date_str = date.strftime("%Y-%m-%d")
        path = BRIEFINGS_DIR / f"{date_str}.json"
        if not path.exists():
            continue

        try:
            with open(path) as f:
                data = json.load(f)
        except Exception:
            continue

        sections = data.get("sections", data)
        if not isinstance(sections, dict):
            continue

        # Look for decisions_needed section
        decisions_needed = sections.get("decisions_needed", [])
        if isinstance(decisions_needed, list):
            for item in decisions_needed:
                if isinstance(item, dict):
                    decisions.append({
                        "decision": item.get("decision", str(item)),
                        "context": item.get("context", ""),
                        "deadline": item.get("deadline", ""),
                        "so_what": item.get("so_what", ""),
                        "source": "briefing",
                        "date": date_str,
                        "status": "pending",
                    })
                elif isinstance(item, str) and len(item) > 10:
                    decisions.append({
                        "decision": item,
                        "context": "",
                        "deadline": "",
                        "so_what": "",
                        "source": "briefing",
                        "date": date_str,
                        "status": "pending",
                    })

    return decisions


def extract_from_emails(days_back=3):
    """Extract decision-related emails (action_type=decide or subjects with decision keywords)."""
    decisions = []
    decision_keywords = re.compile(r'decid|decision|approve|reject|go ahead|green light|sign off|final call', re.IGNORECASE)

    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        date_str = date.strftime("%Y-%m-%d")
        path = INBOX_DIR / f"emails-{date_str}.json"
        if not path.exists():
            continue

        try:
            with open(path) as f:
                emails = json.load(f)
        except Exception:
            continue

        for e in emails:
            subject = e.get("subject", "")
            summary = e.get("summary", "")
            action_type = e.get("action_type", "")

            if action_type in ("decide", "approve") or decision_keywords.search(f"{subject} {summary}"):
                decisions.append({
                    "decision": f"{subject}: {summary[:100]}" if summary else subject,
                    "context": e.get("snippet", "")[:200],
                    "deadline": "",
                    "so_what": "",
                    "source": "email",
                    "date": date_str,
                    "project": e.get("detected_project"),
                    "from": e.get("from", ""),
                    "status": "pending",
                })

    return decisions


def extract_from_commitments(days_back=7):
    """Extract decisions implicit in commitments (things that were decided in meetings)."""
    decisions = []
    decision_words = re.compile(r'agreed|decided|will|approved|confirmed|committed', re.IGNORECASE)

    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        date_str = date.strftime("%Y-%m-%d")
        path = INBOX_DIR / f"awaiting-{date_str}.json"
        if not path.exists():
            continue

        try:
            with open(path) as f:
                items = json.load(f)
        except Exception:
            continue

        for item in items:
            task = item.get("task", "")
            if decision_words.search(task):
                decisions.append({
                    "decision": task[:200],
                    "context": f"Meeting: {item.get('meeting', '')}",
                    "deadline": item.get("deadline", ""),
                    "so_what": "",
                    "source": "meeting",
                    "date": item.get("meeting_date", date_str),
                    "project": item.get("project"),
                    "status": "decided",
                })

    return decisions


def deduplicate(existing, new_decisions):
    """Add new decisions, skip duplicates."""
    existing_texts = set()
    for d in existing.get("decisions", []):
        existing_texts.add(d.get("decision", "")[:50].lower())

    added = 0
    for d in new_decisions:
        key = d.get("decision", "")[:50].lower()
        if key not in existing_texts and len(key) > 5:
            import hashlib
            d["id"] = hashlib.md5(f"{d['date']}:{d['decision']}".encode()).hexdigest()[:10]
            existing["decisions"].append(d)
            existing_texts.add(key)
            added += 1

    return added


def analyze_patterns(decisions_data):
    """Analyze decision patterns over time."""
    decisions = decisions_data.get("decisions", [])
    if len(decisions) < 3:
        return {}

    from collections import Counter

    sources = Counter(d.get("source", "unknown") for d in decisions)
    projects = Counter(d.get("project", "none") for d in decisions if d.get("project"))
    statuses = Counter(d.get("status", "unknown") for d in decisions)

    # Decisions per week
    weeks = Counter()
    for d in decisions:
        date_str = d.get("date", "")
        if date_str and len(date_str) >= 10:
            try:
                dt = datetime.strptime(date_str[:10], "%Y-%m-%d")
                week = dt.strftime("%Y-W%U")
                weeks[week] += 1
            except ValueError:
                pass

    avg_per_week = sum(weeks.values()) / max(len(weeks), 1)

    return {
        "total_decisions": len(decisions),
        "by_source": dict(sources),
        "by_project": dict(projects.most_common(5)),
        "by_status": dict(statuses),
        "avg_decisions_per_week": round(avg_per_week, 1),
        "pending_count": statuses.get("pending", 0),
    }


def main():
    log("Starting decision journal extraction")
    data = load_decisions()

    # Extract from all sources
    from_briefings = extract_from_briefings(days_back=3)
    from_emails = extract_from_emails(days_back=3)
    from_commitments = extract_from_commitments(days_back=7)

    all_new = from_briefings + from_emails + from_commitments
    log(f"Found: {len(from_briefings)} from briefings, {len(from_emails)} from emails, {len(from_commitments)} from meetings")

    added = deduplicate(data, all_new)
    log(f"Added {added} new decisions (total: {len(data['decisions'])})")

    # Analyze patterns
    data["patterns"] = analyze_patterns(data)
    save_decisions(data)

    # Save daily snapshot
    date_str = datetime.now().strftime("%Y-%m-%d")
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    snapshot = {
        "date": date_str,
        "new_decisions": added,
        "total_decisions": len(data["decisions"]),
        "patterns": data["patterns"],
        "recent": data["decisions"][-10:],
    }
    with open(BRIEFINGS_DIR / f"{date_str}-decisions.json", "w") as f:
        json.dump(snapshot, f, indent=2, default=str)

    log(f"Patterns: {json.dumps(data.get('patterns', {}))}")
    log("Decision journal complete")


if __name__ == "__main__":
    main()
