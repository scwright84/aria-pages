#!/usr/bin/env python3
"""
ARIA Workflow Optimizer
Analyzes communication patterns over time to identify:
1. Repetitive tasks that could be automated
2. Time sinks (high volume, low value)
3. Response patterns (templates the user sends repeatedly)
4. Commitment patterns (what slips, what gets done)
5. Workflow bottlenecks (where things stall)

Generates a weekly "Optimization Report" with actionable recommendations.
Runs weekly (Sunday, before the weekly rollup) or manually.

This is the feature Kelly identified as the north star:
"not just debriefs, but recommends what AI can/should help with"
"""

import json
import os
import re
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

import aria_ai

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
LOG_FILE = PROJECT_DIR / "logs" / "workflow-optimizer.log"
STATE_FILE = PROJECT_DIR / "logs" / "workflow-optimizer-state.json"
REPORT_DIR = PROJECT_DIR / "briefings"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_inbox_files(source, days_back=7):
    """Load all inbox files for a source over the past N days."""
    all_data = []
    for day_offset in range(days_back):
        date = datetime.now() - timedelta(days=day_offset)
        date_str = date.strftime("%Y-%m-%d")
        path = INBOX_DIR / f"{source}-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                if isinstance(data, list):
                    for item in data:
                        item["_date"] = date_str
                    all_data.extend(data)
            except Exception:
                pass
    return all_data


def load_state():
    if STATE_FILE.exists():
        try:
            with open(STATE_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"last_run": None, "previous_recommendations": [], "automation_score_history": []}


def save_state(state):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


# --- Analysis Functions ---

def analyze_email_patterns(emails):
    """Find repetitive email patterns that could be automated."""
    patterns = {
        "senders": Counter(),
        "subjects_by_sender": defaultdict(list),
        "high_volume_senders": [],
        "response_candidates": [],
        "fyi_volume": 0,
        "action_volume": 0,
        "total": len(emails),
    }

    for email in emails:
        sender = email.get("from", "unknown")
        # Normalize sender (extract just the email/name)
        sender_clean = re.sub(r'<[^>]+>', '', sender).strip().strip('"')
        patterns["senders"][sender_clean] += 1
        patterns["subjects_by_sender"][sender_clean].append(email.get("subject", ""))

        triage = email.get("triage", {})
        if triage.get("action_type") == "fyi":
            patterns["fyi_volume"] += 1
        elif triage.get("action_needed"):
            patterns["action_volume"] += 1

    # High volume senders (>5 emails/week)
    for sender, count in patterns["senders"].most_common(20):
        if count >= 5:
            subjects = patterns["subjects_by_sender"][sender]
            patterns["high_volume_senders"].append({
                "sender": sender,
                "count": count,
                "sample_subjects": subjects[:3],
            })

    # Response candidates: senders with many emails that need action
    for sender, count in patterns["senders"].most_common(20):
        if count >= 3:
            subjects = patterns["subjects_by_sender"][sender]
            # Check if subjects are similar (repetitive pattern)
            if len(set(s.lower()[:30] for s in subjects)) < len(subjects) * 0.7:
                patterns["response_candidates"].append({
                    "sender": sender,
                    "count": count,
                    "pattern": "Similar subjects detected - may be templateable",
                    "sample_subjects": subjects[:3],
                })

    return patterns


def analyze_calendar_patterns(events):
    """Find calendar patterns and time allocation."""
    patterns = {
        "total_events": len(events),
        "meetings_by_day": Counter(),
        "recurring_attendees": Counter(),
        "meeting_heavy_days": [],
        "avg_meetings_per_day": 0,
        "solo_time_estimate": 0,
    }

    days_seen = set()
    for event in events:
        start = event.get("start", "")
        if "T" in start:
            day = start.split("T")[0]
            days_seen.add(day)
            patterns["meetings_by_day"][day] += 1

        for attendee in event.get("attendees", []):
            name = attendee.get("name") or attendee.get("email", "")
            if name:
                patterns["recurring_attendees"][name] += 1

    if days_seen:
        total_meetings = sum(patterns["meetings_by_day"].values())
        patterns["avg_meetings_per_day"] = round(total_meetings / len(days_seen), 1)

        # Meeting-heavy days (>4 meetings)
        for day, count in patterns["meetings_by_day"].items():
            if count > 4:
                patterns["meeting_heavy_days"].append({"date": day, "count": count})

        # Estimate solo/deep work time (8hr day minus ~45min per meeting)
        avg_meeting_hours = patterns["avg_meetings_per_day"] * 0.75
        patterns["solo_time_estimate"] = round(8 - avg_meeting_hours, 1)

    return patterns


def analyze_commitment_patterns(awaiting_data):
    """Analyze what gets done vs what slips."""
    patterns = {
        "total_commitments": len(awaiting_data),
        "by_project": Counter(),
        "overdue": [],
        "patterns": [],
    }

    for item in awaiting_data:
        project = item.get("project", "Unknown")
        patterns["by_project"][project] += 1

        # Check if overdue
        due = item.get("due_date") or item.get("deadline")
        if due:
            try:
                due_date = datetime.strptime(due, "%Y-%m-%d")
                if due_date < datetime.now():
                    patterns["overdue"].append({
                        "description": item.get("description", ""),
                        "project": project,
                        "days_overdue": (datetime.now() - due_date).days,
                    })
            except ValueError:
                pass

    return patterns


def analyze_notification_patterns(notifications):
    """Find notification noise that could be filtered."""
    patterns = {
        "total": len(notifications),
        "by_app": Counter(),
        "noise_candidates": [],
    }

    for n in notifications:
        app = n.get("app", n.get("app_name", "Unknown"))
        patterns["by_app"][app] += 1

    # High-volume notification apps (potential noise)
    for app, count in patterns["by_app"].most_common(10):
        if count > 20:
            patterns["noise_candidates"].append({
                "app": app,
                "count": count,
                "suggestion": f"Consider muting or filtering {app} notifications ({count}/week)",
            })

    return patterns


def generate_recommendations(email_patterns, calendar_patterns, commitment_patterns, notification_patterns):
    """Use AI to synthesize patterns into actionable recommendations."""
    full_config = aria_ai.get_full_config()
    client_name = full_config.get("client", {}).get("contact_name", "the user")

    context = f"""WORKFLOW ANALYSIS FOR {client_name} (Past 7 Days)

EMAIL PATTERNS:
- Total emails: {email_patterns['total']}
- Emails needing action: {email_patterns['action_volume']}
- FYI emails (informational only): {email_patterns['fyi_volume']}
- High volume senders: {json.dumps(email_patterns['high_volume_senders'], indent=2)}
- Potential template candidates: {json.dumps(email_patterns['response_candidates'], indent=2)}

CALENDAR PATTERNS:
- Total events: {calendar_patterns['total_events']}
- Average meetings per day: {calendar_patterns['avg_meetings_per_day']}
- Meeting-heavy days: {json.dumps(calendar_patterns['meeting_heavy_days'], indent=2)}
- Estimated solo/deep work time per day: {calendar_patterns['solo_time_estimate']} hours
- Most frequent attendees: {json.dumps(dict(calendar_patterns['recurring_attendees'].most_common(5)), indent=2)}

COMMITMENT PATTERNS:
- Total tracked commitments: {commitment_patterns['total_commitments']}
- By project: {json.dumps(dict(commitment_patterns['by_project']), indent=2)}
- Overdue items: {json.dumps(commitment_patterns['overdue'], indent=2)}

NOTIFICATION PATTERNS:
- Total notifications: {notification_patterns['total']}
- By app: {json.dumps(dict(notification_patterns['by_app'].most_common(10)), indent=2)}
- Noise candidates: {json.dumps(notification_patterns['noise_candidates'], indent=2)}"""

    system_prompt = f"""You are ARIA's Workflow Optimizer. Analyze {client_name}'s communication patterns and generate specific, actionable recommendations for what AI can automate or improve.

For each recommendation, specify:
1. What the pattern is (with data)
2. What the automation would do
3. Estimated time saved per week
4. Difficulty to implement (easy/medium/hard)
5. Whether ARIA can do this now or it needs new capability

Respond with ONLY a valid JSON object:
{{
  "automation_score": 0-100,
  "automation_score_explanation": "one sentence explaining the score",
  "total_estimated_hours_saved": 0.0,
  "quick_wins": [
    {{
      "title": "short name",
      "pattern": "what you observed",
      "recommendation": "what to automate",
      "hours_saved_weekly": 0.0,
      "difficulty": "easy/medium/hard",
      "aria_ready": true/false
    }}
  ],
  "medium_term": [
    {{
      "title": "short name",
      "pattern": "what you observed",
      "recommendation": "what to build",
      "hours_saved_weekly": 0.0,
      "difficulty": "easy/medium/hard"
    }}
  ],
  "workflow_insights": [
    "observation about how {client_name} works and what could be better"
  ]
}}

Be specific and data-driven. Reference actual numbers from the analysis. Don't invent patterns that aren't in the data. If data is sparse, say so and recommend collecting more before acting."""

    result = aria_ai.chat_json(system_prompt, context, timeout=180)
    return result


def generate_report_html(recommendations, email_patterns, calendar_patterns, state):
    """Generate the HTML optimization report."""
    if not recommendations:
        recommendations = {
            "automation_score": 0,
            "automation_score_explanation": "Not enough data to analyze. Run for at least 7 days.",
            "total_estimated_hours_saved": 0,
            "quick_wins": [],
            "medium_term": [],
            "workflow_insights": ["Collecting data. First real analysis will be available next week."],
        }

    score = recommendations.get("automation_score", 0)
    score_color = "#10b981" if score >= 70 else "#f59e0b" if score >= 40 else "#ef4444"
    hours_saved = recommendations.get("total_estimated_hours_saved", 0)

    # Score history for trend
    history = state.get("automation_score_history", [])
    trend = ""
    if len(history) >= 2:
        diff = score - history[-1].get("score", 0)
        if diff > 0:
            trend = f" (up {diff} from last week)"
        elif diff < 0:
            trend = f" (down {abs(diff)} from last week)"

    quick_wins_html = ""
    for qw in recommendations.get("quick_wins", []):
        ready_badge = '<span style="background:#dcfce7;color:#166534;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;">ARIA Ready</span>' if qw.get("aria_ready") else '<span style="background:#fef3c7;color:#92400e;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;">Needs Build</span>'
        quick_wins_html += f"""
        <div style="padding:14px;margin-bottom:8px;background:#f8f9fb;border-radius:8px;border-left:3px solid #0096FF;">
            <div style="display:flex;justify-content:space-between;align-items:center;">
                <strong style="font-size:14px;">{qw.get('title', '')}</strong>
                {ready_badge}
            </div>
            <div style="font-size:13px;color:#374151;margin-top:6px;">{qw.get('pattern', '')}</div>
            <div style="font-size:13px;color:#0096FF;margin-top:4px;font-weight:500;">{qw.get('recommendation', '')}</div>
            <div style="font-size:12px;color:#6b7280;margin-top:4px;">Est. {qw.get('hours_saved_weekly', 0)} hrs/week saved | Difficulty: {qw.get('difficulty', 'unknown')}</div>
        </div>"""

    medium_html = ""
    for mt in recommendations.get("medium_term", []):
        medium_html += f"""
        <div style="padding:14px;margin-bottom:8px;background:#f8f9fb;border-radius:8px;border-left:3px solid #6366f1;">
            <strong style="font-size:14px;">{mt.get('title', '')}</strong>
            <div style="font-size:13px;color:#374151;margin-top:6px;">{mt.get('pattern', '')}</div>
            <div style="font-size:13px;color:#6366f1;margin-top:4px;font-weight:500;">{mt.get('recommendation', '')}</div>
            <div style="font-size:12px;color:#6b7280;margin-top:4px;">Est. {mt.get('hours_saved_weekly', 0)} hrs/week saved | Difficulty: {mt.get('difficulty', 'unknown')}</div>
        </div>"""

    insights_html = ""
    for insight in recommendations.get("workflow_insights", []):
        insights_html += f'<li style="font-size:13px;color:#374151;margin-bottom:8px;line-height:1.5;">{insight}</li>'

    html = f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>ARIA Workflow Optimization Report</title></head>
<body style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;max-width:640px;margin:0 auto;padding:24px;background:#fff;color:#1a1a2e;">

<div style="text-align:center;margin-bottom:24px;">
    <div style="font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#0096FF;">ARIA Workflow Optimizer</div>
    <div style="font-size:22px;font-weight:800;margin-top:4px;">Weekly Optimization Report</div>
    <div style="font-size:13px;color:#6b7280;">{datetime.now().strftime('%B %d, %Y')}</div>
</div>

<!-- Score Card -->
<div style="display:flex;gap:16px;margin-bottom:24px;">
    <div style="flex:1;text-align:center;padding:20px;border-radius:12px;background:linear-gradient(135deg,{score_color}15,{score_color}05);border:1px solid {score_color}30;">
        <div style="font-size:36px;font-weight:800;color:{score_color};">{score}</div>
        <div style="font-size:12px;font-weight:600;color:#374151;">Automation Score{trend}</div>
        <div style="font-size:11px;color:#6b7280;margin-top:4px;">{recommendations.get('automation_score_explanation', '')}</div>
    </div>
    <div style="flex:1;text-align:center;padding:20px;border-radius:12px;background:#eff6ff;border:1px solid #bfdbfe;">
        <div style="font-size:36px;font-weight:800;color:#0096FF;">{hours_saved}</div>
        <div style="font-size:12px;font-weight:600;color:#374151;">Hours/Week Saveable</div>
        <div style="font-size:11px;color:#6b7280;margin-top:4px;">If all recommendations implemented</div>
    </div>
</div>

<!-- Data Summary -->
<div style="display:flex;gap:8px;margin-bottom:24px;">
    <div style="flex:1;text-align:center;padding:10px;background:#f8f9fb;border-radius:8px;">
        <div style="font-size:18px;font-weight:700;">{email_patterns['total']}</div>
        <div style="font-size:11px;color:#6b7280;">Emails</div>
    </div>
    <div style="flex:1;text-align:center;padding:10px;background:#f8f9fb;border-radius:8px;">
        <div style="font-size:18px;font-weight:700;">{calendar_patterns['total_events']}</div>
        <div style="font-size:11px;color:#6b7280;">Meetings</div>
    </div>
    <div style="flex:1;text-align:center;padding:10px;background:#f8f9fb;border-radius:8px;">
        <div style="font-size:18px;font-weight:700;">{calendar_patterns['solo_time_estimate']}h</div>
        <div style="font-size:11px;color:#6b7280;">Deep Work/Day</div>
    </div>
    <div style="flex:1;text-align:center;padding:10px;background:#f8f9fb;border-radius:8px;">
        <div style="font-size:18px;font-weight:700;">{email_patterns['fyi_volume']}</div>
        <div style="font-size:11px;color:#6b7280;">FYI Emails</div>
    </div>
</div>

<!-- Quick Wins -->
<div style="margin-bottom:24px;">
    <h2 style="font-size:16px;font-weight:700;margin-bottom:12px;color:#1a1a2e;">Quick Wins (Implement This Week)</h2>
    {quick_wins_html or '<p style="font-size:13px;color:#9ca3af;">No quick wins identified yet. More data needed.</p>'}
</div>

<!-- Medium Term -->
<div style="margin-bottom:24px;">
    <h2 style="font-size:16px;font-weight:700;margin-bottom:12px;color:#1a1a2e;">Medium Term Opportunities</h2>
    {medium_html or '<p style="font-size:13px;color:#9ca3af;">No medium-term opportunities identified yet.</p>'}
</div>

<!-- Workflow Insights -->
<div style="margin-bottom:24px;">
    <h2 style="font-size:16px;font-weight:700;margin-bottom:12px;color:#1a1a2e;">Workflow Insights</h2>
    <ul style="padding-left:18px;">{insights_html or '<li style="font-size:13px;color:#9ca3af;">Collecting data for analysis.</li>'}</ul>
</div>

<div style="text-align:center;padding:16px;font-size:12px;color:#9ca3af;border-top:1px solid #e5e7eb;margin-top:24px;">
    ARIA Workflow Optimizer | This report is generated weekly from your communication patterns.
</div>

</body>
</html>"""

    return html


def main():
    log("Starting workflow optimization analysis...")

    # Collect data from past 7 days
    log("Collecting 7 days of email data...")
    emails = load_inbox_files("emails", days_back=7)
    log(f"  {len(emails)} emails")

    log("Collecting 7 days of calendar data...")
    events = load_inbox_files("calendar", days_back=7)
    log(f"  {len(events)} calendar events")

    log("Collecting commitment data...")
    awaiting = load_inbox_files("awaiting", days_back=7)
    log(f"  {len(awaiting)} commitment items")

    log("Collecting notification data...")
    notifications = load_inbox_files("notifications", days_back=7)
    log(f"  {len(notifications)} notifications")

    # Analyze patterns
    log("Analyzing email patterns...")
    email_patterns = analyze_email_patterns(emails)
    log(f"  {len(email_patterns['high_volume_senders'])} high-volume senders, {len(email_patterns['response_candidates'])} template candidates")

    log("Analyzing calendar patterns...")
    calendar_patterns = analyze_calendar_patterns(events)
    log(f"  {calendar_patterns['avg_meetings_per_day']} avg meetings/day, {calendar_patterns['solo_time_estimate']}h estimated deep work")

    log("Analyzing commitment patterns...")
    commitment_patterns = analyze_commitment_patterns(awaiting)
    log(f"  {len(commitment_patterns['overdue'])} overdue items")

    log("Analyzing notification patterns...")
    notification_patterns = analyze_notification_patterns(notifications)
    log(f"  {len(notification_patterns['noise_candidates'])} noise candidates")

    # Generate AI recommendations
    total_data = len(emails) + len(events) + len(awaiting) + len(notifications)
    if total_data > 10:
        log("Generating AI recommendations...")
        recommendations = generate_recommendations(
            email_patterns, calendar_patterns, commitment_patterns, notification_patterns
        )
    else:
        log("Not enough data for AI analysis (need at least 7 days). Generating placeholder report.")
        recommendations = None

    # Load state for trend tracking
    state = load_state()

    # Generate report
    log("Generating optimization report...")
    html = generate_report_html(recommendations, email_patterns, calendar_patterns, state)

    # Save report
    date_str = datetime.now().strftime("%Y-%m-%d")
    report_path = REPORT_DIR / f"optimization-{date_str}.html"
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    with open(report_path, "w") as f:
        f.write(html)
    log(f"Report saved to {report_path}")

    # Save JSON data
    json_path = REPORT_DIR / f"optimization-{date_str}.json"
    with open(json_path, "w") as f:
        json.dump({
            "date": date_str,
            "recommendations": recommendations,
            "email_patterns": {
                "total": email_patterns["total"],
                "action_volume": email_patterns["action_volume"],
                "fyi_volume": email_patterns["fyi_volume"],
                "high_volume_senders": email_patterns["high_volume_senders"],
                "response_candidates": email_patterns["response_candidates"],
            },
            "calendar_patterns": {
                "total_events": calendar_patterns["total_events"],
                "avg_meetings_per_day": calendar_patterns["avg_meetings_per_day"],
                "solo_time_estimate": calendar_patterns["solo_time_estimate"],
            },
            "commitment_patterns": {
                "total": commitment_patterns["total_commitments"],
                "overdue": len(commitment_patterns["overdue"]),
            },
        }, f, indent=2)

    # Update state
    if recommendations:
        state["automation_score_history"].append({
            "date": date_str,
            "score": recommendations.get("automation_score", 0),
        })
        # Keep last 12 weeks
        state["automation_score_history"] = state["automation_score_history"][-12:]
        state["previous_recommendations"] = recommendations.get("quick_wins", [])

    state["last_run"] = datetime.now().isoformat()
    save_state(state)

    # Send via email
    import aria_email
    full_config = aria_ai.get_full_config()
    recipient = full_config.get("email", "")
    if recipient and recommendations:
        score = recommendations.get("automation_score", 0)
        subject = f"ARIA Workflow Optimizer: Score {score}/100 - {recommendations.get('total_estimated_hours_saved', 0)} hrs/week saveable"
        success, method = aria_email.send_briefing_email(recipient, subject, html)
        log(f"Report email {'sent via ' + method if success else 'failed'}")

    log("Workflow optimization complete")


if __name__ == "__main__":
    main()
