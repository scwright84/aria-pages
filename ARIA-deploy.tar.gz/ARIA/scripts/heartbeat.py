#!/usr/bin/env python3
"""
ARIA Heartbeat
Sends a lightweight status ping to the admin server.
Runs every hour via launchd.

Sends: version, health, last briefing, sync stats, errors.
Never sends customer data (emails, calendar, messages).
"""

import json
import os
import platform
import subprocess
import sys
from datetime import datetime
from pathlib import Path

import requests

PROJECT_DIR = Path(__file__).parent.parent
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
CREDENTIALS_FILE = PROJECT_DIR / "config" / "credentials.json"
VERSION_FILE = PROJECT_DIR / "VERSION"
HEALTH_STATE = PROJECT_DIR / "logs" / "health-check-state.json"
HEARTBEAT_LOG = PROJECT_DIR / "logs" / "heartbeat.log"
HEARTBEAT_STATE = PROJECT_DIR / "logs" / "heartbeat-state.json"

# Default endpoint — override in aria.json under "monitoring.heartbeat_url"
DEFAULT_HEARTBEAT_URL = "https://scwright84.github.io/aria-pages/heartbeat"  # placeholder


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    HEARTBEAT_LOG.parent.mkdir(parents=True, exist_ok=True)
    with open(HEARTBEAT_LOG, "a") as f:
        f.write(line + "\n")


def get_version():
    if VERSION_FILE.exists():
        return VERSION_FILE.read_text().strip()
    return "unknown"


def get_install_id():
    """Unique ID per installation. Generated once, persists."""
    state = {}
    if HEARTBEAT_STATE.exists():
        try:
            with open(HEARTBEAT_STATE) as f:
                state = json.load(f)
        except Exception:
            pass

    if "install_id" not in state:
        import uuid
        state["install_id"] = str(uuid.uuid4())[:12]
        HEARTBEAT_STATE.parent.mkdir(parents=True, exist_ok=True)
        with open(HEARTBEAT_STATE, "w") as f:
            json.dump(state, f, indent=2)

    return state["install_id"]


def get_client_name():
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE) as f:
                config = json.load(f)
            return config.get("client", {}).get("name", config.get("email", "Unknown"))
        except Exception:
            pass
    return "Unknown"


def get_health():
    if HEALTH_STATE.exists():
        try:
            with open(HEALTH_STATE) as f:
                state = json.load(f)
            alerts = state.get("last_alerts", {})
            if alerts:
                return {"status": "warning", "issues": list(alerts.keys())}
            return {"status": "healthy", "issues": []}
        except Exception:
            pass
    return {"status": "unknown", "issues": []}


def get_connected_accounts():
    """Count connected accounts by type. Never sends account details."""
    if CREDENTIALS_FILE.exists():
        try:
            with open(CREDENTIALS_FILE) as f:
                creds = json.load(f)
            accounts = creds.get("accounts", [])
            counts = {}
            for a in accounts:
                atype = a.get("type", "unknown")
                counts[atype] = counts.get(atype, 0) + 1
            return {"total": len(accounts), "by_type": counts}
        except Exception:
            pass
    return {"total": 0, "by_type": {}}


def get_last_briefing():
    """Find the most recent briefing date."""
    briefings_dir = PROJECT_DIR / "briefings"
    if briefings_dir.exists():
        dates = []
        for f in briefings_dir.glob("*.html"):
            name = f.stem
            # Only match YYYY-MM-DD format (not suffixed files)
            if len(name) == 10 and name[4] == "-" and name[7] == "-":
                dates.append(name)
        if dates:
            return max(dates)
    return None


def get_last_sync():
    """Check when email sync last ran."""
    state_file = PROJECT_DIR / "logs" / "email-sync-state.json"
    if state_file.exists():
        try:
            with open(state_file) as f:
                state = json.load(f)
            return state.get("last_sync", {}).get("timestamp")
        except Exception:
            pass
    return None


def get_errors():
    """Get recent errors from logs (last 5)."""
    errors = []
    for log_name in ["email-sync.log", "launchd-command-center.log", "briefing.log"]:
        log_path = PROJECT_DIR / "logs" / log_name
        if log_path.exists():
            try:
                with open(log_path) as f:
                    lines = f.readlines()
                for line in lines[-50:]:
                    lower = line.lower()
                    if "error" in lower or "fail" in lower or "exception" in lower:
                        errors.append({"source": log_name, "line": line.strip()[-150:]})
            except Exception:
                pass
    return errors[-5:]


def get_hardware():
    """Basic hardware info — no identifying details."""
    try:
        ram = int(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / (1024 ** 3))
    except Exception:
        ram = 0
    return {
        "chip": platform.processor() or "unknown",
        "ram_gb": ram,
        "os_version": platform.mac_ver()[0],
    }


def build_heartbeat():
    """Build the heartbeat payload. Contains NO customer data."""
    return {
        "install_id": get_install_id(),
        "client_name": get_client_name(),
        "version": get_version(),
        "timestamp": datetime.now().isoformat(),
        "health": get_health(),
        "accounts": get_connected_accounts(),
        "last_briefing": get_last_briefing(),
        "last_sync": get_last_sync(),
        "hardware": get_hardware(),
        "errors": get_errors(),
        "uptime": _get_command_center_uptime(),
    }


def _get_command_center_uptime():
    """Check if the command center is running."""
    try:
        resp = requests.get("http://localhost:8642/", timeout=3)
        return "running" if resp.status_code == 200 else "error"
    except Exception:
        return "down"


def send_heartbeat():
    """Send heartbeat to admin server."""
    config = {}
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE) as f:
                config = json.load(f)
        except Exception:
            pass

    url = config.get("monitoring", {}).get("heartbeat_url", DEFAULT_HEARTBEAT_URL)
    if not url or "placeholder" in url:
        log("No heartbeat URL configured. Set monitoring.heartbeat_url in aria.json.")
        # Still save locally for admin to check via SSH/Tailscale
        payload = build_heartbeat()
        HEARTBEAT_STATE.parent.mkdir(parents=True, exist_ok=True)
        state = {}
        if HEARTBEAT_STATE.exists():
            try:
                with open(HEARTBEAT_STATE) as f:
                    state = json.load(f)
            except Exception:
                pass
        state["last_heartbeat"] = payload
        with open(HEARTBEAT_STATE, "w") as f:
            json.dump(state, f, indent=2)
        log("Heartbeat saved locally (no remote URL configured)")
        return

    payload = build_heartbeat()

    try:
        resp = requests.post(url, json=payload, timeout=10)
        if resp.status_code == 200:
            log(f"Heartbeat sent to {url}")
        else:
            log(f"Heartbeat failed: HTTP {resp.status_code}")
    except Exception as e:
        log(f"Heartbeat failed: {e}")

    # Always save locally too
    state = {}
    if HEARTBEAT_STATE.exists():
        try:
            with open(HEARTBEAT_STATE) as f:
                state = json.load(f)
        except Exception:
            pass
    state["last_heartbeat"] = payload
    with open(HEARTBEAT_STATE, "w") as f:
        json.dump(state, f, indent=2)


if __name__ == "__main__":
    send_heartbeat()
