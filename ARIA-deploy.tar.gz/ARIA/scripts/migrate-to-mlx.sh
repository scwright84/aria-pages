#!/bin/bash
# ARIA: Migrate from Ollama to MLX-native inference (oMLX)
#
# What this does:
#   1. Verifies MLX is installed
#   2. Downloads MLX-format models (Qwen3-8B, Qwen3-4B)
#   3. Stops Ollama
#   4. Starts mlx_lm.server on the same port (11434)
#   5. Verifies all endpoints work
#   6. Updates launchd to start MLX on boot instead of Ollama
#   7. If anything fails, rolls back to Ollama
#
# Performance gain: 2x faster token generation, 10x faster prompt processing
# on Apple Silicon (MLX is native to Apple's GPU, Ollama runs via llama.cpp)
#
# Rollback: ./scripts/migrate-to-mlx.sh --rollback

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
VENV="$PROJECT_DIR/.venv/bin"
AGENTS_DIR="$HOME/Library/LaunchAgents"
MLX_PORT=11434

BOLD='\033[1m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${GREEN}[MLX]${NC} $1"; }
warn() { echo -e "${YELLOW}[MLX]${NC} $1"; }
err()  { echo -e "${RED}[MLX]${NC} $1"; }
step() { echo -e "\n${BOLD}=== $1 ===${NC}"; }

# Models to download
DEFAULT_MODEL="mlx-community/Qwen3-8B-4bit"
FAST_MODEL="mlx-community/Qwen3-4B-4bit"

# ============================================================
# Rollback
# ============================================================

if [[ "${1:-}" == "--rollback" ]]; then
    step "Rolling back to Ollama"

    # Stop MLX server
    pkill -f "mlx_lm.server" 2>/dev/null || true
    pkill -f "mlx_lm server" 2>/dev/null || true
    log "Stopped MLX server"

    # Unload MLX launchd job
    launchctl unload "$AGENTS_DIR/com.aria.mlx-server.plist" 2>/dev/null || true

    # Start Ollama
    if command -v ollama &>/dev/null; then
        ollama serve &>/dev/null &
        sleep 3
        if curl -s http://localhost:$MLX_PORT/v1/models &>/dev/null; then
            log "Ollama is back online"
        else
            err "Ollama failed to start. Run: ollama serve"
        fi
    else
        err "Ollama not found. Install with: brew install ollama"
    fi

    log "Rollback complete. Running on Ollama."
    exit 0
fi

# ============================================================
# Migration
# ============================================================

step "Pre-flight checks"

# Check Apple Silicon
ARCH=$(uname -m)
if [[ "$ARCH" != "arm64" ]]; then
    err "MLX requires Apple Silicon (arm64). Your machine is $ARCH."
    err "Staying on Ollama."
    exit 1
fi
log "Apple Silicon: $ARCH"

# Check Python venv
if [[ ! -f "$VENV/python3" ]]; then
    err "Python venv not found at $VENV"
    exit 1
fi

# Check mlx_lm
if ! "$VENV/python3" -c "import mlx_lm" 2>/dev/null; then
    log "Installing mlx_lm..."
    "$VENV/pip" install mlx-lm --quiet
fi
MLX_VERSION=$("$VENV/python3" -c "import mlx_lm; print(getattr(mlx_lm, '__version__', 'installed'))" 2>/dev/null)
log "mlx_lm version: $MLX_VERSION"

# Check available RAM
RAM_GB=$(sysctl -n hw.memsize | awk '{printf "%.0f", $1/1073741824}')
log "Available RAM: ${RAM_GB}GB"
if [[ "$RAM_GB" -lt 8 ]]; then
    warn "Less than 8GB RAM. MLX performance may be limited."
fi

step "Downloading MLX models"

log "Downloading default model: $DEFAULT_MODEL"
"$VENV/python3" -c "
from mlx_lm import load
print('Downloading $DEFAULT_MODEL...')
model, tokenizer = load('$DEFAULT_MODEL')
print('Default model ready.')
" 2>&1 | grep -v "^$"

log "Downloading fast model: $FAST_MODEL"
"$VENV/python3" -c "
from mlx_lm import load
print('Downloading $FAST_MODEL...')
model, tokenizer = load('$FAST_MODEL')
print('Fast model ready.')
" 2>&1 | grep -v "^$"

step "Stopping Ollama"

# Save current state for rollback
OLLAMA_WAS_RUNNING=false
if pgrep ollama &>/dev/null; then
    OLLAMA_WAS_RUNNING=true
    log "Stopping Ollama..."

    # Quit the Ollama macOS app (it manages its own server)
    osascript -e 'quit app "Ollama"' 2>/dev/null || true
    sleep 2

    # Unload Ollama's launchd service
    launchctl bootout "gui/$(id -u)/com.ollama.ollama" 2>/dev/null || true
    launchctl remove com.ollama.ollama 2>/dev/null || true

    # Unload ARIA's stack-start if it references ollama
    launchctl unload "$AGENTS_DIR/com.aria.stack-start.plist" 2>/dev/null || true

    # Kill all ollama processes
    pkill -f "Ollama" 2>/dev/null || true
    pkill -f "ollama" 2>/dev/null || true
    sleep 3

    # Force kill if still running
    if pgrep -f ollama &>/dev/null; then
        warn "Ollama still running, force killing..."
        pkill -9 -f ollama 2>/dev/null || true
        sleep 2
    fi

    # Wait for port to be released
    log "Waiting for port $MLX_PORT to be free..."
    for i in $(seq 1 10); do
        if ! lsof -i :$MLX_PORT &>/dev/null; then
            log "Port $MLX_PORT is free"
            break
        fi
        sleep 1
        echo -n "."
    done
    echo ""

    if lsof -i :$MLX_PORT &>/dev/null; then
        err "Port $MLX_PORT still in use. Cannot proceed."
        err "Run: lsof -i :$MLX_PORT to see what's using it."
        exit 1
    fi

    log "Ollama stopped and port released"
else
    log "Ollama was not running"
fi

step "Starting MLX server"

# Start mlx_lm.server on the same port Ollama used
log "Starting MLX server on port $MLX_PORT with model $DEFAULT_MODEL..."

nohup "$VENV/python3" -m mlx_lm server \
    --model "$DEFAULT_MODEL" \
    --port $MLX_PORT \
    --host 127.0.0.1 \
    > "$PROJECT_DIR/logs/mlx-server.log" 2>&1 &

MLX_PID=$!
log "MLX server started (PID $MLX_PID)"

# Wait for it to be ready
log "Waiting for MLX server to be ready..."
for i in $(seq 1 30); do
    if curl -s http://localhost:$MLX_PORT/v1/models &>/dev/null; then
        log "MLX server is responding!"
        break
    fi
    sleep 1
    echo -n "."
done
echo ""

# Verify
if ! curl -s http://localhost:$MLX_PORT/v1/models &>/dev/null; then
    err "MLX server failed to start. Rolling back to Ollama."
    kill $MLX_PID 2>/dev/null || true
    if [[ "$OLLAMA_WAS_RUNNING" == true ]]; then
        ollama serve &>/dev/null &
        sleep 3
    fi
    err "Rollback complete. Check logs/mlx-server.log for errors."
    exit 1
fi

step "Verifying inference"

# First check what model name the server reports
log "Checking model name from server..."
MODELS_RESPONSE=$(curl -s http://localhost:$MLX_PORT/v1/models 2>/dev/null)
ACTUAL_MODEL=$(echo "$MODELS_RESPONSE" | "$VENV/python3" -c "import sys,json; d=json.load(sys.stdin); print(d['data'][0]['id'] if d.get('data') else '')" 2>/dev/null)
log "Server reports model: $ACTUAL_MODEL"

# Test a simple completion (try without model field first, then with reported name)
log "Testing inference..."
RESPONSE=$(curl -s http://localhost:$MLX_PORT/v1/chat/completions \
    -H "Content-Type: application/json" \
    -d '{
        "messages": [{"role": "user", "content": "Say the word hello. Nothing else."}],
        "max_tokens": 20
    }' 2>/dev/null)

CONTENT=$("$VENV/python3" -c "
import sys, json, re
try:
    d = json.loads(sys.stdin.read())
    content = d['choices'][0]['message']['content']
    # Strip think tags
    content = re.sub(r'<think>[\s\S]*?</think>', '', content).strip()
    print(content[:50])
except Exception as e:
    print(f'FAIL:{e}')
    sys.exit(1)
" <<< "$RESPONSE" 2>/dev/null)

if [[ "$CONTENT" != FAIL* ]] && [[ -n "$CONTENT" ]]; then
    log "Inference working! Response: $CONTENT"
else
    err "Inference test failed. Response: $RESPONSE"
    err "Rolling back to Ollama..."
    kill $MLX_PID 2>/dev/null || true
    pkill -f "mlx_lm" 2>/dev/null || true
    if [[ "$OLLAMA_WAS_RUNNING" == true ]]; then
        ollama serve &>/dev/null &
    fi
    exit 1
fi

step "Updating configuration"

# Update aria.json with MLX model names
"$VENV/python3" -c "
import json
config_path = '$PROJECT_DIR/config/aria.json'
with open(config_path) as f:
    config = json.load(f)

# Update model names
config['ai']['default_model'] = '$DEFAULT_MODEL'
config['ai']['fast_model'] = '$FAST_MODEL'
config['ai']['inference_engine'] = 'mlx'
config['ai']['_previous_engine'] = 'ollama'
config['ai']['_previous_default_model'] = config['ai'].get('default_model', 'qwen3:8b')
config['ai']['_previous_fast_model'] = config['ai'].get('fast_model', 'qwen3:4b')

with open(config_path, 'w') as f:
    json.dump(config, f, indent=2)
print('Config updated.')
"
log "aria.json updated with MLX model names"

step "Installing launchd service"

# Create launchd plist for MLX server
cat > "$AGENTS_DIR/com.aria.mlx-server.plist" << PLISTEOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.aria.mlx-server</string>
    <key>ProgramArguments</key>
    <array>
        <string>$VENV/python3</string>
        <string>-m</string>
        <string>mlx_lm</string>
        <string>server</string>
        <string>--model</string>
        <string>$DEFAULT_MODEL</string>
        <string>--port</string>
        <string>$MLX_PORT</string>
        <string>--host</string>
        <string>127.0.0.1</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>$PROJECT_DIR/logs/mlx-server.log</string>
    <key>StandardErrorPath</key>
    <string>$PROJECT_DIR/logs/mlx-server.log</string>
    <key>WorkingDirectory</key>
    <string>$PROJECT_DIR</string>
</dict>
</plist>
PLISTEOF

log "launchd service installed: com.aria.mlx-server"

step "Running ARIA test suite"

log "Verifying all ARIA scripts still work..."
# Quick verification that aria_ai can still call the inference
"$VENV/python3" -c "
import sys
sys.path.insert(0, '$PROJECT_DIR/scripts')
import aria_ai
aria_ai.reload_config()

# Test default model
result = aria_ai.chat('You are a test.', 'Say OK in one word.', timeout=60)
if result:
    print(f'Default model: OK ({result[:30].strip()})')
else:
    print('Default model: FAILED')
    sys.exit(1)
" 2>&1

if [[ $? -ne 0 ]]; then
    err "ARIA integration test failed. Rolling back..."
    kill $MLX_PID 2>/dev/null || true
    # Restore config
    "$VENV/python3" -c "
import json
config_path = '$PROJECT_DIR/config/aria.json'
with open(config_path) as f:
    config = json.load(f)
if '_previous_default_model' in config.get('ai', {}):
    config['ai']['default_model'] = config['ai'].pop('_previous_default_model')
    config['ai']['fast_model'] = config['ai'].pop('_previous_fast_model')
    config['ai'].pop('inference_engine', None)
    config['ai'].pop('_previous_engine', None)
with open(config_path, 'w') as f:
    json.dump(config, f, indent=2)
"
    if [[ "$OLLAMA_WAS_RUNNING" == true ]]; then
        ollama serve &>/dev/null &
    fi
    err "Rolled back to Ollama."
    exit 1
fi

step "Migration complete!"

echo ""
echo -e "${GREEN}${BOLD}Successfully migrated to MLX inference!${NC}"
echo ""
echo "  Engine:  MLX (Apple-native, GPU-accelerated)"
echo "  Default: $DEFAULT_MODEL"
echo "  Fast:    $FAST_MODEL"
echo "  Port:    $MLX_PORT (same as before)"
echo "  API:     OpenAI-compatible (same as before)"
echo ""
echo "  Performance improvement: ~2x faster token generation"
echo "  All existing scripts work without changes."
echo ""
echo "  To rollback: ./scripts/migrate-to-mlx.sh --rollback"
echo "  Server log:  $PROJECT_DIR/logs/mlx-server.log"
echo ""
warn "Ollama is still installed. You can remove it later with: brew uninstall ollama"
warn "Keep it around until you've verified MLX is stable for a few days."
