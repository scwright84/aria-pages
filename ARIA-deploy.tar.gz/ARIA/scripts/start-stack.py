#!/usr/bin/env python3
"""Start the ARIA Docker stack (postgres + n8n only, no qdrant)."""
import subprocess
import os
from datetime import datetime
from pathlib import Path

LOG = Path(__file__).parent.parent / "logs" / "stack.log"
LOG.parent.mkdir(parents=True, exist_ok=True)

# Ensure PATH includes /usr/local/bin for docker-credential-desktop and other tools
env = os.environ.copy()
env["PATH"] = "/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:" + env.get("PATH", "")

compose_dir = os.path.expanduser("~/self-hosted-ai-starter-kit")
result = subprocess.run(
    ["/usr/local/bin/docker", "compose", "up", "postgres", "n8n-import", "n8n", "-d"],
    cwd=compose_dir,
    capture_output=True,
    text=True,
    timeout=120,
    env=env,
)

ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
with open(LOG, "a") as f:
    f.write(f"[{ts}] Stack started (exit={result.returncode})\n")
    if result.stderr:
        f.write(f"  {result.stderr[:500]}\n")
