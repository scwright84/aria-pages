#!/bin/bash
# One-shot notification sync: reads new notifications and forwards to n8n
# Called by launchd on schedule

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
VENV="$PROJECT_DIR/.venv/bin/python3"
LOG="$PROJECT_DIR/logs/notification-sync.log"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Notification sync starting" >> "$LOG"
"$VENV" "$SCRIPT_DIR/notification-sync.py" >> "$LOG" 2>&1
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Notification sync complete" >> "$LOG"
