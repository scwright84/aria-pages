#!/usr/bin/env python3
"""
ARIA Email Actions
Manages Gmail inbox: archive junk, create draft replies, apply labels, learn preferences.

Uses the same OAuth credentials as email-sync.py.
Called by the command center API or can run standalone.
"""

import json
import os
import base64
from datetime import datetime
from pathlib import Path
from email.mime.text import MIMEText

from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build

import aria_ai

PROJECT_DIR = Path(__file__).parent.parent
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
CREDENTIALS_FILE = PROJECT_DIR / "config" / "credentials.json"
PREFERENCES_FILE = PROJECT_DIR / "config" / "email-preferences.json"
LOG_FILE = PROJECT_DIR / "logs" / "email-actions.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_credentials():
    if CREDENTIALS_FILE.exists():
        with open(CREDENTIALS_FILE) as f:
            return json.load(f)
    return {"accounts": []}


def load_preferences():
    if PREFERENCES_FILE.exists():
        try:
            with open(PREFERENCES_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {
        "important_senders": [],
        "junk_senders": [],
        "junk_domains": [],
        "junk_subject_patterns": [],
        "important_subject_patterns": [],
        "auto_archive_junk": False,
        "auto_label": True,
        "auto_draft_replies": True,
        "feedback_log": [],
    }


def save_preferences(prefs):
    PREFERENCES_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(PREFERENCES_FILE, "w") as f:
        json.dump(prefs, f, indent=2)


def get_gmail_service(account):
    """Build authenticated Gmail service from stored credentials."""
    creds = Credentials(
        token=account.get("access_token"),
        refresh_token=account.get("refresh_token"),
        token_uri=account.get("token_uri", "https://oauth2.googleapis.com/token"),
        client_id=account.get("client_id"),
        client_secret=account.get("client_secret"),
        scopes=account.get("scopes", []),
    )
    if creds.expired and creds.refresh_token:
        creds.refresh(Request())
        account["access_token"] = creds.token
    return build("gmail", "v1", credentials=creds)


def find_account(email_address=None):
    """Find the Gmail account credentials for a given email, or the first one."""
    creds_data = load_credentials()
    accounts = [a for a in creds_data.get("accounts", []) if "gmail" in a.get("services", [])]
    if not accounts:
        return None
    if email_address:
        for a in accounts:
            if a.get("email") == email_address:
                return a
    return accounts[0]


# ============================================================
# Actions
# ============================================================

def archive_email(message_id, account_email=None):
    """Archive an email (remove from INBOX label)."""
    account = find_account(account_email)
    if not account:
        return {"error": "No Gmail account found"}
    try:
        service = get_gmail_service(account)
        service.users().messages().modify(
            userId="me", id=message_id,
            body={"removeLabelIds": ["INBOX"]}
        ).execute()
        log(f"Archived message {message_id}")
        return {"status": "archived", "message_id": message_id}
    except Exception as e:
        log(f"Archive failed for {message_id}: {e}")
        return {"error": str(e)}


def trash_email(message_id, account_email=None):
    """Move an email to trash."""
    account = find_account(account_email)
    if not account:
        return {"error": "No Gmail account found"}
    try:
        service = get_gmail_service(account)
        service.users().messages().trash(userId="me", id=message_id).execute()
        log(f"Trashed message {message_id}")
        return {"status": "trashed", "message_id": message_id}
    except Exception as e:
        log(f"Trash failed for {message_id}: {e}")
        return {"error": str(e)}


def create_label(label_name, account_email=None):
    """Create a Gmail label if it doesn't exist. Returns label ID."""
    account = find_account(account_email)
    if not account:
        return None
    try:
        service = get_gmail_service(account)
        # Check if label exists
        labels = service.users().labels().list(userId="me").execute()
        for label in labels.get("labels", []):
            if label["name"] == label_name:
                return label["id"]
        # Create it
        result = service.users().labels().create(
            userId="me",
            body={"name": label_name, "labelListVisibility": "labelShow", "messageListVisibility": "show"}
        ).execute()
        log(f"Created label: {label_name}")
        return result["id"]
    except Exception as e:
        log(f"Label creation failed for {label_name}: {e}")
        return None


def label_email(message_id, label_name, account_email=None):
    """Apply a label to an email."""
    account = find_account(account_email)
    if not account:
        return {"error": "No Gmail account found"}
    label_id = create_label(f"ARIA/{label_name}", account_email)
    if not label_id:
        return {"error": f"Could not create label ARIA/{label_name}"}
    try:
        service = get_gmail_service(account)
        service.users().messages().modify(
            userId="me", id=message_id,
            body={"addLabelIds": [label_id]}
        ).execute()
        log(f"Labeled message {message_id} as ARIA/{label_name}")
        return {"status": "labeled", "message_id": message_id, "label": label_name}
    except Exception as e:
        log(f"Label failed for {message_id}: {e}")
        return {"error": str(e)}


def create_draft_reply(message_id, reply_text, account_email=None):
    """Create a draft reply to an email. Goes to Gmail Drafts folder."""
    account = find_account(account_email)
    if not account:
        return {"error": "No Gmail account found"}
    try:
        service = get_gmail_service(account)
        # Get the original message for threading
        original = service.users().messages().get(
            userId="me", id=message_id, format="metadata",
            metadataHeaders=["From", "To", "Subject", "Message-ID"]
        ).execute()
        headers = {h["name"]: h["value"] for h in original.get("payload", {}).get("headers", [])}

        # Build reply
        reply_to = headers.get("From", "")
        subject = headers.get("Subject", "")
        if not subject.lower().startswith("re:"):
            subject = f"Re: {subject}"

        message = MIMEText(reply_text)
        message["to"] = reply_to
        message["from"] = account.get("email", "")
        message["subject"] = subject
        message["In-Reply-To"] = headers.get("Message-ID", "")
        message["References"] = headers.get("Message-ID", "")

        raw = base64.urlsafe_b64encode(message.as_bytes()).decode()
        draft = service.users().drafts().create(
            userId="me",
            body={"message": {"raw": raw, "threadId": original.get("threadId")}}
        ).execute()

        log(f"Created draft reply to {reply_to} (subject: {subject})")
        return {"status": "draft_created", "draft_id": draft["id"], "to": reply_to, "subject": subject}
    except Exception as e:
        log(f"Draft creation failed: {e}")
        return {"error": str(e)}


def generate_draft_reply(message_id, account_email=None):
    """Use AI to generate a draft reply, then save it to Gmail Drafts."""
    account = find_account(account_email)
    if not account:
        return {"error": "No Gmail account found"}
    try:
        service = get_gmail_service(account)
        msg = service.users().messages().get(
            userId="me", id=message_id, format="full"
        ).execute()
        headers = {h["name"]: h["value"] for h in msg.get("payload", {}).get("headers", [])}
        snippet = msg.get("snippet", "")

        # Get email body
        body = ""
        payload = msg.get("payload", {})
        if "parts" in payload:
            for part in payload["parts"]:
                if part.get("mimeType") == "text/plain":
                    data = part.get("body", {}).get("data", "")
                    if data:
                        body = base64.urlsafe_b64decode(data).decode("utf-8", errors="replace")
                        break
        elif payload.get("body", {}).get("data"):
            body = base64.urlsafe_b64decode(payload["body"]["data"]).decode("utf-8", errors="replace")

        if not body:
            body = snippet

        # Load soul file for context
        soul = ""
        soul_path = PROJECT_DIR / "config" / "soul.md"
        if soul_path.exists():
            with open(soul_path) as f:
                soul = f.read()[:1000]

        sender = headers.get("From", "")
        subject = headers.get("Subject", "")

        system = f"""You are drafting an email reply on behalf of the user. Write a professional, concise reply.
{('Context about the user: ' + soul) if soul else ''}
Keep it natural and direct. Match the tone of the original email. Don't be overly formal unless the original is.
Return ONLY the reply text (no subject line, no "Dear X" unless appropriate). Ready to send."""

        reply_text = aria_ai.chat(
            system,
            f"Reply to this email:\nFrom: {sender}\nSubject: {subject}\n\n{body[:2000]}",
            escalate=True,
            timeout=30,
        )

        if not reply_text:
            return {"error": "AI could not generate a reply"}

        # Save as draft
        return create_draft_reply(message_id, reply_text, account_email)
    except Exception as e:
        log(f"Generate draft failed: {e}")
        return {"error": str(e)}


# ============================================================
# Feedback / Learning
# ============================================================

def record_feedback(sender, subject, feedback_type, details=""):
    """Record user feedback on an email for future triage learning.

    feedback_type: 'important', 'not_important', 'junk', 'wrong_project'
    """
    prefs = load_preferences()

    # Extract domain from sender
    domain = ""
    if "@" in sender:
        domain = sender.split("@")[-1].strip(">").strip()

    entry = {
        "timestamp": datetime.now().isoformat(),
        "sender": sender,
        "domain": domain,
        "subject": subject,
        "feedback": feedback_type,
        "details": details,
    }
    prefs["feedback_log"].append(entry)

    # Auto-update rules based on feedback
    if feedback_type == "junk":
        if domain and domain not in prefs["junk_domains"]:
            prefs["junk_domains"].append(domain)
        if sender and sender not in prefs["junk_senders"]:
            prefs["junk_senders"].append(sender)
    elif feedback_type == "important":
        if sender and sender not in prefs["important_senders"]:
            prefs["important_senders"].append(sender)
        # Remove from junk if previously marked
        if sender in prefs["junk_senders"]:
            prefs["junk_senders"].remove(sender)
    elif feedback_type == "not_important":
        # Don't auto-junk, but record for AI to learn from
        pass

    # Keep feedback log manageable
    prefs["feedback_log"] = prefs["feedback_log"][-500:]

    save_preferences(prefs)
    log(f"Feedback recorded: {feedback_type} for {sender[:40]}")
    return {"status": "recorded", "feedback": feedback_type}


def get_preferences_summary():
    """Return a summary of learned preferences for the triage prompt."""
    prefs = load_preferences()
    parts = []
    if prefs.get("important_senders"):
        parts.append(f"Always flag as important: {', '.join(prefs['important_senders'][:10])}")
    if prefs.get("junk_senders"):
        parts.append(f"Junk/ignore: {', '.join(prefs['junk_senders'][:10])}")
    if prefs.get("junk_domains"):
        parts.append(f"Junk domains: {', '.join(prefs['junk_domains'][:10])}")
    return "\n".join(parts) if parts else ""
