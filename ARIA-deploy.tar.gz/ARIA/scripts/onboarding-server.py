#!/usr/bin/env python3
"""
ARIA Onboarding Server
Local web UI for connecting email, calendar, and other accounts.
Run this during setup, then close when done.

Usage: python3 scripts/onboarding-server.py
Opens: http://localhost:8642
"""

import json
import os
import secrets
import sys
import webbrowser
from datetime import datetime
from pathlib import Path
from urllib.parse import urlencode

import requests as http_requests
from flask import Flask, redirect, request, render_template_string, url_for, flash, session
from google_auth_oauthlib.flow import Flow
from google.oauth2.credentials import Credentials
import msal

# Allow HTTP for localhost OAuth (Google requires this flag for non-HTTPS)
os.environ["OAUTHLIB_INSECURE_TRANSPORT"] = "1"

PROJECT_DIR = Path(__file__).parent.parent
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
CREDENTIALS_FILE = PROJECT_DIR / "config" / "credentials.json"
GOOGLE_CLIENT_FILE = PROJECT_DIR / "config" / "google-oauth-client.json"

ONBOARDING_PORT = 8642
REDIRECT_URI = f"http://localhost:{ONBOARDING_PORT}/oauth/google/callback"
MS_REDIRECT_URI = f"http://localhost:{ONBOARDING_PORT}/oauth/microsoft/callback"

# Google API scopes
GMAIL_SCOPES = [
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/gmail.labels",
]
CALENDAR_SCOPES = [
    "https://www.googleapis.com/auth/calendar.readonly",
]
ALL_SCOPES = GMAIL_SCOPES + CALENDAR_SCOPES

# Microsoft scopes (read + write for email management, send for draft delivery)
# Note: offline_access, openid, profile are added automatically by MSAL - don't include them
MS_SCOPES = [
    "Mail.Read",
    "Mail.ReadWrite",
    "Mail.Send",
    "Calendars.Read",
    "Calendars.ReadWrite",
    "User.Read",
    "Chat.Read",
    "ChannelMessage.Read.All",
    "Team.ReadBasic.All",
]
MS_CLIENT_FILE = PROJECT_DIR / "config" / "microsoft-oauth-client.json"
MS_AUTHORITY = "https://login.microsoftonline.com/common"

# Slack OAuth (uses GitHub Pages as HTTPS relay for the callback)
SLACK_CLIENT_FILE = PROJECT_DIR / "config" / "slack-oauth-client.json"
SLACK_REDIRECT_URI = "https://scwright84.github.io/aria-pages/slack-callback.html"
SLACK_SCOPES = "channels:history,channels:read,groups:read,groups:history,users:read,team:read,im:history,im:read,mpim:history,mpim:read"

app = Flask(__name__)
app.secret_key = secrets.token_hex(32)

# Detect hardware once at startup
try:
    import importlib.util as _ilu
    _spec = _ilu.spec_from_file_location("hw", str(PROJECT_DIR / "scripts" / "detect-hardware.py"))
    _hw_mod = _ilu.module_from_spec(_spec)
    _spec.loader.exec_module(_hw_mod)
    _hw_result = _hw_mod.detect()
    _hw_info = _hw_result["hardware"]
    _hw_rec = _hw_result["recommendation"]
except Exception:
    _hw_info = {"mac_model": "Unknown", "chip": "Unknown", "ram_gb": 0}
    _hw_rec = {"tier_name": "Unknown", "local_percentage": 0, "cloud_percentage": 0}


# --- Helpers ---

def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def save_config(config):
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)


def load_credentials():
    if CREDENTIALS_FILE.exists():
        with open(CREDENTIALS_FILE) as f:
            return json.load(f)
    return {"accounts": []}


def save_credentials(creds):
    CREDENTIALS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CREDENTIALS_FILE, "w") as f:
        json.dump(creds, f, indent=2)
    # Secure the file
    os.chmod(CREDENTIALS_FILE, 0o600)


def get_connected_accounts():
    """Get list of connected accounts with status."""
    creds = load_credentials()
    accounts = []
    for acct in creds.get("accounts", []):
        accounts.append({
            "email": acct.get("email", "Unknown"),
            "type": acct.get("type", "google"),
            "services": acct.get("services", []),
            "connected_at": acct.get("connected_at", ""),
            "status": "connected" if acct.get("refresh_token") else "expired",
        })
    return accounts


def _check_tailscale():
    """Check if Tailscale is installed and connected."""
    import subprocess
    try:
        result = subprocess.run(["tailscale", "status", "--json"],
                                capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            data = json.loads(result.stdout)
            return data.get("BackendState") == "Running"
    except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError):
        pass
    return False


def google_client_exists():
    return GOOGLE_CLIENT_FILE.exists()


def ms_client_exists():
    return MS_CLIENT_FILE.exists()


def slack_client_exists():
    return SLACK_CLIENT_FILE.exists()


def get_slack_client_config():
    if SLACK_CLIENT_FILE.exists():
        with open(SLACK_CLIENT_FILE) as f:
            return json.load(f)
    return None


def get_ms_client_config():
    """Load Microsoft OAuth client config."""
    if MS_CLIENT_FILE.exists():
        with open(MS_CLIENT_FILE) as f:
            return json.load(f)
    return None


def get_ms_app():
    """Create MSAL confidential client application."""
    config = get_ms_client_config()
    if not config:
        return None
    return msal.ConfidentialClientApplication(
        config["client_id"],
        authority=MS_AUTHORITY,
        client_credential=config.get("client_secret"),
    )


# --- HTML Templates ---

DASHBOARD_HTML = """
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>ARIA Setup</title>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Inter', sans-serif; background: #f8f9fb; color: #1a1a2e; min-height: 100vh; }
    .container { max-width: 720px; margin: 0 auto; padding: 40px 20px; }
    .header { text-align: center; margin-bottom: 40px; }
    .header h1 { font-size: 28px; font-weight: 800; color: #1a1a2e; }
    .header p { font-size: 15px; color: #6b7280; margin-top: 6px; }
    .card { background: #fff; border-radius: 12px; border: 1px solid #e5e7eb; padding: 24px; margin-bottom: 16px; }
    .card h2 { font-size: 16px; font-weight: 700; margin-bottom: 12px; display: flex; align-items: center; gap: 8px; }
    .card p { font-size: 14px; color: #6b7280; margin-bottom: 16px; line-height: 1.5; }
    .status { display: inline-block; font-size: 11px; font-weight: 700; padding: 3px 10px; border-radius: 12px; text-transform: uppercase; letter-spacing: 0.5px; }
    .status.connected { background: #dcfce7; color: #166534; }
    .status.not-connected { background: #fef3c7; color: #92400e; }
    .status.error { background: #fee2e2; color: #991b1b; }
    .btn { display: inline-block; padding: 10px 20px; border-radius: 8px; font-size: 14px; font-weight: 600; text-decoration: none; cursor: pointer; border: none; }
    .btn-primary { background: #0096FF; color: #fff; }
    .btn-primary:hover { background: #0077cc; }
    .btn-secondary { background: #f3f4f6; color: #374151; }
    .btn-secondary:hover { background: #e5e7eb; }
    .btn-danger { background: #fee2e2; color: #991b1b; }
    .btn-sm { padding: 6px 14px; font-size: 12px; }
    .account-row { display: flex; align-items: center; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #f3f4f6; }
    .account-row:last-child { border-bottom: none; }
    .account-info { display: flex; align-items: center; gap: 12px; }
    .account-email { font-size: 14px; font-weight: 500; }
    .account-services { font-size: 12px; color: #6b7280; }
    .flash { padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 14px; }
    .flash.success { background: #dcfce7; color: #166534; }
    .flash.error { background: #fee2e2; color: #991b1b; }
    .flash.info { background: #dbeafe; color: #1e40af; }
    .setup-steps { list-style: none; padding: 0; }
    .setup-steps li { padding: 10px 0; border-bottom: 1px solid #f3f4f6; font-size: 14px; display: flex; align-items: center; gap: 10px; }
    .setup-steps li:last-child { border-bottom: none; }
    .check { color: #16a34a; font-weight: 700; }
    .pending { color: #d97706; font-weight: 700; }
    .step-num { width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; flex-shrink: 0; }
    .step-done { background: #dcfce7; color: #166534; }
    .step-todo { background: #fef3c7; color: #92400e; }
    .config-section { margin-top: 12px; }
    .config-row { display: flex; justify-content: space-between; padding: 6px 0; font-size: 13px; }
    .config-label { color: #6b7280; }
    .config-value { font-weight: 500; }
    input[type="text"], input[type="number"], select {
        width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;
        font-size: 14px; font-family: 'Inter', sans-serif; margin-bottom: 12px;
    }
    label { font-size: 13px; font-weight: 500; color: #374151; display: block; margin-bottom: 4px; }
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>ARIA Setup</h1>
        <p>Connect your accounts to get started</p>
    </div>

    {% with messages = get_flashed_messages(with_categories=true) %}
    {% if messages %}
    {% for category, message in messages %}
    <div class="flash {{ category }}">{{ message }}</div>
    {% endfor %}
    {% endif %}
    {% endwith %}

    <!-- Quick Setup Checklist -->
    <div class="card">
        <h2>Quick Setup Checklist</h2>
        <p style="font-size:13px;color:#6b7280;margin-bottom:12px;">Complete these to get your first briefing.</p>
        <ul class="setup-steps">
            <li>
                <div class="step-num {{ 'step-done' if email_connected else 'step-todo' }}">{{ '✓' if email_connected else '1' }}</div>
                First email account connected {% if not email_connected and google_client %}
                <a href="/connect/google?scope=all" class="btn btn-primary btn-sm" style="margin-left:auto;">Connect Gmail</a>
                {% elif not google_client %}
                <a href="/setup/google-client" class="btn btn-primary btn-sm" style="margin-left:auto;">Setup Google OAuth</a>
                {% endif %}
            </li>
            <li>
                <div class="step-num {{ 'step-done' if calendar_connected else 'step-todo' }}">{{ '✓' if calendar_connected else '2' }}</div>
                Calendar connected {% if not calendar_connected and google_client and email_connected %}
                <a href="/connect/google?scope=calendar" class="btn btn-primary btn-sm" style="margin-left:auto;">Connect Calendar</a>
                {% endif %}
            </li>
            <li>
                <div class="step-num {{ 'step-done' if telegram_set else 'step-todo' }}">{{ '✓' if telegram_set else '3' }}</div>
                Telegram bot configured {% if not telegram_set %}
                <a href="/setup/telegram" class="btn btn-primary btn-sm" style="margin-left:auto;">Setup Telegram</a>
                {% endif %}
            </li>
            <li>
                <div class="step-num {{ 'step-done' if notifications_enabled else 'step-todo' }}">{{ '✓' if notifications_enabled else '4' }}</div>
                Notification monitoring (iMessage, WhatsApp, Signal) {% if not notifications_enabled %}
                <a href="/setup/notifications" class="btn btn-primary btn-sm" style="margin-left:auto;">Enable</a>
                {% endif %}
            </li>
            <li>
                <div class="step-num {{ 'step-done' if tailscale_connected else 'step-todo' }}">{{ '✓' if tailscale_connected else '5' }}</div>
                Remote support connected {% if not tailscale_connected %}
                <a href="/setup/remote-support" class="btn btn-primary btn-sm" style="margin-left:auto;">Connect</a>
                {% endif %}
            </li>
        </ul>
        {% if email_connected and calendar_connected and telegram_set %}
        <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:12px 16px;margin-top:12px;font-size:14px;color:#166534;font-weight:500;">
            Setup complete. Your first briefing will arrive at {{ briefing_time }} tomorrow. Add more accounts below to give ARIA full visibility.
        </div>
        {% endif %}
    </div>

    <!-- Connected Accounts -->
    <div class="card">
        <h2>Connected Accounts ({{ accounts | length }})</h2>
        {% if accounts %}
        {% for acct in accounts %}
        <div class="account-row">
            <div class="account-info">
                <div>
                    <div class="account-email">{{ acct.email }}</div>
                    <div class="account-services">{{ ', '.join(acct.services) }} &middot; {{ acct.type }}</div>
                </div>
            </div>
            <div>
                <span class="status {{ acct.status }}">{{ acct.status }}</span>
                <a href="/disconnect/{{ loop.index0 }}" class="btn btn-danger btn-sm" style="margin-left:8px;">Remove</a>
            </div>
        </div>
        {% endfor %}
        {% else %}
        <p style="font-size:14px;color:#9ca3af;">No accounts connected yet.</p>
        {% endif %}
    </div>

    <!-- Add Accounts -->
    <div class="card">
        <h2>Add Accounts</h2>
        <p style="font-size:13px;color:#6b7280;margin-bottom:16px;">The more channels ARIA monitors, the better your briefings.</p>

        <!-- Google (Gmail + Calendar) -->
        <div style="padding:14px;background:#f8f9fb;border-radius:8px;margin-bottom:10px;display:flex;align-items:center;justify-content:space-between;">
            <div>
                <div style="font-size:14px;font-weight:600;">Google (Gmail + Calendar)</div>
                <div style="font-size:12px;color:#6b7280;">Connect any Google account. Add as many as you need.</div>
            </div>
            <div style="display:flex;gap:6px;">
                {% if google_client %}
                <a href="/connect/google?scope=all" class="btn btn-primary btn-sm">Connect</a>
                <a href="/connect/google?scope=email" class="btn btn-secondary btn-sm">Gmail Only</a>
                <a href="/connect/google?scope=calendar" class="btn btn-secondary btn-sm">Calendar Only</a>
                {% else %}
                <a href="/setup/google-client" class="btn btn-primary btn-sm">Setup Required</a>
                {% endif %}
            </div>
        </div>

        <!-- Slack -->
        <div style="padding:14px;background:#f8f9fb;border-radius:8px;margin-bottom:10px;display:flex;align-items:center;justify-content:space-between;">
            <div>
                <div style="font-size:14px;font-weight:600;">Slack</div>
                <div style="font-size:12px;color:#6b7280;">Monitor team conversations. ARIA summarizes channels daily.</div>
            </div>
            {% if slack_client %}
            <a href="/connect/slack" class="btn btn-primary btn-sm">Connect Workspace</a>
            {% else %}
            <a href="/setup/slack" class="btn btn-primary btn-sm">Setup Slack</a>
            {% endif %}
        </div>

        <!-- Outlook -->
        <div style="padding:14px;background:#f8f9fb;border-radius:8px;margin-bottom:10px;display:flex;align-items:center;justify-content:space-between;">
            <div>
                <div style="font-size:14px;font-weight:600;">Outlook / Microsoft 365</div>
                <div style="font-size:12px;color:#6b7280;">Connect Outlook email and calendar.</div>
            </div>
            {% if ms_client %}
            <a href="/connect/microsoft" class="btn btn-primary btn-sm">Connect Account</a>
            {% else %}
            <a href="/setup/outlook" class="btn btn-primary btn-sm">Setup Outlook</a>
            {% endif %}
        </div>

        <!-- Microsoft Teams -->
        {% if ms_client %}
        <div style="padding:14px;background:#f8f9fb;border-radius:8px;margin-bottom:10px;display:flex;align-items:center;justify-content:space-between;">
            <div>
                <div style="font-size:14px;font-weight:600;">Microsoft Teams</div>
                <div style="font-size:12px;color:#6b7280;">
                    {% if ms_connected %}Included with your Outlook connection. Channels and chats are monitored.
                    {% else %}Connect Outlook above to also enable Teams monitoring.{% endif %}
                </div>
            </div>
            {% if ms_connected %}
            <span class="status connected">Active</span>
            {% else %}
            <a href="/connect/microsoft" class="btn btn-primary btn-sm">Connect Microsoft</a>
            {% endif %}
        </div>
        {% endif %}

        <!-- Zoom -->
        <div style="padding:14px;background:#f8f9fb;border-radius:8px;margin-bottom:10px;display:flex;align-items:center;justify-content:space-between;">
            <div>
                <div style="font-size:14px;font-weight:600;">Zoom</div>
                <div style="font-size:12px;color:#6b7280;">Sync meeting recordings and transcripts.</div>
            </div>
            {% if zoom_client %}
            <a href="/connect/zoom" class="btn btn-primary btn-sm">Connect Zoom</a>
            {% else %}
            <a href="/setup/zoom" class="btn btn-primary btn-sm">Setup Zoom</a>
            {% endif %}
        </div>

        <!-- Granola -->
        <div style="padding:14px;background:#f8f9fb;border-radius:8px;margin-bottom:10px;display:flex;align-items:center;justify-content:space-between;">
            <div>
                <div style="font-size:14px;font-weight:600;">Granola</div>
                <div style="font-size:12px;color:#6b7280;">Meeting notes with automatic commitment tracking.</div>
            </div>
            <a href="/setup/granola" class="btn btn-primary btn-sm">{{ 'Connected' if granola_connected else 'Connect Granola' }}</a>
        </div>

        <!-- Dedicated AI Email -->
        <div style="padding:14px;background:#f8f9fb;border-radius:8px;margin-bottom:10px;display:flex;align-items:center;justify-content:space-between;">
            <div>
                <div style="font-size:14px;font-weight:600;">Dedicated AI Email (Recommended)</div>
                <div style="font-size:12px;color:#6b7280;">Give ARIA its own email for sending briefings and drafts.</div>
            </div>
            <a href="/setup/ai-email" class="btn btn-primary btn-sm">Setup</a>
        </div>

        <!-- Claude AI (Enhanced Quality) -->
        <div style="padding:14px;background:#f8f9fb;border-radius:8px;margin-bottom:10px;display:flex;align-items:center;justify-content:space-between;">
            <div>
                <div style="font-size:14px;font-weight:600;">Enhanced AI (Optional)</div>
                <div style="font-size:12px;color:#6b7280;">Better quality drafts, complex analysis, strategy memos. ~$50-150/mo.</div>
            </div>
            <a href="/setup/cloud-ai" class="btn btn-primary btn-sm">{{ 'Configured' if cloud_ai_set else 'Enable' }}</a>
        </div>

        <!-- Calendly -->
        <div style="padding:14px;background:#f8f9fb;border-radius:8px;margin-bottom:10px;display:flex;align-items:center;justify-content:space-between;">
            <div>
                <div style="font-size:14px;font-weight:600;">Calendly</div>
                <div style="font-size:12px;color:#6b7280;">Sync scheduled meetings and invitee details.</div>
            </div>
            <a href="/setup/calendly" class="btn btn-primary btn-sm">Connect Calendly</a>
        </div>

        <!-- Notion -->
        <div style="padding:14px;background:#f8f9fb;border-radius:8px;margin-bottom:10px;display:flex;align-items:center;justify-content:space-between;">
            <div>
                <div style="font-size:14px;font-weight:600;">Notion</div>
                <div style="font-size:12px;color:#6b7280;">Task management and knowledge base integration.</div>
            </div>
            <a href="/setup/notion" class="btn btn-primary btn-sm">Connect Notion</a>
        </div>

        <!-- Telegram (already in checklist but also here for discoverability) -->
        {% if not telegram_set %}
        <div style="padding:14px;background:#f8f9fb;border-radius:8px;margin-bottom:10px;display:flex;align-items:center;justify-content:space-between;">
            <div>
                <div style="font-size:14px;font-weight:600;">Telegram</div>
                <div style="font-size:12px;color:#6b7280;">Mobile AI access. Ask ARIA anything from your phone.</div>
            </div>
            <a href="/setup/telegram" class="btn btn-primary btn-sm">Setup Telegram</a>
        </div>
        {% endif %}
    </div>

    <!-- Current Config -->
    <div class="card">
        <h2>Configuration</h2>
        <div class="config-section">
            <div class="config-row"><span class="config-label">Client</span><span class="config-value">{{ client_name or 'Not set' }}</span></div>
            <div class="config-row"><span class="config-label">Timezone</span><span class="config-value">{{ timezone }}</span></div>
            <div class="config-row"><span class="config-label">Morning Brief</span><span class="config-value">{{ briefing_time }}</span></div>
            <div class="config-row"><span class="config-label">Inference</span><span class="config-value">{{ inference_url }}</span></div>
            <div class="config-row"><span class="config-label">Telegram Bot</span><span class="config-value">{{ 'Configured' if telegram_set else 'Not set' }}</span></div>
        </div>
    </div>

    <div style="text-align:center; margin-top:24px; color:#9ca3af; font-size:13px;">
        ARIA v1.0 &middot; <a href="/health" style="color:#0096FF;">Run Health Check</a> &middot;
        <a href="http://localhost:8643" style="color:#0096FF;">Open Dashboard</a> &middot;
        <a href="/shutdown" style="color:#dc2626;">Close Setup Server</a>
    </div>
</div>
</body>
</html>
"""

GOOGLE_CLIENT_GUIDE_HTML = """
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>ARIA - Google OAuth Setup</title>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Inter', sans-serif; background: #f8f9fb; color: #1a1a2e; }
    .container { max-width: 720px; margin: 0 auto; padding: 40px 20px; }
    h1 { font-size: 24px; font-weight: 800; margin-bottom: 8px; }
    .subtitle { font-size: 15px; color: #6b7280; margin-bottom: 32px; }
    .step { background: #fff; border: 1px solid #e5e7eb; border-radius: 12px; padding: 20px; margin-bottom: 16px; }
    .step h3 { font-size: 15px; font-weight: 700; margin-bottom: 8px; }
    .step p, .step li { font-size: 14px; color: #374151; line-height: 1.6; }
    .step ol { padding-left: 20px; }
    .step li { margin-bottom: 6px; }
    code { background: #f3f4f6; padding: 2px 6px; border-radius: 4px; font-size: 13px; }
    .highlight { background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 12px 16px; margin: 12px 0; font-size: 13px; }
    .btn { display: inline-block; padding: 10px 20px; border-radius: 8px; font-size: 14px; font-weight: 600; text-decoration: none; }
    .btn-primary { background: #0096FF; color: #fff; }
    .btn-back { background: #f3f4f6; color: #374151; }
    .upload-form { margin-top: 16px; }
    input[type="file"] { margin: 8px 0; }
</style>
</head>
<body>
<div class="container">
    <a href="/" class="btn btn-back" style="margin-bottom:24px;">← Back to Dashboard</a>
    <h1>Google OAuth Setup</h1>
    <p class="subtitle">One-time setup to allow ARIA to read your Gmail and Calendar. Takes about 5 minutes.</p>

    <div class="step">
        <h3>Step 1: Create a Google Cloud Project</h3>
        <ol>
            <li>Go to <a href="https://console.cloud.google.com/projectcreate" target="_blank">console.cloud.google.com/projectcreate</a></li>
            <li>Name it "ARIA" (or anything you like)</li>
            <li>Click Create</li>
        </ol>
    </div>

    <div class="step">
        <h3>Step 2: Enable Gmail and Calendar APIs</h3>
        <ol>
            <li>Go to <a href="https://console.cloud.google.com/apis/library" target="_blank">APIs & Services > Library</a></li>
            <li>Search for "Gmail API" and click Enable</li>
            <li>Search for "Google Calendar API" and click Enable</li>
        </ol>
    </div>

    <div class="step">
        <h3>Step 3: Configure OAuth Consent Screen</h3>
        <ol>
            <li>Go to <a href="https://console.cloud.google.com/apis/credentials/consent" target="_blank">APIs & Services > OAuth consent screen</a></li>
            <li>Choose "External" user type (even for personal use)</li>
            <li>Fill in app name: "ARIA"</li>
            <li>Fill in your email for support and developer contact</li>
            <li>Add scopes: <code>gmail.readonly</code>, <code>gmail.labels</code>, <code>calendar.readonly</code></li>
            <li>Add your email as a test user</li>
            <li>Save</li>
        </ol>
    </div>

    <div class="step">
        <h3>Step 4: Create OAuth Client Credentials</h3>
        <ol>
            <li>Go to <a href="https://console.cloud.google.com/apis/credentials" target="_blank">APIs & Services > Credentials</a></li>
            <li>Click "Create Credentials" > "OAuth client ID"</li>
            <li>Application type: <strong>Web application</strong></li>
            <li>Name: "ARIA Local"</li>
            <li>Authorized redirect URIs: add <code>http://localhost:{{ port }}/oauth/google/callback</code></li>
            <li>Click Create</li>
            <li>Click "Download JSON" on the created credential</li>
        </ol>
    </div>

    <div class="step">
        <h3>Step 5: Upload the JSON file</h3>
        <p>Upload the downloaded OAuth client JSON file here:</p>
        <form action="/setup/google-client/upload" method="post" enctype="multipart/form-data" class="upload-form">
            <input type="file" name="client_file" accept=".json">
            <br>
            <button type="submit" class="btn btn-primary">Upload & Save</button>
        </form>
        <div class="highlight">
            The file will be saved to <code>config/google-oauth-client.json</code>. This file contains your client secret and should never be shared.
        </div>
    </div>
</div>
</body>
</html>
"""


TELEGRAM_SETUP_HTML = """
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>ARIA - Telegram Setup</title>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Inter', sans-serif; background: #f8f9fb; color: #1a1a2e; }
    .container { max-width: 720px; margin: 0 auto; padding: 40px 20px; }
    h1 { font-size: 24px; font-weight: 800; margin-bottom: 8px; }
    .subtitle { font-size: 15px; color: #6b7280; margin-bottom: 32px; }
    .step { background: #fff; border: 1px solid #e5e7eb; border-radius: 12px; padding: 20px; margin-bottom: 16px; }
    .step h3 { font-size: 15px; font-weight: 700; margin-bottom: 8px; }
    .step p, .step li { font-size: 14px; color: #374151; line-height: 1.6; }
    .step ol { padding-left: 20px; }
    .step li { margin-bottom: 6px; }
    code { background: #f3f4f6; padding: 2px 6px; border-radius: 4px; font-size: 13px; }
    .btn { display: inline-block; padding: 10px 20px; border-radius: 8px; font-size: 14px; font-weight: 600; text-decoration: none; border: none; cursor: pointer; }
    .btn-primary { background: #0096FF; color: #fff; }
    .btn-back { background: #f3f4f6; color: #374151; }
    input[type="text"] { width: 100%; padding: 10px 14px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 14px; font-family: 'Inter', sans-serif; margin: 8px 0; }
    label { font-size: 13px; font-weight: 600; color: #374151; display: block; margin-top: 12px; }
    .highlight { background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 12px 16px; margin: 12px 0; font-size: 13px; }
</style>
</head>
<body>
<div class="container">
    <a href="/" class="btn btn-back" style="margin-bottom:24px;">&larr; Back to Dashboard</a>
    <h1>Telegram Bot Setup</h1>
    <p class="subtitle">Set up your mobile AI assistant. Takes about 3 minutes.</p>

    <div class="step">
        <h3>Step 1: Install Telegram</h3>
        <p>If you don't have Telegram yet, download it from the <a href="https://telegram.org/dl" target="_blank">App Store</a> or <a href="https://desktop.telegram.org" target="_blank">desktop app</a>. It's free.</p>
    </div>

    <div class="step">
        <h3>Step 2: Create Your Bot</h3>
        <ol>
            <li>Open Telegram and search for <code>@BotFather</code></li>
            <li>Send the message: <code>/newbot</code></li>
            <li>Choose a name for your bot (e.g., "My ARIA Assistant")</li>
            <li>Choose a username (must end in "bot", e.g., "myaria_bot")</li>
            <li>BotFather will give you a token that looks like: <code>123456789:ABCdefGHIjklMNO...</code></li>
        </ol>
    </div>

    <div class="step">
        <h3>Step 3: Get Your Telegram ID</h3>
        <ol>
            <li>In Telegram, search for <code>@userinfobot</code></li>
            <li>Send it any message</li>
            <li>It will reply with your user ID (a number like <code>7958794313</code>)</li>
        </ol>
    </div>

    <div class="step">
        <h3>Step 4: Enter Your Details</h3>
        <form action="/setup/telegram/save" method="post">
            <label for="token">Bot Token (from BotFather)</label>
            <input type="text" name="token" id="token" placeholder="123456789:ABCdefGHIjklMNOpqrsTUVwxyz" required>

            <label for="user_id">Your Telegram User ID (from @userinfobot)</label>
            <input type="text" name="user_id" id="user_id" placeholder="7958794313" required>

            <label for="bot_username">Bot Username (optional)</label>
            <input type="text" name="bot_username" id="bot_username" placeholder="@myaria_bot">

            <br><br>
            <button type="submit" class="btn btn-primary">Save & Activate</button>
        </form>

        <div class="highlight">
            Your bot token is stored locally and never shared. ARIA uses it to receive and respond to your messages.
        </div>
    </div>
</div>
</body>
</html>
"""


# --- Routes ---

@app.route("/")
def dashboard():
    config = load_config()
    accounts = get_connected_accounts()

    # Load env to check telegram
    env_file = PROJECT_DIR / ".env"
    telegram_set = False
    if env_file.exists():
        with open(env_file) as f:
            for line in f:
                if line.strip().startswith("ARIA_TELEGRAM_TOKEN=") and "CHANGE_ME" not in line:
                    telegram_set = True

    email_connected = any("gmail" in a.get("services", []) for a in accounts)
    calendar_connected = any("calendar" in a.get("services", []) for a in accounts)

    # Check if notification monitoring is enabled (test if we can read the DB)
    notifications_enabled = False
    notif_db = Path.home() / "Library" / "Group Containers" / "group.com.apple.usernoted" / "db2" / "db"
    if notif_db.exists():
        try:
            import sqlite3
            conn = sqlite3.connect(str(notif_db))
            conn.execute("SELECT COUNT(*) FROM record")
            conn.close()
            notifications_enabled = True
        except Exception:
            pass

    # Load template from file for easier editing
    template_path = PROJECT_DIR / "templates" / "onboarding-dashboard.html"
    if template_path.exists():
        with open(template_path) as f:
            template = f.read()
    else:
        template = DASHBOARD_HTML

    return render_template_string(template,
        config_loaded=bool(config.get("client") or config.get("email")),
        client_name=config.get("client", {}).get("name") or config.get("email", ""),
        google_client=google_client_exists(),
        ms_client=ms_client_exists(),
        slack_client=slack_client_exists(),
        granola_connected=any(a.get("type") == "granola" for a in accounts),
        tailscale_connected=_check_tailscale(),
        zoom_client=zoom_client_exists(),
        ms_connected=any(a.get("type") == "microsoft" for a in accounts),
        cloud_ai_set=bool(os.environ.get("ANTHROPIC_API_KEY")),
        email_connected=email_connected,
        calendar_connected=calendar_connected,
        telegram_set=telegram_set,
        notifications_enabled=notifications_enabled,
        accounts=accounts,
        timezone=config.get("timezone", "Not set"),
        briefing_time=config.get("schedules", {}).get("morning_briefing", "07:30"),
        inference_url=config.get("ai", {}).get("inference_url", "Not configured"),
        ai_email=config.get("ai_email", ""),
        hw_model=_hw_info.get("mac_model", "Unknown"),
        hw_chip=_hw_info.get("chip", "Unknown"),
        hw_ram=_hw_info.get("ram_gb", 0),
        hw_tier=_hw_rec.get("tier_name", "Unknown"),
        hw_local=_hw_rec.get("local_percentage", 0),
        hw_cloud=_hw_rec.get("cloud_percentage", 0),
    )


@app.route("/setup/telegram")
def telegram_setup():
    return render_template_string(TELEGRAM_SETUP_HTML)


@app.route("/setup/telegram/save", methods=["POST"])
def telegram_save():
    token = request.form.get("token", "").strip()
    user_id = request.form.get("user_id", "").strip()
    bot_username = request.form.get("bot_username", "").strip()

    if not token or ":" not in token:
        flash("Invalid bot token. It should look like 123456789:ABCdef...", "error")
        return redirect(url_for("telegram_setup"))

    if not user_id or not user_id.isdigit():
        flash("Invalid user ID. It should be a number.", "error")
        return redirect(url_for("telegram_setup"))

    # Save token to .env
    env_path = PROJECT_DIR / ".env"
    env_lines = []
    token_written = False
    if env_path.exists():
        with open(env_path) as f:
            for line in f:
                if line.strip().startswith("ARIA_TELEGRAM_TOKEN="):
                    env_lines.append(f"ARIA_TELEGRAM_TOKEN={token}\n")
                    token_written = True
                else:
                    env_lines.append(line)
    if not token_written:
        env_lines.append(f"\nARIA_TELEGRAM_TOKEN={token}\n")
    with open(env_path, "w") as f:
        f.writelines(env_lines)

    # Save user ID and bot username to config
    config = load_config()
    if "telegram" not in config:
        config["telegram"] = {}
    config["telegram"]["authorized_users"] = [int(user_id)]
    config["telegram"]["token_env"] = "ARIA_TELEGRAM_TOKEN"
    if bot_username:
        config["telegram"]["bot_username"] = bot_username
    save_config(config)

    # Restart the Telegram bot if it's running
    import subprocess
    subprocess.run(["pkill", "-f", "aria-telegram-bot"], capture_output=True)
    # launchd KeepAlive will restart it automatically

    flash(f"Telegram bot configured! Bot will restart automatically. Try messaging {bot_username or 'your bot'} on Telegram.", "success")
    return redirect(url_for("dashboard"))


@app.route("/setup/google-client")
def google_client_guide():
    return render_template_string(GOOGLE_CLIENT_GUIDE_HTML, port=ONBOARDING_PORT)


@app.route("/setup/google-client/upload", methods=["POST"])
def upload_google_client():
    if "client_file" not in request.files:
        flash("No file uploaded", "error")
        return redirect(url_for("google_client_guide"))

    file = request.files["client_file"]
    if file.filename == "":
        flash("No file selected", "error")
        return redirect(url_for("google_client_guide"))

    try:
        content = json.loads(file.read())
        # Google exports as {"web": {...}} or {"installed": {...}}
        if "web" not in content and "installed" not in content:
            flash("Invalid Google OAuth client file. Expected 'web' or 'installed' key.", "error")
            return redirect(url_for("google_client_guide"))

        GOOGLE_CLIENT_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(GOOGLE_CLIENT_FILE, "w") as f:
            json.dump(content, f, indent=2)
        os.chmod(GOOGLE_CLIENT_FILE, 0o600)

        flash("Google OAuth client saved. You can now connect accounts.", "success")
        return redirect(url_for("dashboard"))
    except json.JSONDecodeError:
        flash("Invalid JSON file", "error")
        return redirect(url_for("google_client_guide"))


@app.route("/connect/google")
def connect_google():
    if not google_client_exists():
        flash("Set up Google OAuth client first", "error")
        return redirect(url_for("google_client_guide"))

    scope_param = request.args.get("scope", "all")
    if scope_param == "email":
        scopes = GMAIL_SCOPES
    elif scope_param == "calendar":
        scopes = CALENDAR_SCOPES
    else:
        scopes = ALL_SCOPES

    try:
        # Always request ALL scopes to avoid mismatch when Google returns
        # previously granted scopes. Track requested services separately.
        flow = Flow.from_client_secrets_file(
            str(GOOGLE_CLIENT_FILE),
            scopes=ALL_SCOPES,
            redirect_uri=REDIRECT_URI,
        )
        auth_url, state = flow.authorization_url(
            access_type="offline",
            include_granted_scopes="true",
            prompt="consent",
        )
        session["oauth_state"] = state
        session["oauth_scopes"] = scopes  # Track what user originally wanted
        session["oauth_code_verifier"] = flow.code_verifier
        return redirect(auth_url)
    except Exception as e:
        flash(f"OAuth error: {e}", "error")
        return redirect(url_for("dashboard"))


@app.route("/oauth/google/callback")
def google_callback():
    try:
        scopes = session.get("oauth_scopes", ALL_SCOPES)
        code_verifier = session.get("oauth_code_verifier")

        # Always use ALL_SCOPES for the flow to avoid scope mismatch errors
        # when Google returns previously granted scopes alongside new ones
        flow = Flow.from_client_secrets_file(
            str(GOOGLE_CLIENT_FILE),
            scopes=ALL_SCOPES,
            redirect_uri=REDIRECT_URI,
        )
        flow.code_verifier = code_verifier
        flow.fetch_token(
            authorization_response=request.url,
        )
        credentials = flow.credentials

        # Get the user's email from the ID token (no extra API call needed)
        email = "unknown"
        if credentials.id_token:
            import google.auth.transport.requests
            from google.oauth2 import id_token as id_token_module
            try:
                info = id_token_module.verify_oauth2_token(
                    credentials.id_token,
                    google.auth.transport.requests.Request(),
                    credentials.client_id,
                )
                email = info.get("email", "unknown")
            except Exception:
                pass
        # Fallback: try the Gmail API to get the email
        if email == "unknown":
            try:
                from googleapiclient.discovery import build
                service = build("gmail", "v1", credentials=credentials)
                profile = service.users().getProfile(userId="me").execute()
                email = profile.get("emailAddress", "unknown")
            except Exception:
                pass

        # Determine services based on scopes
        services = []
        granted = credentials.scopes or scopes
        if any("gmail" in s for s in granted):
            services.append("gmail")
        if any("calendar" in s for s in granted):
            services.append("calendar")

        # Save credentials
        creds_data = load_credentials()
        # Update existing or add new
        existing = next((a for a in creds_data["accounts"] if a.get("email") == email), None)
        if existing:
            existing["access_token"] = credentials.token
            existing["refresh_token"] = credentials.refresh_token or existing.get("refresh_token")
            existing["token_uri"] = credentials.token_uri
            existing["client_id"] = credentials.client_id
            existing["client_secret"] = credentials.client_secret
            existing["scopes"] = list(credentials.scopes or scopes)
            # Merge services
            for s in services:
                if s not in existing["services"]:
                    existing["services"].append(s)
            existing["updated_at"] = datetime.now().isoformat()
        else:
            creds_data["accounts"].append({
                "email": email,
                "type": "google",
                "services": services,
                "access_token": credentials.token,
                "refresh_token": credentials.refresh_token,
                "token_uri": credentials.token_uri,
                "client_id": credentials.client_id,
                "client_secret": credentials.client_secret,
                "scopes": list(credentials.scopes or scopes),
                "connected_at": datetime.now().isoformat(),
            })

        save_credentials(creds_data)

        # Also update aria.json channels
        config = load_config()
        if "channels" not in config:
            config["channels"] = {}
        if "email_accounts" not in config["channels"]:
            config["channels"]["email_accounts"] = []
        if "calendar_accounts" not in config["channels"]:
            config["channels"]["calendar_accounts"] = []

        if "gmail" in services:
            if not any(a["address"] == email for a in config["channels"]["email_accounts"]):
                config["channels"]["email_accounts"].append({
                    "address": email,
                    "provider": "gmail",
                    "credential_id": email,
                })
        if "calendar" in services:
            if not any(a["name"] == email for a in config["channels"]["calendar_accounts"]):
                config["channels"]["calendar_accounts"].append({
                    "name": email,
                    "provider": "google",
                    "credential_id": email,
                })
        save_config(config)

        flash(f"Connected {email} ({', '.join(services)})", "success")
        return redirect(url_for("dashboard"))

    except Exception as e:
        flash(f"OAuth callback error: {e}", "error")
        return redirect(url_for("dashboard"))


@app.route("/disconnect/<int:index>")
def disconnect(index):
    creds = load_credentials()
    if 0 <= index < len(creds.get("accounts", [])):
        removed = creds["accounts"].pop(index)
        save_credentials(creds)
        flash(f"Disconnected {removed.get('email', 'account')}", "info")
    return redirect(url_for("dashboard"))


CHANNEL_SETUP_HTML = """
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>ARIA - {{ channel_name }} Setup</title>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Inter', sans-serif; background: #f8f9fb; color: #1a1a2e; }
    .container { max-width: 720px; margin: 0 auto; padding: 40px 20px; }
    h1 { font-size: 24px; font-weight: 800; margin-bottom: 8px; }
    .subtitle { font-size: 15px; color: #6b7280; margin-bottom: 32px; }
    .step { background: #fff; border: 1px solid #e5e7eb; border-radius: 12px; padding: 20px; margin-bottom: 16px; }
    .step h3 { font-size: 15px; font-weight: 700; margin-bottom: 8px; }
    .step p, .step li { font-size: 14px; color: #374151; line-height: 1.6; }
    .step ol { padding-left: 20px; }
    .step li { margin-bottom: 6px; }
    code { background: #f3f4f6; padding: 2px 6px; border-radius: 4px; font-size: 13px; }
    .btn { display: inline-block; padding: 10px 20px; border-radius: 8px; font-size: 14px; font-weight: 600; text-decoration: none; border: none; cursor: pointer; }
    .btn-primary { background: #0096FF; color: #fff; }
    .btn-back { background: #f3f4f6; color: #374151; }
    input[type="text"] { width: 100%; padding: 10px 14px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 14px; font-family: 'Inter', sans-serif; margin: 8px 0; }
    label { font-size: 13px; font-weight: 600; color: #374151; display: block; margin-top: 12px; }
    .highlight { background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 12px 16px; margin: 12px 0; font-size: 13px; }
</style>
</head>
<body>
<div class="container">
    <a href="/" class="btn btn-back" style="margin-bottom:24px;">&larr; Back to Dashboard</a>
    <h1>{{ channel_name }} Setup</h1>
    <p class="subtitle">{{ channel_description }}</p>
    {{ content | safe }}
</div>
</body>
</html>
"""


@app.route("/setup/slack")
def slack_setup():
    if slack_client_exists():
        # App is configured, show one-click connect
        content = """
        <div class="step">
            <h3>Connect a Slack Workspace</h3>
            <p>Click below to add ARIA to any Slack workspace. You'll be asked to authorize ARIA to read channel messages and direct messages (read-only).</p>
            <br>
            <a href="/connect/slack" class="btn btn-primary" style="font-size:16px;padding:14px 28px;">Add ARIA to Slack</a>
            <br><br>
            <p style="font-size:12px;color:#6b7280;">You can connect multiple workspaces. Just click the button again for each one.</p>
        </div>
        <div class="step">
            <h3>What ARIA Reads</h3>
            <div class="highlight">
                <p>ARIA reads channel messages, group DMs, and direct messages to include in your daily briefings. ARIA <strong>never posts, sends, or modifies</strong> anything in Slack. All data stays on your computer.</p>
            </div>
        </div>
        """
    else:
        content = f"""
        <div class="step">
            <h3>First-Time Setup (Administrator Only)</h3>
            <p>This configures Slack integration for all ARIA users. Takes about 3 minutes.</p>
        </div>
        <div class="step">
            <h3>Step 1: Create a Slack App</h3>
            <ol>
                <li>Go to <a href="https://api.slack.com/apps" target="_blank">api.slack.com/apps</a></li>
                <li>Click <strong>Create New App</strong> &gt; <strong>From scratch</strong></li>
                <li>App name: <strong>ARIA</strong></li>
                <li>Pick any workspace you have access to</li>
                <li>Click <strong>Create App</strong></li>
            </ol>
        </div>
        <div class="step">
            <h3>Step 2: Configure the App</h3>
            <ol>
                <li>Click <strong>OAuth & Permissions</strong> in the left sidebar</li>
                <li>Under <strong>Redirect URLs</strong>, add: <code>{SLACK_REDIRECT_URI}</code></li>
                <li>Click <strong>Save URLs</strong></li>
                <li>Under <strong>Bot Token Scopes</strong>, add all of these:
                    <code>channels:history</code>, <code>channels:read</code>,
                    <code>groups:read</code>, <code>groups:history</code>,
                    <code>users:read</code>, <code>team:read</code>,
                    <code>im:history</code>, <code>im:read</code>,
                    <code>mpim:history</code>, <code>mpim:read</code></li>
            </ol>
        </div>
        <div class="step">
            <h3>Step 3: Enable Distribution</h3>
            <ol>
                <li>Click <strong>Manage Distribution</strong> in the left sidebar</li>
                <li>Under "Share Your App with Other Workspaces", make sure all checkmarks are green</li>
                <li>Click <strong>Activate Public Distribution</strong></li>
            </ol>
            <div class="highlight">This lets the app be installed on any workspace, not just the one it was created in.</div>
        </div>
        <div class="step">
            <h3>Step 4: Enter App Credentials</h3>
            <p>Click <strong>Basic Information</strong> in the left sidebar to find these.</p>
            <form action="/setup/slack/save-client" method="post">
                <label for="client_id">Client ID</label>
                <input type="text" name="client_id" id="client_id" placeholder="1234567890.1234567890" required>
                <label for="client_secret">Client Secret</label>
                <input type="text" name="client_secret" id="client_secret" placeholder="abcdef1234567890..." required>
                <br><br>
                <button type="submit" class="btn btn-primary">Save & Enable Slack</button>
            </form>
            <div class="highlight">After saving, users just click "Connect Slack" and authorize. No technical steps for them.</div>
        </div>
        """
    return render_template_string(CHANNEL_SETUP_HTML,
        channel_name="Slack",
        channel_description="Connect your Slack workspace so ARIA can summarize team conversations.",
        content=content)


@app.route("/setup/slack/save-client", methods=["POST"])
def slack_save_client():
    client_id = request.form.get("client_id", "").strip()
    client_secret = request.form.get("client_secret", "").strip()

    if not client_id or not client_secret:
        flash("Both Client ID and Client Secret are required", "error")
        return redirect(url_for("slack_setup"))

    slack_config = {
        "client_id": client_id,
        "client_secret": client_secret,
        "scopes": SLACK_SCOPES,
        "redirect_uri": SLACK_REDIRECT_URI,
    }

    SLACK_CLIENT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(SLACK_CLIENT_FILE, "w") as f:
        json.dump(slack_config, f, indent=2)
    os.chmod(SLACK_CLIENT_FILE, 0o600)

    flash("Slack credentials saved! Users can now connect with one click.", "success")
    return redirect(url_for("slack_setup"))


@app.route("/connect/slack")
def connect_slack():
    config = get_slack_client_config()
    if not config:
        flash("Set up Slack app credentials first", "error")
        return redirect(url_for("slack_setup"))

    import secrets as sec
    state = f"{ONBOARDING_PORT}_{sec.token_hex(8)}"
    session["slack_state"] = state

    from urllib.parse import urlencode
    params = {
        "client_id": config["client_id"],
        "scope": SLACK_SCOPES,
        "redirect_uri": SLACK_REDIRECT_URI,
        "state": state,
    }
    auth_url = f"https://slack.com/oauth/v2/authorize?{urlencode(params)}"
    return redirect(auth_url)


@app.route("/oauth/slack/complete")
def slack_complete():
    """Receives the code relayed from the GitHub Pages callback."""
    try:
        code = request.args.get("code")
        if not code:
            flash("No authorization code received from Slack", "error")
            return redirect(url_for("dashboard"))

        config = get_slack_client_config()
        if not config:
            flash("Slack app not configured", "error")
            return redirect(url_for("dashboard"))

        # Exchange code for token
        resp = http_requests.post("https://slack.com/api/oauth.v2.access", data={
            "client_id": config["client_id"],
            "client_secret": config["client_secret"],
            "code": code,
            "redirect_uri": SLACK_REDIRECT_URI,
        }, timeout=15)

        data = resp.json()
        if not data.get("ok"):
            flash(f"Slack error: {data.get('error', 'unknown')}", "error")
            return redirect(url_for("dashboard"))

        bot_token = data.get("access_token", "")
        team_name = data.get("team", {}).get("name", "Unknown")
        team_id = data.get("team", {}).get("id", "")

        # Save token to .env
        env_path = PROJECT_DIR / ".env"
        safe_name = team_name.lower().replace(" ", "_").replace("-", "_")
        env_key = f"ARIA_SLACK_TOKEN_{safe_name}"

        lines = []
        written = False
        if env_path.exists():
            with open(env_path) as f:
                for line in f:
                    if line.strip().startswith(f"{env_key}="):
                        lines.append(f"{env_key}={bot_token}\n")
                        written = True
                    else:
                        lines.append(line)
        if not written:
            lines.append(f"\n# Slack: {team_name}\n{env_key}={bot_token}\n")
        with open(env_path, "w") as f:
            f.writelines(lines)

        # Update config
        aria_config = load_config()
        if "channels" not in aria_config:
            aria_config["channels"] = {}
        aria_config["channels"]["slack"] = {
            "enabled": True,
            "workspace_name": team_name,
            "team_id": team_id,
            "token_env": env_key,
        }
        save_config(aria_config)

        # Add to credentials
        creds = load_credentials()
        creds["accounts"] = [a for a in creds["accounts"] if not (a.get("type") == "slack" and a.get("team_id") == team_id)]
        creds["accounts"].append({
            "email": f"Slack: {team_name}",
            "type": "slack",
            "services": ["slack"],
            "team_id": team_id,
            "connected_at": datetime.now().isoformat(),
            "refresh_token": bot_token,
        })
        save_credentials(creds)

        flash(f"Connected Slack workspace: {team_name}", "success")
        return redirect(url_for("dashboard"))

    except Exception as e:
        flash(f"Slack connection error: {e}", "error")
        return redirect(url_for("dashboard"))


@app.route("/setup/outlook")
def outlook_setup():
    if ms_client_exists():
        # Client is configured, show connect button
        content = """
        <div class="step">
            <h3>Connect Your Microsoft Account</h3>
            <p>Click below to authorize ARIA to read your Outlook email and calendar. ARIA only requests read-only access.</p>
            <br>
            <a href="/connect/microsoft" class="btn btn-primary">Connect Outlook / Microsoft 365</a>
        </div>
        """
    else:
        content = """
        <div class="step">
            <h3>One-Time Setup: Register ARIA with Microsoft</h3>
            <p>This takes about 5 minutes. You only do it once, then all Microsoft accounts can connect.</p>
        </div>
        <div class="step">
            <h3>Step 1: Register an App</h3>
            <ol>
                <li>Go to <a href="https://portal.azure.com/#blade/Microsoft_AAD_RegisteredApps/ApplicationsListBlade" target="_blank">Azure App Registrations</a></li>
                <li>Click <strong>New registration</strong></li>
                <li>Name: <strong>ARIA</strong></li>
                <li>Supported account types: <strong>Accounts in any organizational directory and personal Microsoft accounts</strong></li>
                <li>Redirect URI: Select <strong>Web</strong> and enter: <code>http://localhost:8642/oauth/microsoft/callback</code></li>
                <li>Click <strong>Register</strong></li>
            </ol>
        </div>
        <div class="step">
            <h3>Step 2: Add API Permissions</h3>
            <ol>
                <li>In your new app, click <strong>API permissions</strong> in the left sidebar</li>
                <li>Click <strong>Add a permission</strong> &gt; <strong>Microsoft Graph</strong> &gt; <strong>Delegated permissions</strong></li>
                <li>Add: <code>Mail.Read</code>, <code>Calendars.Read</code>, <code>User.Read</code>, <code>offline_access</code></li>
                <li>Click <strong>Add permissions</strong></li>
            </ol>
        </div>
        <div class="step">
            <h3>Step 3: Create a Client Secret</h3>
            <ol>
                <li>Click <strong>Certificates & secrets</strong> in the left sidebar</li>
                <li>Click <strong>New client secret</strong></li>
                <li>Description: <strong>ARIA Local</strong></li>
                <li>Expiry: <strong>24 months</strong></li>
                <li>Click <strong>Add</strong></li>
                <li>Copy the <strong>Value</strong> (not the ID) immediately (it won't show again)</li>
            </ol>
        </div>
        <div class="step">
            <h3>Step 4: Enter Your Credentials</h3>
            <p>Find your Application (client) ID on the app's Overview page.</p>
            <form action="/setup/outlook/save" method="post">
                <label for="client_id">Application (Client) ID</label>
                <input type="text" name="client_id" id="client_id" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" required>
                <label for="client_secret">Client Secret (Value)</label>
                <input type="text" name="client_secret" id="client_secret" placeholder="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" required>
                <br><br>
                <button type="submit" class="btn btn-primary">Save & Continue</button>
            </form>
            <div class="highlight">These credentials are stored locally in <code>config/microsoft-oauth-client.json</code> and never shared.</div>
        </div>
        """
    return render_template_string(CHANNEL_SETUP_HTML,
        channel_name="Outlook / Microsoft 365",
        channel_description="Connect your Outlook email and calendar.",
        content=content)


@app.route("/setup/outlook/save", methods=["POST"])
def outlook_save_client():
    client_id = request.form.get("client_id", "").strip()
    client_secret = request.form.get("client_secret", "").strip()

    if not client_id or not client_secret:
        flash("Both Client ID and Client Secret are required", "error")
        return redirect(url_for("outlook_setup"))

    ms_config = {
        "client_id": client_id,
        "client_secret": client_secret,
        "authority": MS_AUTHORITY,
        "redirect_uri": MS_REDIRECT_URI,
        "scopes": MS_SCOPES,
    }

    MS_CLIENT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(MS_CLIENT_FILE, "w") as f:
        json.dump(ms_config, f, indent=2)
    os.chmod(MS_CLIENT_FILE, 0o600)

    flash("Microsoft OAuth credentials saved. You can now connect Outlook accounts.", "success")
    return redirect(url_for("outlook_setup"))


@app.route("/connect/microsoft")
def connect_microsoft():
    ms_app = get_ms_app()
    if not ms_app:
        flash("Set up Microsoft OAuth credentials first", "error")
        return redirect(url_for("outlook_setup"))

    auth_url = ms_app.get_authorization_request_url(
        scopes=MS_SCOPES,
        redirect_uri=MS_REDIRECT_URI,
    )
    return redirect(auth_url)


@app.route("/oauth/microsoft/callback")
def microsoft_callback():
    try:
        code = request.args.get("code")
        if not code:
            error = request.args.get("error_description", request.args.get("error", "Unknown error"))
            flash(f"Microsoft OAuth error: {error}", "error")
            return redirect(url_for("dashboard"))

        ms_app = get_ms_app()
        if not ms_app:
            flash("Microsoft OAuth not configured", "error")
            return redirect(url_for("dashboard"))

        result = ms_app.acquire_token_by_authorization_code(
            code,
            scopes=MS_SCOPES,
            redirect_uri=MS_REDIRECT_URI,
        )

        if "error" in result:
            flash(f"Microsoft token error: {result.get('error_description', result['error'])}", "error")
            return redirect(url_for("dashboard"))

        # Get user email from the token
        email = result.get("id_token_claims", {}).get("preferred_username", "unknown")

        # Determine services
        services = ["outlook_email", "outlook_calendar"]

        # Save credentials
        creds_data = load_credentials()
        ms_config = get_ms_client_config()

        existing = next((a for a in creds_data["accounts"] if a.get("email") == email and a.get("type") == "microsoft"), None)
        if existing:
            existing["access_token"] = result.get("access_token")
            existing["refresh_token"] = result.get("refresh_token", existing.get("refresh_token"))
            existing["updated_at"] = datetime.now().isoformat()
        else:
            creds_data["accounts"].append({
                "email": email,
                "type": "microsoft",
                "services": services,
                "access_token": result.get("access_token"),
                "refresh_token": result.get("refresh_token"),
                "client_id": ms_config["client_id"],
                "client_secret": ms_config["client_secret"],
                "authority": MS_AUTHORITY,
                "scopes": MS_SCOPES,
                "connected_at": datetime.now().isoformat(),
            })

        save_credentials(creds_data)

        # Update aria.json
        config = load_config()
        if "channels" not in config:
            config["channels"] = {}
        if "email_accounts" not in config["channels"]:
            config["channels"]["email_accounts"] = []
        if not any(a["address"] == email for a in config["channels"]["email_accounts"]):
            config["channels"]["email_accounts"].append({
                "address": email,
                "provider": "outlook",
                "credential_id": email,
            })
        save_config(config)

        flash(f"Connected {email} (Outlook email + calendar)", "success")
        return redirect(url_for("dashboard"))

    except Exception as e:
        flash(f"Microsoft OAuth error: {e}", "error")
        return redirect(url_for("dashboard"))


@app.route("/setup/calendly")
def calendly_setup():
    content = """
    <div class="step">
        <h3>Step 1: Get Your Calendly Personal Access Token</h3>
        <ol>
            <li>Go to <a href="https://calendly.com/integrations/api_webhooks" target="_blank">calendly.com/integrations/api_webhooks</a></li>
            <li>Click <strong>Generate New Token</strong></li>
            <li>Name it <strong>ARIA</strong></li>
            <li>Copy the token</li>
        </ol>
    </div>
    <div class="step">
        <h3>Step 2: Enter Your Token</h3>
        <form action="/setup/calendly/save" method="post">
            <label for="token">Calendly Personal Access Token</label>
            <input type="text" name="token" id="token" placeholder="eyJhbGciOi..." required>
            <br><br>
            <button type="submit" class="btn btn-primary">Save & Connect</button>
        </form>
        <div class="highlight">Your token is stored locally and never shared.</div>
    </div>
    """
    return render_template_string(CHANNEL_SETUP_HTML,
        channel_name="Calendly",
        channel_description="Sync your scheduled meetings and invitee details.",
        content=content)


@app.route("/setup/calendly/save", methods=["POST"])
def calendly_save():
    token = request.form.get("token", "").strip()
    if not token:
        flash("Token is required", "error")
        return redirect(url_for("calendly_setup"))

    env_path = PROJECT_DIR / ".env"
    lines = []
    written = False
    if env_path.exists():
        with open(env_path) as f:
            for line in f:
                if line.strip().startswith("ARIA_CALENDLY_TOKEN="):
                    lines.append(f"ARIA_CALENDLY_TOKEN={token}\n")
                    written = True
                else:
                    lines.append(line)
    if not written:
        lines.append(f"\n# Calendly Personal Access Token\nARIA_CALENDLY_TOKEN={token}\n")
    with open(env_path, "w") as f:
        f.writelines(lines)

    config = load_config()
    if "channels" not in config:
        config["channels"] = {}
    config["channels"]["calendly"] = {"enabled": True, "token_env": "ARIA_CALENDLY_TOKEN"}
    save_config(config)

    creds = load_credentials()
    creds["accounts"].append({
        "email": "Calendly",
        "type": "calendly",
        "services": ["calendly"],
        "connected_at": datetime.now().isoformat(),
        "refresh_token": "configured",
    })
    save_credentials(creds)

    flash("Calendly connected!", "success")
    return redirect(url_for("dashboard"))


@app.route("/setup/notion")
def notion_setup():
    content = """
    <div class="step">
        <h3>Step 1: Create a Notion Integration</h3>
        <ol>
            <li>Go to <a href="https://www.notion.so/my-integrations" target="_blank">notion.so/my-integrations</a></li>
            <li>Click <strong>New integration</strong></li>
            <li>Name: <strong>ARIA</strong></li>
            <li>Select your workspace</li>
            <li>Click <strong>Submit</strong></li>
            <li>Copy the <strong>Internal Integration Secret</strong> (starts with <code>ntn_</code>)</li>
        </ol>
    </div>
    <div class="step">
        <h3>Step 2: Share Your Database with ARIA</h3>
        <ol>
            <li>Open the Notion database you want ARIA to manage (tasks, etc.)</li>
            <li>Click <strong>Share</strong> (top right)</li>
            <li>Invite <strong>ARIA</strong> (your integration)</li>
            <li>Copy the database ID from the URL (the long string after your workspace name)</li>
        </ol>
    </div>
    <div class="step">
        <h3>Step 3: Enter Your Details</h3>
        <form action="/setup/notion/save" method="post">
            <label for="token">Notion Integration Secret</label>
            <input type="text" name="token" id="token" placeholder="ntn_..." required>
            <label for="database_id">Database ID (from the URL)</label>
            <input type="text" name="database_id" id="database_id" placeholder="abc123def456..." required>
            <br><br>
            <button type="submit" class="btn btn-primary">Save & Connect</button>
        </form>
        <div class="highlight">Your credentials are stored locally and never shared.</div>
    </div>
    """
    return render_template_string(CHANNEL_SETUP_HTML,
        channel_name="Notion",
        channel_description="Connect your Notion workspace for task management.",
        content=content)


@app.route("/setup/notion/save", methods=["POST"])
def notion_save():
    token = request.form.get("token", "").strip()
    database_id = request.form.get("database_id", "").strip()
    if not token or not database_id:
        flash("Both token and database ID are required", "error")
        return redirect(url_for("notion_setup"))

    env_path = PROJECT_DIR / ".env"
    lines = []
    written = False
    if env_path.exists():
        with open(env_path) as f:
            for line in f:
                if line.strip().startswith("ARIA_NOTION_TOKEN="):
                    lines.append(f"ARIA_NOTION_TOKEN={token}\n")
                    written = True
                else:
                    lines.append(line)
    if not written:
        lines.append(f"\n# Notion Integration Secret\nARIA_NOTION_TOKEN={token}\n")
    with open(env_path, "w") as f:
        f.writelines(lines)

    config = load_config()
    if "notion" not in config:
        config["notion"] = {}
    config["notion"]["database_id"] = database_id
    config["notion"]["token_env"] = "ARIA_NOTION_TOKEN"
    save_config(config)

    creds = load_credentials()
    creds["accounts"].append({
        "email": "Notion",
        "type": "notion",
        "services": ["notion"],
        "connected_at": datetime.now().isoformat(),
        "refresh_token": "configured",
    })
    save_credentials(creds)

    flash("Notion connected!", "success")
    return redirect(url_for("dashboard"))


@app.route("/setup/teams")
def teams_setup():
    content = """
    <div class="step">
        <h3>Microsoft Teams</h3>
        <p>Teams uses the same Microsoft connection you already set up. You just need to add one more permission.</p>
        <ol>
            <li>Go to <a href="https://portal.azure.com/#blade/Microsoft_AAD_RegisteredApps/ApplicationsListBlade" target="_blank">Azure App Registrations</a></li>
            <li>Click on the <strong>ARIA</strong> app</li>
            <li>Click <strong>API permissions</strong></li>
            <li>Click <strong>Add a permission</strong> &gt; <strong>Microsoft Graph</strong> &gt; <strong>Delegated permissions</strong></li>
            <li>Search and add: <code>ChannelMessage.Read.All</code>, <code>Chat.Read</code></li>
            <li>Click <strong>Add permissions</strong></li>
        </ol>
        <p>After adding the permissions, you may need to re-authorize your Microsoft account. Go back to the dashboard and click <strong>Connect Account</strong> under Outlook to refresh the authorization.</p>
        <form action="/setup/teams/save" method="post">
            <br>
            <button type="submit" class="btn btn-primary">I've Added the Permissions</button>
        </form>
    </div>
    """
    return render_template_string(CHANNEL_SETUP_HTML,
        channel_name="Microsoft Teams",
        channel_description="Monitor Teams channels and chats alongside your other communications.",
        content=content)


@app.route("/setup/teams/save", methods=["POST"])
def teams_save():
    config = load_config()
    if "channels" not in config:
        config["channels"] = {}
    config["channels"]["teams"] = {"enabled": True, "note": "Uses Microsoft OAuth connection"}
    save_config(config)
    flash("Teams monitoring enabled. Teams messages will appear in your next briefing.", "success")
    return redirect(url_for("dashboard"))


ZOOM_CLIENT_FILE = PROJECT_DIR / "config" / "zoom-oauth-client.json"
ZOOM_REDIRECT_URI = "https://scwright84.github.io/aria-pages/zoom-callback.html"


def zoom_client_exists():
    return ZOOM_CLIENT_FILE.exists()


def get_zoom_client_config():
    if ZOOM_CLIENT_FILE.exists():
        with open(ZOOM_CLIENT_FILE) as f:
            return json.load(f)
    return None


@app.route("/setup/zoom")
def zoom_setup():
    if zoom_client_exists():
        content = """
        <div class="step">
            <h3>Connect Zoom</h3>
            <p>Click below to authorize ARIA to read your Zoom meetings and recordings.</p>
            <br>
            <a href="/connect/zoom" class="btn btn-primary" style="font-size:16px;padding:14px 28px;">Connect Zoom</a>
        </div>
        <div class="step">
            <h3>What ARIA Reads</h3>
            <div class="highlight">
                <p>ARIA reads your meeting list, recordings, and transcripts (read-only). It uses this to prepare meeting briefs and track commitments. ARIA never schedules, modifies, or cancels meetings.</p>
            </div>
        </div>
        """
    else:
        content = f"""
        <div class="step">
            <h3>First-Time Setup (Administrator Only)</h3>
            <p>Register an ARIA app with Zoom. Takes about 3 minutes. Customers will just click "Connect Zoom."</p>
        </div>
        <div class="step">
            <h3>Step 1: Create a Zoom App</h3>
            <ol>
                <li>Go to <a href="https://marketplace.zoom.us/" target="_blank">marketplace.zoom.us</a></li>
                <li>Click <strong>Develop</strong> &gt; <strong>Build App</strong></li>
                <li>Choose <strong>General App</strong></li>
                <li>App name: <strong>ARIA</strong></li>
                <li>Click <strong>Create</strong></li>
            </ol>
        </div>
        <div class="step">
            <h3>Step 2: Configure OAuth</h3>
            <ol>
                <li>Under OAuth settings, add redirect URL: <code>{ZOOM_REDIRECT_URI}</code></li>
                <li>Under <strong>Scopes</strong>, add: <code>meeting:read</code>, <code>recording:read</code>, <code>user:read</code></li>
            </ol>
        </div>
        <div class="step">
            <h3>Step 3: Enter App Credentials</h3>
            <p>Copy the Client ID and Client Secret from the app's credentials section.</p>
            <form action="/setup/zoom/save-client" method="post">
                <label for="client_id">Client ID</label>
                <input type="text" name="client_id" id="client_id" required>
                <label for="client_secret">Client Secret</label>
                <input type="text" name="client_secret" id="client_secret" required>
                <br><br>
                <button type="submit" class="btn btn-primary">Save & Enable Zoom</button>
            </form>
        </div>
        """
    return render_template_string(CHANNEL_SETUP_HTML,
        channel_name="Zoom",
        channel_description="Sync meeting recordings and transcripts.",
        content=content)


@app.route("/setup/zoom/save-client", methods=["POST"])
def zoom_save_client():
    client_id = request.form.get("client_id", "").strip()
    client_secret = request.form.get("client_secret", "").strip()
    if not client_id or not client_secret:
        flash("Both Client ID and Client Secret are required", "error")
        return redirect(url_for("zoom_setup"))

    zoom_config = {
        "client_id": client_id,
        "client_secret": client_secret,
        "redirect_uri": ZOOM_REDIRECT_URI,
    }
    ZOOM_CLIENT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(ZOOM_CLIENT_FILE, "w") as f:
        json.dump(zoom_config, f, indent=2)
    os.chmod(ZOOM_CLIENT_FILE, 0o600)

    flash("Zoom credentials saved! Users can now connect with one click.", "success")
    return redirect(url_for("zoom_setup"))


@app.route("/connect/zoom")
def connect_zoom():
    config = get_zoom_client_config()
    if not config:
        flash("Set up Zoom app credentials first", "error")
        return redirect(url_for("zoom_setup"))

    import secrets as sec
    state = f"{ONBOARDING_PORT}_{sec.token_hex(8)}"
    session["zoom_state"] = state

    params = {
        "response_type": "code",
        "client_id": config["client_id"],
        "redirect_uri": ZOOM_REDIRECT_URI,
        "state": state,
    }
    auth_url = f"https://zoom.us/oauth/authorize?{urlencode(params)}"
    return redirect(auth_url)


@app.route("/oauth/zoom/complete")
def zoom_complete():
    """Receives the code relayed from the GitHub Pages callback."""
    try:
        code = request.args.get("code")
        if not code:
            flash("No authorization code received from Zoom", "error")
            return redirect(url_for("dashboard"))

        config = get_zoom_client_config()
        if not config:
            flash("Zoom app not configured", "error")
            return redirect(url_for("dashboard"))

        # Exchange code for token
        import base64
        credentials = base64.b64encode(
            f"{config['client_id']}:{config['client_secret']}".encode()
        ).decode()

        resp = http_requests.post("https://zoom.us/oauth/token", data={
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": ZOOM_REDIRECT_URI,
        }, headers={
            "Authorization": f"Basic {credentials}",
        }, timeout=15)

        data = resp.json()
        if "access_token" not in data:
            flash(f"Zoom token error: {data.get('reason', data.get('error', 'unknown'))}", "error")
            return redirect(url_for("dashboard"))

        access_token = data["access_token"]
        refresh_token = data.get("refresh_token", "")

        # Get user info
        user_resp = http_requests.get("https://api.zoom.us/v2/users/me", headers={
            "Authorization": f"Bearer {access_token}",
        }, timeout=10)

        email = "Zoom User"
        if user_resp.status_code == 200:
            user_data = user_resp.json()
            email = user_data.get("email", "Zoom User")

        # Save credentials
        creds = load_credentials()
        creds["accounts"] = [a for a in creds["accounts"] if a.get("type") != "zoom"]
        creds["accounts"].append({
            "email": f"Zoom: {email}",
            "type": "zoom",
            "services": ["zoom"],
            "access_token": access_token,
            "refresh_token": refresh_token,
            "client_id": config["client_id"],
            "client_secret": config["client_secret"],
            "connected_at": datetime.now().isoformat(),
        })
        save_credentials(creds)

        # Update config
        aria_config = load_config()
        if "channels" not in aria_config:
            aria_config["channels"] = {}
        aria_config["channels"]["zoom"] = {"enabled": True, "email": email}
        save_config(aria_config)

        flash(f"Connected Zoom: {email}", "success")
        return redirect(url_for("dashboard"))

    except Exception as e:
        flash(f"Zoom connection error: {e}", "error")
        return redirect(url_for("dashboard"))


@app.route("/setup/granola")
def granola_setup():
    # Check if Granola is installed on this Mac
    granola_cache = Path.home() / "Library" / "Application Support" / "Granola"
    granola_installed = granola_cache.exists()

    if granola_installed:
        status_html = """
        <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:16px;margin-bottom:16px;">
            <strong style="color:#166534;">Granola is installed on this Mac.</strong>
            <p style="font-size:13px;color:#374151;margin-top:4px;">ARIA will automatically sync your meeting notes and extract commitments.</p>
        </div>
        """
    else:
        status_html = """
        <div style="background:#fef3c7;border:1px solid #fde68a;border-radius:8px;padding:16px;margin-bottom:16px;">
            <strong style="color:#92400e;">Granola not detected on this Mac.</strong>
            <p style="font-size:13px;color:#374151;margin-top:4px;">Install Granola first, then come back here.</p>
        </div>
        """

    content = f"""
    <div class="step">
        <h3>What Granola Does for ARIA</h3>
        <p>Granola captures meeting notes automatically. ARIA reads these notes and:</p>
        <ul style="padding-left:20px;margin:8px 0;">
            <li>Extracts <strong>commitments</strong>: who promised what to whom</li>
            <li>Tracks <strong>"you owe"</strong> items (things you committed to)</li>
            <li>Tracks <strong>"they owe"</strong> items (things others committed to you)</li>
            <li>Surfaces <strong>slipped commitments</strong> in your briefings</li>
            <li>Provides <strong>meeting context</strong> for prep briefs (what you last discussed with each attendee)</li>
        </ul>
    </div>

    {status_html}

    <div class="step">
        <h3>Setup</h3>
        <ol>
            <li>Install Granola from <a href="https://granola.ai" target="_blank">granola.ai</a> (free plan works)</li>
            <li>Sign in and let it capture a few meetings</li>
            <li>ARIA syncs automatically via the Granola API (no token needed, uses your local Granola session)</li>
        </ol>
        <form action="/setup/granola/save" method="post">
            <br>
            <button type="submit" class="btn btn-primary">{'Mark as Connected' if granola_installed else 'I Have Installed Granola'}</button>
        </form>
    </div>

    <div class="step">
        <h3>Privacy</h3>
        <div class="highlight">
            <p>ARIA reads Granola's local data through its API. Meeting transcripts stay on your computer. ARIA extracts only the structured data it needs (decisions, commitments, attendees) for your briefings.</p>
        </div>
    </div>
    """
    return render_template_string(CHANNEL_SETUP_HTML,
        channel_name="Granola",
        channel_description="Automatic meeting notes with commitment tracking.",
        content=content)


@app.route("/setup/granola/save", methods=["POST"])
def granola_save():
    config = load_config()
    if "channels" not in config:
        config["channels"] = {}
    config["channels"]["meeting_notes"] = {"enabled": True, "provider": "granola"}
    save_config(config)

    creds = load_credentials()
    # Remove existing granola entries
    creds["accounts"] = [a for a in creds["accounts"] if a.get("type") != "granola"]
    creds["accounts"].append({
        "email": "Granola",
        "type": "granola",
        "services": ["meeting_notes"],
        "connected_at": datetime.now().isoformat(),
        "refresh_token": "local",
    })
    save_credentials(creds)

    flash("Granola connected! Meeting notes will be included in your briefings.", "success")
    return redirect(url_for("dashboard"))


@app.route("/setup/ai-email")
def ai_email_setup():
    content = """
    <div class="step">
        <h3>Why a Dedicated Email?</h3>
        <p>We recommend creating a separate email address for ARIA. This gives you:</p>
        <ul style="padding-left:20px;margin:8px 0;">
            <li><strong>Clean briefing delivery</strong> - Morning briefs come from "aria@yourdomain.com" or "yourname.aria@gmail.com"</li>
            <li><strong>Draft sending</strong> - ARIA can send approved drafts from its own address</li>
            <li><strong>No inbox noise</strong> - ARIA's email isn't mixed with your personal subscriptions</li>
            <li><strong>Professional appearance</strong> - Recipients see a branded sender, not your personal email</li>
        </ul>
    </div>

    <div class="step">
        <h3>Option A: Create a Free Gmail (Easiest)</h3>
        <ol>
            <li>Go to <a href="https://accounts.google.com/signup" target="_blank">accounts.google.com/signup</a></li>
            <li>Create an account like <code>yourname.aria@gmail.com</code> or <code>aria.yourpractice@gmail.com</code></li>
            <li>Come back here and connect it using the <strong>Connect Google</strong> button on the main page</li>
        </ol>
        <div class="highlight">This is the fastest option. Free, takes 2 minutes.</div>
    </div>

    <div class="step">
        <h3>Option B: Use Your Business Domain</h3>
        <p>If you have Google Workspace or Microsoft 365 for your business, create an alias or mailbox like <code>aria@yourbusiness.com</code>. Then connect it via the Google or Outlook button on the main page.</p>
    </div>

    <div class="step">
        <h3>After Creating the Email</h3>
        <form action="/setup/ai-email/save" method="post">
            <label for="ai_email">ARIA's email address</label>
            <input type="text" name="ai_email" id="ai_email" placeholder="aria.yourname@gmail.com">
            <br>
            <button type="submit" class="btn btn-primary">Save as ARIA's Sending Address</button>
            <a href="/" class="btn btn-secondary" style="margin-left:8px;">Skip for Now</a>
        </form>
        <p style="font-size:12px;color:#6b7280;margin-top:8px;">This sets which email address ARIA uses to send briefings and drafts. You still need to connect it via Google or Outlook on the main page.</p>
    </div>
    """
    return render_template_string(CHANNEL_SETUP_HTML,
        channel_name="Dedicated AI Email",
        channel_description="Give ARIA its own email address for sending briefings and approved drafts.",
        content=content)


@app.route("/setup/ai-email/save", methods=["POST"])
def ai_email_save():
    ai_email = request.form.get("ai_email", "").strip()
    if not ai_email or "@" not in ai_email:
        flash("Please enter a valid email address", "error")
        return redirect(url_for("ai_email_setup"))

    config = load_config()
    config["ai_email"] = ai_email
    save_config(config)

    # Also update the SMTP user in .env if not already set
    env_path = PROJECT_DIR / ".env"
    lines = []
    smtp_set = False
    if env_path.exists():
        with open(env_path) as f:
            for line in f:
                if line.strip().startswith("ARIA_SMTP_USER="):
                    smtp_set = True
                lines.append(line)
    if not smtp_set:
        lines.append(f"\n# ARIA's sending email address\nARIA_SMTP_USER={ai_email}\n")
        with open(env_path, "w") as f:
            f.writelines(lines)

    flash(f"ARIA will send briefings from {ai_email}. Make sure to connect this email via Google or Outlook on the main page.", "success")
    return redirect(url_for("dashboard"))


@app.route("/setup/cloud-ai")
def cloud_ai_setup():
    # Load env vars from .env
    env_file = PROJECT_DIR / ".env"
    if env_file.exists():
        with open(env_file) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, value = line.partition("=")
                    key = key.strip()
                    value = value.strip().strip("'\"")
                    if key:
                        os.environ[key] = value
    is_set = bool(os.environ.get("ANTHROPIC_API_KEY"))

    if is_set:
        status_html = """
        <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:16px;margin-bottom:16px;">
            <strong style="color:#166534;">Enhanced AI is configured.</strong>
            <p style="font-size:13px;color:#374151;margin-top:4px;">ARIA will use Claude for complex tasks like strategy memos, customer-facing drafts, and multi-step analysis.</p>
        </div>
        """
    else:
        status_html = ""

    content = f"""
    <div class="step">
        <h3>What This Does</h3>
        <p>ARIA runs most tasks on the local AI (free, private, on your hardware). For tasks that need higher quality, like:</p>
        <ul style="padding-left:20px;margin:8px 0;">
            <li>Customer-facing email drafts that need perfect tone</li>
            <li>Strategy memos and complex analysis</li>
            <li>Board/investor update writing</li>
            <li>Multi-source research synthesis</li>
        </ul>
        <p>ARIA can escalate to Claude (by Anthropic), one of the most capable AI models available. This is optional. ARIA works fully without it.</p>
    </div>

    <div class="step">
        <h3>Cost</h3>
        <p>Claude is pay-per-use. Typical business usage is <strong>$50-150/month</strong>. You can set a spending limit in your Anthropic dashboard.</p>
        <p style="font-size:12px;color:#6b7280;">Most daily briefings and email triage use local AI ($0). Cloud AI is only used for high-quality tasks, roughly 10-15% of requests.</p>
    </div>

    {status_html}

    <div class="step">
        <h3>Setup</h3>
        <ol>
            <li>Go to <a href="https://console.anthropic.com/settings/keys" target="_blank">console.anthropic.com/settings/keys</a></li>
            <li>Create an account (or sign in)</li>
            <li>Click <strong>Create Key</strong></li>
            <li>Copy the key (starts with <code>sk-ant-</code>)</li>
            <li>Recommended: Go to <a href="https://console.anthropic.com/settings/limits" target="_blank">Settings > Limits</a> and set a monthly spending limit</li>
        </ol>
        <form action="/setup/cloud-ai/save" method="post">
            <label for="api_key">Anthropic API Key</label>
            <input type="text" name="api_key" id="api_key" placeholder="sk-ant-..." {('value="configured"' if is_set else '')}>
            <br><br>
            <button type="submit" class="btn btn-primary">{('Update Key' if is_set else 'Enable Enhanced AI')}</button>
            {(' <a href="/" class="btn btn-secondary" style="margin-left:8px;">Skip for Now</a>' if not is_set else '')}
        </form>
        <div class="highlight">
            <p>Your API key is stored locally and never shared. You can remove it anytime to go back to local-only AI.</p>
        </div>
    </div>
    """
    return render_template_string(CHANNEL_SETUP_HTML,
        channel_name="Enhanced AI (Claude)",
        channel_description="Optional: higher quality AI for complex tasks.",
        content=content)


@app.route("/setup/cloud-ai/save", methods=["POST"])
def cloud_ai_save():
    api_key = request.form.get("api_key", "").strip()

    if not api_key or api_key == "configured":
        flash("Please enter a valid API key", "error")
        return redirect(url_for("cloud_ai_setup"))

    if not api_key.startswith("sk-ant-"):
        flash("Invalid key format. Anthropic keys start with sk-ant-", "error")
        return redirect(url_for("cloud_ai_setup"))

    # Save to .env
    env_path = PROJECT_DIR / ".env"
    lines = []
    written = False
    if env_path.exists():
        with open(env_path) as f:
            for line in f:
                if line.strip().startswith("ANTHROPIC_API_KEY="):
                    lines.append(f"ANTHROPIC_API_KEY={api_key}\n")
                    written = True
                else:
                    lines.append(line)
    if not written:
        lines.append(f"\n# Anthropic API Key (Enhanced AI)\nANTHROPIC_API_KEY={api_key}\n")
    with open(env_path, "w") as f:
        f.writelines(lines)

    # Reload env
    os.environ["ANTHROPIC_API_KEY"] = api_key

    flash("Enhanced AI enabled! Complex tasks will now use Claude for higher quality.", "success")
    return redirect(url_for("dashboard"))


@app.route("/setup/remote-support")
def remote_support_setup():
    is_connected = _check_tailscale()

    # Check if tailscale is installed
    import subprocess
    tailscale_installed = False
    try:
        subprocess.run(["tailscale", "version"], capture_output=True, timeout=5)
        tailscale_installed = True
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    # Get Tailscale IP if connected
    tailscale_ip = ""
    hostname = ""
    if is_connected:
        try:
            result = subprocess.run(["tailscale", "ip", "-4"], capture_output=True, text=True, timeout=5)
            tailscale_ip = result.stdout.strip()
            result2 = subprocess.run(["tailscale", "status", "--json"], capture_output=True, text=True, timeout=5)
            data = json.loads(result2.stdout)
            hostname = data.get("Self", {}).get("HostName", "")
        except Exception:
            pass

    if is_connected:
        status_html = f"""
        <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:16px;margin-bottom:16px;">
            <strong style="color:#166534;">Remote support is connected.</strong>
            <p style="font-size:13px;color:#374151;margin-top:4px;">Your administrator can now securely connect to help you.</p>
            <p style="font-size:13px;color:#374151;margin-top:4px;">Tailscale IP: <code>{tailscale_ip}</code> | Hostname: <code>{hostname}</code></p>
            <p style="font-size:12px;color:#6b7280;margin-top:4px;">Share this IP with your administrator if they need to connect.</p>
        </div>
        <a href="/" class="btn btn-primary">Back to Dashboard</a>
        """
    elif tailscale_installed:
        status_html = """
        <div style="background:#fef3c7;border:1px solid #fde68a;border-radius:8px;padding:16px;margin-bottom:16px;">
            <strong style="color:#92400e;">Tailscale is installed but not connected.</strong>
            <p style="font-size:13px;color:#374151;margin-top:4px;">Click the Tailscale icon in your menu bar and log in.</p>
        </div>
        """
    else:
        status_html = """
        <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:16px;margin-bottom:16px;">
            <strong style="color:#991b1b;">Tailscale is not installed.</strong>
        </div>
        """

    content = f"""
    <div class="step">
        <h3>What This Does</h3>
        <p>Remote support allows your ARIA administrator to securely connect to this computer to help with setup, troubleshooting, and updates. The connection is:</p>
        <ul style="padding-left:20px;margin:8px 0;">
            <li><strong>Encrypted end-to-end</strong> (no one in the middle can see the traffic)</li>
            <li><strong>Peer-to-peer</strong> (direct connection, not through a third-party server)</li>
            <li><strong>On-demand</strong> (your administrator connects only when helping you)</li>
            <li><strong>Visible</strong> (you can see the Tailscale icon in your menu bar when connected)</li>
        </ul>
        <p>Your administrator cannot access your computer without your knowledge. You can disconnect at any time by clicking the Tailscale icon and selecting Disconnect.</p>
    </div>

    {status_html}

    <div class="step">
        <h3>How to Set Up</h3>
        <ol>
            <li>{'Tailscale is already installed.' if tailscale_installed else 'Install Tailscale: <a href="https://tailscale.com/download/mac" target="_blank">Download for Mac</a> (free for personal use)'}</li>
            <li>Open Tailscale from your Applications folder or menu bar</li>
            <li>Click <strong>Log in</strong> and sign in with Google, Microsoft, or Apple</li>
            <li>Once connected, you'll see a green icon in your menu bar</li>
            <li>Share your <strong>Tailscale IP</strong> with your administrator (shown above when connected)</li>
        </ol>
    </div>

    <div class="step">
        <h3>For Your Administrator</h3>
        <div class="highlight">
            <p>To connect to this machine remotely:</p>
            <p><code>ssh user@[tailscale-ip]</code> (for terminal access)</p>
            <p>Or use Screen Sharing: <code>vnc://[tailscale-ip]</code></p>
            <p>The customer must also enable <strong>Remote Login</strong> (for SSH) or <strong>Screen Sharing</strong> in System Settings > General > Sharing.</p>
        </div>
    </div>

    <div class="step">
        <h3>Enable Remote Access</h3>
        <p>For your administrator to connect, enable one or both of these in System Settings:</p>
        <ol>
            <li>Open <strong>System Settings</strong> > <strong>General</strong> > <strong>Sharing</strong></li>
            <li>Turn on <strong>Remote Login</strong> (allows terminal access via SSH)</li>
            <li>Turn on <strong>Screen Sharing</strong> (allows your administrator to see your screen)</li>
        </ol>
        <a href="x-apple.systempreferences:com.apple.preference.sharing" class="btn btn-secondary" style="margin-top:8px;">Open Sharing Settings</a>
    </div>
    """
    return render_template_string(CHANNEL_SETUP_HTML,
        channel_name="Remote Support",
        channel_description="Let your administrator securely connect to help with setup and troubleshooting.",
        content=content)


@app.route("/setup/notifications")
def notifications_setup():
    # Check current status
    notif_db = Path.home() / "Library" / "Group Containers" / "group.com.apple.usernoted" / "db2" / "db"
    can_read = False
    if notif_db.exists():
        try:
            import sqlite3
            conn = sqlite3.connect(str(notif_db))
            conn.execute("SELECT COUNT(*) FROM record")
            conn.close()
            can_read = True
        except Exception:
            pass

    # Find the Python binary path
    python_path = str(PROJECT_DIR / ".venv" / "bin" / "python3")
    # Resolve symlinks to get the actual binary
    import os
    real_python = os.path.realpath(python_path)

    if can_read:
        status_html = """
        <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:16px;margin-bottom:16px;">
            <strong style="color:#166534;">Notification monitoring is working.</strong>
            <p style="font-size:13px;color:#374151;margin-top:4px;">ARIA can read your Mac's notifications. iMessage, WhatsApp, Signal, and other messaging apps are being monitored.</p>
        </div>
        <a href="/" class="btn btn-primary">Back to Dashboard</a>
        """
    else:
        status_html = f"""
        <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:16px;margin-bottom:16px;">
            <strong style="color:#991b1b;">Full Disk Access is required.</strong>
            <p style="font-size:13px;color:#374151;margin-top:4px;">ARIA needs permission to read the macOS notification database to monitor your messages.</p>
        </div>
        """

    content = f"""
    <div class="step">
        <h3>What This Does</h3>
        <p>When enabled, ARIA reads your Mac's notification center to capture messages from:</p>
        <ul style="padding-left:20px;margin:8px 0;">
            <li><strong>iMessage</strong> (texts from your iPhone sync to your Mac)</li>
            <li><strong>WhatsApp</strong> (if WhatsApp desktop is installed)</li>
            <li><strong>Signal</strong> (if Signal desktop is installed)</li>
            <li><strong>Telegram</strong> (message notifications)</li>
            <li><strong>Slack</strong> (notifications from any workspace)</li>
            <li><strong>Teams, Discord, FaceTime</strong> and other messaging apps</li>
        </ul>
        <p>These messages are included in your daily briefing so you don't miss important communications across any channel.</p>
    </div>

    <div class="step">
        <h3>How Your Data Is Handled</h3>
        <div class="highlight">
            <p><strong>All notification data stays on this computer.</strong> ARIA reads the notification database that macOS already maintains. It does not install any monitoring software, keyloggers, or screen readers. It only reads the same notifications you see in your notification center.</p>
            <p style="margin-top:8px;">Notification data is saved to <code>inbox/notifications-YYYY-MM-DD.json</code> and automatically deleted after 30 days.</p>
        </div>
    </div>

    {status_html}

    <div class="step">
        <h3>How to Enable</h3>
        <ol>
            <li>Open <strong>System Settings</strong> (click the Apple menu &gt; System Settings)</li>
            <li>Go to <strong>Privacy & Security</strong> &gt; <strong>Full Disk Access</strong></li>
            <li>Click the <strong>+</strong> button</li>
            <li>Navigate to and select this file:<br>
                <code>{real_python}</code><br>
                <span style="font-size:12px;color:#6b7280;">(Tip: In the file picker, press Cmd+Shift+G and paste the path above)</span>
            </li>
            <li>Toggle it <strong>ON</strong></li>
            <li>You may also need to add your <strong>Terminal app</strong> (Terminal, iTerm, or Ghostty) to Full Disk Access</li>
            <li>Come back here and refresh to verify it's working</li>
        </ol>
    </div>

    <div class="step">
        <h3>Why Full Disk Access?</h3>
        <p>macOS protects the notification database as part of your private data. Full Disk Access permission tells macOS that you trust ARIA's Python process to read this data. This is the same permission that backup tools, antivirus software, and other system utilities need.</p>
        <p style="margin-top:8px;">You can revoke this permission at any time in System Settings. ARIA will continue to work but won't include notification data in your briefings.</p>
    </div>

    <div style="margin-top:16px;">
        <a href="/" class="btn btn-primary">Back to Dashboard</a>
        <a href="x-apple.systempreferences:com.apple.preference.security?Privacy_AllFiles" class="btn btn-secondary" style="margin-left:8px;">Open Privacy Settings</a>
    </div>
    """
    return render_template_string(CHANNEL_SETUP_HTML,
        channel_name="Notification Monitoring",
        channel_description="Monitor iMessage, WhatsApp, Signal, and other messaging apps on this Mac.",
        content=content)


@app.route("/health")
def health():
    """Run health check and show results as a proper page."""
    import subprocess
    result = subprocess.run(
        [str(PROJECT_DIR / ".venv" / "bin" / "python3"), str(PROJECT_DIR / "scripts" / "health-check.py")],
        capture_output=True, text=True, timeout=30,
    )
    lines = (result.stdout + result.stderr).strip().split("\n")

    checks = []
    for line in lines:
        if "OK:" in line:
            name = line.split("OK:")[1].split("—")[0].strip()
            detail = line.split("—")[1].strip() if "—" in line else ""
            checks.append({"name": name, "status": "ok", "detail": detail})
        elif "FAIL:" in line:
            name = line.split("FAIL:")[1].split("—")[0].strip()
            detail = line.split("—")[1].strip() if "—" in line else ""
            checks.append({"name": name, "status": "fail", "detail": detail})
        elif "Health check complete:" in line:
            summary = line.split("]")[1].strip() if "]" in line else line

    all_ok = all(c["status"] == "ok" for c in checks)

    content = f"""
    <div style="text-align:center;margin-bottom:24px">
        <div style="font-size:48px;margin-bottom:8px">{'✓' if all_ok else '⚠'}</div>
        <div style="font-size:18px;font-weight:700;color:{'var(--badge-green-text)' if all_ok else 'var(--badge-yellow-text)'}">
            {'All Systems Healthy' if all_ok else 'Issues Detected'}
        </div>
    </div>
    """
    for c in checks:
        icon = "✓" if c["status"] == "ok" else "✕"
        color = "var(--badge-green-text)" if c["status"] == "ok" else "var(--danger-text)"
        bg = "var(--badge-green-bg)" if c["status"] == "ok" else "var(--danger-bg)"
        content += f"""
        <div style="display:flex;align-items:center;gap:12px;padding:12px 16px;margin-bottom:6px;background:{bg};border-radius:10px">
            <span style="font-size:16px;color:{color};font-weight:700">{icon}</span>
            <div style="flex:1">
                <div style="font-size:14px;font-weight:600;color:var(--text)">{c['name']}</div>
                <div style="font-size:12px;color:var(--text-dim)">{c['detail']}</div>
            </div>
        </div>
        """
    content += """
    <div style="margin-top:20px;display:flex;gap:8px">
        <a href="/health" class="btn btn-primary">Run Again</a>
        <a href="/" class="btn btn-ghost">Back to Setup</a>
    </div>
    """
    return render_template_string(CHANNEL_SETUP_HTML,
        channel_name="System Health",
        channel_description="Check that all ARIA services are running correctly.",
        content=content)


@app.route("/shutdown")
def shutdown():
    """Shutdown the onboarding server."""
    func = request.environ.get("werkzeug.server.shutdown")
    if func:
        func()
    return """
    <html><body style="font-family:Inter,sans-serif;text-align:center;padding:80px;">
    <h2>ARIA Setup Server Closed</h2>
    <p style="color:#6b7280;">You can close this tab. ARIA is configured and running.</p>
    </body></html>
    """


# --- Main ---

if __name__ == "__main__":
    print(f"\n  ARIA Onboarding Server")
    print(f"  Open: http://localhost:{ONBOARDING_PORT}\n")
    webbrowser.open(f"http://localhost:{ONBOARDING_PORT}")
    app.run(host="127.0.0.1", port=ONBOARDING_PORT, debug=False)
