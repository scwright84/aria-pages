#!/usr/bin/env python3
"""
ARIA Training Data Collector
Logs every draft approval, edit, and rejection to build the dataset
for LoRA fine-tuning in 6 months.

Captures:
  - Original AI-generated draft
  - User's edit (what they changed)
  - Whether approved, edited-then-approved, or rejected
  - Context (who the email was to, what project, what type)

This data teaches the model:
  - How the user actually writes (vs how AI writes)
  - What corrections they make (tone, length, phrasing)
  - What they reject entirely (wrong approach)

Format: config/training-data.jsonl (JSON Lines, one example per line)
Each line is a training pair: {"input": "...", "output": "...", "context": {...}}

Runs passively - called by draft_manager when approvals happen.
Also has a manual ingest mode for importing historical data.
"""

import json
import os
from datetime import datetime
from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent
TRAINING_FILE = PROJECT_DIR / "config" / "training-data.jsonl"
DRAFTS_FILE = PROJECT_DIR / "config" / "pending-drafts.json"
LOG_FILE = PROJECT_DIR / "logs" / "training-collector.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def record_approval(draft, action="approved", edited_body=None):
    """
    Record a draft approval/edit/rejection as training data.

    Args:
        draft: The draft dict (from pending-drafts.json)
        action: "approved" (used as-is), "edited" (user changed it), "rejected"
        edited_body: The user's edited version (only for action="edited")
    """
    entry = {
        "timestamp": datetime.now().isoformat(),
        "action": action,
        "context": {
            "to": draft.get("to", ""),
            "subject": draft.get("subject", ""),
            "project": draft.get("project"),
            "source": draft.get("source", ""),
        },
        "ai_draft": draft.get("body", ""),
    }

    if action == "edited" and edited_body:
        entry["user_edit"] = edited_body
        entry["training_pair"] = {
            "input": f"Draft an email to {draft.get('to', '')} about {draft.get('subject', '')}",
            "ai_output": draft.get("body", ""),
            "preferred_output": edited_body,
        }
    elif action == "approved":
        entry["training_pair"] = {
            "input": f"Draft an email to {draft.get('to', '')} about {draft.get('subject', '')}",
            "output": draft.get("body", ""),
            "quality": "good",
        }
    elif action == "rejected":
        entry["training_pair"] = {
            "input": f"Draft an email to {draft.get('to', '')} about {draft.get('subject', '')}",
            "output": draft.get("body", ""),
            "quality": "bad",
        }

    TRAINING_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(TRAINING_FILE, "a") as f:
        f.write(json.dumps(entry) + "\n")

    log(f"Recorded {action}: {draft.get('subject', '?')[:50]}")


def record_briefing_feedback(briefing_date, feedback_text, feedback_type="general"):
    """Record feedback on a briefing (what was useful, what wasn't)."""
    entry = {
        "timestamp": datetime.now().isoformat(),
        "type": "briefing_feedback",
        "briefing_date": briefing_date,
        "feedback": feedback_text,
        "feedback_type": feedback_type,
    }

    TRAINING_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(TRAINING_FILE, "a") as f:
        f.write(json.dumps(entry) + "\n")

    log(f"Recorded briefing feedback for {briefing_date}")


def record_search_result_feedback(query, result_index, helpful):
    """Record whether a search result was helpful (for ranking improvement)."""
    entry = {
        "timestamp": datetime.now().isoformat(),
        "type": "search_feedback",
        "query": query,
        "result_index": result_index,
        "helpful": helpful,
    }

    TRAINING_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(TRAINING_FILE, "a") as f:
        f.write(json.dumps(entry) + "\n")


def get_stats():
    """Get training data collection stats."""
    if not TRAINING_FILE.exists():
        return {"total": 0, "approvals": 0, "edits": 0, "rejections": 0}

    from collections import Counter
    actions = Counter()
    total = 0

    with open(TRAINING_FILE) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
                actions[entry.get("action", entry.get("type", "unknown"))] += 1
                total += 1
            except json.JSONDecodeError:
                continue

    return {
        "total": total,
        "approvals": actions.get("approved", 0),
        "edits": actions.get("edited", 0),
        "rejections": actions.get("rejected", 0),
        "briefing_feedback": actions.get("briefing_feedback", 0),
        "search_feedback": actions.get("search_feedback", 0),
        "ready_for_finetuning": total >= 100,
        "finetuning_eta": f"~{max(0, (100 - total) * 7 // 30)} weeks" if total < 100 else "Ready now",
    }


def main():
    """Show training data stats."""
    stats = get_stats()
    print("ARIA Training Data Collector\n")
    print(f"Total examples: {stats['total']}")
    print(f"  Approvals: {stats['approvals']}")
    print(f"  Edits: {stats['edits']}")
    print(f"  Rejections: {stats['rejections']}")
    print(f"  Briefing feedback: {stats['briefing_feedback']}")
    print(f"  Search feedback: {stats['search_feedback']}")
    print(f"\nReady for fine-tuning: {'Yes' if stats['ready_for_finetuning'] else 'No'}")
    print(f"ETA: {stats['finetuning_eta']}")
    print(f"\nData file: {TRAINING_FILE}")


if __name__ == "__main__":
    main()
