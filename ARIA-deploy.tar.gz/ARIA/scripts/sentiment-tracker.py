#!/usr/bin/env python3
"""
ARIA Sentiment Tracker
Tracks communication tone per client/project over time.
Detects warming/cooling trends as early warning for relationship issues.

Signals:
  - Email tone (positive/neutral/negative keywords)
  - Response patterns (getting slower = cooling)
  - Exclamation/emoji usage trends
  - Subject line formality changes
  - Slack urgency levels

Output: config/sentiment-history.json (persistent)
        briefings/YYYY-MM-DD-sentiment.json (weekly snapshot)
"""

import json
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
SENTIMENT_FILE = PROJECT_DIR / "config" / "sentiment-history.json"
LOG_FILE = PROJECT_DIR / "logs" / "sentiment-tracker.log"

POSITIVE_WORDS = set("great excellent awesome wonderful perfect love happy excited thank thanks appreciate grateful amazing good nice fantastic brilliant superb".split())
NEGATIVE_WORDS = set("concerned worried frustrated disappointed issue problem urgent delay blocked stuck confused wrong failed missing broken bad terrible".split())
FORMAL_WORDS = set("regarding pursuant kindly hereby acknowledge forthwith".split())
CASUAL_WORDS = set("hey cool awesome yeah sure thing haha lol btw fyi".split())


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def load_sentiment_history():
    if SENTIMENT_FILE.exists():
        try:
            with open(SENTIMENT_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"weekly_scores": {}}


def save_sentiment(data):
    SENTIMENT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(SENTIMENT_FILE, "w") as f:
        json.dump(data, f, indent=2, default=str)


def load_emails(days_back=7):
    all_emails = []
    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        path = INBOX_DIR / f"emails-{date.strftime('%Y-%m-%d')}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                all_emails.extend(data if isinstance(data, list) else [data])
            except Exception:
                pass
    return all_emails


def score_text_sentiment(text):
    """Score text sentiment from -1 (negative) to +1 (positive)."""
    if not text:
        return 0

    words = set(re.findall(r'\b[a-z]+\b', text.lower()))
    pos = len(words & POSITIVE_WORDS)
    neg = len(words & NEGATIVE_WORDS)

    if pos + neg == 0:
        return 0

    return round((pos - neg) / (pos + neg), 2)


def score_formality(text):
    """Score formality from -1 (very casual) to +1 (very formal)."""
    if not text:
        return 0

    words = set(re.findall(r'\b[a-z]+\b', text.lower()))
    formal = len(words & FORMAL_WORDS)
    casual = len(words & CASUAL_WORDS)

    if formal + casual == 0:
        return 0

    return round((formal - casual) / (formal + casual), 2)


def analyze_project_sentiment(emails, project):
    """Analyze sentiment for a specific project."""
    proj_emails = [e for e in emails if e.get("detected_project") == project]
    if not proj_emails:
        return None

    sentiments = []
    formalities = []
    exclamation_count = 0
    question_count = 0

    for e in proj_emails:
        text = f"{e.get('subject', '')} {e.get('summary', '')} {e.get('snippet', '')}"
        sentiments.append(score_text_sentiment(text))
        formalities.append(score_formality(text))
        exclamation_count += text.count("!")
        question_count += text.count("?")

    avg_sentiment = sum(sentiments) / len(sentiments) if sentiments else 0
    avg_formality = sum(formalities) / len(formalities) if formalities else 0

    # Check Slack urgency
    slack_urgency = 0
    for d in range(7):
        date = datetime.now() - timedelta(days=d)
        path = INBOX_DIR / f"slack-{date.strftime('%Y-%m-%d')}.json"
        if path.exists():
            try:
                with open(path) as f:
                    slack = json.load(f)
                for s in slack:
                    if s.get("project") == project:
                        urg = s.get("urgency", "normal")
                        if urg == "high":
                            slack_urgency += 2
                        elif urg == "medium":
                            slack_urgency += 1
            except Exception:
                pass

    # Composite mood score (0-100)
    mood = 50 + (avg_sentiment * 30) - (slack_urgency * 5)
    mood = max(0, min(100, round(mood)))

    if mood >= 70:
        label = "positive"
    elif mood >= 40:
        label = "neutral"
    else:
        label = "concerning"

    return {
        "project": project,
        "email_count": len(proj_emails),
        "avg_sentiment": round(avg_sentiment, 3),
        "avg_formality": round(avg_formality, 3),
        "exclamation_rate": round(exclamation_count / max(len(proj_emails), 1), 2),
        "question_rate": round(question_count / max(len(proj_emails), 1), 2),
        "slack_urgency_signals": slack_urgency,
        "mood_score": mood,
        "mood_label": label,
    }


def detect_trends(history, project, current_score):
    """Compare current sentiment to history to detect trends."""
    project_history = history.get("weekly_scores", {}).get(project, [])
    if len(project_history) < 2:
        return "insufficient_data"

    recent_scores = [s.get("mood_score", 50) for s in project_history[-4:]]
    avg_recent = sum(recent_scores) / len(recent_scores)

    if current_score > avg_recent + 10:
        return "warming"
    elif current_score < avg_recent - 10:
        return "cooling"
    return "stable"


def main():
    log("Starting sentiment tracking")
    config = load_config()
    history = load_sentiment_history()
    emails = load_emails(days_back=7)

    known_projects = config.get("known_projects", [])
    date_str = datetime.now().strftime("%Y-%m-%d")
    week_key = datetime.now().strftime("%Y-W%U")

    results = []
    alerts = []

    for project in known_projects:
        score = analyze_project_sentiment(emails, project)
        if not score:
            continue

        trend = detect_trends(history, project, score["mood_score"])
        score["trend"] = trend
        results.append(score)

        # Store in history
        if project not in history["weekly_scores"]:
            history["weekly_scores"][project] = []
        history["weekly_scores"][project].append({
            "week": week_key,
            "mood_score": score["mood_score"],
            "date": date_str,
        })
        # Keep last 12 weeks
        history["weekly_scores"][project] = history["weekly_scores"][project][-12:]

        # Alert on concerning trends
        if score["mood_label"] == "concerning":
            alerts.append(f"{project}: mood score {score['mood_score']} (concerning)")
        if trend == "cooling":
            alerts.append(f"{project}: sentiment trending DOWN")

        log(f"  {project}: mood={score['mood_score']} ({score['mood_label']}), trend={trend}, sentiment={score['avg_sentiment']}")

    save_sentiment(history)

    # Save report
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    report = {
        "date": date_str,
        "projects": results,
        "alerts": alerts,
    }
    with open(BRIEFINGS_DIR / f"{date_str}-sentiment.json", "w") as f:
        json.dump(report, f, indent=2, default=str)

    log(f"Tracked {len(results)} projects")
    if alerts:
        log(f"ALERTS: {len(alerts)}")
        for a in alerts:
            log(f"  {a}")
    log("Sentiment tracking complete")


if __name__ == "__main__":
    main()
