#!/bin/bash
# Generate and send Conceivable weekly team brief
# Runs Sunday at 6pm via launchd (before general weekly rollup at 7pm)

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
VENV="$PROJECT_DIR/.venv/bin/python3"
LOG="$PROJECT_DIR/logs/conceivable-weekly.log"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Conceivable weekly brief generation starting" >> "$LOG"

"$VENV" "$SCRIPT_DIR/generate-conceivable-weekly.py" >> "$LOG" 2>&1
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Conceivable weekly brief generation complete" >> "$LOG"
