#!/usr/bin/env python3
"""
ARIA Auto Task Extraction
Pulls action items from emails, Slack, and commitments into a unified task list.

Sources:
  - Emails: action_needed, action_type, suggested_reply fields
  - Slack: action_items array per channel
  - Awaiting: commitments with owners and deadlines

Output: briefings/YYYY-MM-DD-tasks.json + briefings/YYYY-MM-DD-tasks.html
Also maintains a rolling task file: config/tasks.json (persistent, tracks completion)

Runs daily after inbox sync, or on demand.
"""

import json
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
TASKS_FILE = PROJECT_DIR / "config" / "tasks.json"
LOG_FILE = PROJECT_DIR / "logs" / "task-extractor.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_config():
    config_path = PROJECT_DIR / "config" / "aria.json"
    if config_path.exists():
        with open(config_path) as f:
            return json.load(f)
    return {}


def load_inbox_files(prefix, days_back=7):
    all_data = []
    for day_offset in range(days_back):
        date = datetime.now() - timedelta(days=day_offset)
        date_str = date.strftime("%Y-%m-%d")
        path = INBOX_DIR / f"{prefix}-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                if isinstance(data, list):
                    all_data.extend(data)
            except (json.JSONDecodeError, IOError):
                pass
    return all_data


def load_existing_tasks():
    if TASKS_FILE.exists():
        with open(TASKS_FILE) as f:
            return json.load(f)
    return {"tasks": [], "completed": []}


def save_tasks(data):
    TASKS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(TASKS_FILE, "w") as f:
        json.dump(data, f, indent=2, default=str)


def _parse_date(val):
    if val is None:
        return None
    if isinstance(val, (int, float)) or (isinstance(val, str) and val.isdigit()):
        ts = int(val)
        if ts > 1e12:
            ts = ts / 1000
        try:
            return datetime.fromtimestamp(ts)
        except (ValueError, OSError):
            return None
    if isinstance(val, str):
        try:
            return datetime.fromisoformat(val.replace("Z", "+00:00")).replace(tzinfo=None)
        except (ValueError, TypeError):
            return None
    return None


def _task_id(source, key):
    """Generate a stable ID for deduplication."""
    import hashlib
    return hashlib.md5(f"{source}:{key}".encode()).hexdigest()[:12]


def extract_email_tasks(days_back=3):
    """Extract tasks from emails with action_needed=true."""
    tasks = []
    emails = load_inbox_files("emails", days_back)

    for e in emails:
        if not e.get("action_needed"):
            continue

        subject = e.get("subject", "")
        sender = e.get("from", "")
        project = e.get("detected_project")
        action_type = e.get("action_type", "respond")
        summary = e.get("summary", "")
        suggested = e.get("suggested_reply", "")
        date = _parse_date(e.get("date") or e.get("processed_at"))
        msg_id = e.get("message_id", subject)

        task = {
            "id": _task_id("email", msg_id),
            "source": "email",
            "action": action_type,
            "title": f"{action_type.capitalize()}: {subject[:80]}",
            "from": sender,
            "project": project,
            "summary": summary[:200] if summary else subject,
            "suggested_reply": suggested[:300] if suggested else None,
            "date": date.isoformat() if date else None,
            "priority": e.get("priority", "normal"),
            "status": "open",
        }
        tasks.append(task)

    return tasks


def extract_slack_tasks(days_back=3):
    """Extract action items from Slack channel summaries."""
    tasks = []
    slack = load_inbox_files("slack", days_back)

    for s in slack:
        action_items = s.get("action_items", [])
        channel = s.get("channel_name", "")
        project = s.get("project")
        date = _parse_date(s.get("processed_at"))

        for i, item in enumerate(action_items):
            if isinstance(item, str) and len(item) > 5:
                task = {
                    "id": _task_id("slack", f"{channel}:{i}:{item[:30]}"),
                    "source": "slack",
                    "action": "follow_up",
                    "title": item[:100],
                    "from": f"#{channel}",
                    "project": project,
                    "summary": item,
                    "suggested_reply": None,
                    "date": date.isoformat() if date else None,
                    "priority": s.get("urgency", "normal"),
                    "status": "open",
                }
                tasks.append(task)

    return tasks


def extract_commitment_tasks(days_back=14):
    """Extract open commitments as tasks."""
    tasks = []
    awaiting = load_inbox_files("awaiting", days_back)
    today = datetime.now()

    for a in awaiting:
        task_desc = a.get("task", "")
        owner = a.get("owner", "")
        deadline = a.get("deadline", "")
        project = a.get("project")
        meeting = a.get("meeting", "")

        if not task_desc or len(task_desc) < 5:
            continue

        # Determine if overdue
        is_overdue = False
        if deadline and deadline not in ("none", "TBD", ""):
            try:
                dl = datetime.strptime(deadline, "%Y-%m-%d")
                is_overdue = dl < today
            except ValueError:
                pass

        priority = "high" if is_overdue else "normal"

        task = {
            "id": _task_id("commitment", f"{project}:{task_desc[:30]}"),
            "source": "commitment",
            "action": "follow_up" if "Sean" not in owner else "do",
            "title": f"{'OVERDUE: ' if is_overdue else ''}Commitment: {task_desc[:80]}",
            "from": f"Meeting: {meeting}" if meeting else owner,
            "project": project,
            "summary": task_desc,
            "suggested_reply": None,
            "date": a.get("meeting_date"),
            "deadline": deadline,
            "owner": owner,
            "priority": priority,
            "status": "open",
        }
        tasks.append(task)

    return tasks


def merge_tasks(existing, new_tasks):
    """Merge new tasks into existing list, deduplicating by ID."""
    existing_ids = {t["id"] for t in existing.get("tasks", [])}
    completed_ids = {t["id"] for t in existing.get("completed", [])}

    added = 0
    for task in new_tasks:
        if task["id"] not in existing_ids and task["id"] not in completed_ids:
            existing["tasks"].append(task)
            existing_ids.add(task["id"])
            added += 1

    return existing, added


def generate_html(tasks, date_str):
    """Generate HTML task list."""
    priority_order = {"high": 0, "urgent": 0, "medium": 1, "normal": 2, "low": 3}
    sorted_tasks = sorted(tasks, key=lambda t: (priority_order.get(t.get("priority", "normal"), 2), t.get("date") or ""))

    source_icons = {"email": "&#x2709;", "slack": "&#x23;", "commitment": "&#x2611;"}
    priority_colors = {"high": "#ef4444", "urgent": "#ef4444", "medium": "#f97316", "normal": "#6b7280", "low": "#9ca3af"}

    rows = ""
    for t in sorted_tasks:
        icon = source_icons.get(t["source"], "")
        p_color = priority_colors.get(t.get("priority", "normal"), "#6b7280")
        project = t.get("project") or "-"
        date = (t.get("date") or "")[:10]

        rows += f"""
        <tr>
            <td style="text-align:center;font-size:18px">{icon}</td>
            <td><strong>{t["title"]}</strong><br><span style="font-size:12px;color:#6b7280">{t.get("from", "")}</span></td>
            <td>{project}</td>
            <td style="color:{p_color};font-weight:600;text-transform:capitalize">{t.get("priority", "normal")}</td>
            <td style="font-size:12px">{date}</td>
        </tr>"""

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>ARIA Task List - {date_str}</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 900px; margin: 0 auto; padding: 20px; background: #f9fafb; }}
  h1 {{ font-size: 20px; color: #111827; margin-bottom: 4px; }}
  .subtitle {{ color: #6b7280; font-size: 14px; margin-bottom: 16px; }}
  .stats {{ display: flex; gap: 16px; margin-bottom: 16px; }}
  .stat {{ background: white; padding: 8px 16px; border-radius: 6px; font-size: 14px; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }}
  .stat strong {{ font-size: 20px; }}
  table {{ width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }}
  th {{ background: #111827; color: white; padding: 10px 12px; text-align: left; font-size: 12px; text-transform: uppercase; }}
  td {{ padding: 10px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px; }}
  tr:hover {{ background: #f3f4f6; }}
</style>
</head>
<body>
<h1>Task List</h1>
<p class="subtitle">{date_str} | {len(sorted_tasks)} open tasks | Generated by ARIA</p>
<div class="stats">
  <div class="stat"><strong>{sum(1 for t in sorted_tasks if t['source']=='email')}</strong> from email</div>
  <div class="stat"><strong>{sum(1 for t in sorted_tasks if t['source']=='slack')}</strong> from Slack</div>
  <div class="stat"><strong>{sum(1 for t in sorted_tasks if t['source']=='commitment')}</strong> commitments</div>
  <div class="stat"><strong>{sum(1 for t in sorted_tasks if t.get('priority') in ('high','urgent'))}</strong> high priority</div>
</div>
<table>
  <thead><tr><th></th><th>Task</th><th>Project</th><th>Priority</th><th>Date</th></tr></thead>
  <tbody>{rows}</tbody>
</table>
</body>
</html>"""
    return html


def main():
    log("Starting task extraction")
    date_str = datetime.now().strftime("%Y-%m-%d")

    email_tasks = extract_email_tasks(days_back=3)
    log(f"Email tasks: {len(email_tasks)}")

    slack_tasks = extract_slack_tasks(days_back=3)
    log(f"Slack tasks: {len(slack_tasks)}")

    commitment_tasks = extract_commitment_tasks(days_back=14)
    log(f"Commitment tasks: {len(commitment_tasks)}")

    all_new = email_tasks + slack_tasks + commitment_tasks
    log(f"Total new tasks: {len(all_new)}")

    # Merge with existing
    existing = load_existing_tasks()
    merged, added = merge_tasks(existing, all_new)
    save_tasks(merged)
    log(f"Added {added} new tasks. Total open: {len(merged['tasks'])}")

    # Save daily snapshot
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    json_path = BRIEFINGS_DIR / f"{date_str}-tasks.json"
    with open(json_path, "w") as f:
        json.dump(merged["tasks"], f, indent=2, default=str)
    log(f"Saved JSON: {json_path}")

    html_path = BRIEFINGS_DIR / f"{date_str}-tasks.html"
    html = generate_html(merged["tasks"], date_str)
    with open(html_path, "w") as f:
        f.write(html)
    log(f"Saved HTML: {html_path}")

    # Summary
    for t in sorted(merged["tasks"], key=lambda x: x.get("priority", "z"))[:10]:
        log(f"  [{t['priority'].upper():>6}] {t['source']:>10} | {t['title'][:70]}")

    log("Task extraction complete")


if __name__ == "__main__":
    main()
