#!/usr/bin/env python3
"""
ARIA Proactive Outreach Alerts
Flags contacts and projects that have gone silent based on configurable thresholds.

Uses thresholds from aria.json:
  - outreach_active_client_days: 5 (active clients)
  - outreach_key_contact_days: 10 (key contacts)
  - outreach_pipeline_days: 14 (pipeline/on-hold)

Checks contact profiles (config/contacts.json) and inbox data.
Outputs alerts to briefings/YYYY-MM-DD-outreach.json for inclusion in briefs.

Runs daily (after inbox sync) or on demand.
"""

import json
import sys
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
CONTACTS_FILE = PROJECT_DIR / "config" / "contacts.json"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
LOG_FILE = PROJECT_DIR / "logs" / "outreach-alerts.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def load_contacts():
    if CONTACTS_FILE.exists():
        with open(CONTACTS_FILE) as f:
            return json.load(f)
    return {}


def load_inbox_files(prefix, days_back=30):
    all_data = []
    for day_offset in range(days_back):
        date = datetime.now() - timedelta(days=day_offset)
        date_str = date.strftime("%Y-%m-%d")
        path = INBOX_DIR / f"{prefix}-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                if isinstance(data, list):
                    all_data.extend(data)
            except (json.JSONDecodeError, IOError):
                pass
    return all_data


def _parse_date(*fields):
    """Try to parse a date from multiple fields. Handles Unix ms timestamps, ISO strings."""
    for val in fields:
        if val is None:
            continue
        # Unix timestamp in milliseconds
        if isinstance(val, (int, float)) or (isinstance(val, str) and val.isdigit()):
            ts = int(val)
            if ts > 1e12:  # Milliseconds
                ts = ts / 1000
            if ts > 1e9:  # Reasonable epoch
                try:
                    return datetime.fromtimestamp(ts)
                except (ValueError, OSError):
                    pass
        # ISO string
        if isinstance(val, str):
            for fmt in ["%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S"]:
                try:
                    return datetime.strptime(val.split("+")[0].split("Z")[0].rstrip(".") + ("" if "." in val.split("+")[0] else ""), fmt.rstrip("Z"))
                except ValueError:
                    pass
            try:
                return datetime.fromisoformat(val.replace("Z", "+00:00")).replace(tzinfo=None)
            except (ValueError, TypeError):
                pass
    return None


def find_last_contact_per_project(config):
    """Find the most recent communication date for each project."""
    known_projects = config.get("known_projects", [])
    last_contact = {}

    # Check emails
    emails = load_inbox_files("emails", days_back=60)
    for e in emails:
        project = e.get("detected_project")
        if not project or project not in known_projects:
            continue
        d = _parse_date(e.get("date"), e.get("processed_at"))
        if d and (project not in last_contact or d > last_contact[project]):
            last_contact[project] = d

    # Check Slack
    slack = load_inbox_files("slack", days_back=60)
    for s in slack:
        project = s.get("project")
        if not project or project not in known_projects:
            continue
        d = _parse_date(s.get("processed_at"))
        if d and (project not in last_contact or d > last_contact[project]):
            last_contact[project] = d

    return last_contact


def generate_alerts(config):
    """Generate outreach alerts based on silence thresholds."""
    thresholds = config.get("thresholds", {})
    active_days = thresholds.get("outreach_active_client_days", 5)
    key_contact_days = thresholds.get("outreach_key_contact_days", 10)
    pipeline_days = thresholds.get("outreach_pipeline_days", 14)

    client_tiers = config.get("client_tiers", {})
    active_clients = set(client_tiers.get("active", []))
    product_projects = set(client_tiers.get("product", []))
    on_hold = set(client_tiers.get("on_hold", []))

    now = datetime.now()
    last_contact = find_last_contact_per_project(config)

    alerts = []

    for project in config.get("known_projects", []):
        last = last_contact.get(project)
        if last is None:
            days_silent = 999
        else:
            days_silent = (now - last).days

        # Determine threshold based on tier
        if project in active_clients:
            threshold = active_days
            tier = "active"
        elif project in product_projects:
            threshold = key_contact_days
            tier = "product"
        elif project in on_hold:
            threshold = pipeline_days
            tier = "on_hold"
        else:
            threshold = pipeline_days
            tier = "other"

        if days_silent > threshold:
            urgency = "high" if days_silent > threshold * 2 else "medium"
            alerts.append({
                "project": project,
                "tier": tier,
                "days_silent": days_silent,
                "threshold": threshold,
                "days_over": days_silent - threshold,
                "last_contact": last.isoformat() if last else None,
                "urgency": urgency,
                "suggestion": _suggest_action(project, tier, days_silent),
            })

    # Also check individual contacts who are important but going dark
    contacts = load_contacts()
    contact_alerts = []
    for key, contact in contacts.items():
        if not contact.get("projects"):
            continue
        last = contact.get("last_contact")
        if not last:
            continue
        try:
            last_dt = datetime.fromisoformat(last)
            days = (now - last_dt).days
        except (ValueError, TypeError):
            continue

        # Only flag contacts in active projects with significant history
        if contact.get("email_count", 0) >= 3 and days > key_contact_days:
            projects = contact.get("projects", [])
            active_overlap = set(projects) & active_clients
            if active_overlap:
                contact_alerts.append({
                    "name": contact.get("name", key),
                    "projects": list(active_overlap),
                    "days_silent": days,
                    "email_count": contact.get("email_count", 0),
                    "last_contact": last,
                })

    return {
        "generated": now.isoformat(),
        "project_alerts": sorted(alerts, key=lambda a: a["days_over"], reverse=True),
        "contact_alerts": sorted(contact_alerts, key=lambda c: c["days_silent"], reverse=True),
        "thresholds": {
            "active_client_days": active_days,
            "key_contact_days": key_contact_days,
            "pipeline_days": pipeline_days,
        }
    }


def _suggest_action(project, tier, days_silent):
    """Generate a suggested action based on context."""
    if tier == "active" and days_silent > 10:
        return f"URGENT: Active client {project} silent for {days_silent} days. Schedule a check-in call."
    elif tier == "active":
        return f"Send a quick status update or check-in email to {project}."
    elif tier == "product":
        return f"Review {project} roadmap. Any updates to share?"
    elif tier == "on_hold":
        return f"Low priority. {project} is on hold. Touch base if re-engagement is planned."
    return f"Consider reaching out to {project}."


def main():
    log("Starting outreach alert generation")
    config = load_config()
    date_str = datetime.now().strftime("%Y-%m-%d")

    alerts = generate_alerts(config)

    # Save JSON
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    json_path = BRIEFINGS_DIR / f"{date_str}-outreach.json"
    with open(json_path, "w") as f:
        json.dump(alerts, f, indent=2, default=str)
    log(f"Saved: {json_path}")

    # Summary
    proj_count = len(alerts["project_alerts"])
    contact_count = len(alerts["contact_alerts"])
    log(f"Project alerts: {proj_count}")
    for a in alerts["project_alerts"]:
        log(f"  {a['urgency'].upper()}: {a['project']} ({a['tier']}) — {a['days_silent']}d silent (threshold: {a['threshold']}d)")
    log(f"Contact alerts: {contact_count}")
    for c in alerts["contact_alerts"][:5]:
        log(f"  {c['name']} — {c['days_silent']}d silent, {c['email_count']} emails total")

    log("Outreach alerts complete")


if __name__ == "__main__":
    main()
