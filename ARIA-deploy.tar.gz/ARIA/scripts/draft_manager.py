"""
ARIA Draft Manager
Manages draft email responses. Works with Telegram bot for mobile approval workflow.

Commands (via Telegram):
  /drafts          - Show pending drafts
  /approve <n>     - Approve and send draft #n
  /reject <n>      - Reject draft #n (delete from Gmail Drafts)
  /edit <n> <text>  - Edit draft #n then approve
  /approveall      - Approve all pending drafts

Also used by the email organizer to track which drafts exist.
"""

import json
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

PROJECT_DIR = Path(__file__).parent.parent
DRAFTS_FILE = PROJECT_DIR / "config" / "pending-drafts.json"
INBOX_DIR = PROJECT_DIR / "inbox"
LOG_FILE = PROJECT_DIR / "logs" / "draft-manager.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_drafts():
    """Load pending drafts."""
    if DRAFTS_FILE.exists():
        try:
            with open(DRAFTS_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"drafts": []}


def save_drafts(data):
    DRAFTS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(DRAFTS_FILE, "w") as f:
        json.dump(data, f, indent=2, default=str)


def add_draft(to, subject, body, original_message_id=None, account=None, project=None):
    """Add a new draft to the pending list."""
    data = load_drafts()
    draft = {
        "id": len(data["drafts"]) + 1,
        "to": to,
        "subject": subject,
        "body": body,
        "original_message_id": original_message_id,
        "account": account,
        "project": project,
        "status": "pending",
        "created": datetime.now().isoformat(),
    }
    data["drafts"].append(draft)
    save_drafts(data)
    log(f"Added draft #{draft['id']}: {subject[:50]}")
    return draft


def list_pending():
    """Get all pending drafts."""
    data = load_drafts()
    return [d for d in data["drafts"] if d.get("status") == "pending"]


def get_draft(draft_id):
    """Get a specific draft by ID."""
    data = load_drafts()
    for d in data["drafts"]:
        if d.get("id") == draft_id:
            return d
    return None


def approve_draft(draft_id):
    """Mark a draft as approved (ready to send)."""
    data = load_drafts()
    for d in data["drafts"]:
        if d.get("id") == draft_id and d.get("status") == "pending":
            d["status"] = "approved"
            d["approved_at"] = datetime.now().isoformat()
            save_drafts(data)
            log(f"Approved draft #{draft_id}")
            return d
    return None


def reject_draft(draft_id):
    """Mark a draft as rejected."""
    data = load_drafts()
    for d in data["drafts"]:
        if d.get("id") == draft_id and d.get("status") == "pending":
            d["status"] = "rejected"
            d["rejected_at"] = datetime.now().isoformat()
            save_drafts(data)
            log(f"Rejected draft #{draft_id}")
            return d
    return None


def edit_draft(draft_id, new_body):
    """Edit a draft's body text."""
    data = load_drafts()
    for d in data["drafts"]:
        if d.get("id") == draft_id and d.get("status") == "pending":
            d["body"] = new_body
            d["edited_at"] = datetime.now().isoformat()
            save_drafts(data)
            log(f"Edited draft #{draft_id}")
            return d
    return None


def approve_all():
    """Approve all pending drafts."""
    data = load_drafts()
    approved = []
    for d in data["drafts"]:
        if d.get("status") == "pending":
            d["status"] = "approved"
            d["approved_at"] = datetime.now().isoformat()
            approved.append(d)
    save_drafts(data)
    log(f"Approved all: {len(approved)} drafts")
    return approved


def format_drafts_for_telegram(drafts):
    """Format pending drafts as a Telegram message."""
    if not drafts:
        return "No pending drafts. You're caught up."

    lines = [f"*{len(drafts)} Pending Draft{'s' if len(drafts) != 1 else ''}*\n"]
    for d in drafts:
        lines.append(f"*#{d['id']}* To: {d['to']}")
        lines.append(f"Re: {d['subject'][:60]}")
        body_preview = d['body'][:150].replace('\n', ' ')
        lines.append(f"_{body_preview}_")
        lines.append(f"`/approve {d['id']}` | `/reject {d['id']}` | `/edit {d['id']} new text`")
        lines.append("")

    lines.append("`/approveall` to send all drafts")
    return "\n".join(lines)


def format_draft_detail(draft):
    """Format a single draft with full body for Telegram."""
    if not draft:
        return "Draft not found."

    lines = [
        f"*Draft #{draft['id']}*",
        f"To: {draft['to']}",
        f"Subject: {draft['subject']}",
        f"Project: {draft.get('project') or 'N/A'}",
        f"Status: {draft['status']}",
        "",
        f"_{draft['body'][:500]}_",
    ]

    if draft["status"] == "pending":
        lines.append("")
        lines.append(f"`/approve {draft['id']}` | `/reject {draft['id']}`")

    return "\n".join(lines)
