#!/usr/bin/env python3
"""
Quick test: read the last 10 messaging notifications from macOS notification center.
Verifies DB access and shows what data is available.
"""

import sqlite3
import plistlib
import os
from datetime import datetime

NOTIFICATION_DB = os.path.expanduser(
    "~/Library/Group Containers/group.com.apple.usernoted/db2/db"
)

WATCHED_APPS = {
    "com.apple.mobilesms": "iMessage",
    "com.apple.ichat": "Messages",
    "desktop.whatsapp": "WhatsApp",
    "net.whatsapp.whatsapp": "WhatsApp",
    "org.whispersystems.signal-desktop": "Signal",
    "com.tdesktop.telegram": "Telegram",
    "com.tinyspeck.slackmacgap": "Slack",
    "com.microsoft.teams2": "Teams",
    "com.hnc.discord": "Discord",
    "com.apple.mail": "Apple Mail",
    "com.microsoft.outlook": "Outlook",
}

app_ids_str = ", ".join(f"'{app}'" for app in WATCHED_APPS.keys())

conn = sqlite3.connect(f"file:{NOTIFICATION_DB}?mode=ro", uri=True)
cursor = conn.cursor()

cursor.execute(f"""
    SELECT r.rec_id, a.identifier, r.data, r.delivered_date
    FROM record r
    JOIN app a ON r.app_id = a.app_id
    WHERE a.identifier IN ({app_ids_str})
    ORDER BY r.rec_id DESC
    LIMIT 10
""")

rows = cursor.fetchall()
conn.close()

if not rows:
    print("No messaging notifications found.")
else:
    print(f"Last {len(rows)} messaging notifications:\n")
    for rec_id, app_id, data, delivered_date in reversed(rows):
        app_name = WATCHED_APPS.get(app_id, app_id)
        try:
            plist = plistlib.loads(data)
            req = plist.get("req", {})
            body = req.get("body", "(no body)")
            title = req.get("titl", "(no title)")
            subtitle = req.get("subt", "")
        except Exception:
            body = "(decode error)"
            title = "(decode error)"
            subtitle = ""

        if delivered_date:
            unix_ts = delivered_date + 978307200
            ts = datetime.fromtimestamp(unix_ts).strftime("%Y-%m-%d %H:%M:%S")
        else:
            ts = "?"

        sub = f" [{subtitle}]" if subtitle else ""
        print(f"  [{ts}] {app_name}{sub} - {title}: {body[:100]}")
