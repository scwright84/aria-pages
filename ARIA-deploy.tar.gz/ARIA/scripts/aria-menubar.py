#!/usr/bin/env python3
"""
ARIA Menu Bar App
Persistent macOS menu bar icon showing system health, data counts,
and quick access to dashboard, setup, and sync.

Uses rumps (Ridiculously Uncomplicated macOS Python Statusbar apps).
Polls health state every 60 seconds.
"""

import json
import os
import subprocess
import webbrowser
from datetime import datetime
from pathlib import Path

import rumps

PROJECT_DIR = Path(__file__).parent.parent
ASSETS_DIR = PROJECT_DIR / "assets"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
CREDENTIALS_FILE = PROJECT_DIR / "config" / "credentials.json"
HEALTH_STATE_FILE = PROJECT_DIR / "logs" / "health-check-state.json"
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
VENV_PYTHON = PROJECT_DIR / ".venv" / "bin" / "python3"

# Full paths for subprocess (launchd doesn't have PATH)
DOCKER_PATH = "/usr/local/bin/docker"
if not os.path.exists(DOCKER_PATH):
    DOCKER_PATH = "/opt/homebrew/bin/docker"


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def count_inbox_items(source):
    date_str = datetime.now().strftime("%Y-%m-%d")
    path = INBOX_DIR / f"{source}-{date_str}.json"
    if path.exists():
        try:
            with open(path) as f:
                data = json.load(f)
            return len(data) if isinstance(data, list) else 0
        except Exception:
            return 0
    return 0


def get_health():
    if HEALTH_STATE_FILE.exists():
        try:
            with open(HEALTH_STATE_FILE) as f:
                state = json.load(f)
            alerts = state.get("last_alerts", {})
            if alerts:
                return "warning", list(alerts.keys())
            return "healthy", []
        except Exception:
            pass
    return "unknown", []


def has_briefing_today():
    date_str = datetime.now().strftime("%Y-%m-%d")
    return (BRIEFINGS_DIR / f"{date_str}.html").exists()


def count_accounts():
    if CREDENTIALS_FILE.exists():
        try:
            with open(CREDENTIALS_FILE) as f:
                return len(json.load(f).get("accounts", []))
        except Exception:
            pass
    return 0


class ARIAMenuBar(rumps.App):
    def __init__(self):
        super().__init__("ARIA", icon=str(ASSETS_DIR / "icon-gray.png"), template=False)

        config = load_config()
        client_name = config.get("client", {}).get("name", "ARIA")

        # Build menu
        self.status_item = rumps.MenuItem("Checking status...")
        self.email_item = rumps.MenuItem("Emails: ...")
        self.calendar_item = rumps.MenuItem("Calendar: ...")
        self.briefing_item = rumps.MenuItem("Briefing: ...")
        self.accounts_item = rumps.MenuItem("Accounts: ...")

        self.menu = [
            self.status_item,
            None,
            self.email_item,
            self.calendar_item,
            self.briefing_item,
            self.accounts_item,
            None,
            rumps.MenuItem("Open Dashboard", callback=self.open_dashboard),
            rumps.MenuItem("Open Setup", callback=self.open_setup),
            None,
            rumps.MenuItem("Sync Email Now", callback=self.sync_email),
            rumps.MenuItem("Sync Calendar Now", callback=self.sync_calendar),
            rumps.MenuItem("Generate Briefing Now", callback=self.gen_briefing),
            None,
            rumps.MenuItem("Run Health Check", callback=self.run_health),
        ]

        # Initial refresh
        self.refresh(None)

        # Poll every 60 seconds
        self.timer = rumps.Timer(self.refresh, 60)
        self.timer.start()

    def refresh(self, _):
        """Update all menu items and status icon."""
        try:
            # Health status
            status, issues = get_health()
            if status == "healthy":
                self.icon = str(ASSETS_DIR / "icon-green.png")
                self.status_item.title = "All Systems Healthy"
            elif status == "warning":
                self.icon = str(ASSETS_DIR / "icon-yellow.png")
                self.status_item.title = f"Issues: {', '.join(issues)}"
            else:
                self.icon = str(ASSETS_DIR / "icon-gray.png")
                self.status_item.title = "Status Unknown"

            # Counts
            emails = count_inbox_items("emails")
            calendar = count_inbox_items("calendar")
            accounts = count_accounts()
            briefing = has_briefing_today()

            self.email_item.title = f"Emails Today: {emails}"
            self.calendar_item.title = f"Calendar Events: {calendar}"
            self.briefing_item.title = f"Briefing: {'Ready' if briefing else 'Not yet'}"
            self.accounts_item.title = f"Connected Accounts: {accounts}"

        except Exception as e:
            self.icon = str(ASSETS_DIR / "icon-red.png")
            self.status_item.title = f"Error: {e}"

    def open_dashboard(self, _):
        webbrowser.open("http://localhost:8642")

    def open_setup(self, _):
        webbrowser.open("http://localhost:8642/integrations")

    def sync_email(self, _):
        subprocess.Popen(
            [str(VENV_PYTHON), str(PROJECT_DIR / "scripts" / "email-sync.py")],
            cwd=str(PROJECT_DIR),
        )
        rumps.notification("ARIA", "", "Email sync started")

    def sync_calendar(self, _):
        subprocess.Popen(
            [str(VENV_PYTHON), str(PROJECT_DIR / "scripts" / "calendar-sync.py")],
            cwd=str(PROJECT_DIR),
        )
        rumps.notification("ARIA", "", "Calendar sync started")

    def gen_briefing(self, _):
        subprocess.Popen(
            [str(VENV_PYTHON), str(PROJECT_DIR / "scripts" / "generate-briefing.py")],
            cwd=str(PROJECT_DIR),
        )
        rumps.notification("ARIA", "", "Generating briefing...")

    def run_health(self, _):
        subprocess.Popen(
            [str(VENV_PYTHON), str(PROJECT_DIR / "scripts" / "health-check.py")],
            cwd=str(PROJECT_DIR),
        )
        rumps.notification("ARIA", "", "Health check running")
        # Refresh after a delay to pick up results
        rumps.Timer(self.refresh, 5).start()


if __name__ == "__main__":
    ARIAMenuBar().run()
