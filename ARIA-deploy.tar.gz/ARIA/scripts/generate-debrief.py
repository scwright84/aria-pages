#!/usr/bin/env python3
"""
ARIA End-of-Day Debrief Generator
Backward-looking companion to morning briefing. What happened today,
what got done, what slipped. Compares morning action items against Notion task state.

Runs at 9:30pm via launchd, or manually anytime.
"""

import json
import os
import sys
import re
import requests
from datetime import datetime, timedelta
from pathlib import Path

import aria_ai

PROJECT_DIR = Path(__file__).parent.parent
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
INBOX_DIR = PROJECT_DIR / "inbox"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
LOG_FILE = PROJECT_DIR / "logs" / "debrief.log"


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def collect_morning_briefing():
    """Load today's morning briefing data for comparison."""
    date_str = datetime.now().strftime("%Y-%m-%d")
    path = BRIEFINGS_DIR / f"{date_str}.json"
    if path.exists():
        try:
            with open(path) as f:
                return json.load(f)
        except Exception:
            pass
    return None


def collect_notion_tasks():
    """Get current task state from Notion."""
    try:
        resp = requests.post(
            "http://localhost:5678/webhook/aria-query-tasks",
            json={},
            timeout=15,
        )
        if resp.status_code == 200:
            return resp.json().get("tasks", [])
        return []
    except Exception as e:
        log(f"Error querying Notion: {e}")
        return []


def collect_inbox_data(source, date_str=None):
    """Collect inbox data for a specific source."""
    if date_str is None:
        date_str = datetime.now().strftime("%Y-%m-%d")
    path = INBOX_DIR / f"{source}-{date_str}.json"
    if path.exists():
        try:
            with open(path) as f:
                data = json.load(f)
            return data if isinstance(data, list) else []
        except Exception:
            pass
    return []


def collect_notifications():
    """Get today's triaged notifications from inbox."""
    return collect_inbox_data("notifications")


def call_ai(system_prompt, user_content):
    """Call AI inference and return the response content."""
    result = aria_ai.chat(system_prompt, user_content, timeout=180)
    if result is None:
        log("AI inference call failed")
    return result


def generate_debrief_html(date_str, sections, notion_tasks=None):
    """Generate the evening debrief HTML."""
    today = datetime.now().strftime("%A, %B %d, %Y")
    notion_tasks = notion_tasks or []

    # Day summary
    summary_html = sections.get("day_summary", "No activity to report.")

    # Completed items
    completed_html = ""
    for item in sections.get("completed", []):
        completed_html += f"""
        <div style="padding:8px 12px;margin-bottom:4px;background:#F0FDF4;border-radius:6px;border-left:3px solid #10B981;">
            <div style="font-size:14px;color:#111827;">{item.get('description', '')}</div>
            <div style="font-size:12px;color:#6B7280;">{item.get('project', '')} {('&middot; ' + item.get('source', '')) if item.get('source') else ''}</div>
        </div>"""

    # Still open / slipped
    slipped_html = ""
    for item in sections.get("slipped", []):
        priority_color = {"high": "#DC2626", "medium": "#D97706", "low": "#059669"}.get(item.get("priority", "medium"), "#6B7280")
        slipped_html += f"""
        <div style="padding:8px 12px;margin-bottom:4px;background:#FEF2F2;border-radius:6px;border-left:3px solid {priority_color};">
            <div style="font-size:14px;color:#111827;">{item.get('description', '')}</div>
            <div style="font-size:12px;color:#6B7280;">{item.get('project', '')} &middot; {item.get('reason', 'Not addressed')}</div>
        </div>"""

    # Key interactions
    interactions_html = ""
    for item in sections.get("key_interactions", []):
        interactions_html += f"""
        <div style="padding:8px 12px;margin-bottom:4px;background:#F9FAFB;border-radius:6px;border-left:3px solid #6366F1;">
            <div style="font-size:14px;color:#111827;">{item.get('person', '')} &middot; {item.get('channel', '')}</div>
            <div style="font-size:13px;color:#6B7280;">{item.get('summary', '')}</div>
        </div>"""

    # Tomorrow preview
    tomorrow_html = ""
    for item in sections.get("tomorrow_preview", []):
        tomorrow_html += f"""
        <div style="padding:8px 12px;margin-bottom:4px;background:#EFF6FF;border-radius:6px;border-left:3px solid #3B82F6;">
            <div style="font-size:14px;color:#111827;">{item.get('description', '')}</div>
            <div style="font-size:12px;color:#6B7280;">{item.get('time', '')} {('&middot; ' + item.get('context', '')) if item.get('context') else ''}</div>
        </div>"""

    # Notion task status
    tasks_html = ""
    if notion_tasks:
        overdue = [t for t in notion_tasks if t.get("overdue")]
        if overdue:
            tasks_html += f'<div style="font-size:13px;font-weight:600;color:#DC2626;margin-bottom:6px;">{len(overdue)} OVERDUE TASKS</div>'
            for t in overdue[:5]:
                tasks_html += f"""<div style="padding:6px 12px;margin-bottom:3px;background:#FEF2F2;border-radius:6px;border-left:3px solid #DC2626;">
                    <div style="font-size:14px;color:#111827;">{t['task']}</div>
                    <div style="font-size:12px;color:#6B7280;">{t['project']} &middot; Due {t['due']}</div>
                </div>"""

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<title>ARIA Debrief - {date_str}</title>
</head>
<body style="margin:0;padding:0;background:#F3F4F6;font-family:Poppins,Helvetica,Arial,sans-serif;">
<div style="max-width:680px;margin:0 auto;padding:20px;">

<!-- Header -->
<div style="background:linear-gradient(135deg, #6366F1 0%, #4338CA 100%);border-radius:12px;padding:24px 28px;margin-bottom:20px;">
    <h1 style="margin:0;color:white;font-size:22px;font-weight:700;">ARIA Evening Debrief</h1>
    <p style="margin:4px 0 0;color:rgba(255,255,255,0.85);font-size:14px;">{today}</p>
    <p style="margin:2px 0 0;color:rgba(255,255,255,0.7);font-size:12px;">Reply to ask ARIA anything about today</p>
</div>

<!-- Day Summary -->
<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 10px;font-size:16px;color:#111827;">Day in Review</h2>
    <p style="margin:0;font-size:14px;color:#374151;line-height:1.6;">{summary_html}</p>
</div>

<!-- Completed -->
{f'''<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 12px;font-size:16px;color:#111827;">What Got Done</h2>
    {completed_html}
</div>''' if completed_html else ''}

<!-- Slipped -->
{f'''<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 12px;font-size:16px;color:#111827;">Still Open</h2>
    {slipped_html}
</div>''' if slipped_html else ''}

<!-- Key Interactions -->
{f'''<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 12px;font-size:16px;color:#111827;">Key Interactions</h2>
    {interactions_html}
</div>''' if interactions_html else ''}

<!-- Overdue Tasks -->
{f'''<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 12px;font-size:16px;color:#111827;">Task Status</h2>
    {tasks_html}
</div>''' if tasks_html else ''}

<!-- Tomorrow Preview -->
{f'''<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 12px;font-size:16px;color:#111827;">Tomorrow Preview</h2>
    {tomorrow_html}
</div>''' if tomorrow_html else ''}

<!-- Footer -->
<div style="text-align:center;padding:16px;color:#9CA3AF;font-size:12px;">
    ARIA &middot; Automated Routing &amp; Intelligence Assistant<br>
    Generated {datetime.now().strftime("%I:%M %p")} &middot; End-of-day debrief
</div>

</div>
</body>
</html>"""
    return html


def main():
    log("Generating evening debrief...")
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)

    date_str = datetime.now().strftime("%Y-%m-%d")

    # Collect today's data
    log("Loading morning briefing...")
    morning = collect_morning_briefing()
    morning_actions = []
    if morning and "sections" in morning:
        morning_actions = morning["sections"].get("action_items", [])
    log(f"  {len(morning_actions)} morning action items to track")

    log("Collecting today's emails...")
    emails = collect_inbox_data("emails")
    log(f"  {len(emails)} emails")

    log("Collecting today's Slack...")
    slack = collect_inbox_data("slack")
    log(f"  {len(slack)} channels")

    log("Collecting today's notifications...")
    notifications = collect_inbox_data("notifications")
    log(f"  {len(notifications)} notifications")

    log("Collecting today's calendar...")
    calendar = collect_inbox_data("calendar")
    calendly = collect_inbox_data("calendly")
    all_events = calendar + calendly
    log(f"  {len(all_events)} events")

    log("Collecting Notion tasks...")
    notion_tasks = collect_notion_tasks()
    log(f"  {len(notion_tasks)} open tasks")

    # Collect tomorrow's events for preview
    tomorrow_str = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
    tomorrow_calendar = collect_inbox_data("calendar", tomorrow_str)
    tomorrow_calendly = collect_inbox_data("calendly", tomorrow_str)
    tomorrow_events = tomorrow_calendar + tomorrow_calendly
    # Also check today's file for tomorrow's events
    for ev in all_events:
        if ev.get("start_time", "")[:10] == tomorrow_str or ev.get("date_local", "").endswith(tomorrow_str):
            if ev not in tomorrow_events:
                tomorrow_events.append(ev)

    # Build context for Ollama
    context_parts = []

    if morning_actions:
        context_parts.append("=== MORNING ACTION ITEMS (from today's briefing) ===")
        for item in morning_actions:
            context_parts.append(f"[{item.get('priority', 'medium')}] {item.get('project', '')}: {item.get('description', '')} (from {item.get('from', '')})")

    if emails:
        context_parts.append("\n=== EMAILS TODAY ===")
        for e in emails:
            context_parts.append(f"[{e.get('account', '')}] {e.get('from', '')}: {e.get('subject', '')} | {e.get('action_type', 'fyi')} | {e.get('summary', '')}")

    if slack:
        context_parts.append("\n=== SLACK TODAY ===")
        for ch in slack:
            context_parts.append(f"#{ch.get('channel_name', '')}: {ch.get('summary', '')}")

    if notifications:
        context_parts.append("\n=== NOTIFICATIONS TODAY ===")
        for n in notifications[:30]:
            context_parts.append(f"[{n.get('app', n.get('app_name', ''))}] {n.get('sender', '')}: {n.get('summary', n.get('body', '')[:100])}")

    today_events = [e for e in all_events if e.get("start_time", "")[:10] == date_str]
    if today_events:
        context_parts.append("\n=== MEETINGS TODAY ===")
        for ev in today_events:
            context_parts.append(f"{ev.get('start_local', '?')}: {ev.get('name', ev.get('title', 'Meeting'))} with {ev.get('invitee_names', ev.get('attendees', ''))}")

    if notion_tasks:
        overdue = [t for t in notion_tasks if t.get("overdue")]
        context_parts.append(f"\n=== NOTION TASKS ({len(notion_tasks)} open, {len(overdue)} overdue) ===")
        for t in overdue:
            context_parts.append(f"  OVERDUE: [{t['project']}] {t['task']} (due {t['due']})")

    if tomorrow_events:
        context_parts.append("\n=== TOMORROW'S SCHEDULE ===")
        for ev in tomorrow_events:
            context_parts.append(f"{ev.get('start_local', '?')}: {ev.get('name', ev.get('title', 'Meeting'))} with {ev.get('invitee_names', ev.get('attendees', ''))}")

    if not context_parts:
        log("No data to report. Skipping debrief.")
        return

    full_context = "\n".join(context_parts)

    log("Analyzing with AI...")
    full_config = aria_ai.get_full_config()
    client_name = full_config.get("client", {}).get("contact_name", "the user")
    projects = full_config.get("projects", full_config.get("known_projects", []))
    projects_str = ", ".join(projects) if projects else "all tracked projects"

    system_prompt = f"""You are ARIA, an executive assistant AI. Generate an end-of-day debrief for {client_name} from today's activity.

Compare the morning's action items against what actually happened (emails sent, meetings held, tasks completed). Identify what got done and what slipped.

Respond with ONLY a valid JSON object. No markdown, no code blocks, no thinking tags.

JSON format:
{{
  "day_summary": "3-5 sentence overview of the day: what happened, what was productive, what needs attention",
  "completed": [
    {{"description": "what was done", "project": "project name", "source": "how we know (email/meeting/task)"}}
  ],
  "slipped": [
    {{"description": "what didn't get done", "project": "project name", "priority": "high/medium/low", "reason": "why or unknown"}}
  ],
  "key_interactions": [
    {{"person": "name", "channel": "email/slack/meeting", "summary": "what was discussed"}}
  ],
  "tomorrow_preview": [
    {{"description": "meeting or task", "time": "time if known", "context": "what to prep for"}}
  ]
}}

Known projects: {projects_str}.
Be honest about what slipped. Don't fabricate completions. If something from the morning list wasn't addressed, say so."""

    response = call_ai(system_prompt, full_context)

    if not response:
        log("AI inference failed. Generating fallback debrief.")
        sections = {
            "day_summary": f"ARIA tracked {len(emails)} emails, {len(notifications)} notifications, and {len(today_events)} meetings today but could not analyze the results.",
            "completed": [],
            "slipped": [{"description": a.get("description", ""), "project": a.get("project", ""), "priority": a.get("priority", "medium"), "reason": "Unable to verify"} for a in morning_actions],
            "key_interactions": [],
            "tomorrow_preview": [],
        }
    else:
        try:
            json_match = re.search(r'\{[\s\S]*\}', response)
            if json_match:
                sections = json.loads(json_match.group(0))
            else:
                raise ValueError("No JSON in response")
        except (json.JSONDecodeError, ValueError) as e:
            log(f"Failed to parse Ollama response: {e}")
            sections = {
                "day_summary": response[:500],
                "completed": [],
                "slipped": [],
                "key_interactions": [],
                "tomorrow_preview": [],
            }

    # Generate HTML
    log("Generating HTML...")
    html = generate_debrief_html(date_str, sections, notion_tasks=notion_tasks)

    # Save to file
    debrief_path = BRIEFINGS_DIR / f"{date_str}-debrief.html"
    with open(debrief_path, "w") as f:
        f.write(html)
    log(f"Saved to {debrief_path}")

    # Send debrief email (n8n first, SMTP fallback)
    import aria_email
    recipient = full_config.get("email", "")
    subject = f"ARIA Debrief - {datetime.now().strftime('%A %b %d')}"
    if recipient:
        log(f"Sending debrief email to {recipient}...")
        success, method = aria_email.send_briefing_email(recipient, subject, html)
        if success:
            log(f"Email sent via {method}")
        else:
            log("Email delivery failed (both n8n and SMTP)")
    else:
        log("No email address configured. Debrief saved to file only.")

    # Process any pending model action requests from briefing replies
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "process_model_actions",
            PROJECT_DIR / "scripts" / "process-model-actions.py"
        )
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        count = mod.process_actions()
        if count > 0:
            log(f"Processed {count} pending model actions")
    except Exception as e:
        log(f"Model action processing error: {e}")

    log("Debrief complete!")


if __name__ == "__main__":
    main()
