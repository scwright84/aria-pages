#!/usr/bin/env python3
"""
ARIA Smart Scheduling Assistant
Analyzes calendar patterns to identify optimal times for different work types.

Learns:
  - When you have meetings (clustering by day/time)
  - When you have deep work blocks (meeting-free stretches)
  - Energy patterns (morning vs afternoon meeting preference)
  - Meeting duration patterns (do you prefer short or long blocks?)
  - Day type patterns (which days are heavy, which are light?)

Recommends:
  - Best times for deep work
  - Best times for meetings
  - Days to protect from meetings
  - Schedule adjustments to improve flow

Output: briefings/YYYY-MM-DD-schedule-insights.json
Runs weekly or on demand.
"""

import json
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
LOG_FILE = PROJECT_DIR / "logs" / "schedule-optimizer.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_calendar(days_back=28):
    """Load 4 weeks of calendar data for pattern analysis."""
    events = []
    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        date_str = date.strftime("%Y-%m-%d")
        for prefix in ["calendar", "calendly"]:
            path = INBOX_DIR / f"{prefix}-{date_str}.json"
            if not path.exists():
                continue
            try:
                with open(path) as f:
                    data = json.load(f)
                for item in (data if isinstance(data, list) else [data]):
                    start_str = item.get("start") or item.get("start_time") or ""
                    end_str = item.get("end") or item.get("end_time") or ""
                    try:
                        start = datetime.fromisoformat(start_str.replace("Z", "+00:00")).replace(tzinfo=None)
                        end = datetime.fromisoformat(end_str.replace("Z", "+00:00")).replace(tzinfo=None)
                    except (ValueError, TypeError):
                        continue
                    duration = (end - start).total_seconds() / 60
                    if duration <= 0 or duration > 480:
                        continue
                    events.append({
                        "summary": item.get("summary") or item.get("name", ""),
                        "start": start,
                        "end": end,
                        "duration_min": duration,
                        "day": start.strftime("%A"),
                        "hour": start.hour,
                        "date": start.strftime("%Y-%m-%d"),
                    })
            except Exception:
                pass
    return events


def analyze_patterns(events):
    """Analyze scheduling patterns from calendar history."""
    if not events:
        return {"error": "No calendar data"}

    # Meeting hours by time of day
    hour_counts = Counter()
    for e in events:
        for h in range(e["start"].hour, min(e["end"].hour + 1, 24)):
            hour_counts[h] += 1

    # Meeting density by day of week
    day_counts = Counter(e["day"] for e in events)
    day_hours = defaultdict(float)
    for e in events:
        day_hours[e["day"]] += e["duration_min"] / 60

    # Identify clusters
    morning_meetings = sum(1 for e in events if 8 <= e["hour"] < 12)
    afternoon_meetings = sum(1 for e in events if 12 <= e["hour"] < 17)
    evening_meetings = sum(1 for e in events if e["hour"] >= 17)

    total = len(events)
    morning_pct = round(morning_meetings / total * 100) if total else 0
    afternoon_pct = round(afternoon_meetings / total * 100) if total else 0

    # Meeting-free blocks (potential deep work times)
    # Group events by date, find gaps
    by_date = defaultdict(list)
    for e in events:
        by_date[e["date"]].append(e)

    free_blocks = defaultdict(list)
    for date, day_events in by_date.items():
        sorted_events = sorted(day_events, key=lambda x: x["start"])
        day_name = sorted_events[0]["day"]

        # Check 8am-6pm for gaps
        prev_end = datetime.strptime(f"{date} 08:00", "%Y-%m-%d %H:%M")
        for e in sorted_events:
            gap = (e["start"] - prev_end).total_seconds() / 60
            if gap >= 60:  # At least 1 hour free
                free_blocks[day_name].append({
                    "start_hour": prev_end.hour,
                    "end_hour": e["start"].hour,
                    "duration_min": gap,
                })
            prev_end = max(prev_end, e["end"])

    # Duration preferences
    durations = [e["duration_min"] for e in events]
    avg_duration = sum(durations) / len(durations) if durations else 0

    # Day type classification
    day_types = {}
    days_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
    for day in days_order:
        hours = day_hours.get(day, 0)
        count = day_counts.get(day, 0)
        weeks_analyzed = max(1, len(set(e["date"] for e in events if e["day"] == day)))
        avg_hours = hours / weeks_analyzed
        avg_count = count / weeks_analyzed

        if avg_hours > 4:
            day_types[day] = "heavy"
        elif avg_hours > 2:
            day_types[day] = "moderate"
        elif avg_hours > 0:
            day_types[day] = "light"
        else:
            day_types[day] = "free"

    return {
        "period": f"last {len(set(e['date'] for e in events))} days with meetings",
        "total_meetings": total,
        "meeting_preference": {
            "morning_pct": morning_pct,
            "afternoon_pct": afternoon_pct,
            "preference": "morning" if morning_pct > afternoon_pct + 15 else "afternoon" if afternoon_pct > morning_pct + 15 else "balanced",
        },
        "busiest_hours": dict(hour_counts.most_common(5)),
        "day_types": day_types,
        "day_meeting_hours": {d: round(h, 1) for d, h in day_hours.items()},
        "avg_meeting_duration_min": round(avg_duration),
        "typical_free_blocks": {day: blocks for day, blocks in free_blocks.items() if blocks},
    }


def generate_recommendations(patterns):
    """Generate actionable scheduling recommendations."""
    recs = []

    # Deep work time
    pref = patterns.get("meeting_preference", {}).get("preference", "balanced")
    if pref == "morning":
        recs.append({
            "type": "deep_work",
            "recommendation": "Your meetings cluster in the mornings. Protect afternoons for deep work.",
            "action": "Block 1-5pm on your calendar as 'Focus Time'",
        })
    elif pref == "afternoon":
        recs.append({
            "type": "deep_work",
            "recommendation": "Your meetings cluster in the afternoons. Mornings are your deep work window.",
            "action": "Block 8am-12pm on your calendar as 'Focus Time'",
        })
    else:
        recs.append({
            "type": "deep_work",
            "recommendation": "Meetings are spread throughout the day. Pick one consistent deep work block and protect it.",
            "action": "Consider 8-10am before meetings typically start",
        })

    # Day protection
    day_types = patterns.get("day_types", {})
    free_days = [d for d, t in day_types.items() if t in ("free", "light")]
    heavy_days = [d for d, t in day_types.items() if t == "heavy"]

    if free_days:
        recs.append({
            "type": "day_protection",
            "recommendation": f"{', '.join(free_days)} tend to be light. Keep them that way for focused project work.",
            "action": f"Decline non-essential meetings on {free_days[0]}",
        })

    if heavy_days:
        recs.append({
            "type": "meeting_consolidation",
            "recommendation": f"{', '.join(heavy_days)} are your heaviest meeting days. Consider batching meetings to these days to free up other days entirely.",
            "action": "When scheduling new meetings, prefer these days first",
        })

    # Duration
    avg = patterns.get("avg_meeting_duration_min", 60)
    if avg > 50:
        recs.append({
            "type": "duration",
            "recommendation": f"Your average meeting is {avg} minutes. Shorter defaults create buffer time.",
            "action": "Set calendar default to 25 or 50 minutes instead of 30/60",
        })

    return recs


def main():
    log("Starting schedule analysis")
    events = load_calendar(days_back=28)
    log(f"Loaded {len(events)} meetings from the last 4 weeks")

    patterns = analyze_patterns(events)
    recommendations = generate_recommendations(patterns)

    output = {
        "generated": datetime.now().isoformat(),
        "patterns": patterns,
        "recommendations": recommendations,
    }

    date_str = datetime.now().strftime("%Y-%m-%d")
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    with open(BRIEFINGS_DIR / f"{date_str}-schedule-insights.json", "w") as f:
        json.dump(output, f, indent=2, default=str)

    log(f"Meeting preference: {patterns.get('meeting_preference', {}).get('preference', '?')}")
    log(f"Day types: {json.dumps(patterns.get('day_types', {}))}")
    log(f"Avg meeting: {patterns.get('avg_meeting_duration_min', '?')} min")
    for r in recommendations:
        log(f"  REC [{r['type']}]: {r['recommendation']}")
    log("Schedule analysis complete")


if __name__ == "__main__":
    main()
