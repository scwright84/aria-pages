#!/usr/bin/env python3
"""
ARIA Maintenance Script
Runs daily to clean up old data and rotate logs.

- Deletes inbox files older than retention period (default 30 days)
- Deletes briefing files older than retention period (default 14 days)
- Rotates log files (keeps last 7 days, compresses older)
- Reports disk usage

Runs daily via launchd at midnight, or manually.
"""

import json
import os
import gzip
import shutil
from datetime import datetime, timedelta
from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
LOG_DIR = PROJECT_DIR / "logs"
MAINTENANCE_LOG = LOG_DIR / "maintenance.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    MAINTENANCE_LOG.parent.mkdir(parents=True, exist_ok=True)
    with open(MAINTENANCE_LOG, "a") as f:
        f.write(line + "\n")


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def cleanup_dated_files(directory, max_days, extensions=None):
    """Delete files with YYYY-MM-DD in their name older than max_days."""
    if not directory.exists():
        return 0

    cutoff = datetime.now() - timedelta(days=max_days)
    deleted = 0

    for f in directory.iterdir():
        if not f.is_file():
            continue
        if extensions and f.suffix not in extensions:
            continue

        # Try to extract date from filename
        stem = f.stem
        for fmt in ["%Y-%m-%d", "%Y_%m_%d"]:
            try:
                # Handle filenames like "emails-2026-03-24" or "2026-03-24"
                date_part = stem[-10:] if len(stem) >= 10 else stem
                file_date = datetime.strptime(date_part, fmt)
                if file_date < cutoff:
                    f.unlink()
                    deleted += 1
                break
            except ValueError:
                continue

    return deleted


def rotate_logs(max_days=7):
    """Compress log files older than max_days, delete compressed files older than 30 days."""
    if not LOG_DIR.exists():
        return 0, 0

    cutoff_compress = datetime.now() - timedelta(days=max_days)
    cutoff_delete = datetime.now() - timedelta(days=30)
    compressed = 0
    deleted = 0

    for f in LOG_DIR.iterdir():
        if not f.is_file():
            continue

        # Delete old compressed logs
        if f.suffix == ".gz":
            if f.stat().st_mtime < cutoff_delete.timestamp():
                f.unlink()
                deleted += 1
            continue

        # Skip state files and the maintenance log itself
        if f.suffix == ".json" or f.name == "maintenance.log":
            continue

        # Compress old log files
        if f.suffix == ".log" and f.stat().st_mtime < cutoff_compress.timestamp():
            gz_path = f.with_suffix(f".log.{datetime.fromtimestamp(f.stat().st_mtime).strftime('%Y%m%d')}.gz")
            try:
                with open(f, "rb") as fin, gzip.open(gz_path, "wb") as fout:
                    shutil.copyfileobj(fin, fout)
                f.unlink()
                compressed += 1
            except Exception as e:
                log(f"  Error compressing {f.name}: {e}")

    return compressed, deleted


def get_disk_usage():
    """Get disk usage for ARIA directories."""
    usage = {}
    for name, path in [("inbox", INBOX_DIR), ("briefings", BRIEFINGS_DIR), ("logs", LOG_DIR)]:
        if path.exists():
            total = sum(f.stat().st_size for f in path.rglob("*") if f.is_file())
            count = sum(1 for f in path.rglob("*") if f.is_file())
            usage[name] = {"files": count, "size_mb": round(total / 1048576, 1)}
        else:
            usage[name] = {"files": 0, "size_mb": 0}
    return usage


def main():
    log("Starting maintenance...")
    config = load_config()
    retention = config.get("retention", {})
    inbox_days = retention.get("inbox_days", 30)
    briefing_days = retention.get("briefings_days", 14)

    # Clean inbox
    deleted = cleanup_dated_files(INBOX_DIR, inbox_days, extensions=[".json"])
    log(f"  Inbox: deleted {deleted} files older than {inbox_days} days")

    # Clean briefings
    deleted = cleanup_dated_files(BRIEFINGS_DIR, briefing_days, extensions=[".html", ".json"])
    log(f"  Briefings: deleted {deleted} files older than {briefing_days} days")

    # Rotate logs
    compressed, deleted = rotate_logs(max_days=7)
    log(f"  Logs: compressed {compressed}, deleted {deleted} old archives")

    # Report disk usage
    usage = get_disk_usage()
    total_mb = sum(u["size_mb"] for u in usage.values())
    log(f"  Disk usage: {total_mb:.1f}MB total")
    for name, u in usage.items():
        log(f"    {name}: {u['files']} files, {u['size_mb']:.1f}MB")

    log("Maintenance complete")


if __name__ == "__main__":
    main()
