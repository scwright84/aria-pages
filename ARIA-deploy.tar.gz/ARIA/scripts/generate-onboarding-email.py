#!/usr/bin/env python3
"""
ARIA Onboarding Email Generator
Creates a personalized welcome email for a new client with their
setup instructions, links, and Tailscale invite code.

Usage:
  python3 scripts/generate-onboarding-email.py \
    --name "Dr. Smith" \
    --email "drsmith@example.com" \
    --business "Lakeway Dental" \
    --tailscale-code "abc123" \
    --telegram-bot "@LakewayDentalBot"

Outputs: install/onboarding-emails/<business-slug>.html (ready to send)
"""

import argparse
import re
import sys
from datetime import datetime
from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent
OUTPUT_DIR = PROJECT_DIR / "install" / "onboarding-emails"


def slugify(text):
    return re.sub(r'[^a-z0-9]+', '-', text.lower()).strip('-')


def generate_email(name, email, business, tailscale_code, telegram_bot, admin_email="sean@wrightadvisorsatx.com"):
    first_name = name.split()[0] if name else "there"

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Welcome to ARIA - {business}</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #f4f4f5; margin: 0; padding: 20px; }}
  .email {{ max-width: 600px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }}
  .header {{ background: #0f172a; color: white; padding: 32px 24px; text-align: center; }}
  .header h1 {{ font-size: 24px; margin: 0 0 4px; }}
  .header p {{ font-size: 14px; color: #94a3b8; margin: 0; }}
  .body {{ padding: 24px; }}
  .body p {{ font-size: 15px; line-height: 1.7; color: #374151; margin-bottom: 16px; }}
  .body h2 {{ font-size: 17px; color: #111827; margin: 24px 0 12px; }}
  .cta {{ display: block; text-align: center; background: #3b82f6; color: white; padding: 14px 24px; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 16px; margin: 24px 0; }}
  .cta:hover {{ background: #2563eb; }}
  .code-box {{ background: #f0f9ff; border: 2px dashed #3b82f6; border-radius: 8px; padding: 16px; text-align: center; margin: 16px 0; }}
  .code-box .label {{ font-size: 12px; color: #6b7280; text-transform: uppercase; letter-spacing: 1px; }}
  .code-box .code {{ font-size: 24px; font-weight: 700; color: #1e40af; font-family: 'SF Mono', monospace; letter-spacing: 2px; margin-top: 4px; }}
  .steps {{ background: #f9fafb; border-radius: 8px; padding: 16px 20px; margin: 16px 0; }}
  .steps ol {{ margin: 0; padding-left: 20px; }}
  .steps li {{ font-size: 14px; color: #374151; line-height: 1.8; margin-bottom: 4px; }}
  .steps li strong {{ color: #111827; }}
  .footer {{ background: #f9fafb; padding: 20px 24px; text-align: center; font-size: 12px; color: #9ca3af; border-top: 1px solid #e5e7eb; }}
  .footer a {{ color: #3b82f6; text-decoration: none; }}
  .note {{ background: #fffbeb; border-left: 3px solid #f59e0b; padding: 10px 14px; border-radius: 4px; font-size: 13px; color: #92400e; margin: 12px 0; }}
</style>
</head>
<body>
<div class="email">
  <div class="header">
    <h1>Welcome to ARIA</h1>
    <p>Your AI Operating System is ready to set up</p>
  </div>

  <div class="body">
    <p>Hi {first_name},</p>

    <p>Your ARIA system is ready to go. This email has everything you need to get started. The whole process takes about 15 minutes, and I'll be available remotely to help you through the tricky parts.</p>

    <h2>What You'll Need</h2>
    <div class="steps">
      <ol>
        <li>Your new Mac (plugged in and connected to WiFi)</li>
        <li>Your Gmail password (to connect your email)</li>
        <li>About 15 minutes of uninterrupted time</li>
      </ol>
    </div>

    <h2>Let's Get Started</h2>
    <p>Click the button below to open the setup guide. It walks you through everything step by step with big, clear instructions.</p>

    <a class="cta" href="https://wrightadvisors.com/aria/onboarding?client={slugify(business)}">Open Setup Guide</a>

    <p>The guide will walk you through downloading and running the installer. When you get to Step 3, you'll need this code to connect for remote support:</p>

    <div class="code-box">
      <div class="label">Your Tailscale Invite Code</div>
      <div class="code">{tailscale_code}</div>
    </div>

    <div class="note">This code connects your Mac to a secure, encrypted channel so I can help you finish the setup remotely. I can see your screen but I cannot control it without your permission.</div>

    <h2>What Happens After Setup</h2>
    <div class="steps">
      <ol>
        <li><strong>Tomorrow morning</strong> you'll get your first Presidential Brief by email: a summary of everything important from your inbox and calendar</li>
        <li><strong>Anytime</strong> you can message your Telegram bot ({telegram_bot}) to ask questions about your communications</li>
        <li><strong>Every evening</strong> you'll get a debrief comparing what you planned vs what happened</li>
        <li><strong>Your data never leaves your computer.</strong> The AI runs locally on your Mac.</li>
      </ol>
    </div>

    <h2>Need Help?</h2>
    <p>If you get stuck at any point, just reply to this email or text me. I can usually hop on within the hour to help you through it.</p>

    <p>Looking forward to getting you set up.</p>

    <p>Sean Wright<br>
    Wright Advisors<br>
    <a href="mailto:{admin_email}">{admin_email}</a></p>
  </div>

  <div class="footer">
    <p>Wright Advisors | ARIA AI Operating System</p>
    <p>Your data stays on your computer. <a href="https://wrightadvisors.com/aria/privacy">Privacy Policy</a></p>
  </div>
</div>
</body>
</html>"""
    return html


def main():
    parser = argparse.ArgumentParser(description="Generate ARIA onboarding email")
    parser.add_argument("--name", required=True, help="Client contact name")
    parser.add_argument("--email", required=True, help="Client email address")
    parser.add_argument("--business", required=True, help="Client business name")
    parser.add_argument("--tailscale-code", default="PENDING", help="Tailscale invite code")
    parser.add_argument("--telegram-bot", default="@ARIABot", help="Telegram bot username")
    args = parser.parse_args()

    html = generate_email(args.name, args.email, args.business, args.tailscale_code, args.telegram_bot)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    slug = slugify(args.business)
    output_path = OUTPUT_DIR / f"{slug}-welcome.html"
    with open(output_path, "w") as f:
        f.write(html)

    print(f"Onboarding email generated: {output_path}")
    print(f"  Client: {args.name} ({args.email})")
    print(f"  Business: {args.business}")
    print(f"  Tailscale code: {args.tailscale_code}")
    print(f"  Telegram bot: {args.telegram_bot}")
    print()
    print(f"Open in browser to preview, then copy/paste into email or send as HTML.")


if __name__ == "__main__":
    main()
