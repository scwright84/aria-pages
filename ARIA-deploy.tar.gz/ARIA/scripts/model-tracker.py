#!/usr/bin/env python3
"""
ARIA Model Intelligence Tracker
Scrapes fal.ai for new image/video AI models, compares against Pippa's current stack,
scores relevance with Ollama, and saves alerts to inbox/models-YYYY-MM-DD.json.

Runs daily via launchd or manually.
"""

import json
import re
import hashlib
import requests
from datetime import datetime
from pathlib import Path
from html import unescape

import aria_ai

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
CONFIG_DIR = PROJECT_DIR / "config"
LOG_FILE = PROJECT_DIR / "logs" / "model-tracker.log"
STATE_FILE = PROJECT_DIR / "logs" / "model-tracker-state.json"
FAL_MODELS_URL = "https://fal.ai/models"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_config():
    path = CONFIG_DIR / "model-tracker.json"
    if path.exists():
        with open(path) as f:
            return json.load(f)
    return {"sources": {}, "current_stack": {}, "scoring": {"min_relevance": 60}}


def load_state():
    if STATE_FILE.exists():
        try:
            with open(STATE_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"seen_models": [], "last_run": None}


def save_state(state):
    state["last_run"] = datetime.now().isoformat()
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def strip_html(text):
    text = re.sub(r'<[^>]+>', '', text)
    text = unescape(text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def scrape_fal_models():
    """Scrape fal.ai/models page for model listings."""
    models = []
    try:
        resp = requests.get(FAL_MODELS_URL, timeout=30, headers={
            "User-Agent": "ARIA/1.0 (Pippa Model Tracker)"
        })
        if resp.status_code != 200:
            log(f"  HTTP {resp.status_code} from {FAL_MODELS_URL}")
            return models

        html = resp.text

        # Extract model cards from the page
        # fal.ai uses Next.js with structured data in script tags
        # Look for model IDs in the format fal-ai/model-name
        model_ids = set(re.findall(r'fal-ai/[\w\-]+(?:/[\w\-\.]+)*', html))

        # Also try to find JSON data in script tags
        json_blocks = re.findall(r'<script[^>]*>({.*?})</script>', html, re.DOTALL)
        for block in json_blocks:
            try:
                data = json.loads(block)
                ids = re.findall(r'fal-ai/[\w\-]+(?:/[\w\-\.]+)*', json.dumps(data))
                model_ids.update(ids)
            except (json.JSONDecodeError, TypeError):
                pass

        # Categorize each model
        for model_id in sorted(model_ids):
            category = categorize_model(model_id)
            if category:
                models.append({
                    "model_id": model_id,
                    "source": "fal.ai",
                    "category": category,
                    "discovered_at": datetime.now().isoformat(),
                })

        log(f"  Found {len(models)} relevant models on fal.ai")

    except requests.exceptions.RequestException as e:
        log(f"  Request error from fal.ai: {e}")
    except Exception as e:
        log(f"  Unexpected error scraping fal.ai: {e}")

    return models


def categorize_model(model_id):
    """Categorize a model ID by its path components."""
    mid = model_id.lower()

    # Skip non-generation models
    skip_patterns = ["whisper", "transcri", "tts", "speech", "embedding",
                     "detect", "segment", "caption", "ocr", "classify",
                     "controlnet", "depth", "pose", "face-swap", "remove-bg",
                     "background", "document"]
    if any(p in mid for p in skip_patterns):
        return None

    if "lipsync" in mid or "lip-sync" in mid or "lip_sync" in mid:
        return "lip_sync"
    if "avatar" in mid or "digital-twin" in mid or "omnihuman" in mid:
        return "avatar"
    if "image-to-video" in mid or "i2v" in mid or "first-last-frame" in mid:
        return "image_to_video"
    if "text-to-video" in mid or "t2v" in mid:
        return "video_generation"
    if "/edit" in mid or "inpaint" in mid or "outpaint" in mid or "kontext" in mid:
        return "image_editing"
    if ("text-to-image" in mid or "generate" in mid or
        any(gen in mid for gen in ["flux", "stable-diffusion", "sdxl", "dall-e",
                                     "midjourney", "ideogram", "recraft",
                                     "nano-banana", "seedream", "qwen-image",
                                     "kling-image"])):
        return "image_generation"
    if any(vid in mid for vid in ["kling-video", "minimax", "hailuo", "ltx",
                                    "sora", "runway", "pika", "luma", "veo",
                                    "pixverse", "cosmos", "wan/", "lucy"]):
        return "video_generation"

    return None


def get_current_model_ids(config):
    """Extract all model IDs currently used in Pippa."""
    ids = set()
    stack = config.get("current_stack", {})
    for category_data in stack.values():
        if isinstance(category_data, dict):
            if "primary" in category_data:
                ids.add(category_data["primary"])
            if "fallback" in category_data:
                ids.add(category_data["fallback"])
            for m in category_data.get("also_using", []):
                ids.add(m)
    return ids


def score_with_ollama(new_models, current_stack):
    """Score new models for Pippa relevance using Ollama."""
    if not new_models:
        return []

    batch = new_models[:15]
    items_text = ""
    for i, model in enumerate(batch):
        items_text += f"\n[{i+1}] MODEL: {model['model_id']}\n"
        items_text += f"    CATEGORY: {model['category']}\n"

    current_text = json.dumps(current_stack, indent=2)

    system_prompt = """You are ARIA, evaluating new AI models for Pippa, an AI animation platform.

Pippa's current stack (via fal.ai):
""" + current_text + """

Score each new model for relevance to Pippa. Consider:
- Could it replace or improve on a current model? (quality, speed, cost)
- Does it enable new capabilities Pippa doesn't have yet?
- Is it from a reputable provider (Google, OpenAI, ByteDance, Kling, etc.)?
- Image generation and editing models: compare to Flux 2 Pro and Kontext
- Video models: compare to Kling v3 Pro and Hailuo Fast
- Lip sync models: compare to Kling lipsync

Respond with ONLY a valid JSON array. No markdown, no explanation.
Format: [{"item": 1, "score": 75, "why": "one sentence", "action": "evaluate" or "watch" or "skip"}, ...]

Score guide:
- 80+: Likely better than current stack. Test immediately.
- 60-79: Promising alternative. Worth evaluating when time permits.
- 40-59: Interesting but not clearly better. Watch for updates.
- <40: Not relevant or clearly inferior. Skip."""

    try:
        scores = aria_ai.chat_json(
            system_prompt,
            f"Score these {len(batch)} new models:{items_text}",
            fast=True
        )
        if scores and isinstance(scores, list):
            for score_entry in scores:
                idx = score_entry.get("item", 0) - 1
                if 0 <= idx < len(batch):
                    batch[idx]["score"] = score_entry.get("score", 0)
                    batch[idx]["score_reason"] = score_entry.get("why", "")
                    batch[idx]["action"] = score_entry.get("action", "watch")
            return batch
        else:
            log("  AI scoring returned no results")
    except Exception as e:
        log(f"  AI scoring failed: {e}")

    # Fallback: assign base scores by category relevance
    for model in batch:
        cat = model.get("category", "")
        if cat in ("image_to_video", "video_generation"):
            model["score"] = 65
        elif cat in ("image_editing", "image_generation"):
            model["score"] = 60
        elif cat in ("lip_sync", "avatar"):
            model["score"] = 70
        else:
            model["score"] = 50
        model["score_reason"] = "Scored by category (AI unavailable)"
        model["action"] = "watch"
    return batch


def main():
    log("Starting model intelligence tracker...")
    INBOX_DIR.mkdir(parents=True, exist_ok=True)

    config = load_config()
    state = load_state()
    seen = set(state.get("seen_models", []))
    current_ids = get_current_model_ids(config)
    scoring_config = config.get("scoring", {})
    min_score = scoring_config.get("min_relevance", 60)
    max_alerts = scoring_config.get("max_alerts_per_run", 5)

    # Scrape sources
    all_models = []

    if config.get("sources", {}).get("fal_ai", {}).get("enabled", True):
        log("Scraping fal.ai...")
        fal_models = scrape_fal_models()
        all_models.extend(fal_models)

    # Filter out already-seen and currently-used models
    new_models = []
    for model in all_models:
        mid = model["model_id"]
        if mid in seen:
            continue
        if mid in current_ids:
            continue
        new_models.append(model)

    log(f"Found {len(new_models)} new models (filtered from {len(all_models)} total)")

    if not new_models:
        log("No new models to evaluate.")
        save_state(state)
        return

    # Score in batches of 15
    scored = []
    for i in range(0, len(new_models), 15):
        batch = new_models[i:i+15]
        scored_batch = score_with_ollama(batch, config.get("current_stack", {}))
        scored.extend(scored_batch)

    # Filter and sort
    passing = [m for m in scored if m.get("score", 0) >= min_score]
    passing.sort(key=lambda x: x.get("score", 0), reverse=True)
    final = passing[:max_alerts]

    log(f"Scored: {len(passing)} passed threshold, {len(final)} alerts generated")

    # Mark all discovered models as seen
    for model in all_models:
        seen.add(model["model_id"])
    state["seen_models"] = list(seen)
    save_state(state)

    if not final:
        log("No models passed scoring threshold.")
        return

    # Save to inbox
    today = datetime.now().strftime("%Y-%m-%d")
    models_path = INBOX_DIR / f"models-{today}.json"

    existing = []
    if models_path.exists():
        try:
            with open(models_path) as f:
                existing = json.load(f)
        except Exception:
            existing = []

    existing_ids = {e.get("model_id", "") for e in existing}
    for model in final:
        if model["model_id"] not in existing_ids:
            existing.append({
                "source": "model_tracker",
                "model_id": model["model_id"],
                "provider": "fal.ai",
                "category": model["category"],
                "score": model.get("score", 0),
                "score_reason": model.get("score_reason", ""),
                "action": model.get("action", "watch"),
                "discovered_at": model.get("discovered_at", datetime.now().isoformat()),
            })

    with open(models_path, "w") as f:
        json.dump(existing, f, indent=2)
    log(f"Saved {len(final)} model alerts to {models_path}")

    log("Model tracker complete!")


if __name__ == "__main__":
    main()
