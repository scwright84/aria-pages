#!/bin/bash
# Generate and send weekly rollup
# Runs Sunday at 7pm via launchd

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
VENV="$PROJECT_DIR/.venv/bin/python3"
LOG="$PROJECT_DIR/logs/weekly.log"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Weekly rollup generation starting" >> "$LOG"

"$VENV" "$SCRIPT_DIR/generate-weekly.py" >> "$LOG" 2>&1
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Weekly rollup generation complete" >> "$LOG"
