#!/usr/bin/env python3
"""
ARIA Demo Mode
Generates realistic sample data so Kelly can show prospects what ARIA
looks like without connecting real email/calendar.

Creates:
  - Sample emails (realistic dental practice scenarios)
  - Sample calendar events
  - Sample briefing (morning brief with real-looking data)
  - Sample scorecard
  - Sample task list
  - Sample contacts

Usage:
  python3 scripts/demo-mode.py --enable     # Generate demo data and switch to demo mode
  python3 scripts/demo-mode.py --disable    # Remove demo data and switch back to live
  python3 scripts/demo-mode.py --generate   # Regenerate demo data without switching

Demo data goes to inbox/demo-* and briefings/demo-*
Config flag: aria.json > "demo_mode": true
"""

import json
import sys
from datetime import datetime, timedelta
from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
CONFIG_DIR = PROJECT_DIR / "config"
LOG_FILE = PROJECT_DIR / "logs" / "demo-mode.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def generate_demo_emails():
    """Generate realistic dental practice emails."""
    today = datetime.now()
    return [
        {
            "source": "gmail", "account": "drsmith@lakewaydentalcare.com",
            "from": "Sarah Johnson <sarah@dentalinsuranceco.com>",
            "subject": "Claim #4521 - Pre-authorization needed for crown",
            "date": (today - timedelta(hours=2)).isoformat(),
            "snippet": "Dr. Smith, we need additional documentation for the crown procedure on patient Rodriguez. Please submit the periapical x-ray and treatment plan.",
            "summary": "Insurance company requesting additional documentation for a crown pre-authorization. Need x-ray and treatment plan submitted.",
            "detected_project": "Insurance",
            "priority": "high", "action_needed": True, "action_type": "respond",
            "processed_at": today.isoformat(),
        },
        {
            "source": "gmail", "account": "drsmith@lakewaydentalcare.com",
            "from": "Maria Chen <maria@happysmiles.org>",
            "subject": "Re: Partnership for community dental health fair",
            "date": (today - timedelta(hours=4)).isoformat(),
            "snippet": "Dr. Smith, the community health fair is confirmed for April 15th. We'd love for your practice to set up a table for free consultations. Expecting 200+ families.",
            "summary": "Community health fair confirmed April 15. Free consultation table offered. 200+ families expected. Good marketing opportunity.",
            "detected_project": "Marketing",
            "priority": "normal", "action_needed": True, "action_type": "decide",
            "processed_at": today.isoformat(),
        },
        {
            "source": "gmail", "account": "drsmith@lakewaydentalcare.com",
            "from": "Dentrix Support <support@dentrix.com>",
            "subject": "Your Dentrix software update is ready",
            "date": (today - timedelta(hours=6)).isoformat(),
            "snippet": "A new update for Dentrix G7 is available. This update includes bug fixes and new insurance verification features.",
            "detected_project": "Operations",
            "priority": "low", "action_needed": False,
            "processed_at": today.isoformat(),
        },
        {
            "source": "gmail", "account": "drsmith@lakewaydentalcare.com",
            "from": "Jennifer Williams <jwilliams@gmail.com>",
            "subject": "Thank you so much!",
            "date": (today - timedelta(hours=8)).isoformat(),
            "snippet": "Dr. Smith, I just wanted to send a quick note to thank you and your team for the amazing experience yesterday. My son was so nervous about his first visit and you made it so comfortable.",
            "summary": "Patient thank you note. Great experience with child's first visit. Positive review potential.",
            "detected_project": "Patient Relations",
            "priority": "normal", "action_needed": False,
            "processed_at": today.isoformat(),
        },
        {
            "source": "gmail", "account": "drsmith@lakewaydentalcare.com",
            "from": "Tom at Benco Dental <tom.r@benco.com>",
            "subject": "Your quarterly supply order - 15% discount this week",
            "date": (today - timedelta(hours=10)).isoformat(),
            "snippet": "Dr. Smith, your quarterly supply order is due. We're offering 15% off composite materials and impression kits through Friday. Want to schedule a call to review?",
            "detected_project": "Supplies",
            "priority": "normal", "action_needed": True, "action_type": "decide",
            "processed_at": today.isoformat(),
        },
        {
            "source": "gmail", "account": "drsmith@lakewaydentalcare.com",
            "from": "Lisa Park - Front Desk <lisa@lakewaydentalcare.com>",
            "subject": "3 cancellations tomorrow - should I try to fill?",
            "date": (today - timedelta(hours=1)).isoformat(),
            "snippet": "Dr. Smith, we have 3 cancellations for tomorrow afternoon (2pm, 3pm, 4pm). Should I call the waitlist patients to try to fill them? Also, Mrs. Henderson wants to reschedule her implant consult to next week.",
            "summary": "3 afternoon cancellations tomorrow. Front desk asking whether to fill from waitlist. Also a reschedule request for implant consult.",
            "detected_project": "Scheduling",
            "priority": "urgent", "action_needed": True, "action_type": "respond",
            "processed_at": today.isoformat(),
        },
    ]


def generate_demo_calendar():
    """Generate realistic dental practice calendar."""
    today = datetime.now().replace(hour=0, minute=0, second=0)
    return [
        {
            "summary": "Morning Huddle - Team Standup",
            "start": (today + timedelta(hours=8)).isoformat(),
            "end": (today + timedelta(hours=8, minutes=15)).isoformat(),
            "attendees": [{"name": "Lisa Park"}, {"name": "Dr. Smith"}, {"name": "Katie RDH"}],
        },
        {
            "summary": "Patient: Rodriguez - Crown Prep",
            "start": (today + timedelta(hours=9)).isoformat(),
            "end": (today + timedelta(hours=10)).isoformat(),
            "attendees": [],
        },
        {
            "summary": "Lunch & Learn: New Composite Materials",
            "start": (today + timedelta(hours=12)).isoformat(),
            "end": (today + timedelta(hours=13)).isoformat(),
            "attendees": [{"name": "Tom from Benco"}, {"name": "Full team"}],
        },
        {
            "summary": "Accountant Call - Q1 Review",
            "start": (today + timedelta(hours=17)).isoformat(),
            "end": (today + timedelta(hours=17, minutes=30)).isoformat(),
            "attendees": [{"name": "David Chen CPA"}],
        },
    ]


def generate_demo_briefing():
    """Generate a realistic morning briefing."""
    today = datetime.now()
    return {
        "date": today.strftime("%Y-%m-%d"),
        "sections": {
            "bluf": "6 emails overnight, 2 need your response before 9am. 3 cancellations tomorrow afternoon need a decision. Insurance pre-auth pending for Rodriguez crown. Community health fair opportunity on the table.",
            "decisions_needed": [
                {"decision": "Fill tomorrow's 3 cancellation slots from waitlist?", "deadline": "Today before 5pm", "context": "Lisa can call waitlist patients but needs your OK", "so_what": "Empty slots = lost revenue (~$1,200)"},
                {"decision": "Participate in community health fair April 15?", "deadline": "This week", "context": "Free table, 200+ families expected. Good visibility.", "so_what": "Low cost marketing, potential 5-10 new patient leads"},
                {"decision": "Take Benco's 15% supply discount?", "deadline": "Friday", "context": "Quarterly order due anyway. 15% off composites and impressions.", "so_what": "~$400 savings if ordered this week vs next month"},
            ],
            "todays_schedule": [
                "8:00 AM - Morning huddle (15 min)",
                "9:00 AM - Rodriguez crown prep (1 hr)",
                "12:00 PM - Lunch & Learn: New composite materials with Benco rep",
                "5:00 PM - Accountant call: Q1 review",
            ],
            "commitments_you_owe": [
                "Submit periapical x-ray for Rodriguez insurance claim",
                "Review Lisa's updated patient intake forms (promised Monday)",
            ],
            "waiting_on_others": [
                "Lab: Rodriguez temporary crown (due Thursday)",
                "Insurance: Pre-auth response for Henderson implant",
            ],
            "project_pulse": [
                "Insurance: 1 pending claim, 1 pre-auth needed",
                "Scheduling: 3 cancellations to fill, 1 reschedule request",
                "Patient Relations: Positive thank-you note (review opportunity)",
                "Marketing: Health fair opportunity pending decision",
            ],
        }
    }


def generate_demo_scorecard():
    """Generate realistic engagement scorecard."""
    return {
        "Insurance": {
            "project": "Insurance", "tier": "active", "email_count": 8,
            "trend": "up", "health_grade": "B", "health_score": 75,
            "health_flags": ["2 pending claims need follow-up"],
            "actions_needed": 2, "commitments_total": 1, "commitments_overdue": 0,
        },
        "Scheduling": {
            "project": "Scheduling", "tier": "active", "email_count": 12,
            "trend": "flat", "health_grade": "A", "health_score": 90,
            "health_flags": [],
            "actions_needed": 1, "commitments_total": 0, "commitments_overdue": 0,
        },
        "Patient Relations": {
            "project": "Patient Relations", "tier": "active", "email_count": 5,
            "trend": "up", "health_grade": "A", "health_score": 95,
            "health_flags": [],
            "actions_needed": 0, "commitments_total": 0, "commitments_overdue": 0,
        },
        "Marketing": {
            "project": "Marketing", "tier": "active", "email_count": 3,
            "trend": "new", "health_grade": "B", "health_score": 70,
            "health_flags": ["Health fair decision pending"],
            "actions_needed": 1, "commitments_total": 0, "commitments_overdue": 0,
        },
        "Supplies": {
            "project": "Supplies", "tier": "active", "email_count": 2,
            "trend": "flat", "health_grade": "A", "health_score": 85,
            "health_flags": [],
            "actions_needed": 1, "commitments_total": 0, "commitments_overdue": 0,
        },
    }


def generate_demo_tasks():
    """Generate realistic task list."""
    return {
        "tasks": [
            {"id": "demo-1", "source": "email", "action": "respond", "title": "Respond: Fill tomorrow's cancellation slots?", "project": "Scheduling", "priority": "urgent", "status": "open"},
            {"id": "demo-2", "source": "email", "action": "respond", "title": "Respond: Insurance pre-auth for Rodriguez crown", "project": "Insurance", "priority": "high", "status": "open"},
            {"id": "demo-3", "source": "email", "action": "decide", "title": "Decide: Community health fair participation", "project": "Marketing", "priority": "normal", "status": "open"},
            {"id": "demo-4", "source": "email", "action": "decide", "title": "Decide: Benco supply order (15% discount)", "project": "Supplies", "priority": "normal", "status": "open"},
            {"id": "demo-5", "source": "commitment", "action": "do", "title": "Submit Rodriguez x-ray to insurance", "project": "Insurance", "priority": "high", "status": "open"},
            {"id": "demo-6", "source": "commitment", "action": "do", "title": "Review updated patient intake forms", "project": "Operations", "priority": "normal", "status": "open"},
        ],
        "completed": [],
    }


def generate_demo_contacts():
    """Generate realistic contact profiles."""
    return {
        "lisa@lakewaydentalcare.com": {
            "name": "Lisa Park", "emails": ["lisa@lakewaydentalcare.com"],
            "projects": ["Scheduling", "Operations"], "email_count": 24,
            "relationship_score": 90, "relationship_label": "strong",
        },
        "sarah@dentalinsuranceco.com": {
            "name": "Sarah Johnson", "emails": ["sarah@dentalinsuranceco.com"],
            "projects": ["Insurance"], "email_count": 12,
            "relationship_score": 65, "relationship_label": "healthy",
        },
        "tom.r@benco.com": {
            "name": "Tom Rogers", "emails": ["tom.r@benco.com"],
            "projects": ["Supplies"], "email_count": 8,
            "relationship_score": 55, "relationship_label": "moderate",
        },
        "david.chen.cpa@gmail.com": {
            "name": "David Chen CPA", "emails": ["david.chen.cpa@gmail.com"],
            "projects": ["Finance"], "email_count": 4,
            "relationship_score": 60, "relationship_label": "healthy",
        },
    }


def enable_demo():
    """Enable demo mode: generate data and set config flag."""
    log("Enabling demo mode")
    date_str = datetime.now().strftime("%Y-%m-%d")

    INBOX_DIR.mkdir(parents=True, exist_ok=True)
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    # Generate all demo data
    with open(INBOX_DIR / f"emails-{date_str}.json", "w") as f:
        json.dump(generate_demo_emails(), f, indent=2, default=str)
    log("  Generated demo emails")

    with open(INBOX_DIR / f"calendar-{date_str}.json", "w") as f:
        json.dump(generate_demo_calendar(), f, indent=2, default=str)
    log("  Generated demo calendar")

    with open(BRIEFINGS_DIR / f"{date_str}.json", "w") as f:
        json.dump(generate_demo_briefing(), f, indent=2, default=str)
    log("  Generated demo briefing")

    with open(BRIEFINGS_DIR / f"{date_str}-scorecard.json", "w") as f:
        json.dump(generate_demo_scorecard(), f, indent=2, default=str)
    log("  Generated demo scorecard")

    with open(CONFIG_DIR / "tasks.json", "w") as f:
        json.dump(generate_demo_tasks(), f, indent=2, default=str)
    log("  Generated demo tasks")

    with open(CONFIG_DIR / "contacts.json", "w") as f:
        json.dump(generate_demo_contacts(), f, indent=2, default=str)
    log("  Generated demo contacts")

    # Set demo mode flag
    try:
        with open(CONFIG_FILE) as f:
            config = json.load(f)
        config["demo_mode"] = True
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)
        log("  Config: demo_mode = true")
    except Exception as e:
        log(f"  Warning: could not update config: {e}")

    log("Demo mode enabled. All dashboards now show sample dental practice data.")
    log("Disable with: python3 scripts/demo-mode.py --disable")


def disable_demo():
    """Disable demo mode: remove flag (data stays for reference)."""
    log("Disabling demo mode")

    try:
        with open(CONFIG_FILE) as f:
            config = json.load(f)
        config["demo_mode"] = False
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)
        log("  Config: demo_mode = false")
    except Exception as e:
        log(f"  Warning: could not update config: {e}")

    log("Demo mode disabled. Live data will be used.")
    log("Demo data files are still present. Delete manually if needed.")


def main():
    if "--enable" in sys.argv:
        enable_demo()
    elif "--disable" in sys.argv:
        disable_demo()
    elif "--generate" in sys.argv:
        log("Regenerating demo data (not changing mode)")
        enable_demo()
    else:
        print("Usage:")
        print("  python3 scripts/demo-mode.py --enable    # Generate demo data and enable")
        print("  python3 scripts/demo-mode.py --disable   # Disable demo mode")
        print("  python3 scripts/demo-mode.py --generate  # Regenerate data only")


if __name__ == "__main__":
    main()
