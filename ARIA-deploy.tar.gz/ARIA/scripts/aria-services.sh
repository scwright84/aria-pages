#!/bin/bash
# ARIA Service Manager
# Start, stop, restart, and check status of all ARIA services.
#
# Usage:
#   ./scripts/aria-services.sh start      # Start all services
#   ./scripts/aria-services.sh stop       # Stop all services
#   ./scripts/aria-services.sh restart    # Restart all services
#   ./scripts/aria-services.sh status     # Show status of all services
#   ./scripts/aria-services.sh install    # Install/update all launchd plists
#   ./scripts/aria-services.sh uninstall  # Remove all launchd plists
#   ./scripts/aria-services.sh logs       # Tail all service logs

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
VENV="$PROJECT_DIR/.venv/bin/python3"
LOGS_DIR="$PROJECT_DIR/logs"
PLIST_DIR="$HOME/Library/LaunchAgents"
DOCKER_DIR="$HOME/self-hosted-ai-starter-kit"

BOLD='\033[1m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'

# All ARIA launchd services
SERVICES=(
    # Always-on services (RunAtLoad + KeepAlive)
    "com.aria.telegram-bot"
    "com.aria.dashboard"
    "com.aria.menubar"
    "com.aria.status-page"
    "com.aria.admin-dashboard"
    "com.aria.client-portal"
    # Scheduled services
    "com.aria.health-check"
    "com.aria.remediation"
    "com.aria.morning-briefing"
    "com.aria.evening-debrief"
    "com.aria.weekly-rollup"
    "com.aria.conceivable-weekly"
    "com.aria.notification-sync"
    "com.aria.granola-sync"
    "com.aria.model-tracker"
    "com.aria.backup"
    "com.aria.engagement-scorecard"
    "com.aria.contact-profiles"
    "com.aria.workflow-optimizer"
    "com.aria.maintenance"
)

cmd_start() {
    echo -e "${BOLD}Starting ARIA services...${NC}"

    # Docker stack first
    echo -e "${CYAN}[Docker]${NC} Starting n8n + Postgres..."
    if [ -d "$DOCKER_DIR" ]; then
        cd "$DOCKER_DIR" && docker compose up postgres n8n -d 2>/dev/null && cd "$PROJECT_DIR"
        echo -e "  ${GREEN}OK${NC}"
    else
        echo -e "  ${YELLOW}SKIP${NC} Docker directory not found"
    fi

    # launchd services
    for svc in "${SERVICES[@]}"; do
        plist="$PLIST_DIR/$svc.plist"
        if [ -f "$plist" ]; then
            launchctl load "$plist" 2>/dev/null || true
            echo -e "  ${GREEN}OK${NC} $svc"
        else
            echo -e "  ${YELLOW}SKIP${NC} $svc (no plist)"
        fi
    done

    echo -e "\n${GREEN}All services started.${NC}"
}

cmd_stop() {
    echo -e "${BOLD}Stopping ARIA services...${NC}"

    for svc in "${SERVICES[@]}"; do
        plist="$PLIST_DIR/$svc.plist"
        if [ -f "$plist" ]; then
            launchctl unload "$plist" 2>/dev/null || true
            echo -e "  ${RED}STOP${NC} $svc"
        fi
    done

    # Docker stack
    echo -e "${CYAN}[Docker]${NC} Stopping n8n + Postgres..."
    if [ -d "$DOCKER_DIR" ]; then
        cd "$DOCKER_DIR" && docker compose down 2>/dev/null && cd "$PROJECT_DIR"
    fi

    echo -e "\n${RED}All services stopped.${NC}"
}

cmd_restart() {
    cmd_stop
    sleep 2
    cmd_start
}

cmd_status() {
    echo -e "${BOLD}ARIA Service Status${NC}"
    echo -e "$(date '+%Y-%m-%d %H:%M:%S')\n"

    # Docker
    echo -e "${CYAN}[Docker Stack]${NC}"
    if docker ps --format "{{.Names}}\t{{.Status}}" 2>/dev/null | grep -q "n8n"; then
        docker ps --format "  {{.Names}}\t{{.Status}}" 2>/dev/null | grep -E "n8n|postgres" || true
    else
        echo -e "  ${RED}Not running${NC}"
    fi

    # Web services
    echo -e "\n${CYAN}[Web Services]${NC}"
    check_port() {
        local name=$1 port=$2
        if curl -s -o /dev/null -w "%{http_code}" "http://localhost:$port/healthz" 2>/dev/null | grep -q "200"; then
            echo -e "  ${GREEN}UP${NC}  $name (port $port)"
        else
            echo -e "  ${RED}DOWN${NC} $name (port $port)"
        fi
    }

    check_port "n8n" 5678
    check_port "ARIA Dashboard" 8643
    check_port "Client Status Page" 8644
    check_port "Admin Dashboard" 8645
    check_port "Client Portal" 8646
    check_port "Billing API" 8647

    # Processes
    echo -e "\n${CYAN}[Background Processes]${NC}"
    check_process() {
        local name=$1 pattern=$2
        if pgrep -f "$pattern" >/dev/null 2>&1; then
            local pid=$(pgrep -f "$pattern" | head -1)
            echo -e "  ${GREEN}UP${NC}  $name (PID $pid)"
        else
            echo -e "  ${RED}DOWN${NC} $name"
        fi
    }

    check_process "Telegram Bot" "aria-telegram-bot"
    check_process "Menu Bar App" "aria-menubar"
    check_process "Inference Engine" "ollama"

    # Data freshness
    echo -e "\n${CYAN}[Data Freshness]${NC}"
    for prefix in emails slack calendar awaiting; do
        latest=$(ls -t "$PROJECT_DIR/inbox/${prefix}-"*.json 2>/dev/null | head -1 || true)
        if [ -n "$latest" ] && [ -f "$latest" ]; then
            age_seconds=$(( $(date +%s) - $(stat -f %m "$latest" 2>/dev/null || echo "0") ))
            age_hours=$(( age_seconds / 3600 ))
            if [ $age_hours -lt 24 ]; then
                echo -e "  ${GREEN}OK${NC}  $prefix (${age_hours}h ago)"
            else
                echo -e "  ${YELLOW}STALE${NC} $prefix (${age_hours}h ago)"
            fi
        else
            echo -e "  ${RED}NONE${NC} $prefix (no data)"
        fi
    done

    # Today's briefing
    echo -e "\n${CYAN}[Today's Outputs]${NC}"
    TODAY=$(date '+%Y-%m-%d')
    for output in "$TODAY.html" "$TODAY.json" "$TODAY-scorecard.html" "$TODAY-contacts.html"; do
        if [ -f "$PROJECT_DIR/briefings/$output" ]; then
            echo -e "  ${GREEN}OK${NC}  briefings/$output"
        else
            echo -e "  ${YELLOW}MISSING${NC} briefings/$output"
        fi
    done

    echo ""
}

cmd_install() {
    echo -e "${BOLD}Installing ARIA launchd services...${NC}"
    mkdir -p "$PLIST_DIR" "$LOGS_DIR"

    # Helper to generate plist
    gen_plist() {
        local label=$1 script=$2 log_name=$3
        shift 3
        local plist="$PLIST_DIR/$label.plist"

        cat > "$plist" << PLISTEOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>$label</string>
    <key>ProgramArguments</key>
    <array>
        <string>$VENV</string>
        <string>$PROJECT_DIR/scripts/$script</string>
    </array>
PLISTEOF

        # Add optional keys
        while [ $# -gt 0 ]; do
            echo "    $1" >> "$plist"
            shift
        done

        cat >> "$plist" << PLISTEOF
    <key>StandardOutPath</key>
    <string>$LOGS_DIR/launchd-$log_name.log</string>
    <key>StandardErrorPath</key>
    <string>$LOGS_DIR/launchd-$log_name.log</string>
    <key>WorkingDirectory</key>
    <string>$PROJECT_DIR</string>
</dict>
</plist>
PLISTEOF
        echo -e "  ${GREEN}OK${NC} $label"
    }

    gen_shell_plist() {
        local label=$1 script=$2 log_name=$3
        shift 3
        local plist="$PLIST_DIR/$label.plist"

        cat > "$plist" << PLISTEOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>$label</string>
    <key>ProgramArguments</key>
    <array>
        <string>/bin/bash</string>
        <string>$PROJECT_DIR/scripts/$script</string>
    </array>
PLISTEOF

        while [ $# -gt 0 ]; do
            echo "    $1" >> "$plist"
            shift
        done

        cat >> "$plist" << PLISTEOF
    <key>StandardOutPath</key>
    <string>$LOGS_DIR/launchd-$log_name.log</string>
    <key>StandardErrorPath</key>
    <string>$LOGS_DIR/launchd-$log_name.log</string>
    <key>WorkingDirectory</key>
    <string>$PROJECT_DIR</string>
</dict>
</plist>
PLISTEOF
        echo -e "  ${GREEN}OK${NC} $label"
    }

    # Always-on services (RunAtLoad + KeepAlive)
    echo -e "\n${CYAN}Always-on services:${NC}"
    gen_plist "com.aria.telegram-bot" "aria-telegram-bot.py" "telegram-bot" \
        "<key>RunAtLoad</key>" "<true/>" "<key>KeepAlive</key>" "<true/>"

    gen_plist "com.aria.dashboard" "aria-dashboard.py" "dashboard" \
        "<key>RunAtLoad</key>" "<true/>" "<key>KeepAlive</key>" "<true/>"

    gen_plist "com.aria.menubar" "aria-menubar.py" "menubar" \
        "<key>RunAtLoad</key>" "<true/>" "<key>KeepAlive</key>" "<true/>"

    gen_plist "com.aria.status-page" "status-page.py" "status-page" \
        "<key>RunAtLoad</key>" "<true/>" "<key>KeepAlive</key>" "<true/>"

    gen_plist "com.aria.admin-dashboard" "admin-dashboard.py" "admin-dashboard" \
        "<key>RunAtLoad</key>" "<true/>" "<key>KeepAlive</key>" "<true/>"

    gen_plist "com.aria.client-portal" "client-portal.py" "client-portal" \
        "<key>RunAtLoad</key>" "<true/>" "<key>KeepAlive</key>" "<true/>"

    # Every 5 minutes
    echo -e "\n${CYAN}Frequent checks (every 5 min):${NC}"
    gen_plist "com.aria.health-check" "health-check.py" "health-check" \
        "<key>StartInterval</key>" "<integer>300</integer>"

    gen_plist "com.aria.remediation" "remediate.py" "remediation" \
        "<key>StartInterval</key>" "<integer>300</integer>"

    # Twice daily (7am, 9pm)
    echo -e "\n${CYAN}Twice daily (7am, 9pm):${NC}"
    gen_plist "com.aria.notification-sync" "notification-sync.py" "notifications" \
        "<key>StartCalendarInterval</key>" "<array>" \
        "<dict><key>Hour</key><integer>7</integer><key>Minute</key><integer>0</integer></dict>" \
        "<dict><key>Hour</key><integer>21</integer><key>Minute</key><integer>0</integer></dict>" \
        "</array>"

    gen_plist "com.aria.granola-sync" "granola-sync.py" "granola" \
        "<key>StartCalendarInterval</key>" "<array>" \
        "<dict><key>Hour</key><integer>7</integer><key>Minute</key><integer>0</integer></dict>" \
        "<dict><key>Hour</key><integer>21</integer><key>Minute</key><integer>0</integer></dict>" \
        "</array>"

    # Scheduled briefings
    echo -e "\n${CYAN}Scheduled briefings:${NC}"
    gen_plist "com.aria.morning-briefing" "generate-briefing.py" "briefing" \
        "<key>StartCalendarInterval</key>" \
        "<dict><key>Hour</key><integer>7</integer><key>Minute</key><integer>30</integer></dict>"

    gen_plist "com.aria.evening-debrief" "generate-debrief.py" "debrief" \
        "<key>StartCalendarInterval</key>" \
        "<dict><key>Hour</key><integer>21</integer><key>Minute</key><integer>30</integer></dict>"

    gen_plist "com.aria.weekly-rollup" "generate-weekly.py" "weekly" \
        "<key>StartCalendarInterval</key>" \
        "<dict><key>Weekday</key><integer>0</integer><key>Hour</key><integer>19</integer><key>Minute</key><integer>0</integer></dict>"

    gen_plist "com.aria.conceivable-weekly" "generate-conceivable-weekly.py" "conceivable-weekly" \
        "<key>StartCalendarInterval</key>" \
        "<dict><key>Weekday</key><integer>0</integer><key>Hour</key><integer>18</integer><key>Minute</key><integer>0</integer></dict>"

    # Daily
    echo -e "\n${CYAN}Daily tasks:${NC}"
    gen_plist "com.aria.model-tracker" "model-tracker.py" "model-tracker" \
        "<key>StartCalendarInterval</key>" \
        "<dict><key>Hour</key><integer>6</integer><key>Minute</key><integer>0</integer></dict>"

    gen_shell_plist "com.aria.backup" "backup.sh" "backup" \
        "<key>StartCalendarInterval</key>" \
        "<dict><key>Hour</key><integer>0</integer><key>Minute</key><integer>0</integer></dict>"

    gen_plist "com.aria.maintenance" "maintenance.py" "maintenance" \
        "<key>StartCalendarInterval</key>" \
        "<dict><key>Hour</key><integer>0</integer><key>Minute</key><integer>30</integer></dict>"

    # Weekly (Sunday evening, before weekly rollup)
    echo -e "\n${CYAN}Weekly tasks:${NC}"
    gen_plist "com.aria.engagement-scorecard" "engagement-scorecard.py" "scorecard" \
        "<key>StartCalendarInterval</key>" \
        "<dict><key>Weekday</key><integer>0</integer><key>Hour</key><integer>17</integer><key>Minute</key><integer>0</integer></dict>"

    gen_plist "com.aria.contact-profiles" "contact-profiles.py" "contacts" \
        "<key>StartCalendarInterval</key>" \
        "<dict><key>Weekday</key><integer>0</integer><key>Hour</key><integer>17</integer><key>Minute</key><integer>30</integer></dict>"

    gen_plist "com.aria.workflow-optimizer" "workflow-optimizer.py" "workflow-optimizer" \
        "<key>StartCalendarInterval</key>" \
        "<dict><key>Weekday</key><integer>0</integer><key>Hour</key><integer>18</integer><key>Minute</key><integer>30</integer></dict>"

    echo -e "\n${GREEN}All plists installed to $PLIST_DIR${NC}"
    echo -e "Run ${BOLD}./scripts/aria-services.sh start${NC} to load them."
}

cmd_uninstall() {
    echo -e "${BOLD}Uninstalling ARIA launchd services...${NC}"
    for svc in "${SERVICES[@]}"; do
        plist="$PLIST_DIR/$svc.plist"
        if [ -f "$plist" ]; then
            launchctl unload "$plist" 2>/dev/null || true
            rm "$plist"
            echo -e "  ${RED}REMOVED${NC} $svc"
        fi
    done
    echo -e "\n${RED}All plists removed.${NC}"
}

cmd_logs() {
    echo -e "${BOLD}Tailing ARIA logs (Ctrl+C to stop)...${NC}\n"
    tail -f "$LOGS_DIR"/launchd-*.log 2>/dev/null || echo "No log files found."
}

# Main
case "${1:-status}" in
    start)     cmd_start ;;
    stop)      cmd_stop ;;
    restart)   cmd_restart ;;
    status)    cmd_status ;;
    install)   cmd_install ;;
    uninstall) cmd_uninstall ;;
    logs)      cmd_logs ;;
    *)
        echo "Usage: aria-services.sh {start|stop|restart|status|install|uninstall|logs}"
        exit 1
        ;;
esac
