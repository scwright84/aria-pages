#!/bin/bash
#
# ARIA Deployment Packager
# Creates a clean archive ready to deploy on a new machine.
# Includes all scripts, configs, templates, modules, installer, docs.
# Excludes: inbox data, briefings, logs, venv, state files, credentials.
#
# Usage: ./scripts/package-deploy.sh [output_path]
# Default output: ~/Desktop/ARIA-deploy.tar.gz

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
OUTPUT="${1:-$HOME/Desktop/ARIA-deploy.tar.gz}"
TEMP_DIR=$(mktemp -d)
PACKAGE_DIR="$TEMP_DIR/ARIA"

echo "Building ARIA deployment package..."

# Create clean copy
mkdir -p "$PACKAGE_DIR"

# Core files
cp "$PROJECT_DIR/CLAUDE.md" "$PACKAGE_DIR/"
cp "$PROJECT_DIR/README.md" "$PACKAGE_DIR/"

# Scripts (all Python + shell)
mkdir -p "$PACKAGE_DIR/scripts"
for f in "$PROJECT_DIR/scripts/"*.py "$PROJECT_DIR/scripts/"*.sh; do
    [ -f "$f" ] && cp "$f" "$PACKAGE_DIR/scripts/"
done

# Config (schema and templates, NOT credentials or Sean's config)
mkdir -p "$PACKAGE_DIR/config"
cp "$PROJECT_DIR/config/client-schema.json" "$PACKAGE_DIR/config/" 2>/dev/null || true
# Include Google OAuth client if it exists (bundled for users)
[ -f "$PROJECT_DIR/config/google-oauth-client.json" ] && cp "$PROJECT_DIR/config/google-oauth-client.json" "$PACKAGE_DIR/config/"

# Templates
[ -d "$PROJECT_DIR/templates" ] && cp -r "$PROJECT_DIR/templates" "$PACKAGE_DIR/"

# Workflows
[ -d "$PROJECT_DIR/workflows" ] && cp -r "$PROJECT_DIR/workflows" "$PACKAGE_DIR/"

# Modules (openclaw + comms)
[ -d "$PROJECT_DIR/modules" ] && cp -r "$PROJECT_DIR/modules" "$PACKAGE_DIR/"

# Installer
[ -d "$PROJECT_DIR/install" ] && cp -r "$PROJECT_DIR/install" "$PACKAGE_DIR/"

# Docs
mkdir -p "$PACKAGE_DIR/docs"
for f in "$PROJECT_DIR/docs/"*.md; do
    [ -f "$f" ] && cp "$f" "$PACKAGE_DIR/docs/"
done
[ -f "$PROJECT_DIR/docs/ARIA_Financial_Model.xlsx" ] && cp "$PROJECT_DIR/docs/ARIA_Financial_Model.xlsx" "$PACKAGE_DIR/docs/"

# Assets (menu bar icons)
[ -d "$PROJECT_DIR/assets" ] && cp -r "$PROJECT_DIR/assets" "$PACKAGE_DIR/"

# Create empty directories that ARIA expects
mkdir -p "$PACKAGE_DIR/inbox"
mkdir -p "$PACKAGE_DIR/briefings"
mkdir -p "$PACKAGE_DIR/logs"

# Create .env template
cat > "$PACKAGE_DIR/.env.template" << 'EOF'
# ARIA Environment Variables
# Copy this to .env and fill in real values.

# Telegram Bot Token (from @BotFather)
ARIA_TELEGRAM_TOKEN=CHANGE_ME

# SMTP Fallback (for briefing delivery if n8n is down)
# ARIA_SMTP_HOST=smtp.gmail.com
# ARIA_SMTP_PORT=587
# ARIA_SMTP_USER=CHANGE_ME
# ARIA_SMTP_PASS=CHANGE_ME
EOF

# Create archive
cd "$TEMP_DIR"
tar czf "$OUTPUT" ARIA/

# Cleanup
rm -rf "$TEMP_DIR"

SIZE=$(du -h "$OUTPUT" | cut -f1)
echo ""
echo "Package created: $OUTPUT ($SIZE)"
echo ""
echo "To deploy:"
echo "  1. Copy to target machine"
echo "  2. tar xzf ARIA-deploy.tar.gz"
echo "  3. cd ARIA && ./install/ARIA-Install.command"
echo ""
