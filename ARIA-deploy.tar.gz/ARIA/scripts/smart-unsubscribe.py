#!/usr/bin/env python3
"""
ARIA Smart Unsubscribe Suggestions (FEAT-096)
Detects newsletters and automated emails you never engage with.
Suggests unsubscribing to shrink your inbox over time.

Logic:
  - Track senders who email 3+ times with no reply from you
  - Cross-reference with junk filter learned list
  - Identify unsubscribe links in email headers/body
  - Generate a list of "you could unsubscribe from these"

Output: briefings/YYYY-MM-DD-unsubscribe.json
Monthly report (or on demand).
"""

import json
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
LOG_FILE = PROJECT_DIR / "logs" / "smart-unsubscribe.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def extract_domain(from_field):
    if not from_field:
        return None
    match = re.search(r'@([\w.-]+)', from_field)
    return match.group(1).lower() if match else None


def extract_sender_name(from_field):
    if not from_field:
        return None
    if "<" in from_field:
        return from_field.split("<")[0].strip().strip('"')
    return from_field


def load_all_emails(days_back=30):
    all_emails = []
    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        path = INBOX_DIR / f"emails-{date.strftime('%Y-%m-%d')}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                all_emails.extend(data if isinstance(data, list) else [data])
            except Exception:
                pass
    return all_emails


def analyze_sender_engagement(emails, user_email):
    """Find senders you never reply to."""
    received_from = defaultdict(lambda: {"count": 0, "subjects": [], "domain": None, "name": None})
    replied_to = set()

    for e in emails:
        sender = e.get("from", "").lower()
        subject = e.get("subject", "")

        if user_email.lower() in sender:
            # This is a sent email - mark the thread as replied
            norm_subject = re.sub(r'^(re|fwd|fw)\s*:\s*', '', subject, flags=re.IGNORECASE).strip().lower()
            replied_to.add(norm_subject)
        else:
            domain = extract_domain(sender)
            name = extract_sender_name(e.get("from", ""))
            key = domain or sender
            received_from[key]["count"] += 1
            received_from[key]["domain"] = domain
            received_from[key]["name"] = name
            if subject not in received_from[key]["subjects"]:
                received_from[key]["subjects"].append(subject[:60])

    # Find senders with 3+ emails and 0 replies
    suggestions = []
    for key, info in sorted(received_from.items(), key=lambda x: -x[1]["count"]):
        if info["count"] < 3:
            continue

        # Check if user ever replied to any email from this sender
        sender_subjects = [re.sub(r'^(re|fwd|fw)\s*:\s*', '', s, flags=re.IGNORECASE).strip().lower() for s in info["subjects"]]
        has_reply = any(s in replied_to for s in sender_subjects)

        if not has_reply:
            suggestions.append({
                "sender": info["name"] or key,
                "domain": info["domain"],
                "email_count": info["count"],
                "sample_subjects": info["subjects"][:3],
                "reason": f"Sent you {info['count']} emails, you never replied",
            })

    return suggestions


def main():
    log("Starting smart unsubscribe analysis")
    config = load_config()
    user_email = config.get("email", "")

    emails = load_all_emails(days_back=30)
    log(f"Analyzing {len(emails)} emails from last 30 days")

    suggestions = analyze_sender_engagement(emails, user_email)
    log(f"Found {len(suggestions)} unsubscribe suggestions")

    date_str = datetime.now().strftime("%Y-%m-%d")
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)

    output = {
        "date": date_str,
        "suggestions": suggestions,
        "potential_emails_eliminated_monthly": sum(s["email_count"] for s in suggestions),
    }

    with open(BRIEFINGS_DIR / f"{date_str}-unsubscribe.json", "w") as f:
        json.dump(output, f, indent=2, default=str)

    log(f"Potential emails eliminated per month: {output['potential_emails_eliminated_monthly']}")
    for s in suggestions[:10]:
        log(f"  {s['sender']}: {s['email_count']} emails, never replied")
        log(f"    Sample: {s['sample_subjects'][0] if s['sample_subjects'] else '?'}")

    log("Smart unsubscribe complete")


if __name__ == "__main__":
    main()
