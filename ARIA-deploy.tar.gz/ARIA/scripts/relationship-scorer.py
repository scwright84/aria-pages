#!/usr/bin/env python3
"""
ARIA Relationship Strength Scoring
Scores each contact 0-100 based on relationship health signals.

Signals:
  - Recency: When did you last communicate? (decays over time)
  - Frequency: How often do you communicate? (rolling 30-day average)
  - Reciprocity: Is it balanced or one-sided? (both send and receive)
  - Depth: Long emails vs quick replies? Multiple channels vs one?
  - Context: Active project involvement? Meeting attendance?

Score decays daily if no interaction. Gets boosted by any communication.

Output: Updates config/contacts.json with relationship_score field.
        Generates briefings/YYYY-MM-DD-relationships.json (changes/alerts).

Runs daily after contact-profiles.py.
"""

import json
import math
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

PROJECT_DIR = Path(__file__).parent.parent
CONTACTS_FILE = PROJECT_DIR / "config" / "contacts.json"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
LOG_FILE = PROJECT_DIR / "logs" / "relationship-scorer.log"

# Decay rate: score loses this much per day of no contact
DECAY_PER_DAY = 1.5
# Minimum score (never goes below this for known contacts)
MIN_SCORE = 5
# Maximum score
MAX_SCORE = 100


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def load_contacts():
    if CONTACTS_FILE.exists():
        with open(CONTACTS_FILE) as f:
            return json.load(f)
    return {}


def save_contacts(data):
    with open(CONTACTS_FILE, "w") as f:
        json.dump(data, f, indent=2, default=str)


def compute_score(contact, config):
    """Compute relationship strength score for a contact."""
    now = datetime.now()
    score = 50  # Start at neutral

    email_count = contact.get("email_count", 0)
    slack_mentions = contact.get("slack_mentions", 0)
    meetings = contact.get("meetings", 0)
    projects = contact.get("projects", [])
    last_contact_str = contact.get("last_contact")
    first_seen_str = contact.get("first_seen")

    # Parse dates
    last_contact = None
    if last_contact_str:
        try:
            last_contact = datetime.fromisoformat(str(last_contact_str))
        except (ValueError, TypeError):
            pass

    first_seen = None
    if first_seen_str:
        try:
            first_seen = datetime.fromisoformat(str(first_seen_str))
        except (ValueError, TypeError):
            pass

    # --- Recency (biggest factor) ---
    if last_contact:
        days_since = (now - last_contact).days
        if days_since == 0:
            score += 25  # Communicated today
        elif days_since <= 3:
            score += 20
        elif days_since <= 7:
            score += 10
        elif days_since <= 14:
            score += 0  # Neutral
        elif days_since <= 30:
            score -= 10
        else:
            # Decay: lose points per day beyond 30
            decay = min(40, (days_since - 30) * DECAY_PER_DAY)
            score -= decay
    else:
        score -= 20  # No contact date means weak signal

    # --- Frequency ---
    total_interactions = email_count + slack_mentions + meetings
    if total_interactions >= 20:
        score += 15  # Very active
    elif total_interactions >= 10:
        score += 10
    elif total_interactions >= 5:
        score += 5
    elif total_interactions >= 1:
        score += 0  # At least some interaction
    else:
        score -= 10  # Zero interactions

    # --- Multi-channel ---
    channels = 0
    if email_count > 0:
        channels += 1
    if slack_mentions > 0:
        channels += 1
    if meetings > 0:
        channels += 1
    if channels >= 3:
        score += 10  # Full multi-channel relationship
    elif channels == 2:
        score += 5

    # --- Project involvement ---
    active_clients = set(config.get("client_tiers", {}).get("active", []))
    product_projects = set(config.get("client_tiers", {}).get("product", []))

    if any(p in active_clients for p in projects):
        score += 10  # Active client contact
    elif any(p in product_projects for p in projects):
        score += 5

    # --- Relationship longevity ---
    if first_seen:
        relationship_days = (now - first_seen).days
        if relationship_days > 90:
            score += 5  # Long-standing relationship
        if relationship_days > 365:
            score += 5  # Over a year

    # Clamp
    score = max(MIN_SCORE, min(MAX_SCORE, score))

    return score


def get_score_label(score):
    """Convert score to human-readable label."""
    if score >= 80:
        return "strong"
    elif score >= 60:
        return "healthy"
    elif score >= 40:
        return "moderate"
    elif score >= 20:
        return "weakening"
    else:
        return "dormant"


def main():
    log("Starting relationship scoring")
    config = load_config()
    contacts = load_contacts()

    if not contacts:
        log("No contacts to score")
        return

    changes = []
    scored = 0

    for key, contact in contacts.items():
        old_score = contact.get("relationship_score", 50)
        new_score = compute_score(contact, config)
        label = get_score_label(new_score)

        contact["relationship_score"] = new_score
        contact["relationship_label"] = label
        contact["score_updated"] = datetime.now().isoformat()
        scored += 1

        # Track significant changes
        delta = new_score - old_score
        if abs(delta) >= 10:
            changes.append({
                "name": contact.get("name", key),
                "old_score": old_score,
                "new_score": new_score,
                "delta": delta,
                "label": label,
                "direction": "strengthened" if delta > 0 else "weakened",
                "projects": contact.get("projects", []),
            })

    save_contacts(contacts)

    # Save change report
    date_str = datetime.now().strftime("%Y-%m-%d")
    report = {
        "generated": datetime.now().isoformat(),
        "contacts_scored": scored,
        "significant_changes": changes,
        "distribution": {
            "strong": sum(1 for c in contacts.values() if c.get("relationship_score", 0) >= 80),
            "healthy": sum(1 for c in contacts.values() if 60 <= c.get("relationship_score", 0) < 80),
            "moderate": sum(1 for c in contacts.values() if 40 <= c.get("relationship_score", 0) < 60),
            "weakening": sum(1 for c in contacts.values() if 20 <= c.get("relationship_score", 0) < 40),
            "dormant": sum(1 for c in contacts.values() if c.get("relationship_score", 0) < 20),
        },
        "top_relationships": sorted(
            [{"name": c.get("name", k), "score": c.get("relationship_score", 0), "projects": c.get("projects", [])}
             for k, c in contacts.items() if c.get("relationship_score", 0) > 0],
            key=lambda x: -x["score"]
        )[:15],
        "needs_attention": sorted(
            [{"name": c.get("name", k), "score": c.get("relationship_score", 0), "label": c.get("relationship_label", ""), "projects": c.get("projects", [])}
             for k, c in contacts.items()
             if c.get("relationship_label") in ("weakening", "dormant") and c.get("projects")],
            key=lambda x: x["score"]
        ),
    }

    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    with open(BRIEFINGS_DIR / f"{date_str}-relationships.json", "w") as f:
        json.dump(report, f, indent=2, default=str)

    log(f"Scored {scored} contacts")
    log(f"Distribution: {json.dumps(report['distribution'])}")
    if changes:
        log(f"Significant changes: {len(changes)}")
        for c in changes:
            log(f"  {c['direction'].upper()}: {c['name']} ({c['old_score']} → {c['new_score']})")
    if report["needs_attention"]:
        log(f"Needs attention: {len(report['needs_attention'])}")
        for c in report["needs_attention"]:
            log(f"  {c['name']}: {c['score']} ({c['label']})")

    log("Relationship scoring complete")


if __name__ == "__main__":
    main()
