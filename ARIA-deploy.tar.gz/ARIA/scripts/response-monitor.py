#!/usr/bin/env python3
"""
ARIA Email Response Time Monitor
Tracks how fast you reply and how fast others reply to you.
Per project, per person. Trends over time.

Metrics:
  - Your avg response time per project
  - Their avg response time per project
  - Ratio (are you faster or slower?)
  - Trend (getting faster or slower?)
  - Outliers (emails waiting 3+ days with no reply)

Output: briefings/YYYY-MM-DD-response-times.json
Runs weekly.
"""

import json
import re
import sys
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
LOG_FILE = PROJECT_DIR / "logs" / "response-monitor.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def parse_date(val):
    if val is None:
        return None
    if isinstance(val, (int, float)) or (isinstance(val, str) and val.isdigit()):
        ts = int(val)
        if ts > 1e12:
            ts = ts / 1000
        try:
            return datetime.fromtimestamp(ts)
        except (ValueError, OSError):
            return None
    if isinstance(val, str):
        try:
            return datetime.fromisoformat(val.replace("Z", "+00:00")).replace(tzinfo=None)
        except (ValueError, TypeError):
            return None
    return None


def load_emails(days_back=14):
    all_emails = []
    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        path = INBOX_DIR / f"emails-{date.strftime('%Y-%m-%d')}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                all_emails.extend(data if isinstance(data, list) else [data])
            except Exception:
                pass
    return all_emails


def normalize_subject(subject):
    return re.sub(r'^(re|fwd|fw)\s*:\s*', '', subject, flags=re.IGNORECASE).strip().lower()


def analyze_response_times(emails, user_email):
    """Analyze response times by looking at reply threads."""
    # Group by thread
    threads = defaultdict(list)
    for e in emails:
        subject = e.get("subject", "")
        thread_key = normalize_subject(subject)
        date = parse_date(e.get("date") or e.get("processed_at"))
        if not date:
            continue
        is_from_user = user_email.lower() in e.get("from", "").lower()
        threads[thread_key].append({
            "from_user": is_from_user,
            "date": date,
            "project": e.get("detected_project"),
            "from": e.get("from", ""),
            "subject": e.get("subject", ""),
        })

    # Calculate response times within threads
    project_response_times = defaultdict(lambda: {"user_times": [], "other_times": []})
    stale_emails = []

    for thread_key, messages in threads.items():
        if len(messages) < 2:
            continue

        messages.sort(key=lambda m: m["date"])
        project = messages[0].get("project") or "Unclassified"

        for i in range(1, len(messages)):
            prev = messages[i - 1]
            curr = messages[i]
            gap_hours = (curr["date"] - prev["date"]).total_seconds() / 3600

            if gap_hours < 0 or gap_hours > 168:  # Skip negative or > 1 week
                continue

            if prev["from_user"] and not curr["from_user"]:
                # They replied to us
                project_response_times[project]["other_times"].append(gap_hours)
            elif not prev["from_user"] and curr["from_user"]:
                # We replied to them
                project_response_times[project]["user_times"].append(gap_hours)

    # Find stale emails (received, no reply, 3+ days old)
    now = datetime.now()
    replied_threads = set()
    for thread_key, messages in threads.items():
        for m in messages:
            if m["from_user"]:
                replied_threads.add(thread_key)

    for thread_key, messages in threads.items():
        if thread_key in replied_threads:
            continue
        latest = max(messages, key=lambda m: m["date"])
        if not latest["from_user"]:
            age_hours = (now - latest["date"]).total_seconds() / 3600
            if age_hours > 72:  # 3+ days
                stale_emails.append({
                    "subject": latest["subject"][:60],
                    "from": latest["from"][:40],
                    "age_hours": round(age_hours),
                    "age_days": round(age_hours / 24, 1),
                    "project": latest.get("project"),
                })

    # Compile results
    results = {}
    for project, times in project_response_times.items():
        user_avg = sum(times["user_times"]) / len(times["user_times"]) if times["user_times"] else None
        other_avg = sum(times["other_times"]) / len(times["other_times"]) if times["other_times"] else None

        results[project] = {
            "your_avg_response_hours": round(user_avg, 1) if user_avg else None,
            "their_avg_response_hours": round(other_avg, 1) if other_avg else None,
            "your_reply_count": len(times["user_times"]),
            "their_reply_count": len(times["other_times"]),
            "you_faster": user_avg < other_avg if user_avg and other_avg else None,
        }

    return results, sorted(stale_emails, key=lambda x: -x["age_hours"])


def main():
    log("Starting response time analysis")
    config = load_config()
    user_email = config.get("email", "")
    emails = load_emails(days_back=14)
    log(f"Analyzing {len(emails)} emails")

    results, stale = analyze_response_times(emails, user_email)

    date_str = datetime.now().strftime("%Y-%m-%d")
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)

    output = {
        "date": date_str,
        "response_times": results,
        "stale_emails": stale[:10],
        "stale_count": len(stale),
    }

    with open(BRIEFINGS_DIR / f"{date_str}-response-times.json", "w") as f:
        json.dump(output, f, indent=2, default=str)

    log(f"Projects analyzed: {len(results)}")
    for project, data in results.items():
        your_time = f"{data['your_avg_response_hours']}h" if data['your_avg_response_hours'] else "N/A"
        their_time = f"{data['their_avg_response_hours']}h" if data['their_avg_response_hours'] else "N/A"
        log(f"  {project}: You reply in {your_time}, they reply in {their_time}")

    if stale:
        log(f"Stale emails (3+ days, no reply): {len(stale)}")
        for s in stale[:5]:
            log(f"  {s['age_days']}d old: {s['from']} - {s['subject']}")

    log("Response time analysis complete")


if __name__ == "__main__":
    main()
