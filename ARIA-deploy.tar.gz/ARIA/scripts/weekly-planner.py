#!/usr/bin/env python3
"""
ARIA Weekly Planner
Proactive week-ahead planning. Looks at next week's calendar, open commitments,
project health, outreach alerts, and tasks to generate a prioritized plan.

Runs Sunday evening (before the weekly rollup) or on demand.
Output: briefings/YYYY-MM-DD-plan.json + HTML

Different from the weekly rollup (which looks backward).
The planner looks FORWARD and tells you what to focus on.
"""

import json
import sys
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import aria_ai

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
TASKS_FILE = PROJECT_DIR / "config" / "tasks.json"
LOG_FILE = PROJECT_DIR / "logs" / "weekly-planner.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def load_inbox(prefix, days_back=7):
    all_data = []
    for d in range(days_back):
        date = datetime.now() + timedelta(days=d)
        path = INBOX_DIR / f"{prefix}-{date.strftime('%Y-%m-%d')}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                all_data.extend(data if isinstance(data, list) else [data])
            except Exception:
                pass
    return all_data


def load_past_inbox(prefix, days_back=7):
    all_data = []
    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        path = INBOX_DIR / f"{prefix}-{date.strftime('%Y-%m-%d')}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                all_data.extend(data if isinstance(data, list) else [data])
            except Exception:
                pass
    return all_data


def get_next_week_calendar():
    """Get calendar events for the next 7 days."""
    events = []
    # Calendar data might be in today's file with future dates, or in future-dated files
    for d in range(-1, 8):
        date = datetime.now() + timedelta(days=d)
        date_str = date.strftime("%Y-%m-%d")
        for prefix in ["calendar", "calendly"]:
            path = INBOX_DIR / f"{prefix}-{date_str}.json"
            if path.exists():
                try:
                    with open(path) as f:
                        data = json.load(f)
                    for item in (data if isinstance(data, list) else [data]):
                        # Parse start time
                        start_str = item.get("start") or item.get("start_time") or item.get("start_local", "")
                        try:
                            start = datetime.fromisoformat(start_str.replace("Z", "+00:00")).replace(tzinfo=None)
                        except (ValueError, TypeError):
                            continue
                        # Only include future events within next 7 days
                        now = datetime.now()
                        if start > now and start < now + timedelta(days=7):
                            events.append({
                                "summary": item.get("summary") or item.get("name", "?"),
                                "start": start,
                                "end_str": item.get("end") or item.get("end_time", ""),
                                "attendees": item.get("attendees") or item.get("invitee_names", []),
                                "location": item.get("location") or item.get("join_url", ""),
                                "source": prefix,
                            })
                except Exception:
                    pass

    return sorted(events, key=lambda e: e["start"])


def get_open_tasks():
    """Get open tasks from the task list."""
    if TASKS_FILE.exists():
        try:
            with open(TASKS_FILE) as f:
                data = json.load(f)
            return [t for t in data.get("tasks", []) if t.get("status") == "open"]
        except Exception:
            pass
    return []


def get_outreach_alerts():
    """Get latest outreach alerts."""
    date_str = datetime.now().strftime("%Y-%m-%d")
    path = BRIEFINGS_DIR / f"{date_str}-outreach.json"
    if path.exists():
        with open(path) as f:
            data = json.load(f)
        return data.get("project_alerts", [])
    return []


def get_scorecard():
    """Get latest engagement scorecard."""
    date_str = datetime.now().strftime("%Y-%m-%d")
    path = BRIEFINGS_DIR / f"{date_str}-scorecard.json"
    if path.exists():
        with open(path) as f:
            return json.load(f)
    return {}


def get_open_commitments():
    """Get outstanding commitments."""
    commitments = load_past_inbox("awaiting", days_back=30)
    return [c for c in commitments if c.get("task") and len(c.get("task", "")) > 10]


def build_plan(config):
    """Build the weekly plan from all data sources."""
    now = datetime.now()
    week_start = now + timedelta(days=1)
    week_end = now + timedelta(days=7)

    # Gather data
    calendar = get_next_week_calendar()
    tasks = get_open_tasks()
    outreach = get_outreach_alerts()
    scorecard = get_scorecard()
    commitments = get_open_commitments()

    # Group calendar by day
    days = defaultdict(list)
    for event in calendar:
        day_key = event["start"].strftime("%A, %b %d")
        days[day_key].append(event)

    # Count meetings per day
    meeting_load = {}
    for day_key, events in days.items():
        meeting_load[day_key] = len(events)

    # Identify heavy/light days
    heavy_days = [d for d, c in meeting_load.items() if c >= 3]
    light_days = []
    for d in range(1, 8):
        date = now + timedelta(days=d)
        day_key = date.strftime("%A, %b %d")
        if day_key not in meeting_load or meeting_load[day_key] == 0:
            light_days.append(day_key)

    # Priority items
    high_priority = []

    # Overdue commitments
    for c in commitments:
        deadline = c.get("deadline", "")
        if deadline and deadline not in ("none", "TBD"):
            try:
                dl = datetime.strptime(deadline, "%Y-%m-%d")
                if dl < now:
                    high_priority.append({
                        "type": "overdue_commitment",
                        "text": c.get("task", "")[:100],
                        "project": c.get("project"),
                        "urgency": "high",
                        "suggestion": f"This was due {deadline}. Address first thing Monday.",
                    })
            except ValueError:
                pass

    # Silent clients needing outreach
    for alert in outreach:
        if alert.get("urgency") == "high":
            high_priority.append({
                "type": "outreach",
                "text": f"{alert['project']} has been silent for {alert['days_silent']} days",
                "project": alert["project"],
                "urgency": "high",
                "suggestion": alert.get("suggestion", "Schedule a check-in"),
            })

    # High priority tasks
    for task in tasks:
        if task.get("priority") in ("high", "urgent"):
            high_priority.append({
                "type": "task",
                "text": task.get("title", "")[:100],
                "project": task.get("project"),
                "urgency": task.get("priority"),
                "suggestion": f"From {task.get('source', 'unknown')}: {task.get('summary', '')[:80]}",
            })

    # Projects needing attention (from scorecard)
    projects_attention = []
    for name, metrics in scorecard.items():
        if metrics.get("health_grade") in ("C", "D", "F"):
            projects_attention.append({
                "project": name,
                "grade": metrics["health_grade"],
                "flags": metrics.get("health_flags", []),
            })

    # Build recommendations
    recommendations = []
    if light_days:
        recommendations.append(f"Deep work days: {', '.join(light_days[:3])}. Block these for focused project work.")
    if heavy_days:
        recommendations.append(f"Meeting-heavy days: {', '.join(heavy_days)}. Minimize other commitments.")
    if len(tasks) > 10:
        recommendations.append(f"You have {len(tasks)} open tasks. Consider triaging: close or defer anything that's no longer relevant.")
    if len(commitments) > 5:
        recommendations.append(f"{len(commitments)} outstanding commitments. Review and close any that are done.")

    plan = {
        "generated": now.isoformat(),
        "week": f"{week_start.strftime('%b %d')} - {week_end.strftime('%b %d, %Y')}",
        "summary": {
            "meetings": len(calendar),
            "open_tasks": len(tasks),
            "open_commitments": len(commitments),
            "outreach_alerts": len(outreach),
            "high_priority_items": len(high_priority),
        },
        "high_priority": high_priority,
        "calendar_by_day": {day: [{"summary": e["summary"], "time": e["start"].strftime("%I:%M %p"), "attendees": e.get("attendees", [])} for e in events] for day, events in days.items()},
        "meeting_load": meeting_load,
        "heavy_days": heavy_days,
        "light_days": light_days,
        "projects_needing_attention": projects_attention,
        "recommendations": recommendations,
    }

    return plan


def generate_html(plan):
    """Generate HTML weekly plan."""
    # Priority items
    priority_rows = ""
    for item in plan["high_priority"]:
        color = "#ef4444" if item["urgency"] == "high" else "#f97316"
        priority_rows += f"""
        <tr>
            <td style="color:{color};font-weight:700;font-size:12px;text-transform:uppercase">{item["type"].replace("_"," ")}</td>
            <td><strong>{item["text"]}</strong><br><span style="font-size:12px;color:#6b7280">{item["suggestion"]}</span></td>
            <td>{item.get("project") or "-"}</td>
        </tr>"""

    # Calendar
    calendar_html = ""
    for day, events in plan["calendar_by_day"].items():
        count = len(events)
        load_color = "#ef4444" if count >= 3 else "#f97316" if count >= 2 else "#22c55e"
        calendar_html += f'<div style="margin-bottom:12px"><strong>{day}</strong> <span style="color:{load_color};font-size:12px">({count} meeting{"s" if count != 1 else ""})</span>'
        for e in events:
            att_names = [a if isinstance(a, str) else a.get("name", a.get("email", "?")) for a in (e.get("attendees") or [])]
            attendee_str = f' with {", ".join(att_names[:3])}' if att_names else ""
            calendar_html += f'<div style="font-size:13px;color:#6b7280;padding:2px 0 2px 16px">{e["time"]} - {e["summary"]}{attendee_str}</div>'
        calendar_html += '</div>'

    if not calendar_html:
        calendar_html = '<p style="color:#22c55e">No meetings scheduled. Great week for deep work.</p>'

    # Recommendations
    rec_html = ""
    for r in plan["recommendations"]:
        rec_html += f'<div style="background:#f0f9ff;border-left:3px solid #3b82f6;padding:8px 12px;margin:4px 0;border-radius:4px;font-size:13px">{r}</div>'

    # Projects needing attention
    proj_html = ""
    for p in plan["projects_needing_attention"]:
        flags = ", ".join(p["flags"]) if p["flags"] else "Review needed"
        proj_html += f'<div style="font-size:13px;padding:4px 0"><span style="color:#ef4444;font-weight:700">{p["grade"]}</span> {p["project"]}: {flags}</div>'

    s = plan["summary"]
    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>ARIA Weekly Plan - {plan["week"]}</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; background: #f9fafb; }}
  h1 {{ font-size: 22px; color: #111827; margin-bottom: 4px; }}
  .subtitle {{ color: #6b7280; font-size: 14px; margin-bottom: 20px; }}
  .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 10px; margin-bottom: 20px; }}
  .metric {{ background: white; border-radius: 8px; padding: 12px; text-align: center; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }}
  .metric .value {{ font-size: 24px; font-weight: 700; color: #111827; }}
  .metric .label {{ font-size: 11px; color: #6b7280; }}
  .card {{ background: white; border-radius: 8px; padding: 16px; margin-bottom: 14px; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }}
  .card h2 {{ font-size: 14px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 12px; }}
  table {{ width: 100%; border-collapse: collapse; }}
  td {{ padding: 8px; border-bottom: 1px solid #f3f4f6; font-size: 14px; }}
  tr:last-child td {{ border-bottom: none; }}
</style>
</head>
<body>
<h1>Weekly Plan</h1>
<p class="subtitle">{plan["week"]} | Generated by ARIA</p>

<div class="grid">
  <div class="metric"><div class="value">{s["meetings"]}</div><div class="label">Meetings</div></div>
  <div class="metric"><div class="value">{s["open_tasks"]}</div><div class="label">Open Tasks</div></div>
  <div class="metric"><div class="value">{s["open_commitments"]}</div><div class="label">Commitments</div></div>
  <div class="metric"><div class="value" style="color:{'#ef4444' if s['high_priority_items'] > 0 else '#22c55e'}">{s["high_priority_items"]}</div><div class="label">High Priority</div></div>
</div>

{f'<div class="card" style="border-left:4px solid #ef4444"><h2>Needs Immediate Attention</h2><table>{priority_rows}</table></div>' if priority_rows else ''}

{f'<div class="card"><h2>Recommendations</h2>{rec_html}</div>' if rec_html else ''}

<div class="card">
  <h2>This Week's Calendar</h2>
  {calendar_html}
</div>

{f'<div class="card"><h2>Projects Needing Attention</h2>{proj_html}</div>' if proj_html else ''}

<p style="text-align:center;font-size:11px;color:#9ca3af;margin-top:20px">Generated by ARIA | Plan your week, then work the plan</p>
</body>
</html>"""
    return html


def main():
    log("Starting weekly planner")
    config = load_config()
    date_str = datetime.now().strftime("%Y-%m-%d")

    plan = build_plan(config)

    # Save JSON
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    with open(BRIEFINGS_DIR / f"{date_str}-plan.json", "w") as f:
        json.dump(plan, f, indent=2, default=str)

    # Save HTML
    html = generate_html(plan)
    with open(BRIEFINGS_DIR / f"{date_str}-plan.html", "w") as f:
        f.write(html)

    log(f"Week: {plan['week']}")
    log(f"Meetings: {plan['summary']['meetings']}")
    log(f"Open tasks: {plan['summary']['open_tasks']}")
    log(f"High priority: {plan['summary']['high_priority_items']}")
    for r in plan["recommendations"]:
        log(f"  REC: {r}")
    log(f"Saved to briefings/{date_str}-plan.html")
    log("Weekly planner complete")


if __name__ == "__main__":
    main()
