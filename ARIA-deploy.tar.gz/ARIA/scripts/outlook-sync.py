#!/usr/bin/env python3
"""
ARIA Outlook Email + Calendar Sync (Direct)
Fetches email and calendar from connected Microsoft/Outlook accounts
using stored OAuth credentials via Microsoft Graph API.

Reads credentials from config/credentials.json.
Saves to inbox/emails-YYYY-MM-DD.json and inbox/calendar-YYYY-MM-DD.json.

Runs via launchd or manually.
"""

import json
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

import msal
import requests

import aria_ai

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
CREDENTIALS_FILE = PROJECT_DIR / "config" / "credentials.json"
MS_CLIENT_FILE = PROJECT_DIR / "config" / "microsoft-oauth-client.json"
LOG_FILE = PROJECT_DIR / "logs" / "outlook-sync.log"
STATE_FILE = PROJECT_DIR / "logs" / "outlook-sync-state.json"

GRAPH_BASE = "https://graph.microsoft.com/v1.0"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_credentials():
    if CREDENTIALS_FILE.exists():
        with open(CREDENTIALS_FILE) as f:
            return json.load(f)
    return {"accounts": []}


def save_credentials(creds_data):
    with open(CREDENTIALS_FILE, "w") as f:
        json.dump(creds_data, f, indent=2)


def load_ms_client():
    if MS_CLIENT_FILE.exists():
        with open(MS_CLIENT_FILE) as f:
            return json.load(f)
    return None


def load_state():
    if STATE_FILE.exists():
        try:
            with open(STATE_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"last_sync": {}, "seen_ids": {}}


def save_state(state):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def get_access_token(account, ms_config):
    """Get a valid access token, refreshing if needed."""
    app = msal.ConfidentialClientApplication(
        ms_config["client_id"],
        authority="https://login.microsoftonline.com/common",
        client_credential=ms_config["client_secret"],
    )

    # Try to get token silently using refresh token
    refresh_token = account.get("refresh_token")
    if refresh_token:
        scopes = ["Mail.Read", "Mail.ReadWrite", "Calendars.Read", "Calendars.ReadWrite", "User.Read"]
        result = app.acquire_token_by_refresh_token(refresh_token, scopes=scopes)
        if "access_token" in result:
            # Update stored tokens
            account["access_token"] = result["access_token"]
            if "refresh_token" in result:
                account["refresh_token"] = result["refresh_token"]
            return result["access_token"], True
        else:
            log(f"  Token refresh failed: {result.get('error_description', result.get('error', 'unknown'))}")
            return None, False

    # Fall back to stored access token (may be expired)
    return account.get("access_token"), False


def graph_get(url, access_token, params=None):
    """Make a GET request to Microsoft Graph API."""
    headers = {"Authorization": f"Bearer {access_token}"}
    resp = requests.get(url, headers=headers, params=params, timeout=30)
    if resp.status_code == 200:
        return resp.json()
    elif resp.status_code == 401:
        log(f"  Graph API 401: Token expired or invalid")
        return None
    else:
        log(f"  Graph API error {resp.status_code}: {resp.text[:200]}")
        return None


def fetch_outlook_emails(access_token, days_back=30, max_results=200):
    """Fetch recent emails from Outlook via Microsoft Graph."""
    after_date = (datetime.now() - timedelta(days=days_back)).strftime("%Y-%m-%dT00:00:00Z")

    params = {
        "$filter": f"receivedDateTime ge {after_date}",
        "$orderby": "receivedDateTime desc",
        "$top": max_results,
        "$select": "id,from,toRecipients,subject,receivedDateTime,bodyPreview,importance,isRead,categories",
    }

    data = graph_get(f"{GRAPH_BASE}/me/messages", access_token, params)
    if not data:
        return []

    emails = []
    for msg in data.get("value", []):
        from_info = msg.get("from", {}).get("emailAddress", {})
        to_list = [r.get("emailAddress", {}).get("address", "") for r in msg.get("toRecipients", [])]

        emails.append({
            "id": msg.get("id", ""),
            "account": "outlook",
            "from": f"{from_info.get('name', '')} <{from_info.get('address', '')}>",
            "to": ", ".join(to_list),
            "subject": msg.get("subject", "(no subject)"),
            "date": msg.get("receivedDateTime", ""),
            "snippet": msg.get("bodyPreview", "")[:300],
            "labels": msg.get("categories", []),
            "importance": msg.get("importance", "normal"),
            "is_read": msg.get("isRead", False),
        })

    return emails


def fetch_outlook_calendar(access_token, days_ahead=7):
    """Fetch upcoming calendar events from Outlook via Microsoft Graph."""
    now = datetime.utcnow()
    start = now.strftime("%Y-%m-%dT%H:%M:%SZ")
    end = (now + timedelta(days=days_ahead)).strftime("%Y-%m-%dT%H:%M:%SZ")

    params = {
        "startDateTime": start,
        "endDateTime": end,
        "$orderby": "start/dateTime",
        "$top": 50,
        "$select": "id,subject,start,end,location,attendees,bodyPreview,webLink,isOnlineMeeting,onlineMeetingUrl",
    }

    data = graph_get(f"{GRAPH_BASE}/me/calendarView", access_token, params)
    if not data:
        return []

    events = []
    for event in data.get("value", []):
        start_info = event.get("start", {})
        end_info = event.get("end", {})
        attendees = event.get("attendees", [])

        events.append({
            "id": event.get("id", ""),
            "account": "outlook",
            "summary": event.get("subject", "(no title)"),
            "start": start_info.get("dateTime", ""),
            "end": end_info.get("dateTime", ""),
            "location": event.get("location", {}).get("displayName", ""),
            "description": (event.get("bodyPreview", "") or "")[:500],
            "attendees": [
                {
                    "email": a.get("emailAddress", {}).get("address", ""),
                    "name": a.get("emailAddress", {}).get("name", ""),
                    "response": a.get("status", {}).get("response", ""),
                }
                for a in attendees
            ],
            "hangout_link": event.get("onlineMeetingUrl", ""),
            "html_link": event.get("webLink", ""),
            "status": "confirmed",
        })

    return events


def triage_emails(emails):
    """Use AI to triage Outlook emails."""
    if not emails:
        return emails

    email_summaries = []
    for i, email in enumerate(emails):
        email_summaries.append(
            f"[{i+1}] From: {email['from']}\n"
            f"    Subject: {email['subject']}\n"
            f"    Snippet: {email['snippet'][:150]}"
        )

    full_config = aria_ai.get_full_config()
    projects = full_config.get("projects", full_config.get("known_projects", []))
    projects_str = ", ".join(projects) if projects else "unknown"

    system_prompt = f"""You are ARIA, an email triage assistant. Classify each email.

Known projects: {projects_str}.

Respond with ONLY a valid JSON array. No markdown.
Format: [{{"item": 1, "priority": "high/medium/low", "action_needed": true/false, "action_type": "reply/review/fyi/ignore", "project": "project name or null", "summary": "one sentence"}}]"""

    results = aria_ai.chat_json(
        system_prompt,
        f"Triage these {len(emails)} emails:\n" + "\n".join(email_summaries),
        fast=True,
    )

    if results and isinstance(results, list):
        for entry in results:
            idx = entry.get("item", 0) - 1
            if 0 <= idx < len(emails):
                emails[idx]["triage"] = {
                    "priority": entry.get("priority", "medium"),
                    "action_needed": entry.get("action_needed", False),
                    "action_type": entry.get("action_type", "fyi"),
                    "project": entry.get("project"),
                    "summary": entry.get("summary", ""),
                }
    else:
        for email in emails:
            email["triage"] = {
                "priority": "medium",
                "action_needed": False,
                "action_type": "fyi",
                "project": None,
                "summary": email.get("subject", ""),
            }

    return emails


def main():
    log("Starting Outlook sync (direct)...")
    INBOX_DIR.mkdir(parents=True, exist_ok=True)

    ms_config = load_ms_client()
    if not ms_config:
        log("No Microsoft OAuth config found. Run the onboarding wizard to set up Outlook.")
        return

    creds_data = load_credentials()
    state = load_state()
    all_emails = []
    all_events = []
    creds_updated = False

    # Find all Microsoft accounts
    ms_accounts = [a for a in creds_data.get("accounts", []) if a.get("type") == "microsoft"]

    if not ms_accounts:
        log("No Microsoft accounts connected. Run the onboarding wizard to connect Outlook.")
        return

    for account in ms_accounts:
        email_addr = account.get("email", "unknown")
        log(f"Processing {email_addr}...")

        access_token, refreshed = get_access_token(account, ms_config)
        if refreshed:
            creds_updated = True

        if not access_token:
            log(f"  No valid token for {email_addr}. Re-authorize via onboarding wizard.")
            continue

        # Fetch emails
        log(f"  Fetching emails...")
        emails = fetch_outlook_emails(access_token, days_back=30)
        log(f"  {len(emails)} emails")

        # Update account info on emails
        for e in emails:
            e["account"] = email_addr

        # Deduplicate
        seen = set(state.get("seen_ids", {}).get(email_addr, []))
        new_emails = [e for e in emails if e["id"] not in seen]
        log(f"  {len(new_emails)} new")

        new_seen = list(seen | {e["id"] for e in emails})[-500:]
        state.setdefault("seen_ids", {})[email_addr] = new_seen
        all_emails.extend(new_emails)

        # Fetch calendar
        log(f"  Fetching calendar...")
        events = fetch_outlook_calendar(access_token, days_ahead=7)
        for e in events:
            e["account"] = email_addr
        log(f"  {len(events)} events")
        all_events.extend(events)

    # Triage emails
    if all_emails:
        log(f"Triaging {len(all_emails)} Outlook emails...")
        all_emails = triage_emails(all_emails)

    # Save emails (merge with existing)
    date_str = datetime.now().strftime("%Y-%m-%d")
    email_path = INBOX_DIR / f"emails-{date_str}.json"
    existing_emails = []
    if email_path.exists():
        try:
            with open(email_path) as f:
                existing_emails = json.load(f)
        except Exception:
            pass

    existing_ids = {e.get("id") for e in existing_emails}
    for email in all_emails:
        if email["id"] not in existing_ids:
            existing_emails.append(email)

    with open(email_path, "w") as f:
        json.dump(existing_emails, f, indent=2)
    log(f"Saved {len(existing_emails)} total emails to {email_path.name}")

    # Save calendar (merge with existing)
    cal_path = INBOX_DIR / f"calendar-{date_str}.json"
    existing_events = []
    if cal_path.exists():
        try:
            with open(cal_path) as f:
                existing_events = json.load(f)
        except Exception:
            pass

    existing_event_ids = {e.get("id") for e in existing_events}
    for event in all_events:
        if event["id"] not in existing_event_ids:
            existing_events.append(event)

    existing_events.sort(key=lambda e: e.get("start", ""))

    with open(cal_path, "w") as f:
        json.dump(existing_events, f, indent=2)
    log(f"Saved {len(existing_events)} total events to {cal_path.name}")

    # Update state
    state["last_sync"] = {
        "timestamp": datetime.now().isoformat(),
        "accounts": len(ms_accounts),
        "new_emails": len(all_emails),
        "new_events": len(all_events),
    }
    save_state(state)

    if creds_updated:
        save_credentials(creds_data)
        log("Credentials refreshed and saved")

    log("Outlook sync complete")


if __name__ == "__main__":
    main()
