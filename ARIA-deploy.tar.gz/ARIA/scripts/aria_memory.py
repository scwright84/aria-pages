"""
ARIA Memory Layer — Semantic search across all communications.

Indexes emails, Slack, meetings, commitments, and briefings into Qdrant.
Enables natural language queries like:
  - "What did we discuss with Conceivable about HIPAA?"
  - "When did Jac last mention the proposal?"
  - "What commitments are outstanding from last week's meetings?"

Architecture:
  - Embeddings: nomic-embed-text via local inference (768 dim)
  - Storage: Qdrant (localhost:6333, Docker container)
  - Index: One collection per data type (emails, slack, meetings, commitments, briefings)
  - Dedup: Content hash prevents re-indexing unchanged documents

All ARIA scripts can import this module for semantic search.
"""

import hashlib
import json
import logging
import os
import re
from datetime import datetime, timedelta
from pathlib import Path

import requests

logger = logging.getLogger("aria_memory")

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
STATE_FILE = PROJECT_DIR / "logs" / "memory-state.json"

QDRANT_URL = "http://localhost:6333"
EMBEDDING_URL = "http://localhost:11434/v1/embeddings"
EMBEDDING_MODEL = "nomic-embed-text"
EMBEDDING_DIM = 768

COLLECTION_NAME = "aria_memory"

# Python-native embedding model (fallback when Ollama embedding endpoint not available)
_st_model = None


def _get_python_embedding(text):
    """Generate embedding using sentence-transformers (Python-native, no server needed)."""
    global _st_model
    try:
        if _st_model is None:
            from sentence_transformers import SentenceTransformer
            _st_model = SentenceTransformer('nomic-ai/nomic-embed-text-v1.5', trust_remote_code=True)
        emb = _st_model.encode([text[:8000]])
        return emb[0].tolist()
    except Exception as e:
        logger.error(f"Python embedding failed: {e}")
        return None


def _get_embedding(text):
    """Generate embedding vector. Tries API first, falls back to Python-native."""
    if not text or len(text.strip()) < 3:
        return None
    text = text[:8000]

    # Try API endpoint first (Ollama or compatible)
    try:
        resp = requests.post(EMBEDDING_URL, json={
            "model": EMBEDDING_MODEL,
            "input": text,
        }, timeout=15)
        if resp.status_code == 200:
            data = resp.json()
            return data["data"][0]["embedding"]
    except Exception:
        pass

    # Fallback to Python-native embeddings
    return _get_python_embedding(text)


def _content_hash(text):
    """Generate a hash for deduplication."""
    return hashlib.md5(text.encode()).hexdigest()


def _load_state():
    if STATE_FILE.exists():
        with open(STATE_FILE) as f:
            return json.load(f)
    return {"indexed_hashes": [], "last_index": None}


def _save_state(state):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    # Keep only last 5000 hashes
    state["indexed_hashes"] = state.get("indexed_hashes", [])[-5000:]
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def _qdrant_request(method, path, json_data=None):
    """Make a request to Qdrant API."""
    url = f"{QDRANT_URL}{path}"
    try:
        resp = requests.request(method, url, json=json_data, timeout=10)
        return resp.status_code, resp.json() if resp.text else {}
    except Exception as e:
        logger.error(f"Qdrant request failed: {e}")
        return 0, {"error": str(e)}


def ensure_collection():
    """Create the Qdrant collection if it doesn't exist."""
    status, data = _qdrant_request("GET", f"/collections/{COLLECTION_NAME}")
    if status == 200:
        return True

    status, data = _qdrant_request("PUT", f"/collections/{COLLECTION_NAME}", {
        "vectors": {
            "size": EMBEDDING_DIM,
            "distance": "Cosine",
        }
    })

    if status in (200, 201):
        logger.info(f"Created collection: {COLLECTION_NAME}")

        # Create payload indexes for filtering
        for field in ["source", "project", "date"]:
            _qdrant_request("PUT", f"/collections/{COLLECTION_NAME}/index", {
                "field_name": field,
                "field_schema": "keyword" if field != "date" else "keyword",
            })

        return True
    else:
        logger.error(f"Failed to create collection: {data}")
        return False


def index_document(doc_id, text, metadata):
    """Index a single document into Qdrant."""
    embedding = _get_embedding(text)
    if embedding is None:
        return False

    # Use consistent integer ID from hash
    point_id = int(hashlib.md5(doc_id.encode()).hexdigest()[:15], 16)

    status, data = _qdrant_request("PUT", f"/collections/{COLLECTION_NAME}/points", {
        "points": [{
            "id": point_id,
            "vector": embedding,
            "payload": {
                "doc_id": doc_id,
                "text": text[:2000],  # Store truncated text for retrieval
                **metadata,
            }
        }]
    })

    return status in (200, 201)


def search(query, limit=5, source_filter=None, project_filter=None):
    """
    Semantic search across all indexed communications.

    Args:
        query: Natural language query
        limit: Max results to return
        source_filter: Filter by source type ("email", "slack", "meeting", "commitment", "briefing")
        project_filter: Filter by project name

    Returns:
        List of dicts with text, metadata, and similarity score
    """
    embedding = _get_embedding(query)
    if embedding is None:
        return []

    # Build filter
    must_conditions = []
    if source_filter:
        must_conditions.append({"key": "source", "match": {"value": source_filter}})
    if project_filter:
        must_conditions.append({"key": "project", "match": {"value": project_filter}})

    search_params = {
        "vector": embedding,
        "limit": limit,
        "with_payload": True,
    }
    if must_conditions:
        search_params["filter"] = {"must": must_conditions}

    status, data = _qdrant_request("POST", f"/collections/{COLLECTION_NAME}/points/search", search_params)

    if status != 200:
        logger.error(f"Search failed: {data}")
        return []

    results = []
    for hit in data.get("result", []):
        payload = hit.get("payload", {})
        results.append({
            "text": payload.get("text", ""),
            "source": payload.get("source", ""),
            "project": payload.get("project"),
            "from": payload.get("from_name"),
            "subject": payload.get("subject"),
            "date": payload.get("date"),
            "score": hit.get("score", 0),
        })

    return results


def _parse_date(val):
    """Parse various date formats to string."""
    if val is None:
        return None
    if isinstance(val, (int, float)) or (isinstance(val, str) and val.isdigit()):
        ts = int(val)
        if ts > 1e12:
            ts = ts / 1000
        try:
            return datetime.fromtimestamp(ts).strftime("%Y-%m-%d")
        except (ValueError, OSError):
            return None
    if isinstance(val, str) and len(val) >= 10:
        return val[:10]
    return None


def index_inbox(days_back=7):
    """Index all inbox data from the past N days into Qdrant."""
    state = _load_state()
    indexed_hashes = set(state.get("indexed_hashes", []))
    new_count = 0
    skip_count = 0

    def _load_files(prefix):
        all_data = []
        for day_offset in range(days_back):
            date = datetime.now() - timedelta(days=day_offset)
            date_str = date.strftime("%Y-%m-%d")
            path = INBOX_DIR / f"{prefix}-{date_str}.json"
            if path.exists():
                try:
                    with open(path) as f:
                        data = json.load(f)
                    if isinstance(data, list):
                        for item in data:
                            item["_file_date"] = date_str
                        all_data.extend(data)
                except (json.JSONDecodeError, IOError):
                    pass
        return all_data

    # Index emails
    for e in _load_files("emails"):
        subject = e.get("subject", "")
        snippet = e.get("snippet", "")
        summary = e.get("summary", "")
        text = f"Subject: {subject}\n{summary or snippet}"
        h = _content_hash(text)
        if h in indexed_hashes:
            skip_count += 1
            continue

        sender = e.get("from", "")
        if "<" in sender:
            from_name = sender.split("<")[0].strip().strip('"')
        else:
            from_name = sender

        doc_id = e.get("message_id") or f"email:{h}"
        ok = index_document(doc_id, text, {
            "source": "email",
            "project": e.get("detected_project"),
            "from_name": from_name,
            "subject": subject,
            "date": _parse_date(e.get("date") or e.get("processed_at")),
            "priority": e.get("priority"),
        })
        if ok:
            indexed_hashes.add(h)
            new_count += 1

    # Index Slack
    for s in _load_files("slack"):
        summary = s.get("summary", "")
        topics = ", ".join(s.get("key_topics", []))
        text = f"Slack #{s.get('channel_name', '')}: {summary}\nTopics: {topics}"
        h = _content_hash(text)
        if h in indexed_hashes:
            skip_count += 1
            continue

        doc_id = f"slack:{s.get('channel_name', '')}:{s.get('_file_date', '')}"
        ok = index_document(doc_id, text, {
            "source": "slack",
            "project": s.get("project"),
            "from_name": ", ".join(s.get("key_people", [])),
            "subject": f"#{s.get('channel_name', '')}",
            "date": _parse_date(s.get("processed_at")) or s.get("_file_date"),
        })
        if ok:
            indexed_hashes.add(h)
            new_count += 1

    # Index commitments
    for a in _load_files("awaiting"):
        task = a.get("task", "")
        if len(task) < 10:
            continue
        text = f"Commitment: {task}\nOwner: {a.get('owner', '')}\nMeeting: {a.get('meeting', '')}"
        h = _content_hash(text)
        if h in indexed_hashes:
            skip_count += 1
            continue

        doc_id = f"commitment:{h}"
        ok = index_document(doc_id, text, {
            "source": "commitment",
            "project": a.get("project"),
            "from_name": a.get("owner"),
            "subject": a.get("meeting"),
            "date": a.get("meeting_date") or a.get("_file_date"),
        })
        if ok:
            indexed_hashes.add(h)
            new_count += 1

    # Index briefings (JSON structured data)
    for bf in sorted(BRIEFINGS_DIR.glob("????-??-??.json"), reverse=True)[:days_back]:
        try:
            with open(bf) as f:
                data = json.load(f)
        except (json.JSONDecodeError, IOError):
            continue

        date_str = bf.stem
        sections = data.get("sections", data)
        if isinstance(sections, dict):
            # Index each section separately for better retrieval
            for section_name, content in sections.items():
                if isinstance(content, str):
                    text = f"Briefing {date_str} - {section_name}: {content}"
                elif isinstance(content, list):
                    text = f"Briefing {date_str} - {section_name}: {json.dumps(content, default=str)[:1000]}"
                else:
                    continue

                h = _content_hash(text)
                if h in indexed_hashes:
                    skip_count += 1
                    continue

                doc_id = f"briefing:{date_str}:{section_name}"
                ok = index_document(doc_id, text, {
                    "source": "briefing",
                    "project": None,
                    "from_name": "ARIA",
                    "subject": f"Briefing: {section_name}",
                    "date": date_str,
                })
                if ok:
                    indexed_hashes.add(h)
                    new_count += 1

    # Save state
    state["indexed_hashes"] = list(indexed_hashes)
    state["last_index"] = datetime.now().isoformat()
    _save_state(state)

    return {"new": new_count, "skipped": skip_count, "total_indexed": len(indexed_hashes)}


def get_collection_stats():
    """Get stats about the memory collection."""
    status, data = _qdrant_request("GET", f"/collections/{COLLECTION_NAME}")
    if status == 200:
        result = data.get("result", {})
        return {
            "vectors_count": result.get("vectors_count", 0),
            "points_count": result.get("points_count", 0),
            "status": result.get("status", "unknown"),
        }
    return {"vectors_count": 0, "points_count": 0, "status": "not_found"}
