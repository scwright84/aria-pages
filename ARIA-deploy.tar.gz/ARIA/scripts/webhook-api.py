#!/usr/bin/env python3
"""
ARIA Webhook API (FEAT-099)
Inbound webhook endpoints so external tools (Zapier, Make, n8n, custom) can
push data into ARIA's inbox.

Endpoints:
  POST /webhook/email     - Push an email-like object
  POST /webhook/note      - Push a note/memo
  POST /webhook/event     - Push a calendar event
  POST /webhook/task      - Push a task/action item
  POST /webhook/generic   - Push any JSON data (gets stored as-is)
  GET  /webhook/status    - Check webhook health

Authentication: Bearer token (set ARIA_WEBHOOK_TOKEN in .env)

Runs on port 8648. Data gets saved to inbox/ in the standard format.
"""

import json
import os
import sys
from datetime import datetime
from functools import wraps
from pathlib import Path

from flask import Flask, Response, request, abort

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
ENV_FILE = PROJECT_DIR / ".env"
LOG_FILE = PROJECT_DIR / "logs" / "webhook-api.log"

app = Flask(__name__)


def load_env():
    if ENV_FILE.exists():
        with open(ENV_FILE) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, value = line.partition("=")
                    if key.strip() and key.strip() not in os.environ:
                        os.environ[key.strip()] = value.strip().strip("'\"")


load_env()
WEBHOOK_TOKEN = os.environ.get("ARIA_WEBHOOK_TOKEN", "aria-webhook-2026")


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def require_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        token = request.args.get("token", "")
        if auth == f"Bearer {WEBHOOK_TOKEN}" or token == WEBHOOK_TOKEN:
            return f(*args, **kwargs)
        abort(401)
    return decorated


def save_to_inbox(prefix, data):
    """Save data to inbox as a dated JSON file."""
    INBOX_DIR.mkdir(parents=True, exist_ok=True)
    date_str = datetime.now().strftime("%Y-%m-%d")
    path = INBOX_DIR / f"{prefix}-{date_str}.json"

    existing = []
    if path.exists():
        try:
            with open(path) as f:
                existing = json.load(f)
        except Exception:
            pass

    if isinstance(existing, list):
        existing.append(data)
    else:
        existing = [existing, data]

    with open(path, "w") as f:
        json.dump(existing, f, indent=2, default=str)

    return path.name


@app.route("/webhook/email", methods=["POST"])
@require_auth
def webhook_email():
    data = request.json
    if not data:
        return json.dumps({"error": "No JSON body"}), 400
    data["source"] = data.get("source", "webhook")
    data["processed_at"] = datetime.now().isoformat()
    filename = save_to_inbox("emails", data)
    log(f"Email webhook: {data.get('subject', '?')[:50]} -> {filename}")
    return json.dumps({"status": "ok", "saved_to": filename}), 200


@app.route("/webhook/note", methods=["POST"])
@require_auth
def webhook_note():
    data = request.json
    if not data:
        return json.dumps({"error": "No JSON body"}), 400
    data["source"] = "webhook"
    data["processed_at"] = datetime.now().isoformat()
    filename = save_to_inbox("notes", data)
    log(f"Note webhook: {data.get('title', '?')[:50]} -> {filename}")
    return json.dumps({"status": "ok", "saved_to": filename}), 200


@app.route("/webhook/event", methods=["POST"])
@require_auth
def webhook_event():
    data = request.json
    if not data:
        return json.dumps({"error": "No JSON body"}), 400
    data["source"] = "webhook"
    filename = save_to_inbox("calendar", data)
    log(f"Event webhook: {data.get('summary', '?')[:50]} -> {filename}")
    return json.dumps({"status": "ok", "saved_to": filename}), 200


@app.route("/webhook/task", methods=["POST"])
@require_auth
def webhook_task():
    data = request.json
    if not data:
        return json.dumps({"error": "No JSON body"}), 400
    data["source"] = "webhook"
    data["created_at"] = datetime.now().isoformat()

    # Also add to task list
    sys.path.insert(0, str(Path(__file__).parent))
    try:
        from task_extractor import load_existing_tasks, save_tasks
        tasks = load_existing_tasks()
        import hashlib
        data["id"] = hashlib.md5(f"webhook:{data.get('title','')}:{datetime.now()}".encode()).hexdigest()[:12]
        data["status"] = "open"
        tasks["tasks"].append(data)
        save_tasks(tasks)
    except Exception:
        pass

    filename = save_to_inbox("tasks-webhook", data)
    log(f"Task webhook: {data.get('title', '?')[:50]} -> {filename}")
    return json.dumps({"status": "ok", "saved_to": filename}), 200


@app.route("/webhook/generic", methods=["POST"])
@require_auth
def webhook_generic():
    data = request.json
    if not data:
        return json.dumps({"error": "No JSON body"}), 400
    data["_webhook_received"] = datetime.now().isoformat()
    prefix = data.get("_type", "webhook")
    filename = save_to_inbox(prefix, data)
    log(f"Generic webhook ({prefix}): -> {filename}")
    return json.dumps({"status": "ok", "saved_to": filename}), 200


@app.route("/webhook/status")
def webhook_status():
    return json.dumps({
        "status": "ok",
        "service": "ARIA Webhook API",
        "endpoints": ["/webhook/email", "/webhook/note", "/webhook/event", "/webhook/task", "/webhook/generic"],
        "auth": "Bearer token or ?token= query param",
    }), 200


@app.route("/healthz")
def healthz():
    return "ok", 200


def main():
    print(f"ARIA Webhook API running at http://localhost:8648")
    print(f"Auth token: {WEBHOOK_TOKEN[:10]}...")
    app.run(host="127.0.0.1", port=8648, debug=False)


if __name__ == "__main__":
    main()
