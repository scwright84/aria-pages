#!/usr/bin/env python3
"""
ARIA Notification Intelligence
Smart routing and prioritization of macOS notifications (iMessage, WhatsApp,
Signal, Telegram, etc.)

Takes raw notifications from notification-sync and:
  1. Classifies by priority (urgent, important, routine, noise)
  2. Identifies the sender and matches to contact profiles
  3. Routes: urgent → Telegram alert, important → next brief, routine → log only
  4. Suppresses noise (app updates, promotions, system notifications)
  5. Tracks notification volume per app for anomaly detection

Output: inbox/notifications-YYYY-MM-DD.json (enriched with priority/routing)
Runs after notification-sync, or processes existing notification files.
"""

import json
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import aria_ai

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
CONTACTS_FILE = PROJECT_DIR / "config" / "contacts.json"
LOG_FILE = PROJECT_DIR / "logs" / "notification-intelligence.log"

# App classification
MESSAGING_APPS = {
    "com.apple.MobileSMS": {"name": "iMessage", "type": "personal", "priority_base": "important"},
    "net.whatsapp.WhatsApp": {"name": "WhatsApp", "type": "personal", "priority_base": "important"},
    "org.whispersystems.signal": {"name": "Signal", "type": "personal", "priority_base": "important"},
    "ph.telegra.Telegraph": {"name": "Telegram", "type": "mixed", "priority_base": "normal"},
    "com.facebook.Messenger": {"name": "Messenger", "type": "personal", "priority_base": "normal"},
}

WORK_APPS = {
    "com.tinyspeck.slackmacgap": {"name": "Slack", "type": "work", "priority_base": "normal"},
    "us.zoom.xos": {"name": "Zoom", "type": "work", "priority_base": "important"},
    "com.microsoft.teams2": {"name": "Teams", "type": "work", "priority_base": "normal"},
}

NOISE_APPS = {
    "com.apple.AppStore", "com.apple.systempreferences", "com.apple.SoftwareUpdate",
    "com.apple.ScreenTime", "com.apple.findmy", "com.apple.Tips",
    "com.apple.reminders", "com.apple.Photos",
}

# Urgent keywords (in notification body/title)
URGENT_KEYWORDS = [
    r"urgent", r"emergency", r"asap", r"immediately", r"call me",
    r"911", r"help", r"critical", r"down", r"broken",
    r"sick", r"hospital", r"accident",
]


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_contacts():
    if CONTACTS_FILE.exists():
        try:
            with open(CONTACTS_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def classify_notification(notification, contacts):
    """Classify a notification by priority and routing."""
    app_id = notification.get("app_identifier", "")
    app_name = notification.get("app_name", "")
    title = notification.get("title", "")
    body = notification.get("body", "")
    text = f"{title} {body}".lower()

    result = {
        "priority": "routine",
        "routing": "log",  # log, brief, alert
        "category": "unknown",
        "suppress": False,
        "sender_name": title,  # Best guess: title is often the sender name
        "contact_match": None,
    }

    # Suppress noise apps entirely
    if app_id in NOISE_APPS:
        result["priority"] = "noise"
        result["routing"] = "suppress"
        result["suppress"] = True
        result["category"] = "system"
        return result

    # Check for urgent keywords
    for pattern in URGENT_KEYWORDS:
        if re.search(pattern, text, re.IGNORECASE):
            result["priority"] = "urgent"
            result["routing"] = "alert"
            result["category"] = "urgent"
            return result

    # Messaging app classification
    app_config = MESSAGING_APPS.get(app_id) or WORK_APPS.get(app_id)
    if app_config:
        result["category"] = app_config["type"]
        result["priority"] = app_config["priority_base"]

        # Match sender against contacts
        sender = title.split(":")[0].strip() if ":" in title else title
        for key, contact in contacts.items():
            contact_name = contact.get("name", "")
            if contact_name and contact_name.lower() in sender.lower():
                result["contact_match"] = contact_name
                result["sender_name"] = contact_name
                # Boost priority for contacts in active projects
                projects = contact.get("projects", [])
                if projects:
                    result["priority"] = "important"
                    result["routing"] = "brief"
                break

        # iMessage/WhatsApp from unknown = still important (personal)
        if app_config["type"] == "personal" and not result["contact_match"]:
            result["routing"] = "brief"

    # Default: unknown apps go to log
    if result["routing"] == "log" and result["priority"] in ("important", "urgent"):
        result["routing"] = "brief"

    return result


def process_notifications(notifications, contacts):
    """Process a batch of notifications and enrich with intelligence."""
    enriched = []
    stats = Counter()

    for n in notifications:
        classification = classify_notification(n, contacts)
        n["_intelligence"] = classification
        enriched.append(n)

        stats[classification["routing"]] += 1
        stats[f"priority_{classification['priority']}"] += 1

    return enriched, dict(stats)


def generate_summary(enriched):
    """Generate a notification summary for inclusion in briefings."""
    alerts = [n for n in enriched if n.get("_intelligence", {}).get("routing") == "alert"]
    important = [n for n in enriched if n.get("_intelligence", {}).get("routing") == "brief"]
    suppressed = [n for n in enriched if n.get("_intelligence", {}).get("suppress")]

    # Group by app
    by_app = defaultdict(list)
    for n in enriched:
        if not n.get("_intelligence", {}).get("suppress"):
            by_app[n.get("app_name", "Unknown")].append(n)

    summary = {
        "total": len(enriched),
        "alerts": len(alerts),
        "important": len(important),
        "suppressed": len(suppressed),
        "by_app": {app: len(notifs) for app, notifs in by_app.items()},
        "alert_details": [
            {"app": n.get("app_name"), "sender": n.get("_intelligence", {}).get("sender_name"), "text": n.get("body", "")[:100]}
            for n in alerts
        ],
        "important_details": [
            {"app": n.get("app_name"), "sender": n.get("_intelligence", {}).get("sender_name"), "text": n.get("body", "")[:100]}
            for n in important[:10]
        ],
    }

    return summary


def main():
    log("Starting notification intelligence")
    contacts = load_contacts()

    # Process today's notifications
    date_str = datetime.now().strftime("%Y-%m-%d")
    notif_file = INBOX_DIR / f"notifications-{date_str}.json"

    if not notif_file.exists():
        log("No notification file for today. Nothing to process.")
        return 0

    with open(notif_file) as f:
        notifications = json.load(f)

    log(f"Processing {len(notifications)} notifications")

    enriched, stats = process_notifications(notifications, contacts)
    summary = generate_summary(enriched)

    # Save enriched notifications back
    with open(notif_file, "w") as f:
        json.dump(enriched, f, indent=2, default=str)

    # Save summary for briefing consumption
    summary_path = INBOX_DIR / f"notification-summary-{date_str}.json"
    with open(summary_path, "w") as f:
        json.dump(summary, f, indent=2, default=str)

    log(f"Stats: {json.dumps(stats)}")
    log(f"Alerts: {summary['alerts']}")
    log(f"Important: {summary['important']}")
    log(f"Suppressed: {summary['suppressed']}")

    if summary["alert_details"]:
        log("URGENT notifications:")
        for a in summary["alert_details"]:
            log(f"  [{a['app']}] {a['sender']}: {a['text']}")

    log("Notification intelligence complete")
    return 0


if __name__ == "__main__":
    sys.exit(main())
