#!/bin/bash
# Start the ARIA Docker stack (postgres + n8n only, no qdrant)
cd "$HOME/self-hosted-ai-starter-kit"
docker compose up postgres n8n-import n8n -d 2>&1
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Stack started" >> "$HOME/Desktop/dev projects/ARIA/logs/stack.log"
