#!/usr/bin/env python3
"""
ARIA Calendar Sync (Direct)
Fetches events from connected Google Calendar accounts using stored OAuth credentials.
No dependency on n8n for calendar data.

Reads credentials from config/credentials.json (created by onboarding server).
Saves to inbox/calendar-YYYY-MM-DD.json.

Runs via launchd or manually.
"""

import json
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
CREDENTIALS_FILE = PROJECT_DIR / "config" / "credentials.json"
LOG_FILE = PROJECT_DIR / "logs" / "calendar-sync.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_credentials():
    if CREDENTIALS_FILE.exists():
        with open(CREDENTIALS_FILE) as f:
            return json.load(f)
    return {"accounts": []}


def save_credentials(creds_data):
    with open(CREDENTIALS_FILE, "w") as f:
        json.dump(creds_data, f, indent=2)


def get_calendar_credentials(account):
    """Build Google credentials from stored account data."""
    creds = Credentials(
        token=account.get("access_token"),
        refresh_token=account.get("refresh_token"),
        token_uri=account.get("token_uri", "https://oauth2.googleapis.com/token"),
        client_id=account.get("client_id"),
        client_secret=account.get("client_secret"),
        scopes=account.get("scopes", []),
    )
    if creds.expired and creds.refresh_token:
        try:
            creds.refresh(Request())
            account["access_token"] = creds.token
            return creds, True
        except Exception as e:
            log(f"  Token refresh failed for {account.get('email')}: {e}")
            return None, False
    return creds, False


def fetch_events(account, days_ahead=7):
    """Fetch upcoming events from a Google Calendar account."""
    creds, refreshed = get_calendar_credentials(account)
    if creds is None:
        return [], refreshed

    try:
        service = build("calendar", "v3", credentials=creds)
        now = datetime.utcnow()
        time_min = now.isoformat() + "Z"
        time_max = (now + timedelta(days=days_ahead)).isoformat() + "Z"

        events_result = service.events().list(
            calendarId="primary",
            timeMin=time_min,
            timeMax=time_max,
            maxResults=50,
            singleEvents=True,
            orderBy="startTime",
        ).execute()

        events = []
        for event in events_result.get("items", []):
            start = event.get("start", {})
            end = event.get("end", {})
            attendees = event.get("attendees", [])

            events.append({
                "id": event.get("id", ""),
                "account": account.get("email"),
                "summary": event.get("summary", "(no title)"),
                "start": start.get("dateTime", start.get("date", "")),
                "end": end.get("dateTime", end.get("date", "")),
                "location": event.get("location", ""),
                "description": (event.get("description", "") or "")[:500],
                "attendees": [
                    {
                        "email": a.get("email", ""),
                        "name": a.get("displayName", ""),
                        "response": a.get("responseStatus", ""),
                    }
                    for a in attendees
                ],
                "hangout_link": event.get("hangoutLink", ""),
                "html_link": event.get("htmlLink", ""),
                "status": event.get("status", "confirmed"),
            })

        return events, refreshed
    except Exception as e:
        log(f"  Calendar API error for {account.get('email')}: {e}")
        return [], refreshed


def main():
    log("Starting calendar sync (direct)...")
    INBOX_DIR.mkdir(parents=True, exist_ok=True)

    creds_data = load_credentials()
    all_events = []
    creds_updated = False

    # Find all calendar accounts
    cal_accounts = [a for a in creds_data.get("accounts", []) if "calendar" in a.get("services", [])]

    if not cal_accounts:
        log("No calendar accounts connected. Run the onboarding server to connect accounts.")
        return

    for account in cal_accounts:
        email_addr = account.get("email", "unknown")
        log(f"Fetching calendar from {email_addr}...")

        events, refreshed = fetch_events(account, days_ahead=7)
        if refreshed:
            creds_updated = True

        log(f"  {len(events)} events found")
        all_events.extend(events)

    # Deduplicate by event ID (same event may appear in multiple calendars)
    seen_ids = set()
    unique_events = []
    for event in all_events:
        eid = event["id"]
        if eid not in seen_ids:
            seen_ids.add(eid)
            unique_events.append(event)

    # Sort by start time
    unique_events.sort(key=lambda e: e.get("start", ""))

    # Save to inbox
    date_str = datetime.now().strftime("%Y-%m-%d")
    output_path = INBOX_DIR / f"calendar-{date_str}.json"

    with open(output_path, "w") as f:
        json.dump(unique_events, f, indent=2)
    log(f"Saved {len(unique_events)} events to {output_path.name}")

    # Save updated credentials if refreshed
    if creds_updated:
        save_credentials(creds_data)
        log("Credentials refreshed and saved")

    log("Calendar sync complete")


if __name__ == "__main__":
    main()
