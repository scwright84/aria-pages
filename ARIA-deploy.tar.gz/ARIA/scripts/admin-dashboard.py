#!/usr/bin/env python3
"""
ARIA Admin Dashboard (Sean's Multi-Tenant View)
Overview of all client deployments at a glance.

Shows per client:
  - System health (green/yellow/red)
  - Last briefing generated
  - Data freshness
  - Monthly revenue
  - Deployment details
  - Quick action links (SSH, dashboard, status page)

For local clients: polls their /api/status endpoint directly.
For remote clients (via Tailscale): polls via Tailscale IP.

Runs on port 8645. Sean's eyes only.
"""

import json
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

import requests
from flask import Flask, Response

PROJECT_DIR = Path(__file__).parent.parent
REGISTRY_FILE = PROJECT_DIR / "config" / "clients-registry.json"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"

app = Flask(__name__)


def load_registry():
    if REGISTRY_FILE.exists():
        with open(REGISTRY_FILE) as f:
            return json.load(f)
    return {"clients": []}


def poll_client_status(client):
    """Poll a client's status endpoint."""
    url = client.get("status_url")
    if not url:
        return {"overall": "unknown", "overall_text": "No status URL configured", "stats": {}}

    try:
        resp = requests.get(url, timeout=5)
        if resp.status_code == 200:
            return resp.json()
        return {"overall": "red", "overall_text": f"Status returned {resp.status_code}", "stats": {}}
    except requests.exceptions.ConnectionError:
        return {"overall": "red", "overall_text": "Unreachable", "stats": {}}
    except requests.exceptions.Timeout:
        return {"overall": "yellow", "overall_text": "Timeout", "stats": {}}
    except Exception as e:
        return {"overall": "red", "overall_text": str(e)[:100], "stats": {}}


def get_local_stats():
    """Get quick stats for local reference deployment."""
    stats = {}

    # Inbox file count
    inbox = PROJECT_DIR / "inbox"
    if inbox.exists():
        stats["inbox_files"] = len(list(inbox.glob("*.json")))

    # Briefing count
    if BRIEFINGS_DIR.exists():
        stats["briefing_files"] = len(list(BRIEFINGS_DIR.glob("*.html")))

    # Today's briefing
    today = datetime.now().strftime("%Y-%m-%d")
    stats["today_briefing"] = (BRIEFINGS_DIR / f"{today}.html").exists()

    # Contacts
    contacts_file = PROJECT_DIR / "config" / "contacts.json"
    if contacts_file.exists():
        with open(contacts_file) as f:
            stats["contacts"] = len(json.load(f))

    # Latest scorecard
    scorecards = sorted(BRIEFINGS_DIR.glob("*-scorecard.json"), reverse=True)
    if scorecards:
        with open(scorecards[0]) as f:
            scorecard = json.load(f)
        stats["scorecard_projects"] = len(scorecard)
        grades = [m.get("health_grade", "?") for m in scorecard.values()]
        stats["scorecard_summary"] = ", ".join(f"{g}:{grades.count(g)}" for g in sorted(set(grades)))

    return stats


def render_dashboard():
    """Render the admin dashboard."""
    registry = load_registry()
    clients = registry.get("clients", [])
    now = datetime.now()

    colors = {"green": "#22c55e", "yellow": "#eab308", "red": "#ef4444", "unknown": "#9ca3af"}
    dots = {"green": "&#x25CF;", "yellow": "&#x25CF;", "red": "&#x25CF;", "unknown": "&#x25CB;"}

    # Build client rows
    client_cards = ""
    total_mrr = 0

    for client in clients:
        status = poll_client_status(client)
        color = colors.get(status.get("overall", "unknown"), colors["unknown"])
        dot = dots.get(status.get("overall", "unknown"), dots["unknown"])

        monthly = client.get("monthly_fee", 0)
        total_mrr += monthly

        # Links
        links = []
        if client.get("dashboard_url"):
            links.append(f'<a href="{client["dashboard_url"]}" target="_blank">Dashboard</a>')
        if client.get("status_url"):
            status_page = client["status_url"].replace("/api/status", "")
            links.append(f'<a href="{status_page}" target="_blank">Status</a>')
        if client.get("tailscale_ip"):
            links.append(f'<a href="ssh://{client["tailscale_ip"]}">SSH</a>')
        links_html = " &middot; ".join(links) if links else "-"

        # Services summary
        services = status.get("stats", {})
        service_dots = ""
        for svc in ["inference", "n8n", "briefing", "telegram"]:
            s = services.get(svc, {})
            svc_ok = s.get("ok", False) if isinstance(s, dict) else False
            svc_color = colors["green"] if svc_ok else colors["red"]
            svc_label = s.get("label", svc) if isinstance(s, dict) else svc
            service_dots += f'<span title="{svc_label}" style="color:{svc_color};font-size:14px;margin:0 2px">&#x25CF;</span>'

        # Issues
        issues = status.get("issues", []) + status.get("warnings", [])
        issues_html = f'<span style="color:#ef4444;font-size:12px">{len(issues)} issue(s)</span>' if issues else '<span style="color:#22c55e;font-size:12px">OK</span>'

        setup_date = client.get("setup_date", "-")
        if setup_date != "-":
            days_active = (now - datetime.strptime(setup_date, "%Y-%m-%d")).days
            setup_display = f'{setup_date} ({days_active}d)'
        else:
            setup_display = "-"

        client_cards += f"""
        <tr>
            <td><span style="color:{color};font-size:20px;margin-right:8px">{dot}</span> <strong>{client["name"]}</strong><br><span style="font-size:12px;color:#6b7280">{client.get("type", "-")} | {client.get("hardware", "-")}</span></td>
            <td style="text-align:center">{service_dots}</td>
            <td style="text-align:center">{issues_html}</td>
            <td style="text-align:center">${monthly}/mo</td>
            <td style="font-size:12px">{setup_display}</td>
            <td style="font-size:12px">{links_html}</td>
        </tr>"""

    # Local stats for Sean's deployment
    local_stats = get_local_stats()
    stats_html = f"""
    <div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:24px">
        <div style="background:white;border-radius:8px;padding:12px 16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);flex:1;min-width:120px">
            <div style="font-size:24px;font-weight:700;color:#111827">{len(clients)}</div>
            <div style="font-size:12px;color:#6b7280">Deployments</div>
        </div>
        <div style="background:white;border-radius:8px;padding:12px 16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);flex:1;min-width:120px">
            <div style="font-size:24px;font-weight:700;color:#22c55e">${total_mrr}</div>
            <div style="font-size:12px;color:#6b7280">Monthly Revenue</div>
        </div>
        <div style="background:white;border-radius:8px;padding:12px 16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);flex:1;min-width:120px">
            <div style="font-size:24px;font-weight:700;color:#111827">{local_stats.get('contacts', 0)}</div>
            <div style="font-size:12px;color:#6b7280">Contacts Tracked</div>
        </div>
        <div style="background:white;border-radius:8px;padding:12px 16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);flex:1;min-width:120px">
            <div style="font-size:24px;font-weight:700;color:#111827">{local_stats.get('scorecard_summary', '-')}</div>
            <div style="font-size:12px;color:#6b7280">Project Health</div>
        </div>
    </div>"""

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="120">
<title>ARIA Admin Dashboard</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #0f172a; color: #e2e8f0; min-height: 100vh; }}
  .container {{ max-width: 1200px; margin: 0 auto; padding: 24px 16px; }}
  h1 {{ font-size: 20px; font-weight: 600; margin-bottom: 4px; }}
  .subtitle {{ color: #64748b; font-size: 13px; margin-bottom: 24px; }}
  table {{ width: 100%; border-collapse: collapse; background: #1e293b; border-radius: 8px; overflow: hidden; }}
  th {{ background: #334155; padding: 10px 12px; text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; color: #94a3b8; }}
  td {{ padding: 12px; border-bottom: 1px solid #334155; font-size: 14px; }}
  tr:last-child td {{ border-bottom: none; }}
  tr:hover {{ background: #253347; }}
  a {{ color: #60a5fa; text-decoration: none; }}
  a:hover {{ text-decoration: underline; }}
  .footer {{ text-align: center; font-size: 11px; color: #475569; margin-top: 24px; }}
</style>
</head>
<body>
<div class="container">
  <h1>ARIA Admin Dashboard</h1>
  <p class="subtitle">All client deployments | {now.strftime('%b %d, %Y %I:%M %p')} | Auto-refreshes every 2 min</p>

  {stats_html}

  <table>
    <thead>
      <tr>
        <th>Client</th>
        <th style="text-align:center">Services</th>
        <th style="text-align:center">Status</th>
        <th style="text-align:center">MRR</th>
        <th>Since</th>
        <th>Links</th>
      </tr>
    </thead>
    <tbody>
      {client_cards}
    </tbody>
  </table>

  <p class="footer">ARIA Admin | Sean Wright | Wright Advisors</p>
</div>
</body>
</html>"""
    return html


@app.route("/")
def index():
    return Response(render_dashboard(), mimetype="text/html")


@app.route("/api/clients")
def api_clients():
    registry = load_registry()
    clients = registry.get("clients", [])
    result = []
    for client in clients:
        status = poll_client_status(client)
        result.append({**client, "live_status": status})
    return json.dumps(result, default=str), 200, {"Content-Type": "application/json"}


@app.route("/healthz")
def healthz():
    return "ok", 200


def main():
    print("ARIA Admin Dashboard running at http://localhost:8645")
    print("Sean's eyes only. Shows all client deployments.")
    app.run(host="127.0.0.1", port=8645, debug=False)


if __name__ == "__main__":
    main()
