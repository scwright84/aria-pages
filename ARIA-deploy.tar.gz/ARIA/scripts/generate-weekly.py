#!/usr/bin/env python3
"""
ARIA Weekly Strategic Rollup
Portfolio-level view: per-client activity, decisions made, commitments
given/owed, upcoming week preview, engagement trends.

Runs Sunday at 7pm via launchd, or manually anytime.
"""

import json
import os
import re
import requests
from datetime import datetime, timedelta
from pathlib import Path
from collections import defaultdict

PROJECT_DIR = Path(__file__).parent.parent
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
INBOX_DIR = PROJECT_DIR / "inbox"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
LOG_FILE = PROJECT_DIR / "logs" / "weekly.log"

GRANOLA_CACHE = os.path.expanduser(
    "~/Library/Application Support/Granola/cache-v6.json"
)
import aria_ai


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def collect_week_data(source_prefix, days=7):
    """Collect all inbox data for a given source over N days."""
    items = []
    today = datetime.now()
    for days_back in range(days):
        date_str = (today - timedelta(days=days_back)).strftime("%Y-%m-%d")
        path = INBOX_DIR / f"{source_prefix}-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                if isinstance(data, list):
                    items.extend(data)
            except Exception:
                continue
    return items


def collect_notion_tasks():
    try:
        resp = requests.post(
            "http://localhost:5678/webhook/aria-query-tasks",
            json={},
            timeout=15,
        )
        if resp.status_code == 200:
            return resp.json().get("tasks", [])
        return []
    except Exception:
        return []


def collect_granola_week(days=7):
    """Get meetings from the last N days from Granola."""
    cutoff = datetime.now() - timedelta(days=days)
    meetings = []
    try:
        with open(GRANOLA_CACHE) as f:
            data = json.load(f)
        state = data.get("cache", {}).get("state", {})
        documents = state.get("documents", {})

        for doc_id, doc in documents.items():
            if not isinstance(doc, dict):
                continue
            updated = doc.get("updated_at", doc.get("created_at", ""))
            if not updated:
                continue
            try:
                doc_time = datetime.fromisoformat(updated.replace("Z", "+00:00")).replace(tzinfo=None)
                if doc_time < cutoff:
                    continue
            except (ValueError, TypeError):
                continue

            people = []
            raw_people = doc.get("people", {})
            if isinstance(raw_people, dict):
                for pid, person in raw_people.items():
                    if isinstance(person, dict):
                        people.append(person.get("name", ""))
            elif isinstance(raw_people, list):
                people = raw_people

            meetings.append({
                "title": doc.get("title", "Untitled"),
                "date": updated[:10],
                "people": people,
                "notes": (doc.get("notes_markdown", "") or doc.get("notes_plain", ""))[:300],
            })
    except Exception as e:
        log(f"Error reading Granola: {e}")
    return meetings


def call_ai(system_prompt, user_content):
    result = aria_ai.chat(system_prompt, user_content, timeout=240)
    if result is None:
        log("AI inference call failed")
    return result


def generate_weekly_html(date_str, sections):
    """Generate the weekly rollup HTML."""
    week_of = datetime.now().strftime("%B %d, %Y")
    week_start = (datetime.now() - timedelta(days=6)).strftime("%b %d")
    week_end = datetime.now().strftime("%b %d")

    # Client cards
    client_cards_html = ""
    for client in sections.get("client_cards", []):
        activity_color = {"high": "#10B981", "medium": "#F59E0B", "low": "#EF4444", "none": "#9CA3AF"}.get(
            client.get("engagement_level", "none"), "#9CA3AF"
        )
        client_cards_html += f"""
        <div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:12px;box-shadow:0 1px 3px rgba(0,0,0,0.08);border-left:4px solid {activity_color};">
            <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:8px;">
                <h3 style="margin:0;font-size:16px;color:#111827;">{client.get('name', '')}</h3>
                <span style="font-size:12px;color:{activity_color};font-weight:600;text-transform:uppercase;">{client.get('engagement_level', 'unknown')}</span>
            </div>
            <p style="margin:0 0 8px;font-size:14px;color:#374151;">{client.get('summary', '')}</p>
            <div style="font-size:13px;color:#6B7280;">
                {f"Meetings: {client.get('meeting_count', 0)}" if client.get('meeting_count') else ""}
                {f" &middot; Emails: {client.get('email_count', 0)}" if client.get('email_count') else ""}
                {f" &middot; Open tasks: {client.get('open_tasks', 0)}" if client.get('open_tasks') else ""}
            </div>
            {"<div style='font-size:13px;color:#DC2626;margin-top:6px;'>" + client.get('alert', '') + "</div>" if client.get('alert') else ""}
        </div>"""

    # Decisions made
    decisions_html = ""
    for d in sections.get("decisions", []):
        decisions_html += f"""
        <div style="padding:8px 12px;margin-bottom:4px;background:#F0FDF4;border-radius:6px;border-left:3px solid #10B981;">
            <div style="font-size:14px;color:#111827;">{d.get('decision', '')}</div>
            <div style="font-size:12px;color:#6B7280;">{d.get('project', '')} &middot; {d.get('context', '')}</div>
        </div>"""

    # Cracks section
    cracks_html = ""
    for item in sections.get("cracks", []):
        cracks_html += f"""
        <div style="padding:8px 12px;margin-bottom:4px;background:#FEF2F2;border-radius:6px;border-left:3px solid #DC2626;">
            <div style="font-size:14px;color:#111827;">{item.get('description', '')}</div>
            <div style="font-size:12px;color:#6B7280;">{item.get('project', '')} &middot; {item.get('risk', '')}</div>
        </div>"""

    # Next week preview
    next_week_html = ""
    for item in sections.get("next_week", []):
        next_week_html += f"""
        <div style="padding:8px 12px;margin-bottom:4px;background:#EFF6FF;border-radius:6px;border-left:3px solid #3B82F6;">
            <div style="font-size:14px;color:#111827;">{item.get('description', '')}</div>
            <div style="font-size:12px;color:#6B7280;">{item.get('date', '')} &middot; {item.get('project', '')}</div>
        </div>"""

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<title>ARIA Weekly Rollup - {date_str}</title>
</head>
<body style="margin:0;padding:0;background:#F3F4F6;font-family:Poppins,Helvetica,Arial,sans-serif;">
<div style="max-width:680px;margin:0 auto;padding:20px;">

<!-- Header -->
<div style="background:linear-gradient(135deg, #F59E0B 0%, #D97706 100%);border-radius:12px;padding:24px 28px;margin-bottom:20px;">
    <h1 style="margin:0;color:white;font-size:22px;font-weight:700;">ARIA Weekly Rollup</h1>
    <p style="margin:4px 0 0;color:rgba(255,255,255,0.9);font-size:14px;">{week_start} - {week_end}, {datetime.now().year}</p>
    <p style="margin:2px 0 0;color:rgba(255,255,255,0.7);font-size:12px;">Portfolio-level view of the week</p>
</div>

<!-- Executive Summary -->
<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 10px;font-size:16px;color:#111827;">Week in Review</h2>
    <p style="margin:0;font-size:14px;color:#374151;line-height:1.6;">{sections.get('week_summary', 'No data for this week.')}</p>
</div>

<!-- Client Cards -->
{f'''<div style="margin-bottom:16px;">
    <h2 style="margin:0 0 12px;font-size:16px;color:#111827;padding:0 4px;">By Client</h2>
    {client_cards_html}
</div>''' if client_cards_html else ''}

<!-- Key Decisions -->
{f'''<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 12px;font-size:16px;color:#111827;">Key Decisions Made</h2>
    {decisions_html}
</div>''' if decisions_html else ''}

<!-- Things That Might Fall Through the Cracks -->
{f'''<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 12px;font-size:16px;color:#DC2626;">Things That Might Fall Through the Cracks</h2>
    {cracks_html}
</div>''' if cracks_html else ''}

<!-- Next Week Preview -->
{f'''<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 12px;font-size:16px;color:#111827;">Next Week Preview</h2>
    {next_week_html}
</div>''' if next_week_html else ''}

<!-- Footer -->
<div style="text-align:center;padding:16px;color:#9CA3AF;font-size:12px;">
    ARIA &middot; Automated Routing &amp; Intelligence Assistant<br>
    Weekly Rollup &middot; Generated {datetime.now().strftime("%I:%M %p %A")}
</div>

</div>
</body>
</html>"""
    return html


def main():
    log("Generating weekly rollup...")
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)

    config = load_config()
    date_str = datetime.now().strftime("%Y-%m-%d")
    known_projects = config.get("known_projects", [])

    # Collect 7 days of data
    log("Collecting week's emails...")
    emails = collect_week_data("emails", 7)
    log(f"  {len(emails)} emails")

    log("Collecting week's Slack...")
    slack = collect_week_data("slack", 7)
    log(f"  {len(slack)} channels")

    log("Collecting week's notifications...")
    notifications = collect_week_data("notifications", 7)
    log(f"  {len(notifications)} notifications")

    log("Collecting week's calendar events...")
    calendar = collect_week_data("calendar", 7)
    calendly = collect_week_data("calendly", 7)
    all_events = calendar + calendly
    log(f"  {len(all_events)} events")

    log("Collecting week's awaiting items...")
    awaiting = collect_week_data("awaiting", 7)
    log(f"  {len(awaiting)} awaiting items")

    log("Collecting Granola meetings...")
    meetings = collect_granola_week(7)
    log(f"  {len(meetings)} meetings")

    log("Collecting Notion tasks...")
    notion_tasks = collect_notion_tasks()
    log(f"  {len(notion_tasks)} open tasks")

    # Collect next week's events
    next_week_calendar = []
    for days_ahead in range(1, 8):
        date_str_future = (datetime.now() + timedelta(days=days_ahead)).strftime("%Y-%m-%d")
        for source in ["calendar", "calendly"]:
            path = INBOX_DIR / f"{source}-{date_str_future}.json"
            if path.exists():
                try:
                    with open(path) as f:
                        data = json.load(f)
                    if isinstance(data, list):
                        next_week_calendar.extend(data)
                except Exception:
                    continue
    # Also check current files for future events
    today_str = datetime.now().strftime("%Y-%m-%d")
    for ev in all_events:
        if ev.get("start_time", "")[:10] > today_str:
            next_week_calendar.append(ev)

    # Build per-client stats
    client_stats = defaultdict(lambda: {"emails": 0, "meetings": 0, "notifications": 0, "events": 0, "awaiting": 0, "tasks": 0})

    for e in emails:
        proj = e.get("detected_project", e.get("project", "Other"))
        if proj:
            client_stats[proj]["emails"] += 1

    for m in meetings:
        title = m.get("title", "").lower()
        for proj in known_projects:
            if proj.lower() in title:
                client_stats[proj]["meetings"] += 1
                break

    for ev in all_events:
        proj = ev.get("calendar_project", "")
        if proj:
            client_stats[proj]["events"] += 1

    for a in awaiting:
        proj = a.get("project", "")
        if proj:
            client_stats[proj]["awaiting"] += 1

    for t in notion_tasks:
        proj = t.get("project", "")
        if proj:
            client_stats[proj]["tasks"] += 1

    # Build context for Ollama
    context_parts = []

    context_parts.append(f"=== WEEKLY STATS (last 7 days) ===")
    context_parts.append(f"Total: {len(emails)} emails, {len(meetings)} meetings, {len(notifications)} notifications, {len(all_events)} calendar events")

    context_parts.append(f"\n=== PER-CLIENT ACTIVITY ===")
    for proj in sorted(client_stats.keys()):
        stats = client_stats[proj]
        context_parts.append(f"{proj}: {stats['emails']} emails, {stats['meetings']} meetings, {stats['events']} events, {stats['tasks']} open tasks, {stats['awaiting']} awaiting items")

    if emails:
        context_parts.append(f"\n=== EMAILS THIS WEEK ({len(emails)}) ===")
        for e in emails[:40]:
            context_parts.append(f"[{e.get('account', '')}] {e.get('from', '')}: {e.get('subject', '')} | {e.get('summary', '')}")

    if meetings:
        context_parts.append(f"\n=== MEETINGS THIS WEEK ({len(meetings)}) ===")
        for m in meetings:
            people = ", ".join(m.get("people", []))
            context_parts.append(f"[{m['date']}] {m['title']} with {people}")
            if m.get("notes"):
                context_parts.append(f"  Notes: {m['notes'][:200]}")

    if awaiting:
        context_parts.append(f"\n=== WAITING ON OTHERS ({len(awaiting)} items) ===")
        for a in awaiting:
            context_parts.append(f"[{a.get('project', '')}] {a.get('owner', '?')}: {a.get('task', '')} (from {a.get('meeting', '')} on {a.get('meeting_date', '')})")

    if notion_tasks:
        overdue = [t for t in notion_tasks if t.get("overdue")]
        context_parts.append(f"\n=== NOTION TASKS ({len(notion_tasks)} open, {len(overdue)} overdue) ===")
        for t in overdue:
            context_parts.append(f"  OVERDUE: [{t['project']}] {t['task']} (due {t['due']})")

    if next_week_calendar:
        context_parts.append(f"\n=== NEXT WEEK'S SCHEDULE ({len(next_week_calendar)} events) ===")
        for ev in next_week_calendar[:20]:
            context_parts.append(f"{ev.get('date_local', ev.get('start_time', '')[:10])} {ev.get('start_local', '?')}: {ev.get('name', 'Meeting')} with {ev.get('invitee_names', ev.get('attendees', ''))}")

    full_context = "\n".join(context_parts)

    log("Analyzing with AI...")
    full_config = aria_ai.get_full_config()
    client_name = full_config.get("client", {}).get("contact_name", "the user")
    projects = full_config.get("projects", full_config.get("known_projects", []))
    projects_str = ", ".join(projects) if projects else "all tracked projects"

    system_prompt = f"""You are ARIA, an executive assistant AI. Generate a weekly strategic rollup for {client_name} from 7 days of activity data.

Respond with ONLY a valid JSON object. No markdown, no code blocks, no thinking tags.

JSON format:
{{
  "week_summary": "4-6 sentence executive summary of the week: what was productive, where momentum stalled, key themes",
  "client_cards": [
    {{
      "name": "client/project name",
      "engagement_level": "high/medium/low/none",
      "summary": "2-3 sentences about this week's activity",
      "meeting_count": 0,
      "email_count": 0,
      "open_tasks": 0,
      "alert": "any red flag or null"
    }}
  ],
  "decisions": [
    {{"decision": "what was decided", "project": "project name", "context": "in what meeting/email"}}
  ],
  "cracks": [
    {{"description": "what might fall through", "project": "project name", "risk": "why this matters"}}
  ],
  "next_week": [
    {{"description": "meeting or deliverable", "date": "day/time", "project": "project name"}}
  ]
}}

Known projects: {projects_str}.

Focus on:
- Which projects got attention and which didn't
- Commitments made that need follow-through
- Items awaiting response from others
- Overdue tasks that need escalation
- Next week's schedule and what prep is needed

Be direct. Flag real problems. Don't sugarcoat."""

    response = call_ai(system_prompt, full_context)

    if not response:
        log("AI inference failed. Generating fallback rollup.")
        sections = {
            "week_summary": f"ARIA tracked {len(emails)} emails, {len(meetings)} meetings, and {len(notifications)} notifications this week but could not generate analysis.",
            "client_cards": [],
            "decisions": [],
            "cracks": [],
            "next_week": [],
        }
    else:
        try:
            json_match = re.search(r'\{[\s\S]*\}', response)
            if json_match:
                sections = json.loads(json_match.group(0))
            else:
                raise ValueError("No JSON in response")
        except (json.JSONDecodeError, ValueError) as e:
            log(f"Failed to parse Ollama response: {e}")
            sections = {
                "week_summary": response[:500],
                "client_cards": [],
                "decisions": [],
                "cracks": [],
                "next_week": [],
            }

    # Generate HTML
    log("Generating HTML...")
    html = generate_weekly_html(date_str, sections)

    # Save
    rollup_path = BRIEFINGS_DIR / f"{date_str}-weekly.html"
    with open(rollup_path, "w") as f:
        f.write(html)
    log(f"Saved to {rollup_path}")

    # Send weekly email (n8n first, SMTP fallback)
    import aria_email
    week_start = (datetime.now() - timedelta(days=6)).strftime("%b %d")
    week_end = datetime.now().strftime("%b %d")
    subject = f"ARIA Weekly Rollup - {week_start} to {week_end}"
    recipient = full_config.get("email", "")
    if recipient:
        log(f"Sending weekly rollup to {recipient}...")
        success, method = aria_email.send_briefing_email(recipient, subject, html)
        if success:
            log(f"Email sent via {method}")
        else:
            log("Email delivery failed (both n8n and SMTP)")
    else:
        log("No email address configured. Rollup saved to file only.")

    log("Weekly rollup complete!")


if __name__ == "__main__":
    main()
