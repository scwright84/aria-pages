#!/usr/bin/env python3
"""
ARIA Email Auto-Organizer
Applies labels/folders and archives processed emails based on ARIA's classification.

Gmail: Creates ARIA/* labels, applies them, removes from INBOX.
Outlook: Creates ARIA/* folders, moves messages into them.

Classification comes from the existing inbox/emails-*.json data, which already has:
  - detected_project: which project/client the email belongs to
  - priority: urgent, high, normal, low
  - action_needed: true/false
  - action_type: respond, review, schedule, etc.

Rules:
  1. Emails with action_needed=true stay in inbox, get labeled ARIA/Action
  2. Emails classified to a project get labeled ARIA/{ProjectName}
  3. Priority=urgent or high get labeled ARIA/Priority
  4. Everything else gets archived (removed from inbox, label stays)
  5. Known newsletter/marketing senders get labeled ARIA/Newsletters and archived

Runs after email-sync.py processes new emails. Can run standalone or be called as a module.

Requires: Gmail API write scope (gmail.modify) or Outlook Graph API (Mail.ReadWrite)
"""

import json
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import junk_filter

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
CREDENTIALS_FILE = PROJECT_DIR / "config" / "credentials.json"
LOG_FILE = PROJECT_DIR / "logs" / "email-organizer.log"
STATE_FILE = PROJECT_DIR / "logs" / "email-organizer-state.json"

# Known newsletter/marketing patterns (auto-archive)
NEWSLETTER_PATTERNS = [
    "noreply", "no-reply", "newsletter", "marketing", "notifications@",
    "updates@", "info@", "hello@", "team@", "mailer-daemon",
    "donotreply", "unsubscribe",
]

LABEL_PREFIX = "ARIA"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def load_credentials():
    if CREDENTIALS_FILE.exists():
        with open(CREDENTIALS_FILE) as f:
            return json.load(f)
    return {"accounts": []}


def load_state():
    if STATE_FILE.exists():
        try:
            with open(STATE_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"organized_ids": [], "labels_created": []}


def save_state(state):
    # Keep only last 2000 organized IDs
    state["organized_ids"] = state.get("organized_ids", [])[-2000:]
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def load_today_emails():
    """Load today's processed emails (already classified by email-sync)."""
    date_str = datetime.now().strftime("%Y-%m-%d")
    path = INBOX_DIR / f"emails-{date_str}.json"
    if path.exists():
        with open(path) as f:
            return json.load(f)
    return []


def is_newsletter(email_from):
    """Check if sender is a newsletter/marketing sender."""
    if not email_from:
        return False
    lower = email_from.lower()
    return any(p in lower for p in NEWSLETTER_PATTERNS)


def classify_email(email):
    """
    Determine what labels/folders to apply and whether to archive.

    Gmail label structure (shows as nested folders in sidebar):
      ARIA/
        Action Needed/     ← Emails requiring a response. Stay in inbox AND filed here.
        Priority/          ← Urgent/high priority. Stay in inbox AND filed here.
        Projects/
          Conceivable/     ← Project-specific folder
          Pippa/
          MasterFi/
          ...
        Clients/           ← Same as projects but labeled by client tier
        Newsletters/       ← Marketing/automated. Auto-archived.
        Processed/         ← Catchall for emails that don't fit elsewhere.

    Rules:
      - Every email gets filed into a folder (never just archived into the void)
      - action_needed emails: filed into project folder AND Action Needed, kept in inbox
      - Priority emails: filed into project folder AND Priority, kept in inbox
      - Project emails (no action): filed into project folder, removed from inbox
      - Newsletters: filed into Newsletters, removed from inbox
      - Unclassified: filed into Processed, removed from inbox
    """
    labels = []
    archive = True  # Default: remove from inbox. Override below.

    project = email.get("detected_project")
    priority = email.get("priority", "normal")
    action_needed = email.get("action_needed", False)
    action_type = email.get("action_type", "")
    sender = email.get("from", "")

    # Junk detection (check first - overrides everything)
    is_junk, junk_score, junk_reason = junk_filter.is_junk(email, use_ai=False)
    if is_junk:
        labels.append(f"{LABEL_PREFIX}/Junk")
        return labels, True  # Always archive junk

    # Newsletter detection
    if is_newsletter(sender):
        labels.append(f"{LABEL_PREFIX}/Newsletters")
        return labels, True  # Always archive, don't apply other labels

    # Project folder (primary filing location)
    if project and project not in ("Unknown", None):
        labels.append(f"{LABEL_PREFIX}/Projects/{project}")
    else:
        labels.append(f"{LABEL_PREFIX}/Processed")

    # Action needed - ALSO file in Action Needed and keep in inbox
    if action_needed:
        labels.append(f"{LABEL_PREFIX}/Action Needed")
        archive = False  # Keep in inbox so they see it

    # Priority - ALSO file in Priority and keep in inbox
    if priority in ("urgent", "high"):
        labels.append(f"{LABEL_PREFIX}/Priority")
        archive = False  # Keep in inbox

    return labels, archive


# ============================================================
# Gmail Implementation
# ============================================================

def get_gmail_service(account):
    """Build Gmail API service from stored credentials."""
    from google.oauth2.credentials import Credentials
    from google.auth.transport.requests import Request
    from googleapiclient.discovery import build

    creds = Credentials(
        token=account.get("access_token"),
        refresh_token=account.get("refresh_token"),
        token_uri="https://oauth2.googleapis.com/token",
        client_id=account.get("client_id"),
        client_secret=account.get("client_secret"),
    )

    if creds.expired and creds.refresh_token:
        creds.refresh(Request())
        # Update stored credentials
        account["access_token"] = creds.token

    return build("gmail", "v1", credentials=creds)


def gmail_load_all_labels(service, label_cache):
    """Load all existing Gmail labels into cache."""
    try:
        results = service.users().labels().list(userId="me").execute()
        for label in results.get("labels", []):
            label_cache[label["name"]] = label["id"]
    except Exception as e:
        log(f"  Failed to load labels: {e}")


def gmail_ensure_label(service, label_name, label_cache):
    """
    Create a Gmail label if it doesn't exist. Returns label ID.
    Handles nested labels (e.g., ARIA/Projects/Conceivable) by creating
    parent labels first. Gmail uses '/' as the nesting separator.
    """
    if label_name in label_cache:
        return label_cache[label_name]

    # Load all labels on first call
    if not label_cache:
        gmail_load_all_labels(service, label_cache)
        if label_name in label_cache:
            return label_cache[label_name]

    # Ensure parent labels exist first (ARIA, then ARIA/Projects, then ARIA/Projects/Conceivable)
    parts = label_name.split("/")
    for i in range(1, len(parts) + 1):
        partial = "/".join(parts[:i])
        if partial in label_cache:
            continue
        try:
            label = service.users().labels().create(userId="me", body={
                "name": partial,
                "labelListVisibility": "labelShow",
                "messageListVisibility": "show",
            }).execute()
            label_cache[partial] = label["id"]
            log(f"  Created Gmail label: {partial}")
        except Exception as e:
            # Label might already exist (race condition or case sensitivity)
            err_str = str(e)
            if "already exists" in err_str.lower() or "409" in err_str:
                # Reload labels and try to find it
                gmail_load_all_labels(service, label_cache)
                if partial in label_cache:
                    continue
            log(f"  Failed to create label {partial}: {e}")
            return None

    return label_cache.get(label_name)


def gmail_organize_message(service, message_id, label_ids, archive, label_cache):
    """Apply labels and optionally archive a Gmail message."""
    try:
        modify_body = {}

        if label_ids:
            modify_body["addLabelIds"] = label_ids

        if archive:
            modify_body["removeLabelIds"] = ["INBOX"]

        if modify_body:
            service.users().messages().modify(
                userId="me", id=message_id, body=modify_body
            ).execute()
            return True
    except Exception as e:
        log(f"  Failed to organize message {message_id}: {e}")
    return False


def organize_gmail(emails, account, state):
    """Organize emails for a Gmail account."""
    organized_ids = set(state.get("organized_ids", []))
    label_cache = {}

    try:
        service = get_gmail_service(account)
    except Exception as e:
        log(f"  Failed to connect to Gmail for {account.get('email', '?')}: {e}")
        return 0

    count = 0
    for email in emails:
        msg_id = email.get("message_id")
        if not msg_id or msg_id in organized_ids:
            continue

        # Only process emails from this account
        email_account = email.get("account", "")
        if email_account and email_account != account.get("email", ""):
            continue

        labels, archive = classify_email(email)

        # Resolve label names to IDs
        label_ids = []
        for label_name in labels:
            lid = gmail_ensure_label(service, label_name, label_cache)
            if lid:
                label_ids.append(lid)

        if gmail_organize_message(service, msg_id, label_ids, archive, label_cache):
            organized_ids.add(msg_id)
            action = "archived" if archive else "labeled (kept in inbox)"
            log(f"  {action}: {email.get('subject', '?')[:50]} → {', '.join(labels)}")
            count += 1

    state["organized_ids"] = list(organized_ids)
    return count


# ============================================================
# Outlook Implementation
# ============================================================

def organize_outlook(emails, account, state):
    """
    Organize emails for an Outlook account using Microsoft Graph API.
    Outlook supports real nested folders, so we create:
      ARIA/
        Projects/
          Conceivable/
        Action Needed/
        Priority/
        Newsletters/
        Processed/
    """
    organized_ids = set(state.get("organized_ids", []))

    access_token = account.get("access_token")
    if not access_token:
        log(f"  No access token for Outlook account {account.get('email', '?')}")
        return 0

    import requests as req
    graph_url = "https://graph.microsoft.com/v1.0"
    headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}

    # Cache: full_path → folder_id
    folder_cache = {}

    def load_child_folders(parent_id=None):
        """Load folders under a parent (or root)."""
        try:
            if parent_id:
                url = f"{graph_url}/me/mailFolders/{parent_id}/childFolders"
            else:
                url = f"{graph_url}/me/mailFolders"
            resp = req.get(url, headers=headers, timeout=10)
            if resp.status_code == 200:
                return resp.json().get("value", [])
        except Exception:
            pass
        return []

    def ensure_folder_path(path):
        """Create nested folder path (e.g., ARIA/Projects/Conceivable)."""
        if path in folder_cache:
            return folder_cache[path]

        parts = path.split("/")
        parent_id = None
        current_path = ""

        for part in parts:
            current_path = f"{current_path}/{part}" if current_path else part

            if current_path in folder_cache:
                parent_id = folder_cache[current_path]
                continue

            # Check if folder exists
            children = load_child_folders(parent_id)
            found = None
            for child in children:
                if child["displayName"] == part:
                    found = child["id"]
                    break

            if found:
                folder_cache[current_path] = found
                parent_id = found
            else:
                # Create folder
                try:
                    if parent_id:
                        url = f"{graph_url}/me/mailFolders/{parent_id}/childFolders"
                    else:
                        url = f"{graph_url}/me/mailFolders"
                    resp = req.post(url, headers=headers,
                                   json={"displayName": part}, timeout=10)
                    if resp.status_code in (200, 201):
                        fid = resp.json()["id"]
                        folder_cache[current_path] = fid
                        parent_id = fid
                        log(f"  Created Outlook folder: {current_path}")
                    else:
                        log(f"  Failed to create Outlook folder {current_path}: {resp.status_code}")
                        return None
                except Exception as e:
                    log(f"  Failed to create Outlook folder {current_path}: {e}")
                    return None

        return folder_cache.get(path)

    count = 0
    for email in emails:
        msg_id = email.get("message_id")
        if not msg_id or msg_id in organized_ids:
            continue

        email_account = email.get("account", "")
        if email_account and email_account != account.get("email", ""):
            continue

        labels, archive = classify_email(email)

        # Move to the primary folder (first label = primary filing location)
        target_folder = None
        for label in labels:
            fid = ensure_folder_path(label)
            if fid:
                target_folder = fid
                break

        if target_folder:
            try:
                resp = req.post(
                    f"{graph_url}/me/messages/{msg_id}/move",
                    headers=headers,
                    json={"destinationId": target_folder},
                    timeout=10
                )
                if resp.status_code == 200:
                    organized_ids.add(msg_id)
                    log(f"  Moved (Outlook): {email.get('subject', '?')[:50]} → {labels[0]}")
                    count += 1
            except Exception as e:
                log(f"  Failed to move Outlook message: {e}")

    state["organized_ids"] = list(organized_ids)
    return count


# ============================================================
# Main
# ============================================================

def main():
    log("Starting email auto-organizer")
    config = load_config()
    state = load_state()

    emails = load_today_emails()
    if not emails:
        log("No emails to organize today")
        return 0

    log(f"Processing {len(emails)} emails")

    # Classify all emails first (report)
    action_count = sum(1 for e in emails if e.get("action_needed"))
    newsletter_count = sum(1 for e in emails if is_newsletter(e.get("from", "")))
    project_emails = sum(1 for e in emails if e.get("detected_project"))

    log(f"  {action_count} need action (stay in inbox)")
    log(f"  {newsletter_count} newsletters (auto-archive)")
    log(f"  {project_emails} classified to projects")
    log(f"  {len(emails) - action_count} to be archived")

    # Load credentials and organize per account
    creds_data = load_credentials()
    total_organized = 0

    for account in creds_data.get("accounts", []):
        email_addr = account.get("email", "unknown")
        services = account.get("services", [])

        if "gmail" in services:
            log(f"Organizing Gmail: {email_addr}")
            count = organize_gmail(emails, account, state)
            total_organized += count
            log(f"  Organized {count} messages")

        elif "outlook" in services:
            log(f"Organizing Outlook: {email_addr}")
            count = organize_outlook(emails, account, state)
            total_organized += count
            log(f"  Organized {count} messages")

    save_state(state)
    log(f"Total organized: {total_organized} messages")
    log("Email organizer complete")

    return 0


if __name__ == "__main__":
    sys.exit(main())
