#!/usr/bin/env python3
"""
ARIA Priority Inbox
AI-powered email ranking. Goes beyond junk filtering to actively rank
every email by what matters most RIGHT NOW.

Scoring factors:
  - Sender importance (relationship score from contacts)
  - Project priority (active client > product > on-hold)
  - Action urgency (deadline proximity, explicit action_needed)
  - Content relevance (does it relate to current goals?)
  - Recency (newer emails rank higher, but urgent old ones stay up)
  - Thread heat (part of an active conversation?)

Output: briefings/YYYY-MM-DD-priority-inbox.json
        Top 5 most important emails surfaced in morning brief

Runs after email-sync and before briefing generation.
"""

import json
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
CONTACTS_FILE = PROJECT_DIR / "config" / "contacts.json"
GOALS_FILE = PROJECT_DIR / "config" / "goals.json"
LOG_FILE = PROJECT_DIR / "logs" / "priority-inbox.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_json(path):
    if Path(path).exists():
        try:
            with open(path) as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def load_config():
    return load_json(CONFIG_FILE)


def load_contacts():
    return load_json(CONTACTS_FILE)


def load_goals():
    data = load_json(GOALS_FILE)
    return [g for g in data.get("goals", []) if g.get("status") == "active"]


def load_today_emails():
    date_str = datetime.now().strftime("%Y-%m-%d")
    path = INBOX_DIR / f"emails-{date_str}.json"
    if path.exists():
        with open(path) as f:
            return json.load(f)
    return []


def get_sender_score(email, contacts):
    """Score based on who sent the email."""
    sender = email.get("from", "").lower()
    for key, contact in contacts.items():
        contact_name = (contact.get("name") or "").lower()
        contact_emails = [e.lower() for e in contact.get("emails", [])]

        if any(e in sender for e in contact_emails) or (contact_name and contact_name in sender):
            return contact.get("relationship_score", 50)

    return 30  # Unknown sender default


def get_project_score(email, config):
    """Score based on which project the email belongs to."""
    project = email.get("detected_project")
    if not project:
        return 0

    tiers = config.get("client_tiers", {})
    if project in tiers.get("active", []):
        return 30  # Active client = highest project priority
    elif project in tiers.get("product", []):
        return 20  # Product work
    elif project in tiers.get("on_hold", []):
        return 5   # On hold = low priority
    return 10  # Known but uncategorized


def get_action_score(email):
    """Score based on action urgency."""
    score = 0
    if email.get("action_needed"):
        score += 25
    priority = email.get("priority", "normal")
    if priority == "urgent":
        score += 30
    elif priority == "high":
        score += 20
    elif priority == "normal":
        score += 5

    action_type = email.get("action_type", "")
    if action_type in ("decide", "approve"):
        score += 15
    elif action_type in ("respond", "reply"):
        score += 10

    return score


def get_goal_relevance(email, goals):
    """Score based on relevance to current goals."""
    subject = (email.get("subject", "") + " " + email.get("summary", "")).lower()
    project = (email.get("detected_project") or "").lower()

    max_relevance = 0
    for goal in goals:
        keywords = [k.lower() for k in goal.get("keywords", [])]
        goal_project = (goal.get("project") or "").lower()

        if goal_project and goal_project == project:
            max_relevance = max(max_relevance, 15)
        elif any(k in subject for k in keywords):
            max_relevance = max(max_relevance, 10)

    return max_relevance


def rank_emails(emails, config, contacts, goals):
    """Rank all emails by composite priority score."""
    ranked = []

    for email in emails:
        sender_score = get_sender_score(email, contacts)
        project_score = get_project_score(email, config)
        action_score = get_action_score(email)
        goal_score = get_goal_relevance(email, goals)

        # Composite score (weighted)
        total = (
            sender_score * 0.25 +    # 25% who sent it
            project_score * 0.20 +    # 20% which project
            action_score * 0.35 +     # 35% does it need action (biggest weight)
            goal_score * 0.20         # 20% does it relate to current goals
        )

        ranked.append({
            "subject": email.get("subject", "?"),
            "from": email.get("from", "?"),
            "project": email.get("detected_project"),
            "priority": email.get("priority", "normal"),
            "action_needed": email.get("action_needed", False),
            "composite_score": round(total, 1),
            "breakdown": {
                "sender": round(sender_score * 0.25, 1),
                "project": round(project_score * 0.20, 1),
                "action": round(action_score * 0.35, 1),
                "goal_relevance": round(goal_score * 0.20, 1),
            },
            "message_id": email.get("message_id"),
            "summary": email.get("summary", "")[:200],
        })

    return sorted(ranked, key=lambda x: -x["composite_score"])


def main():
    log("Starting priority inbox ranking")

    config = load_config()
    contacts = load_contacts()
    goals = load_goals()
    emails = load_today_emails()

    if not emails:
        log("No emails to rank today")
        return

    log(f"Ranking {len(emails)} emails against {len(contacts)} contacts and {len(goals)} active goals")

    ranked = rank_emails(emails, config, contacts, goals)

    # Save full ranking
    date_str = datetime.now().strftime("%Y-%m-%d")
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)

    output = {
        "date": date_str,
        "total_emails": len(ranked),
        "top_5": ranked[:5],
        "full_ranking": ranked,
        "scoring_weights": {
            "sender_importance": "25%",
            "project_priority": "20%",
            "action_urgency": "35%",
            "goal_relevance": "20%",
        },
    }

    with open(BRIEFINGS_DIR / f"{date_str}-priority-inbox.json", "w") as f:
        json.dump(output, f, indent=2, default=str)

    log(f"Top 5 priority emails:")
    for i, e in enumerate(ranked[:5], 1):
        log(f"  {i}. [{e['composite_score']}] {e['from'][:30]} | {e['subject'][:50]}")
        b = e['breakdown']
        log(f"     Sender:{b['sender']} Project:{b['project']} Action:{b['action']} Goal:{b['goal_relevance']}")

    log("Priority inbox complete")


if __name__ == "__main__":
    main()
