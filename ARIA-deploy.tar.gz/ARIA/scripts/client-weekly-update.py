#!/usr/bin/env python3
"""
ARIA Auto Weekly Client Update Emails
Generates a draft weekly status email per active client from activity data.

For each client, pulls:
  - Email threads this week
  - Slack activity
  - Meeting summaries
  - Commitments completed vs outstanding
  - Engagement scorecard grade

Generates a professional update email using the client's communication template.
Saves as a draft for Sean to review and approve (never auto-sent).

Output: config/pending-drafts.json (added to draft queue)
        briefings/YYYY-MM-DD-client-updates.json (all generated updates)
Runs Sunday afternoon before the weekly rollup.
"""

import json
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import aria_ai
import draft_manager

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
TEMPLATES_FILE = PROJECT_DIR / "config" / "client-templates.json"
STYLE_FILE = PROJECT_DIR / "config" / "writing-style.json"
CONTACTS_FILE = PROJECT_DIR / "config" / "contacts.json"
LOG_FILE = PROJECT_DIR / "logs" / "client-weekly-update.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def load_templates():
    if TEMPLATES_FILE.exists():
        with open(TEMPLATES_FILE) as f:
            return json.load(f)
    return {}


def load_style():
    if STYLE_FILE.exists():
        with open(STYLE_FILE) as f:
            return json.load(f)
    return {}


def load_inbox(prefix, days_back=7):
    all_data = []
    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        path = INBOX_DIR / f"{prefix}-{date.strftime('%Y-%m-%d')}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                all_data.extend(data if isinstance(data, list) else [data])
            except Exception:
                pass
    return all_data


def get_client_week_summary(project):
    """Gather this week's activity for a client."""
    emails = [e for e in load_inbox("emails") if e.get("detected_project") == project]
    slack = [s for s in load_inbox("slack") if s.get("project") == project]
    commitments = [c for c in load_inbox("awaiting") if c.get("project") == project]

    # Get scorecard grade
    date_str = datetime.now().strftime("%Y-%m-%d")
    scorecard_path = BRIEFINGS_DIR / f"{date_str}-scorecard.json"
    grade = "?"
    if scorecard_path.exists():
        try:
            with open(scorecard_path) as f:
                sc = json.load(f)
            if project in sc:
                grade = sc[project].get("health_grade", "?")
        except Exception:
            pass

    # Key topics from Slack
    topics = []
    for s in slack:
        topics.extend(s.get("key_topics", []))

    # Action items from Slack
    actions = []
    for s in slack:
        actions.extend(s.get("action_items", []))

    return {
        "email_count": len(emails),
        "slack_messages": sum(s.get("message_count", 0) for s in slack),
        "commitments_open": len(commitments),
        "health_grade": grade,
        "key_topics": topics[:5],
        "action_items": actions[:5],
        "email_subjects": [e.get("subject", "") for e in emails[:5]],
    }


def generate_update_email(project, summary, templates, style):
    """Use AI to generate a client update email from the week's data."""
    style_instructions = style.get("draft_instructions", "Professional but approachable.")

    # Get template for this client
    client_templates = templates.get(project, {}).get("templates", {})
    template = client_templates.get("status_update", {}).get("body", "")

    # Get primary contact
    tone = templates.get(project, {}).get("tone_analysis", {})
    contacts = list(tone.get("top_contacts", {}).keys())
    primary_contact = contacts[0] if contacts else "[Name]"

    context = f"""Client: {project}
Primary contact: {primary_contact}
Health grade: {summary['health_grade']}
Emails this week: {summary['email_count']}
Slack messages: {summary['slack_messages']}
Open commitments: {summary['commitments_open']}
Key topics: {', '.join(summary['key_topics'][:3]) if summary['key_topics'] else 'None'}
Action items: {', '.join(str(a)[:50] for a in summary['action_items'][:3]) if summary['action_items'] else 'None'}
Recent subjects: {', '.join(s[:40] for s in summary['email_subjects'][:3]) if summary['email_subjects'] else 'None'}"""

    prompt = f"""Write a brief weekly status update email to {primary_contact} at {project}.

Style: {style_instructions}

Use this data to write a 3-5 sentence update. Be specific about what happened this week.
Don't be vague. Reference real topics and progress.
If there are open commitments or action items, mention them.
End with a clear next step or question.

Sign as Sean."""

    result = aria_ai.chat(prompt, context, escalate=True, timeout=30)
    if result:
        return {
            "to": primary_contact,
            "subject": f"{project} - Weekly Update ({datetime.now().strftime('%b %d')})",
            "body": result,
            "project": project,
        }

    # Fallback: use template
    return {
        "to": primary_contact,
        "subject": f"{project} - Weekly Update ({datetime.now().strftime('%b %d')})",
        "body": template.replace("[KEY PROGRESS POINT 1]", summary['key_topics'][0] if summary['key_topics'] else "Continued progress").replace("[KEY PROGRESS POINT 2]", f"Health grade: {summary['health_grade']}").replace("[NEXT STEP 1]", summary['action_items'][0] if summary['action_items'] else "Continue current trajectory").replace("[NEXT STEP 2]", "Sync on priorities this week"),
        "project": project,
    }


def main():
    log("Starting weekly client update generation")
    config = load_config()
    templates = load_templates()
    style = load_style()

    active_clients = config.get("client_tiers", {}).get("active", [])
    updates = []

    for project in active_clients:
        log(f"Generating update for: {project}")
        summary = get_client_week_summary(project)

        # Skip if very little activity
        if summary["email_count"] == 0 and summary["slack_messages"] == 0:
            log(f"  Skipping {project}: no activity this week")
            continue

        update = generate_update_email(project, summary, templates, style)
        updates.append(update)

        # Add to draft queue
        draft_manager.add_draft(
            to=update["to"],
            subject=update["subject"],
            body=update["body"],
            project=project,
        )

        log(f"  Draft created: {update['subject']}")
        log(f"  To: {update['to']}")

    # Save all updates
    date_str = datetime.now().strftime("%Y-%m-%d")
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    with open(BRIEFINGS_DIR / f"{date_str}-client-updates.json", "w") as f:
        json.dump({"date": date_str, "updates": updates}, f, indent=2, default=str)

    log(f"Generated {len(updates)} client update drafts")
    log("Review and approve via Telegram: /drafts")
    log("Client update generation complete")


if __name__ == "__main__":
    main()
