"""
ARIA White-Label Theming System
Config-driven branding for all client-facing UI.

Every dashboard, status page, portal, briefing email, and report
calls aria_theme.get_theme() to get the client's branding.

Config in aria.json under "branding":
  {
    "branding": {
      "company_name": "Lakeway Dental Care",
      "product_name": "ARIA",
      "logo_url": "/static/logo.png",
      "primary_color": "#3b82f6",
      "accent_color": "#22c55e",
      "dark_bg": "#0f172a",
      "light_bg": "#f9fafb",
      "font_family": "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      "admin_name": "Wright Advisors",
      "admin_email": "sean@wrightadvisorsatx.com",
      "support_email": "support@wrightadvisorsatx.com",
      "footer_text": "Powered by ARIA | Your data stays on this computer",
      "powered_by": true
    }
  }

If no branding config, falls back to ARIA defaults.
All UI scripts import this module: from aria_theme import get_theme
"""

import json
from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"

DEFAULT_THEME = {
    "company_name": "ARIA",
    "product_name": "ARIA",
    "logo_url": None,
    "primary_color": "#3b82f6",
    "accent_color": "#22c55e",
    "danger_color": "#ef4444",
    "warning_color": "#f97316",
    "success_color": "#22c55e",
    "dark_bg": "#0f172a",
    "dark_surface": "#1e293b",
    "dark_border": "#334155",
    "light_bg": "#f9fafb",
    "light_surface": "#ffffff",
    "light_border": "#e5e7eb",
    "text_primary": "#111827",
    "text_secondary": "#6b7280",
    "text_muted": "#9ca3af",
    "text_on_dark": "#e2e8f0",
    "font_family": "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    "admin_name": "Wright Advisors",
    "admin_email": "sean@wrightadvisorsatx.com",
    "support_email": "support@wrightadvisorsatx.com",
    "footer_text": "Powered by ARIA | Your data stays on this computer",
    "powered_by": True,
}


def get_theme():
    """Get the current theme config, merged with defaults."""
    try:
        with open(CONFIG_FILE) as f:
            config = json.load(f)
        branding = config.get("branding", {})
    except Exception:
        branding = {}

    # Also pull client name if available
    try:
        with open(CONFIG_FILE) as f:
            config = json.load(f)
        client_name = config.get("client", {}).get("name")
        if client_name and "company_name" not in branding:
            branding["company_name"] = client_name
    except Exception:
        pass

    # Merge with defaults
    theme = dict(DEFAULT_THEME)
    theme.update({k: v for k, v in branding.items() if v is not None})
    return theme


def get_css(mode="light"):
    """Generate CSS variables from the theme. Inject into any HTML page."""
    t = get_theme()

    if mode == "dark":
        bg = t["dark_bg"]
        surface = t["dark_surface"]
        border = t["dark_border"]
        text = t["text_on_dark"]
        text_sec = t["text_secondary"]
    else:
        bg = t["light_bg"]
        surface = t["light_surface"]
        border = t["light_border"]
        text = t["text_primary"]
        text_sec = t["text_secondary"]

    return f"""
    :root {{
        --primary: {t['primary_color']};
        --accent: {t['accent_color']};
        --danger: {t['danger_color']};
        --warning: {t['warning_color']};
        --success: {t['success_color']};
        --bg: {bg};
        --surface: {surface};
        --border: {border};
        --text: {text};
        --text-secondary: {text_sec};
        --text-muted: {t['text_muted']};
        --font: {t['font_family']};
    }}
    body {{ font-family: var(--font); background: var(--bg); color: var(--text); }}
    """


def get_header_html(title=None):
    """Generate a reusable header for client-facing pages."""
    t = get_theme()
    name = title or t["company_name"]
    logo = f'<img src="{t["logo_url"]}" alt="" style="height:32px;margin-right:12px">' if t.get("logo_url") else ""

    return f"""
    <div style="background:{t['dark_bg']};color:{t['text_on_dark']};padding:16px 24px;display:flex;align-items:center;justify-content:space-between">
        <div style="display:flex;align-items:center">
            {logo}
            <span style="font-size:18px;font-weight:600">{name}</span>
        </div>
        {'<span style="font-size:11px;color:' + t['text_muted'] + '">Powered by ARIA</span>' if t['powered_by'] else ''}
    </div>"""


def get_footer_html():
    """Generate a reusable footer."""
    t = get_theme()
    return f"""
    <div style="text-align:center;font-size:11px;color:{t['text_muted']};margin-top:24px;padding:16px">
        {t['footer_text']}
        {' | <a href="mailto:' + t['support_email'] + '" style="color:' + t['primary_color'] + ';text-decoration:none">' + t['support_email'] + '</a>' if t.get('support_email') else ''}
    </div>"""


def get_email_header_html(title=""):
    """Generate branded email header."""
    t = get_theme()
    return f"""
    <div style="background:{t['dark_bg']};color:white;padding:20px;border-radius:10px 10px 0 0;text-align:center">
        <h1 style="font-size:18px;margin:0">{title or t['product_name']}</h1>
        <p style="font-size:13px;color:{t['text_muted']};margin:4px 0 0">{t['company_name']}</p>
    </div>"""


def get_email_footer_html():
    """Generate branded email footer."""
    t = get_theme()
    return f"""
    <div style="background:{t['light_bg']};padding:16px;text-align:center;font-size:11px;color:{t['text_muted']};border-top:1px solid {t['light_border']}">
        <p>{t['footer_text']}</p>
        <p>{t['admin_name']} | <a href="mailto:{t['admin_email']}" style="color:{t['primary_color']};text-decoration:none">{t['admin_email']}</a></p>
    </div>"""
