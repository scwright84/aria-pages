#!/usr/bin/env python3
"""
ARIA Granola Sync (one-shot)
Pulls meeting notes from Granola's API for ALL projects.
Extracts notes content, forwards new/updated meetings to n8n.
Designed to be called on a schedule by launchd (7am and 9pm).
"""

import json
import os
import hashlib
import requests
from datetime import datetime, timedelta
from pathlib import Path

GRANOLA_AUTH_FILE = os.path.expanduser(
    "~/Library/Application Support/Granola/supabase.json"
)
GRANOLA_API = "https://api.granola.ai"

N8N_WEBHOOK_URL = os.environ.get(
    "ARIA_GRANOLA_WEBHOOK_URL",
    "http://localhost:5678/webhook/aria-granola"
)

PROJECT_DIR = Path(__file__).parent.parent
STATE_FILE = PROJECT_DIR / "logs" / "granola-state.json"
LOG_FILE = PROJECT_DIR / "logs" / "granola-sync.log"

# Map meeting titles to projects
KNOWN_PROJECTS = {
    "conceivable": "Conceivable",
    "pippa": "Pippa",
    "hearthril": "Pippa",
    "wild monkey": "Wild Monkey Bar",
    "monkey bar": "Wild Monkey Bar",
    "masterfi": "MasterFi",
    "joined": "Joined",
    "strandwise": "Strandwise",
    "wright advisor": "Wright Advisors",
    "founderos": "FounderOS",
    "founder os": "FounderOS",
    "startup cfo": "StartupCFO",
    "hogan": "Pippa",
    "kelly": "Pippa",
}


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_state():
    if STATE_FILE.exists():
        with open(STATE_FILE) as f:
            return json.load(f)
    return {"known_documents": {}}


def save_state(state):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def get_auth_token():
    """Read the current access token from Granola's local auth file."""
    if not os.path.exists(GRANOLA_AUTH_FILE):
        log(f"Granola auth file not found at {GRANOLA_AUTH_FILE}")
        return None
    with open(GRANOLA_AUTH_FILE) as f:
        supa = json.load(f)
    tokens = json.loads(supa.get("workos_tokens", "{}"))
    return tokens.get("access_token")


def prosemirror_to_text(node, depth=0):
    """Convert ProseMirror JSON to readable plain text."""
    if not isinstance(node, dict):
        return ""

    parts = []
    node_type = node.get("type", "")

    # Handle text nodes
    if "text" in node:
        text = node["text"]
        marks = node.get("marks", [])
        for mark in marks:
            if mark.get("type") == "bold":
                text = f"**{text}**"
        parts.append(text)

    # Handle block-level nodes
    prefix = ""
    suffix = ""
    if node_type == "heading":
        level = node.get("attrs", {}).get("level", 1)
        prefix = "#" * level + " "
        suffix = "\n"
    elif node_type == "bulletList":
        suffix = ""
    elif node_type == "listItem":
        prefix = "- "
    elif node_type == "paragraph":
        suffix = "\n"
    elif node_type == "horizontalRule":
        parts.append("\n---\n")
    elif node_type == "hardBreak":
        parts.append("\n")

    # Process children
    children_text = []
    for child in node.get("content", []):
        child_text = prosemirror_to_text(child, depth + 1)
        if child_text:
            children_text.append(child_text)

    if children_text:
        joined = "".join(children_text)
        parts.append(prefix + joined + suffix)

    return "".join(parts)


def detect_project(title):
    """Detect which project a meeting belongs to based on title."""
    title_lower = title.lower()
    for keyword, project in KNOWN_PROJECTS.items():
        if keyword in title_lower:
            return project
    return "Personal"


def fetch_documents(token, limit=50):
    """Fetch documents from Granola API with content."""
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    try:
        resp = requests.post(
            f"{GRANOLA_API}/v2/get-documents",
            headers=headers,
            json={
                "limit": limit,
                "offset": 0,
                "include_last_viewed_panel": True,
            },
            timeout=30,
        )
        if resp.status_code == 200:
            return resp.json().get("docs", [])
        elif resp.status_code == 401:
            log("Granola API token expired. Granola app needs to be open to refresh.")
            return None
        else:
            log(f"Granola API error {resp.status_code}: {resp.text[:200]}")
            return None
    except Exception as e:
        log(f"Granola API request failed: {e}")
        return None


def process_document(doc):
    """Extract useful data from a Granola API document."""
    doc_id = doc.get("id", "")
    title = doc.get("title", "Untitled")
    created = doc.get("created_at", "")
    updated = doc.get("updated_at", "")

    # Extract notes from the panel content (ProseMirror JSON)
    notes_text = ""
    panel = doc.get("last_viewed_panel", {})
    content = panel.get("content", {})
    if content and content.get("content"):
        notes_text = prosemirror_to_text(content).strip()

    # Extract people from calendar event if available
    people = []
    cal_event = doc.get("google_calendar_event", {})
    if isinstance(cal_event, dict):
        attendees = cal_event.get("attendees", [])
        if isinstance(attendees, list):
            for a in attendees:
                if isinstance(a, dict):
                    people.append(a.get("displayName", a.get("email", "")))

    project = detect_project(title)

    return {
        "document_id": doc_id,
        "title": title,
        "created_at": created,
        "updated_at": updated,
        "notes": notes_text,
        "people": people,
        "project": project,
        "source": "granola",
    }


def content_hash(doc_data):
    """Hash the content to detect changes."""
    content = f"{doc_data['title']}|{doc_data['notes']}|{doc_data['updated_at']}"
    return hashlib.md5(content.encode()).hexdigest()


def main():
    token = get_auth_token()
    if not token:
        log("No auth token available. Is Granola installed and logged in?")
        return

    log("Fetching documents from Granola API...")
    documents = fetch_documents(token, limit=50)

    if documents is None:
        log("Could not fetch documents. Exiting.")
        return

    log(f"Got {len(documents)} documents from API")

    state = load_state()

    # First run: catalog without forwarding
    if not state["known_documents"]:
        log(f"First run: cataloging {len(documents)} existing documents")
        for doc in documents:
            doc_data = process_document(doc)
            state["known_documents"][doc_data["document_id"]] = {
                "hash": content_hash(doc_data),
                "title": doc_data["title"],
                "project": doc_data["project"],
                "updated_at": doc_data["updated_at"],
            }
        save_state(state)
        log("First run complete. Will forward changes on next run.")
        return

    new_count = 0
    updated_count = 0
    errors = 0

    for doc in documents:
        doc_data = process_document(doc)
        new_hash = content_hash(doc_data)
        doc_id = doc_data["document_id"]

        event_type = None
        if doc_id not in state["known_documents"]:
            event_type = "new_meeting"
            new_count += 1
        elif state["known_documents"][doc_id]["hash"] != new_hash:
            event_type = "meeting_updated"
            updated_count += 1

        if event_type:
            log(f"  {event_type.upper()}: [{doc_data['project']}] {doc_data['title']}")
            if doc_data["notes"]:
                log(f"    Notes: {len(doc_data['notes'])} chars")
            else:
                log(f"    No notes content")

            doc_data["event_type"] = event_type
            doc_data["forwarded_at"] = datetime.now().isoformat()
            try:
                resp = requests.post(N8N_WEBHOOK_URL, json=doc_data, timeout=10)
                if resp.status_code != 200:
                    log(f"    n8n responded {resp.status_code}")
                    errors += 1
            except requests.exceptions.ConnectionError:
                log("    n8n not reachable")
                errors += 1
            except Exception as e:
                log(f"    Error: {e}")
                errors += 1

            state["known_documents"][doc_id] = {
                "hash": new_hash,
                "title": doc_data["title"],
                "project": doc_data["project"],
                "updated_at": doc_data["updated_at"],
            }
            save_state(state)

    if new_count == 0 and updated_count == 0:
        log("No changes detected")
    else:
        log(f"Done: {new_count} new, {updated_count} updated, {errors} errors")


if __name__ == "__main__":
    main()
