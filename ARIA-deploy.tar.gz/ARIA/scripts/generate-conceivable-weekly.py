#!/usr/bin/env python3
"""
ARIA Conceivable Weekly Team Brief
Client-specific deep dive for Conceivable (fertility app startup).
Covers: decisions, action items/owners, blockers, upcoming work, risk items.

Key team members: Lakshmi, Andrew, Maria, Kirsten, Grace

Runs Sunday at 6pm via launchd (before general weekly rollup at 7pm),
or manually anytime.
"""

import json
import os
import re
import requests
from datetime import datetime, timedelta
from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
INBOX_DIR = PROJECT_DIR / "inbox"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
LOG_FILE = PROJECT_DIR / "logs" / "conceivable-weekly.log"

GRANOLA_CACHE = os.path.expanduser(
    "~/Library/Application Support/Granola/cache-v6.json"
)
import aria_ai
BRIEFING_WEBHOOK = "http://localhost:5678/webhook/aria-send-briefing"
SEND_TO = "scwright84@gmail.com"

CONCEIVABLE_TEAM = ["Lakshmi", "Andrew", "Maria", "Kirsten", "Grace"]


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def collect_week_data(source_prefix, days=7):
    """Collect all inbox data for a given source over N days."""
    items = []
    today = datetime.now()
    for days_back in range(days):
        date_str = (today - timedelta(days=days_back)).strftime("%Y-%m-%d")
        path = INBOX_DIR / f"{source_prefix}-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                if isinstance(data, list):
                    items.extend(data)
            except Exception:
                continue
    return items


def filter_conceivable_emails(emails):
    """Filter emails for Conceivable project or account."""
    filtered = []
    for e in emails:
        project = (e.get("detected_project", "") or "").lower()
        account = (e.get("account", "") or "").lower()
        if "conceivable" in project or "conceivable" in account:
            filtered.append(e)
    return filtered


def filter_conceivable_awaiting(awaiting):
    """Filter awaiting items for Conceivable project."""
    filtered = []
    for a in awaiting:
        project = (a.get("project", "") or "").lower()
        if "conceivable" in project:
            filtered.append(a)
    return filtered


def collect_conceivable_granola(days=7):
    """Get Conceivable meetings from the last N days from Granola cache."""
    cutoff = datetime.now() - timedelta(days=days)
    meetings = []
    try:
        with open(GRANOLA_CACHE) as f:
            data = json.load(f)
        state = data.get("cache", {}).get("state", {})
        documents = state.get("documents", {})

        for doc_id, doc in documents.items():
            if not isinstance(doc, dict):
                continue

            title = (doc.get("title", "") or "").lower()
            if "conceivable" not in title:
                continue

            updated = doc.get("updated_at", doc.get("created_at", ""))
            if not updated:
                continue
            try:
                doc_time = datetime.fromisoformat(
                    updated.replace("Z", "+00:00")
                ).replace(tzinfo=None)
                if doc_time < cutoff:
                    continue
            except (ValueError, TypeError):
                continue

            people = []
            raw_people = doc.get("people", {})
            if isinstance(raw_people, dict):
                for pid, person in raw_people.items():
                    if isinstance(person, dict):
                        people.append(person.get("name", ""))
            elif isinstance(raw_people, list):
                people = raw_people

            # Get longer notes for Conceivable-specific analysis
            notes = doc.get("notes_markdown", "") or doc.get("notes_plain", "")

            meetings.append({
                "title": doc.get("title", "Untitled"),
                "date": updated[:10],
                "people": people,
                "notes": notes[:800],
            })
    except Exception as e:
        log(f"Error reading Granola: {e}")
    return meetings


def call_ai(system_prompt, user_content):
    result = aria_ai.chat(system_prompt, user_content, timeout=240)
    if result is None:
        log("AI inference call failed")
    return result


def generate_conceivable_html(date_str, sections):
    """Generate the Conceivable weekly brief HTML."""
    week_start = (datetime.now() - timedelta(days=6)).strftime("%b %d")
    week_end = datetime.now().strftime("%b %d")

    # Executive summary
    exec_summary = sections.get("executive_summary", "No data available for this week.")

    # Key decisions
    decisions_html = ""
    for d in sections.get("key_decisions", []):
        decisions_html += f"""
        <div style="padding:10px 14px;margin-bottom:6px;background:#F0FDF4;border-radius:6px;border-left:3px solid #10B981;">
            <div style="font-size:14px;color:#111827;font-weight:500;">{d.get('decision', '')}</div>
            <div style="font-size:12px;color:#6B7280;margin-top:2px;">{d.get('context', '')}</div>
        </div>"""

    # Action items
    actions_html = ""
    for a in sections.get("action_items", []):
        owner = a.get("owner", "Unassigned")
        status_color = "#F59E0B" if a.get("status", "").lower() in ("in progress", "started") else "#3B82F6"
        actions_html += f"""
        <div style="padding:10px 14px;margin-bottom:6px;background:white;border-radius:6px;border-left:3px solid {status_color};box-shadow:0 1px 2px rgba(0,0,0,0.05);">
            <div style="display:flex;justify-content:space-between;align-items:baseline;">
                <div style="font-size:14px;color:#111827;">{a.get('item', '')}</div>
                <span style="font-size:11px;color:white;background:{status_color};padding:2px 8px;border-radius:10px;white-space:nowrap;">{owner}</span>
            </div>
            {f"<div style='font-size:12px;color:#6B7280;margin-top:2px;'>{a.get('deadline', '')}</div>" if a.get('deadline') else ""}
        </div>"""

    # Open blockers
    blockers_html = ""
    for b in sections.get("open_blockers", []):
        blockers_html += f"""
        <div style="padding:10px 14px;margin-bottom:6px;background:#FEF2F2;border-radius:6px;border-left:3px solid #DC2626;">
            <div style="font-size:14px;color:#111827;font-weight:500;">{b.get('blocker', '')}</div>
            <div style="font-size:12px;color:#6B7280;margin-top:2px;">Owner: {b.get('owner', 'TBD')} {f"| Impact: {b.get('impact', '')}" if b.get('impact') else ""}</div>
        </div>"""

    # Coming next week
    next_week_html = ""
    for item in sections.get("next_week", []):
        next_week_html += f"""
        <div style="padding:10px 14px;margin-bottom:6px;background:#EFF6FF;border-radius:6px;border-left:3px solid #3B82F6;">
            <div style="font-size:14px;color:#111827;">{item.get('description', '')}</div>
            <div style="font-size:12px;color:#6B7280;margin-top:2px;">{item.get('owner', '')} {f"| {item.get('date', '')}" if item.get('date') else ""}</div>
        </div>"""

    # At risk
    risk_html = ""
    for r in sections.get("at_risk", []):
        risk_html += f"""
        <div style="padding:10px 14px;margin-bottom:6px;background:#FFFBEB;border-radius:6px;border-left:3px solid #F59E0B;">
            <div style="font-size:14px;color:#111827;font-weight:500;">{r.get('item', '')}</div>
            <div style="font-size:12px;color:#6B7280;margin-top:2px;">{r.get('reason', '')}</div>
        </div>"""

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<title>Conceivable Weekly Brief - {date_str}</title>
</head>
<body style="margin:0;padding:0;background:#F3F4F6;font-family:Poppins,Helvetica,Arial,sans-serif;">
<div style="max-width:680px;margin:0 auto;padding:20px;">

<!-- Header -->
<div style="background:linear-gradient(135deg, #7C3AED 0%, #5B21B6 100%);border-radius:12px;padding:24px 28px;margin-bottom:20px;">
    <h1 style="margin:0;color:white;font-size:22px;font-weight:700;">Conceivable Weekly Brief</h1>
    <p style="margin:4px 0 0;color:rgba(255,255,255,0.9);font-size:14px;">{week_start} - {week_end}, {datetime.now().year}</p>
    <p style="margin:2px 0 0;color:rgba(255,255,255,0.7);font-size:12px;">Team: Lakshmi, Andrew, Maria, Kirsten, Grace</p>
</div>

<!-- Executive Summary -->
<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 10px;font-size:16px;color:#111827;">Executive Summary</h2>
    <p style="margin:0;font-size:14px;color:#374151;line-height:1.6;">{exec_summary}</p>
</div>

<!-- Key Decisions -->
{f'''<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 12px;font-size:16px;color:#111827;">Key Decisions Made</h2>
    {decisions_html}
</div>''' if decisions_html else ''}

<!-- Action Items -->
{f'''<div style="background:#F9FAFB;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 12px;font-size:16px;color:#111827;">Action Items &amp; Owners</h2>
    {actions_html}
</div>''' if actions_html else ''}

<!-- Open Blockers -->
{f'''<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 12px;font-size:16px;color:#DC2626;">Open Blockers</h2>
    {blockers_html}
</div>''' if blockers_html else ''}

<!-- Coming Next Week -->
{f'''<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 12px;font-size:16px;color:#111827;">Coming Next Week</h2>
    {next_week_html}
</div>''' if next_week_html else ''}

<!-- At Risk -->
{f'''<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 12px;font-size:16px;color:#F59E0B;">Items at Risk of Slipping</h2>
    {risk_html}
</div>''' if risk_html else ''}

<!-- Footer -->
<div style="text-align:center;padding:16px;color:#9CA3AF;font-size:12px;">
    ARIA &middot; Automated Routing &amp; Intelligence Assistant<br>
    Conceivable Weekly Brief &middot; Generated {datetime.now().strftime("%I:%M %p %A")}
</div>

</div>
</body>
</html>"""
    return html


def cleanup_old_briefings(days=14):
    """Remove conceivable weekly briefings older than N days."""
    cutoff = datetime.now() - timedelta(days=days)
    for f in BRIEFINGS_DIR.glob("conceivable-weekly-*.html"):
        try:
            date_part = f.stem.replace("conceivable-weekly-", "")
            file_date = datetime.strptime(date_part, "%Y-%m-%d")
            if file_date < cutoff:
                f.unlink()
                log(f"Cleaned up old briefing: {f.name}")
        except (ValueError, OSError):
            continue


def main():
    log("Generating Conceivable weekly brief...")
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)

    date_str = datetime.now().strftime("%Y-%m-%d")

    # Collect 7 days of data, filtered for Conceivable
    log("Collecting Conceivable emails...")
    all_emails = collect_week_data("emails", 7)
    emails = filter_conceivable_emails(all_emails)
    log(f"  {len(emails)} Conceivable emails (of {len(all_emails)} total)")

    log("Collecting Slack messages...")
    slack = collect_week_data("slack", 7)
    log(f"  {len(slack)} Slack entries (all Conceivable workspace)")

    log("Collecting awaiting items...")
    all_awaiting = collect_week_data("awaiting", 7)
    awaiting = filter_conceivable_awaiting(all_awaiting)
    log(f"  {len(awaiting)} Conceivable awaiting items")

    log("Collecting Granola meetings...")
    meetings = collect_conceivable_granola(7)
    log(f"  {len(meetings)} Conceivable meetings")

    log("Collecting Sean's notes...")
    all_notes = collect_week_data("notes", 7)
    conceivable_notes = [n for n in all_notes if (n.get("project", "").lower() == "conceivable")]
    log(f"  {len(conceivable_notes)} Conceivable notes")

    # Build context for Ollama
    context_parts = []

    context_parts.append("=== CONCEIVABLE WEEKLY DATA (last 7 days) ===")
    context_parts.append(f"Emails: {len(emails)}, Slack entries: {len(slack)}, Meetings: {len(meetings)}, Awaiting items: {len(awaiting)}")
    context_parts.append(f"Known team: Lakshmi, Andrew, Maria, Kirsten, Grace, Sean (fractional advisor)")

    if emails:
        context_parts.append(f"\n=== CONCEIVABLE EMAILS ({len(emails)}) ===")
        for e in emails[:30]:
            context_parts.append(
                f"[{e.get('date', '')[:10]}] From: {e.get('from', '')} | "
                f"Subject: {e.get('subject', '')} | {e.get('summary', '')}"
            )

    if slack:
        context_parts.append(f"\n=== SLACK MESSAGES ({len(slack)}) ===")
        # Slack data may be channel-level or message-level
        for s in slack[:40]:
            if isinstance(s, dict):
                channel = s.get("channel", s.get("channel_name", ""))
                summary = s.get("summary", s.get("text", ""))
                context_parts.append(f"[#{channel}] {summary}")

    if meetings:
        context_parts.append(f"\n=== CONCEIVABLE MEETINGS ({len(meetings)}) ===")
        for m in meetings:
            people = ", ".join(m.get("people", []))
            context_parts.append(f"[{m['date']}] {m['title']} with {people}")
            if m.get("notes"):
                context_parts.append(f"  Notes: {m['notes']}")

    if awaiting:
        context_parts.append(f"\n=== AWAITING FROM OTHERS ({len(awaiting)}) ===")
        for a in awaiting:
            context_parts.append(
                f"{a.get('owner', '?')}: {a.get('task', '')} "
                f"(from {a.get('meeting', '')} on {a.get('meeting_date', '')})"
            )

    if conceivable_notes:
        context_parts.append(f"\n=== SEAN'S NOTES ({len(conceivable_notes)}) ===")
        for n in conceivable_notes:
            due = f" (due {n.get('action_due')})" if n.get("action_due") else ""
            context_parts.append(f"  [{n.get('type', 'note')}] {n.get('content', '')}{due}")

    full_context = "\n".join(context_parts)

    log("Analyzing with Ollama (qwen3:8b)...")

    # Load style template
    template_path = PROJECT_DIR / "templates" / "conceivable-weekly-email.md"
    style_example = ""
    if template_path.exists():
        with open(template_path) as f:
            style_example = f.read()

    system_prompt = f"""You are ARIA, Sean Wright's executive assistant AI. Draft a weekly team email for the Conceivable project (a fertility app startup where Sean is fractional advisor).

Key team members: Lakshmi, Andrew, Maria, Kirsten, Grace, Peter. Sean is the fractional advisor.

Respond with ONLY a valid JSON object. No markdown, no code blocks, no thinking tags.

JSON format:
{{
  "intro": "1-2 sentence casual but professional opening",
  "where_we_stand": ["bullet 1", "bullet 2", "bullet 3"],
  "accomplishments": ["concrete deliverable 1", "concrete deliverable 2"],
  "goals": ["Owner: specific actionable goal", "Owner: another goal"],
  "closing": "1 sentence closing"
}}

STYLE RULES (match Sean's voice exactly):
- Direct, builder tone. No fluff, no filler.
- No em dashes or en dashes. Use commas or periods instead.
- Each bullet should be one clear sentence.
- Accomplishments = things that got DONE (shipped, completed, built). Not plans.
- Goals = specific tasks with owner names. Format: "Name: what they need to do"
- Where we stand = executive summary bullets about the overall state of things.
- Keep it tight. 3-5 bullets per section max. Do NOT pad with generic items.
- Only include items that are directly supported by the data. Do NOT invent details.
- If data is sparse, have fewer bullets rather than making things up.

EXAMPLE OF APPROVED OUTPUT (match this style):
{style_example}"""

    response = call_ai(system_prompt, full_context)

    if not response:
        log("AI inference failed. Generating fallback.")
        sections = {
            "intro": "Quick update on Conceivable this week.",
            "where_we_stand": [f"ARIA tracked {len(emails)} emails, {len(slack)} Slack entries, and {len(meetings)} meetings but could not generate analysis."],
            "accomplishments": [],
            "goals": [],
            "closing": "More next week.",
        }
    else:
        try:
            json_match = re.search(r'\{[\s\S]*\}', response)
            if json_match:
                sections = json.loads(json_match.group(0))
            else:
                raise ValueError("No JSON in response")
        except (json.JSONDecodeError, ValueError) as e:
            log(f"Failed to parse Ollama response: {e}")
            sections = {
                "intro": response[:300],
                "where_we_stand": [],
                "accomplishments": [],
                "goals": [],
                "closing": "",
            }

    # Generate HTML email body with proper bullet points
    log("Generating email...")
    week_start = (datetime.now() - timedelta(days=6)).strftime("%b %d")
    week_end = datetime.now().strftime("%b %d")
    subject = f"Conceivable Weekly Update: {week_start} - {week_end}"

    def bullets_html(items):
        if not items:
            return ""
        return "<ul>" + "".join(f"<li>{item}</li>" for item in items) + "</ul>"

    email_html = f"""<div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; color: #1a1a1a; line-height: 1.6;">

<p>Team,</p>

<p>{sections.get('intro', '')}</p>

<p><b>Where we stand</b></p>
{bullets_html(sections.get('where_we_stand', []))}

<p><b>Accomplishments this week</b></p>
{bullets_html(sections.get('accomplishments', []))}

<p><b>Goals this week ({week_start} - {week_end})</b></p>
{bullets_html(sections.get('goals', []))}

<p>{sections.get('closing', 'Talk soon,')}</p>
<p>Sean</p>

</div>"""

    # Save HTML version
    brief_path = BRIEFINGS_DIR / f"conceivable-weekly-{date_str}.html"
    with open(brief_path, "w") as f:
        f.write(email_html)
    log(f"Saved to {brief_path}")

    # Create Gmail draft via n8n webhook
    log("Creating Gmail draft...")
    try:
        resp = requests.post(
            BRIEFING_WEBHOOK,
            json={
                "date": date_str,
                "html": email_html,
                "subject": subject,
                "draft": True,
            },
            timeout=15,
        )
        if resp.status_code == 200:
            log("Gmail draft created")
        else:
            log(f"n8n responded {resp.status_code}: {resp.text[:100]}")
    except Exception as e:
        log(f"Could not create draft: {e}")

    # Cleanup old briefings (14-day retention)
    cleanup_old_briefings(14)

    log("Conceivable weekly brief complete!")


if __name__ == "__main__":
    main()
