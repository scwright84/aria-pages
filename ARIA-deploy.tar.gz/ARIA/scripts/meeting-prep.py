#!/usr/bin/env python3
"""
ARIA Meeting Prep Brief Generator
Checks for upcoming meetings in the next 25-35 minutes and sends
a prep email with context: last interactions, open tasks, recent emails,
and past meeting notes for each invitee.

Designed to run on a 5-minute cron via n8n or launchd.
"""

import json
import os
import re
import requests
from datetime import datetime, timedelta
from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
STATE_FILE = PROJECT_DIR / "logs" / "meeting-prep-state.json"
LOG_FILE = PROJECT_DIR / "logs" / "meeting-prep.log"

GRANOLA_CACHE = os.path.expanduser(
    "~/Library/Application Support/Granola/cache-v6.json"
)
import aria_ai


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_state():
    if STATE_FILE.exists():
        try:
            with open(STATE_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"prepped_meetings": {}}


def save_state(state):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def collect_upcoming_events():
    """Find events starting in the next 25-35 minutes."""
    now = datetime.now()
    window_start = now + timedelta(minutes=25)
    window_end = now + timedelta(minutes=35)
    today = now.strftime("%Y-%m-%d")

    events = []
    for source in ["calendar", "calendly"]:
        path = INBOX_DIR / f"{source}-{today}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                if isinstance(data, list):
                    events.extend(data)
            except Exception:
                continue

    upcoming = []
    for ev in events:
        start_str = ev.get("start_time", "")
        if not start_str:
            continue
        try:
            start = datetime.fromisoformat(start_str.replace("Z", "+00:00")).replace(tzinfo=None)
            if window_start <= start <= window_end:
                upcoming.append(ev)
        except (ValueError, TypeError):
            continue

    return upcoming


def search_emails_for_person(name, email_addr):
    """Search recent emails for mentions of a person."""
    matches = []
    today = datetime.now()
    for days_back in range(7):
        date_str = (today - timedelta(days=days_back)).strftime("%Y-%m-%d")
        path = INBOX_DIR / f"emails-{date_str}.json"
        if not path.exists():
            continue
        try:
            with open(path) as f:
                data = json.load(f)
            for e in data:
                from_field = e.get("from", "").lower()
                if name.lower() in from_field or (email_addr and email_addr.lower() in from_field):
                    matches.append({
                        "date": e.get("date", ""),
                        "subject": e.get("subject", ""),
                        "summary": e.get("summary", e.get("snippet", "")),
                        "account": e.get("account", ""),
                    })
        except Exception:
            continue
    return matches[:10]


def search_granola_for_person(name):
    """Search Granola meeting notes for a person."""
    matches = []
    try:
        with open(GRANOLA_CACHE) as f:
            data = json.load(f)
        state = data.get("cache", {}).get("state", {})
        documents = state.get("documents", {})

        for doc_id, doc in documents.items():
            if not isinstance(doc, dict):
                continue
            people = doc.get("people", {})
            person_names = []
            if isinstance(people, dict):
                for pid, person in people.items():
                    if isinstance(person, dict):
                        person_names.append(person.get("name", "").lower())
            elif isinstance(people, list):
                person_names = [p.lower() for p in people if isinstance(p, str)]

            title = doc.get("title", "")
            if name.lower() in " ".join(person_names) or name.lower() in title.lower():
                notes = doc.get("notes_markdown", doc.get("notes_plain", ""))
                matches.append({
                    "title": title,
                    "date": doc.get("created_at", "")[:10],
                    "notes_preview": notes[:300] if notes else "",
                })
    except Exception:
        pass
    # Return most recent first
    matches.sort(key=lambda m: m.get("date", ""), reverse=True)
    return matches[:5]


def collect_notion_tasks_for_project(project_name):
    """Get open tasks related to a specific project."""
    try:
        resp = requests.post(
            "http://localhost:5678/webhook/aria-query-tasks",
            json={},
            timeout=15,
        )
        if resp.status_code == 200:
            tasks = resp.json().get("tasks", [])
            return [t for t in tasks if t.get("project", "").lower() == project_name.lower()]
        return []
    except Exception:
        return []


def call_ai(system_prompt, user_content):
    result = aria_ai.chat(system_prompt, user_content)
    if result is None:
        log("AI inference call failed")
    return result


def generate_prep_html(event, context_summary):
    """Generate meeting prep email HTML."""
    meeting_name = event.get("name", event.get("title", "Meeting"))
    start_local = event.get("start_local", "?")
    duration = event.get("duration_min", "?")
    invitees = event.get("invitee_names", event.get("attendees", ""))
    join_url = event.get("join_url", "")
    today = datetime.now().strftime("%A, %B %d, %Y")

    join_html = ""
    if join_url:
        join_html = f'<a href="{join_url}" style="display:inline-block;padding:10px 20px;background:#10B981;color:white;text-decoration:none;border-radius:6px;font-weight:600;font-size:14px;margin-top:8px;">Join Meeting</a>'

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body style="margin:0;padding:0;background:#F3F4F6;font-family:Poppins,Helvetica,Arial,sans-serif;">
<div style="max-width:680px;margin:0 auto;padding:20px;">

<!-- Header -->
<div style="background:linear-gradient(135deg, #10B981 0%, #059669 100%);border-radius:12px;padding:24px 28px;margin-bottom:20px;">
    <h1 style="margin:0;color:white;font-size:20px;font-weight:700;">ARIA Prep: {meeting_name}</h1>
    <p style="margin:6px 0 0;color:rgba(255,255,255,0.9);font-size:15px;">{start_local} &middot; {duration} min &middot; {invitees}</p>
    {join_html}
</div>

<!-- Context -->
<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    {context_summary}
</div>

<!-- Footer -->
<div style="text-align:center;padding:16px;color:#9CA3AF;font-size:12px;">
    ARIA &middot; Meeting Prep Brief &middot; {today}
</div>

</div>
</body>
</html>"""
    return html


def prep_meeting(event, state):
    """Generate and send a prep brief for one meeting."""
    meeting_name = event.get("name", event.get("title", "Meeting"))
    invitee_names = event.get("invitee_names", event.get("attendees", ""))
    invitee_emails = event.get("invitee_emails", "")
    calendar_project = event.get("calendar_project", "")

    log(f"Prepping: {meeting_name} with {invitee_names}")

    # Gather context for each invitee
    context_parts = []
    names = [n.strip() for n in invitee_names.split(",") if n.strip()]
    emails = [e.strip() for e in invitee_emails.split(",") if e.strip()]

    for i, name in enumerate(names):
        email = emails[i] if i < len(emails) else ""
        context_parts.append(f"\n--- Context for {name} ({email}) ---")

        # Recent emails
        recent_emails = search_emails_for_person(name, email)
        if recent_emails:
            context_parts.append(f"Recent emails ({len(recent_emails)}):")
            for e in recent_emails[:5]:
                context_parts.append(f"  [{e['date'][:10]}] {e['subject']}: {e['summary']}")
        else:
            context_parts.append("No recent emails found.")

        # Past meetings
        past_meetings = search_granola_for_person(name)
        if past_meetings:
            context_parts.append(f"Past meetings ({len(past_meetings)}):")
            for m in past_meetings[:3]:
                context_parts.append(f"  [{m['date']}] {m['title']}")
                if m['notes_preview']:
                    context_parts.append(f"    Notes: {m['notes_preview'][:200]}")
        else:
            context_parts.append("No past meeting notes found.")

    # Get project tasks if we know the project
    project = calendar_project or ""
    if not project and names:
        # Try to infer project from email domain or name
        config = load_config()
        known = config.get("known_projects", [])
        for kp in known:
            if kp.lower() in meeting_name.lower() or kp.lower() in invitee_names.lower():
                project = kp
                break

    if project:
        tasks = collect_notion_tasks_for_project(project)
        if tasks:
            context_parts.append(f"\nOpen Notion tasks for {project} ({len(tasks)}):")
            for t in tasks[:8]:
                due = f" (due {t['due']})" if t.get('due') else ""
                status = f" [{t.get('status', '')}]" if t.get('status') else ""
                context_parts.append(f"  {t['task']}{due}{status}")

    full_context = "\n".join(context_parts)

    # Ask AI to synthesize
    full_config = aria_ai.get_full_config()
    user_name = full_config.get("client", {}).get("contact_name", "the user")

    system_prompt = f"""You are ARIA, an executive assistant AI. Generate a concise meeting prep brief for {user_name}'s upcoming meeting.

Meeting: {meeting_name}
Attendees: {invitee_names}
Project: {project or 'Unknown'}

Format your response as HTML sections. Use these exact headers with h3 tags:
- "Last Interaction" - when {user_name} last interacted with these people and what about
- "Open Items" - any open tasks or threads with these people
- "Suggested Talking Points" - 3-5 bullet points for the meeting
- "Watch Out For" - anything {user_name} should be aware of (overdue items, unanswered requests, etc.)

Keep it concise and actionable. Use inline styles (no CSS classes). Use the ARIA design: #111827 for text, #6B7280 for secondary, #0096FF for highlights."""

    response = call_ai(system_prompt, full_context)

    if not response:
        context_summary = f"""<h3 style="margin:0 0 8px;font-size:15px;color:#111827;">Context Gathered</h3>
<pre style="font-size:13px;color:#374151;white-space:pre-wrap;font-family:Poppins,sans-serif;">{full_context[:2000]}</pre>"""
    else:
        context_summary = response

    html = generate_prep_html(event, context_summary)

    # Send via n8n
    try:
        resp = requests.post(
            "http://localhost:5678/webhook/aria-send-briefing",
            json={
                "html": html,
                "subject": f"ARIA Prep: {meeting_name} in 30 min",
            },
            timeout=15,
        )
        if resp.status_code == 200:
            log(f"  Prep email sent for {meeting_name}")
        else:
            log(f"  n8n responded {resp.status_code}")
    except Exception as e:
        log(f"  Could not send prep email: {e}")

    # Mark as prepped
    event_key = event.get("uri", event.get("event_id", meeting_name))
    state["prepped_meetings"][event_key] = datetime.now().isoformat()
    save_state(state)


def main():
    state = load_state()

    # Clean up old state entries (older than 2 days)
    cutoff = (datetime.now() - timedelta(days=2)).isoformat()
    state["prepped_meetings"] = {
        k: v for k, v in state["prepped_meetings"].items()
        if v > cutoff
    }

    upcoming = collect_upcoming_events()
    if not upcoming:
        return  # Silent exit, this runs every 5 min

    for event in upcoming:
        event_key = event.get("uri", event.get("event_id", event.get("name", "")))
        if event_key in state["prepped_meetings"]:
            continue  # Already prepped

        # Skip all-day events
        if event.get("is_all_day"):
            continue

        prep_meeting(event, state)


if __name__ == "__main__":
    main()
