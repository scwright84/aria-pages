#!/usr/bin/env python3
"""
ARIA Morning Briefing Generator
Collects all incoming data from the last 24 hours, triages with Ollama,
generates an HTML briefing, saves to file, and sends via Gmail.

Run at 7:05am after syncs complete, or manually anytime.
"""

import sqlite3
import plistlib
import json
import os
import sys
import hashlib
import glob
import requests
from datetime import datetime, timedelta
from pathlib import Path
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

PROJECT_DIR = Path(__file__).parent.parent
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
INBOX_DIR = PROJECT_DIR / "inbox"
LOG_FILE = PROJECT_DIR / "logs" / "briefing.log"

NOTIFICATION_DB = os.path.expanduser(
    "~/Library/Group Containers/group.com.apple.usernoted/db2/db"
)
GRANOLA_CACHE = os.path.expanduser(
    "~/Library/Application Support/Granola/cache-v6.json"
)

import aria_ai

WATCHED_APPS = {
    "com.apple.mobilesms": "iMessage",
    "com.apple.ichat": "Messages",
    "desktop.whatsapp": "WhatsApp",
    "net.whatsapp.whatsapp": "WhatsApp",
    "org.whispersystems.signal-desktop": "Signal",
    "com.tdesktop.telegram": "Telegram",
    "com.tinyspeck.slackmacgap": "Slack",
    "com.microsoft.teams2": "Teams",
    "com.hnc.discord": "Discord",
    "com.apple.mail": "Apple Mail",
    "com.microsoft.outlook": "Outlook",
    "com.apple.facetime": "FaceTime",
}

# Load projects from config (falls back to empty list)
_full_config = aria_ai.get_full_config()
KNOWN_PROJECTS = _full_config.get("projects", _full_config.get("known_projects", []))


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


# --- Data Collection ---

def collect_notion_tasks():
    """Get open tasks from the Notion Monitor Board via n8n webhook."""
    try:
        resp = requests.post(
            "http://localhost:5678/webhook/aria-query-tasks",
            json={},
            timeout=15,
        )
        if resp.status_code == 200:
            data = resp.json()
            return data.get("tasks", [])
        else:
            log(f"Notion query failed: {resp.status_code}")
            return []
    except Exception as e:
        log(f"Error querying Notion: {e}")
        return []


def collect_notifications(since_hours=24):
    """Get messaging notifications from the last N hours."""
    cutoff_core_data = (datetime.now() - timedelta(hours=since_hours)).timestamp() - 978307200
    app_ids_str = ", ".join(f"'{app}'" for app in WATCHED_APPS.keys())

    try:
        conn = sqlite3.connect(f"file:{NOTIFICATION_DB}?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute(f"""
            SELECT r.rec_id, a.identifier, r.data, r.delivered_date
            FROM record r JOIN app a ON r.app_id = a.app_id
            WHERE a.identifier IN ({app_ids_str})
              AND r.delivered_date > ?
            ORDER BY r.delivered_date ASC
        """, (cutoff_core_data,))

        messages = []
        for row in cursor.fetchall():
            try:
                plist = plistlib.loads(row["data"])
                req = plist.get("req", {})
                body = req.get("body", "")
                title = req.get("titl", "")
                if not body and not title:
                    continue
                unix_ts = row["delivered_date"] + 978307200
                messages.append({
                    "source": "notification",
                    "app": WATCHED_APPS.get(row["identifier"], row["identifier"]),
                    "sender": title,
                    "body": body,
                    "subtitle": req.get("subt", ""),
                    "timestamp": datetime.fromtimestamp(unix_ts).isoformat(),
                })
            except Exception:
                continue
        conn.close()
        return messages
    except Exception as e:
        log(f"Error reading notifications: {e}")
        return []


def collect_emails():
    """Get triaged emails from n8n inbox files."""
    today = datetime.now().strftime("%Y-%m-%d")
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    emails = []
    for date_str in [today, yesterday]:
        path = INBOX_DIR / f"emails-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                if isinstance(data, list):
                    emails.extend(data)
            except Exception:
                continue
    # Deduplicate by message_id
    seen = set()
    unique = []
    for e in emails:
        mid = e.get("message_id", "")
        if mid and mid not in seen:
            seen.add(mid)
            unique.append(e)
    return unique


def collect_notes():
    """Get captured notes from Telegram."""
    today = datetime.now().strftime("%Y-%m-%d")
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    notes = []
    for date_str in [today, yesterday]:
        path = INBOX_DIR / f"notes-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                if isinstance(data, list):
                    notes.extend(data)
            except Exception:
                continue
    return notes


def collect_slack():
    """Get triaged Slack summaries from n8n inbox files."""
    today = datetime.now().strftime("%Y-%m-%d")
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    channels = []
    for date_str in [today, yesterday]:
        path = INBOX_DIR / f"slack-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                if isinstance(data, list):
                    channels.extend(data)
            except Exception:
                continue
    # Deduplicate by channel_name (keep newest)
    seen = {}
    for ch in channels:
        seen[ch.get("channel_name", "")] = ch
    return list(seen.values())


def collect_calendly():
    """Get upcoming Calendly events from inbox files."""
    today = datetime.now().strftime("%Y-%m-%d")
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    events = []
    for date_str in [today, yesterday]:
        path = INBOX_DIR / f"calendly-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                if isinstance(data, list):
                    events.extend(data)
            except Exception:
                continue
    # Deduplicate by URI
    seen = {}
    for ev in events:
        seen[ev.get("uri", "")] = ev
    return list(seen.values())


def collect_calendar():
    """Get Google Calendar events from inbox files."""
    today = datetime.now().strftime("%Y-%m-%d")
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    events = []
    for date_str in [today, yesterday]:
        path = INBOX_DIR / f"calendar-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                if isinstance(data, list):
                    events.extend(data)
            except Exception:
                continue
    # Deduplicate by URI
    seen = {}
    for ev in events:
        seen[ev.get("uri", "")] = ev
    return list(seen.values())


def merge_calendar_events(calendar_events, calendly_events):
    """Merge Google Calendar and Calendly events, deduplicating by time overlap."""
    all_events = list(calendly_events)  # Calendly events take priority (have invitee data)

    for cal_ev in calendar_events:
        cal_start = cal_ev.get("start_time", "")
        cal_name = cal_ev.get("name", "").lower()
        is_duplicate = False

        for existing in all_events:
            ex_start = existing.get("start_time", "")
            # Check for time overlap (within 15 min) and similar names
            if cal_start and ex_start:
                try:
                    t1 = datetime.fromisoformat(cal_start.replace("Z", "+00:00")).replace(tzinfo=None)
                    t2 = datetime.fromisoformat(ex_start.replace("Z", "+00:00")).replace(tzinfo=None)
                    time_diff = abs((t1 - t2).total_seconds())
                    if time_diff < 900:  # 15 min overlap
                        is_duplicate = True
                        # Merge any missing data from calendar event
                        if not existing.get("join_url") and cal_ev.get("join_url"):
                            existing["join_url"] = cal_ev["join_url"]
                        if not existing.get("description") and cal_ev.get("description"):
                            existing["description"] = cal_ev["description"]
                        break
                except (ValueError, TypeError):
                    pass

        if not is_duplicate:
            all_events.append(cal_ev)

    # Sort by start time
    all_events.sort(key=lambda e: e.get("start_time", ""))
    return all_events


def collect_news():
    """Get news intelligence items from inbox files."""
    today = datetime.now().strftime("%Y-%m-%d")
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    items = []
    for date_str in [today, yesterday]:
        path = INBOX_DIR / f"news-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                if isinstance(data, list):
                    items.extend(data)
            except Exception:
                continue
    # Deduplicate by hash
    seen = set()
    unique = []
    for item in items:
        h = item.get("hash", "")
        if h and h not in seen:
            seen.add(h)
            unique.append(item)
    # Sort by score descending
    unique.sort(key=lambda x: x.get("score", 0), reverse=True)
    return unique


def collect_model_alerts():
    """Get new AI model alerts from inbox files."""
    today = datetime.now().strftime("%Y-%m-%d")
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    items = []
    for date_str in [today, yesterday]:
        path = INBOX_DIR / f"models-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                if isinstance(data, list):
                    items.extend(data)
            except Exception:
                continue
    # Deduplicate by model_id
    seen = set()
    unique = []
    for item in items:
        mid = item.get("model_id", "")
        if mid and mid not in seen:
            seen.add(mid)
            unique.append(item)
    unique.sort(key=lambda x: x.get("score", 0), reverse=True)
    return unique


def collect_notifications_from_inbox():
    """Get pre-triaged notifications from inbox files (preferred over raw DB)."""
    today = datetime.now().strftime("%Y-%m-%d")
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    notifications = []
    for date_str in [today, yesterday]:
        path = INBOX_DIR / f"notifications-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                if isinstance(data, list):
                    notifications.extend(data)
            except Exception:
                continue
    # Deduplicate by rec_id
    seen = set()
    unique = []
    for n in notifications:
        rid = n.get("rec_id", 0)
        if rid and rid not in seen:
            seen.add(rid)
            unique.append(n)
    return unique


def collect_granola_meetings(since_hours=24):
    """Get Granola meeting notes updated in the last N hours."""
    cutoff = datetime.now() - timedelta(hours=since_hours)

    try:
        with open(GRANOLA_CACHE) as f:
            data = json.load(f)
        state = data.get("cache", {}).get("state", {})
        documents = state.get("documents", {})
        transcripts = state.get("transcripts", {})

        meetings = []
        for doc_id, doc in documents.items():
            if not isinstance(doc, dict):
                continue
            updated = doc.get("updated_at", doc.get("created_at", ""))
            if not updated:
                continue
            try:
                doc_time = datetime.fromisoformat(updated.replace("Z", "+00:00")).replace(tzinfo=None)
                if doc_time < cutoff:
                    continue
            except (ValueError, TypeError):
                continue

            notes = ""
            if doc.get("notes_markdown"):
                notes = doc["notes_markdown"]
            elif doc.get("notes_plain"):
                notes = doc["notes_plain"]

            transcript_segs = transcripts.get(doc_id, [])
            transcript_preview = ""
            if isinstance(transcript_segs, list) and transcript_segs:
                lines = [s.get("text", "").strip() for s in transcript_segs[:80] if s.get("text", "").strip()]
                transcript_preview = " ".join(lines)[:1500]

            meetings.append({
                "source": "granola",
                "title": doc.get("title", "Untitled"),
                "created_at": doc.get("created_at", ""),
                "notes": notes[:1000],
                "transcript_preview": transcript_preview,
                "segment_count": len(transcript_segs) if isinstance(transcript_segs, list) else 0,
            })
        return meetings
    except Exception as e:
        log(f"Error reading Granola: {e}")
        return []


# --- AI Inference ---

def call_ai(system_prompt, user_content):
    """Call AI inference and return the response content."""
    result = aria_ai.chat(system_prompt, user_content, timeout=180)
    if result is None:
        log("AI inference call failed")
    return result


# --- HTML Generation ---

def generate_briefing_html(date_str, sections, notion_tasks=None, calendly_events=None, news_items=None, model_alerts=None):
    """Generate the morning briefing HTML."""
    today = datetime.now().strftime("%A, %B %d, %Y")
    notion_tasks = notion_tasks or []
    calendly_events = calendly_events or []
    news_items = news_items or []
    model_alerts = model_alerts or []

    action_items_html = ""
    for item in sections.get("action_items", []):
        priority_color = {"high": "#DC2626", "medium": "#D97706", "low": "#059669"}.get(item.get("priority", "medium"), "#6B7280")
        action_items_html += f"""
        <tr>
            <td style="padding:8px 12px;border-bottom:1px solid #E5E7EB;">
                <span style="display:inline-block;padding:2px 8px;border-radius:4px;background:{priority_color};color:white;font-size:11px;font-weight:600;text-transform:uppercase;">{item.get('priority', 'medium')}</span>
            </td>
            <td style="padding:8px 12px;border-bottom:1px solid #E5E7EB;color:#374151;">{item.get('project', '')}</td>
            <td style="padding:8px 12px;border-bottom:1px solid #E5E7EB;color:#111827;">{item.get('description', '')}</td>
            <td style="padding:8px 12px;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:13px;">{item.get('from', '')}</td>
            <td style="padding:8px 12px;border-bottom:1px solid #E5E7EB;color:#9CA3AF;font-size:11px;font-style:italic;">{item.get('source', '')}</td>
        </tr>"""

    messages_by_project = {}
    for msg in sections.get("messages", []):
        proj = msg.get("project", "Other")
        if proj not in messages_by_project:
            messages_by_project[proj] = []
        messages_by_project[proj].append(msg)

    messages_html = ""
    for proj in sorted(messages_by_project.keys()):
        msgs = messages_by_project[proj]
        messages_html += f'<h3 style="margin:16px 0 8px;font-family:Poppins,sans-serif;font-size:15px;color:#0096FF;font-weight:600;">{proj}</h3>'
        for msg in msgs:
            priority_colors = {"high": "#DC2626", "medium": "#D97706", "low": "#059669"}
            border_color = priority_colors.get(msg.get("priority", "low"), "#E5E7EB")
            messages_html += f"""
            <div style="padding:8px 12px;margin-bottom:4px;background:#F9FAFB;border-radius:6px;border-left:3px solid {border_color};">
                <div style="font-size:13px;color:#6B7280;">{msg.get('source', '')} &middot; {msg.get('sender', '')} &middot; {msg.get('time', '')}</div>
                <div style="font-size:14px;color:#111827;margin-top:2px;">{msg.get('summary', '')}</div>
            </div>"""

    meetings_html = ""
    for mtg in sections.get("meetings", []):
        source_tag = f" <span style='font-size:11px;color:#9CA3AF;font-style:italic;'>via {mtg.get('source', 'Granola')}</span>" if mtg.get('source') else ""
        attendees = mtg.get('attendees', '')
        if isinstance(attendees, list):
            attendees = ', '.join(attendees)
        meetings_html += f"""
        <div style="padding:10px 12px;margin-bottom:8px;background:#F0F9FF;border-radius:6px;border-left:3px solid #0096FF;">
            <div style="font-size:15px;font-weight:600;color:#111827;">{mtg.get('title', '')}</div>
            <div style="font-size:13px;color:#6B7280;margin-top:2px;">{mtg.get('time', '')} &middot; {attendees}{source_tag}</div>
            <div style="font-size:14px;color:#374151;margin-top:6px;">{mtg.get('summary', '')}</div>
            {"<div style='font-size:13px;color:#DC2626;margin-top:4px;font-weight:500;'>Action items: " + (', '.join(mtg['actions']) if isinstance(mtg.get('actions'), list) else str(mtg.get('actions', ''))) + "</div>" if mtg.get('actions') else ""}
        </div>"""

    # News intelligence
    news_html = ""
    for item in news_items[:8]:
        urgency_badge = ""
        if item.get("urgency") == "action":
            urgency_badge = '<span style="display:inline-block;padding:1px 6px;border-radius:3px;background:#DC2626;color:white;font-size:10px;font-weight:600;margin-right:6px;">ACTION</span>'
        score = item.get("score", 0)
        score_color = "#10B981" if score >= 80 else "#F59E0B" if score >= 60 else "#6B7280"
        clients = ", ".join(item.get("clients", []))
        link = item.get("link", "")
        title_html = f'<a href="{link}" style="color:#111827;text-decoration:none;font-weight:500;">{item.get("title", "")}</a>' if link else item.get("title", "")
        news_html += f"""
        <div style="padding:8px 12px;margin-bottom:6px;background:#FEFCE8;border-radius:6px;border-left:3px solid {score_color};">
            <div style="font-size:14px;color:#111827;">{urgency_badge}{title_html}</div>
            <div style="font-size:12px;color:#6B7280;margin-top:2px;">{item.get('vertical_label', '')} &middot; {clients} &middot; Score: {score}</div>
            <div style="font-size:13px;color:#374151;margin-top:3px;">{item.get('score_reason', '')}</div>
        </div>"""

    # Model intelligence alerts
    models_html = ""
    # Load current stack for comparison context
    model_config_path = PROJECT_DIR / "config" / "model-tracker.json"
    current_stack_info = {}
    try:
        if model_config_path.exists():
            with open(model_config_path) as f:
                mc = json.load(f)
            current_stack_info = mc.get("current_stack", {})
    except Exception:
        pass

    for model in model_alerts[:5]:
        action = model.get("action", "watch")
        action_colors = {"evaluate": "#DC2626", "watch": "#F59E0B", "skip": "#6B7280"}
        action_color = action_colors.get(action, "#6B7280")
        action_badge = f'<span style="display:inline-block;padding:1px 6px;border-radius:3px;background:{action_color};color:white;font-size:10px;font-weight:600;margin-right:6px;">{action.upper()}</span>'
        score = model.get("score", 0)
        category = model.get("category", "")
        discovered = model.get("discovered_at", "")[:10]

        # What Pippa model this competes with
        competes_with = ""
        if category in ("image_generation", "image_editing"):
            primary = current_stack_info.get("image", {}).get("primary", "")
            if primary:
                competes_with = f"Competes with: {primary.split('/')[-1]}"
        elif category in ("video_generation", "image_to_video"):
            primary = current_stack_info.get("video", {}).get("primary", "")
            fallback = current_stack_info.get("video", {}).get("fallback", "")
            if primary:
                competes_with = f"Competes with: {primary.split('/')[-1]}"
                if fallback:
                    competes_with += f", {fallback.split('/')[-1]}"
        elif category in ("lip_sync", "avatar"):
            primary = current_stack_info.get("lip_sync", {}).get("primary", "")
            if primary:
                competes_with = f"Competes with: {primary.split('/')[-1]}"

        models_html += f"""
        <div style="padding:10px 12px;margin-bottom:8px;background:#F0FDF4;border-radius:6px;border-left:3px solid #10B981;">
            <div style="font-size:14px;color:#111827;">{action_badge}<strong>{model.get('model_id', '')}</strong></div>
            <div style="font-size:12px;color:#6B7280;margin-top:3px;">{category.replace('_', ' ').title()} &middot; {model.get('provider', 'fal.ai')} &middot; Score: {score} &middot; Found: {discovered}</div>
            <div style="font-size:13px;color:#374151;margin-top:3px;">{model.get('score_reason', '')}</div>
            {"<div style='font-size:12px;color:#0066CC;margin-top:3px;'>" + competes_with + "</div>" if competes_with else ""}
        </div>"""

    # Add reply instructions to model section
    if models_html:
        models_html += """
        <div style="margin-top:10px;padding:10px 12px;background:#F3F4F6;border-radius:6px;font-size:12px;color:#6B7280;">
            <strong>Reply to act on models:</strong> "test [model name]" / "skip [model name]" / "evaluate [model name]"<br>
            ARIA will create a test plan in PippaExplorer docs and track the evaluation.
        </div>"""

    new_entities_html = ""
    for entity in sections.get("new_entities", []):
        new_entities_html += f"""
        <div style="padding:8px 12px;margin-bottom:4px;background:#FFF7ED;border-radius:6px;border-left:3px solid #F59E0B;">
            <div style="font-size:14px;font-weight:600;color:#92400E;">{entity.get('name', '')}</div>
            <div style="font-size:13px;color:#78716C;">{entity.get('context', '')}</div>
        </div>"""

    # Build today's schedule from Calendly
    schedule_html = ""
    if calendly_events:
        today_date = datetime.now().strftime("%Y-%m-%d")
        today_events = [e for e in calendly_events if e.get("start_time", "")[:10] == today_date]
        if today_events:
            for ev in today_events:
                zoom_link = ""
                if ev.get("join_url"):
                    zoom_link = f' <a href="{ev["join_url"]}" style="color:#0096FF;text-decoration:none;font-size:13px;">Join Zoom</a>'
                invitees = ev.get("invitee_names", "")
                schedule_html += f"""<div style="padding:10px 12px;margin-bottom:6px;background:#F0FDF4;border-radius:6px;border-left:3px solid #10B981;">
                    <div style="display:flex;align-items:baseline;gap:8px;">
                        <span style="font-size:14px;font-weight:600;color:#111827;white-space:nowrap;">{ev.get('start_local', '?')} - {ev.get('end_local', '?')}</span>
                        <span style="font-size:14px;color:#374151;">{ev.get('name', 'Meeting')}</span>
                        {zoom_link}
                    </div>
                    <div style="font-size:13px;color:#6B7280;margin-top:2px;">With {invitees} &middot; {ev.get('duration_min', '?')} min</div>
                </div>"""

    # Build commitments section from Notion tasks
    commitments_html = ""
    if notion_tasks:
        overdue = [t for t in notion_tasks if t.get("overdue")]
        upcoming = [t for t in notion_tasks if not t.get("overdue") and t.get("due")]

        if overdue:
            commitments_html += '<div style="margin-bottom:10px;"><div style="font-size:13px;font-weight:600;color:#DC2626;margin-bottom:6px;">OVERDUE</div>'
            for t in overdue:
                commitments_html += f"""<div style="padding:6px 12px;margin-bottom:3px;background:#FEF2F2;border-radius:6px;border-left:3px solid #DC2626;">
                    <div style="font-size:14px;color:#111827;font-weight:500;">{t['task']}</div>
                    <div style="font-size:12px;color:#6B7280;">{t['project']} &middot; Due {t['due']}</div>
                </div>"""
            commitments_html += '</div>'

        if upcoming:
            commitments_html += '<div><div style="font-size:13px;font-weight:600;color:#374151;margin-bottom:6px;">UPCOMING</div>'
            for t in upcoming[:8]:
                commitments_html += f"""<div style="padding:6px 12px;margin-bottom:3px;background:#F9FAFB;border-radius:6px;border-left:3px solid #0096FF;">
                    <div style="font-size:14px;color:#111827;font-weight:500;">{t['task']}</div>
                    <div style="font-size:12px;color:#6B7280;">{t['project']} &middot; Due {t['due']}</div>
                </div>"""
            commitments_html += '</div>'

    schedule_section = ""
    if schedule_html:
        schedule_section = f'''<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 12px;font-size:16px;color:#111827;">Today&apos;s Schedule</h2>
    {schedule_html}
</div>'''

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<title>ARIA Briefing - {date_str}</title>
</head>
<body style="margin:0;padding:0;background:#F3F4F6;font-family:Poppins,Helvetica,Arial,sans-serif;">
<div style="max-width:680px;margin:0 auto;padding:20px;">

<!-- Header -->
<div style="background:linear-gradient(135deg, #0096FF 0%, #0066CC 100%);border-radius:12px;padding:24px 28px;margin-bottom:20px;">
    <h1 style="margin:0;color:white;font-size:22px;font-weight:700;">ARIA Morning Briefing</h1>
    <p style="margin:4px 0 0;color:rgba(255,255,255,0.85);font-size:14px;">{today}</p>
    <p style="margin:2px 0 0;color:rgba(255,255,255,0.7);font-size:12px;">Reply to this email to ask ARIA anything</p>
</div>

<!-- Today's Schedule -->
{schedule_section}

<!-- Executive Summary -->
<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 10px;font-size:16px;color:#111827;">Summary</h2>
    <p style="margin:0;font-size:14px;color:#374151;line-height:1.6;">{sections.get('executive_summary', 'No activity to report.')}</p>
</div>

<!-- Action Items -->
{f'''<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 12px;font-size:16px;color:#111827;">Needs Your Attention</h2>
    <table style="width:100%;border-collapse:collapse;font-size:14px;">
        <tr style="background:#F9FAFB;">
            <th style="padding:8px 12px;text-align:left;font-size:12px;color:#6B7280;font-weight:600;border-bottom:2px solid #E5E7EB;width:70px;">Priority</th>
            <th style="padding:8px 12px;text-align:left;font-size:12px;color:#6B7280;font-weight:600;border-bottom:2px solid #E5E7EB;width:100px;">Project</th>
            <th style="padding:8px 12px;text-align:left;font-size:12px;color:#6B7280;font-weight:600;border-bottom:2px solid #E5E7EB;">What</th>
            <th style="padding:8px 12px;text-align:left;font-size:12px;color:#6B7280;font-weight:600;border-bottom:2px solid #E5E7EB;width:100px;">From</th>
            <th style="padding:8px 12px;text-align:left;font-size:12px;color:#6B7280;font-weight:600;border-bottom:2px solid #E5E7EB;width:80px;">Source</th>
        </tr>
        {action_items_html}
    </table>
</div>''' if action_items_html else ''}

<!-- Commitments (from Notion) -->
{f'''<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 12px;font-size:16px;color:#111827;">Commitments</h2>
    {commitments_html}
</div>''' if commitments_html else ''}

<!-- Meetings -->
{f'''<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 12px;font-size:16px;color:#111827;">Recent Meetings</h2>
    <p style="margin:0 0 10px;font-size:12px;color:#9CA3AF;">From Granola notes (last 24 hours)</p>
    {meetings_html}
</div>''' if meetings_html else ''}

<!-- Messages by Project -->
{f'''<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 8px;font-size:16px;color:#111827;">Messages</h2>
    {messages_html}
</div>''' if messages_html else ''}

<!-- News Intelligence -->
{f'''<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 12px;font-size:16px;color:#111827;">Industry Intel</h2>
    {news_html}
</div>''' if news_html else ''}

<!-- Model Intelligence -->
{f'''<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 12px;font-size:16px;color:#111827;">Pippa Model Tracker</h2>
    {models_html}
</div>''' if models_html else ''}

<!-- New Entities -->
{f'''<div style="background:white;border-radius:10px;padding:20px 24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <h2 style="margin:0 0 12px;font-size:16px;color:#111827;">New on the Radar</h2>
    {new_entities_html}
</div>''' if new_entities_html else ''}

<!-- Footer -->
<div style="text-align:center;padding:16px;color:#9CA3AF;font-size:12px;">
    ARIA &middot; Automated Routing &amp; Intelligence Assistant<br>
    Generated {datetime.now().strftime("%I:%M %p")} &middot; Data from last 24 hours
</div>

</div>
</body>
</html>"""
    return html


# --- Main ---

def main():
    log("Generating morning briefing...")
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)

    date_str = datetime.now().strftime("%Y-%m-%d")

    # Collect data
    log("Collecting notifications from inbox...")
    notifications = collect_notifications_from_inbox()
    if not notifications:
        log("  No inbox notifications, falling back to raw DB...")
        notifications = collect_notifications(since_hours=24)
    log(f"  {len(notifications)} notifications")

    log("Collecting Granola meetings...")
    meetings = collect_granola_meetings(since_hours=24)
    log(f"  {len(meetings)} meetings")

    log("Collecting emails from inbox...")
    emails = collect_emails()
    log(f"  {len(emails)} emails")

    log("Collecting Slack from inbox...")
    slack_channels = collect_slack()
    log(f"  {len(slack_channels)} slack channels")

    log("Collecting Calendly events...")
    calendly_events = collect_calendly()
    log(f"  {len(calendly_events)} Calendly events")

    log("Collecting Google Calendar events...")
    calendar_events = collect_calendar()
    log(f"  {len(calendar_events)} calendar events")

    # Merge calendar sources (dedup by time overlap)
    all_calendar_events = merge_calendar_events(calendar_events, calendly_events)
    log(f"  {len(all_calendar_events)} total events after merge")

    # First-run detection: if no data from any source, generate welcome briefing
    total_data = len(notifications) + len(meetings) + len(emails) + len(slack_channels) + len(all_calendar_events)
    if total_data == 0:
        log("No data from any source. Generating welcome briefing (first run).")
        full_config = aria_ai.get_full_config()
        client_name = full_config.get("client", {}).get("contact_name", "")
        greeting = f"Welcome, {client_name}!" if client_name else "Welcome to ARIA!"
        sections = {
            "bluf": f"{greeting} ARIA is now collecting data from your connected accounts. Your first real briefing with triaged emails, calendar prep, and commitment tracking will arrive tomorrow morning. In the meantime, try messaging the Telegram bot to make sure it's working.",
            "decisions_needed": [],
            "todays_schedule": [],
            "commitments_you_owe": [],
            "waiting_on_others": [],
            "project_pulse": [],
            "overnight_comms": [],
            "strategic_radar": [],
            "closing": "ARIA is online and monitoring your channels. See you tomorrow morning.",
        }
        email_html = generate_briefing_html(date_str, sections)
        html_path = BRIEFINGS_DIR / f"{date_str}.html"
        with open(html_path, "w") as f:
            f.write(email_html)
        log(f"Welcome briefing saved to {html_path}")

        # Send welcome email
        import aria_email
        recipient = full_config.get("email", "")
        subject = f"ARIA is Online - {datetime.now().strftime('%A, %B %d')}"
        if recipient:
            success, method = aria_email.send_briefing_email(recipient, subject, email_html)
            log(f"Welcome email {'sent via ' + method if success else 'failed'}")
        return

    log("Collecting news intelligence...")
    news_items = collect_news()
    log(f"  {len(news_items)} news items")

    log("Collecting model alerts...")
    model_alerts = collect_model_alerts()
    log(f"  {len(model_alerts)} model alerts")

    log("Collecting Notion tasks...")
    notion_tasks = collect_notion_tasks()
    log(f"  {len(notion_tasks)} open tasks")

    log("Collecting user notes...")
    captured_notes = collect_notes()
    log(f"  {len(captured_notes)} notes")

    # Build context for Ollama
    context_parts = []

    if notifications:
        context_parts.append("=== MESSAGES FROM NOTIFICATIONS (source: macOS notification center, last 24h) ===")
        for n in notifications:
            app = n.get('app', n.get('app_name', 'Unknown'))
            sub = f" [{n['subtitle']}]" if n.get('subtitle') else ""
            # Use pre-triaged summary if available, otherwise raw body
            body = n.get('summary', n.get('body', ''))[:200]
            sender = n.get('sender', 'Unknown')
            priority = n.get('priority', '')
            prefix = f"[{priority.upper()}] " if priority else ""
            context_parts.append(f"{prefix}[{app}{sub}] {sender}: {body}")

    if emails:
        context_parts.append("\n=== EMAILS (source: Gmail/Outlook, last 24h) ===")
        for e in emails:
            priority = e.get("priority", "medium")
            project = e.get("detected_project", "Unknown")
            action = e.get("action_type", "fyi")
            summary = e.get("summary", e.get("subject", ""))
            context_parts.append(
                f"[{e.get('account', 'email')}] From: {e.get('from', '?')} | "
                f"Subject: {e.get('subject', '?')} | Priority: {priority} | "
                f"Project: {project} | Action: {action} | Summary: {summary}"
            )

    if slack_channels:
        context_parts.append("\n=== SLACK (last 24h) ===")
        for ch in slack_channels:
            context_parts.append(
                f"#{ch.get('channel_name', '?')} ({ch.get('message_count', 0)} msgs) | "
                f"Urgency: {ch.get('urgency', 'low')} | "
                f"Summary: {ch.get('summary', 'No summary')}"
            )
            actions = ch.get("action_items", [])
            if actions:
                context_parts.append(f"  Action items: {', '.join(actions)}")

    if meetings:
        context_parts.append("\n=== PAST MEETINGS (from Granola notes - these already happened, NOT today) ===")
        for m in meetings:
            context_parts.append(f"PAST Meeting: {m['title']} (date: {m['created_at'][:10]})")
            if m['notes']:
                context_parts.append(f"  Notes (verbatim from Granola): {m['notes'][:800]}")
            if m['transcript_preview']:
                context_parts.append(f"  Transcript excerpt: {m['transcript_preview'][:1000]}")
            context_parts.append("  IMPORTANT: Only report facts that appear in the notes/transcript above. Do NOT embellish.")

    if all_calendar_events:
        today_date = datetime.now().strftime("%Y-%m-%d")
        today_events = [e for e in all_calendar_events if e.get("start_time", "")[:10] == today_date]
        future_events = [e for e in all_calendar_events if e.get("start_time", "")[:10] > today_date]

        if today_events:
            context_parts.append("\n=== TODAY'S MEETINGS (Calendly) ===")
            for ev in today_events:
                invitees = ev.get("invitee_names", "")
                context_parts.append(
                    f"{ev.get('start_local', '?')} - {ev.get('end_local', '?')}: "
                    f"{ev.get('name', 'Meeting')} with {invitees} "
                    f"({ev.get('duration_min', '?')} min)"
                )
        if future_events:
            context_parts.append(f"\n=== UPCOMING MEETINGS ({len(future_events)} this week) ===")
            for ev in future_events[:10]:
                invitees = ev.get("invitee_names", "")
                context_parts.append(
                    f"{ev.get('date_local', '?')} {ev.get('start_local', '?')}: "
                    f"{ev.get('name', 'Meeting')} with {invitees}"
                )

    if notion_tasks:
        overdue = [t for t in notion_tasks if t.get("overdue")]
        upcoming = [t for t in notion_tasks if not t.get("overdue") and t.get("due")]
        no_date = [t for t in notion_tasks if not t.get("due")]

        context_parts.append(f"\n=== NOTION TASKS ({len(notion_tasks)} open) ===")
        if overdue:
            context_parts.append(f"OVERDUE ({len(overdue)}):")
            for t in overdue:
                context_parts.append(f"  [{t['project']}] {t['task']} (due {t['due']})")
        if upcoming:
            context_parts.append(f"UPCOMING:")
            for t in upcoming[:10]:
                context_parts.append(f"  [{t['project']}] {t['task']} (due {t['due']})")
        if no_date:
            context_parts.append(f"NO DUE DATE ({len(no_date)}):")
            for t in no_date[:5]:
                context_parts.append(f"  [{t['project']}] {t['task']}")

    if news_items:
        context_parts.append(f"\n=== NEWS INTELLIGENCE ({len(news_items)} items) ===")
        for item in news_items[:8]:
            urgency = "[ACTION] " if item.get("urgency") == "action" else ""
            clients = ", ".join(item.get("clients", []))
            context_parts.append(
                f"{urgency}[{item.get('vertical_label', '')}] {item.get('title', '')} "
                f"(score: {item.get('score', 0)}, clients: {clients})\n"
                f"  Why: {item.get('score_reason', '')}\n"
                f"  {item.get('description', '')[:150]}"
            )

    # Collect awaiting items (what others owe the user)
    awaiting_items = []
    for days_back in range(7):
        date_str_back = (datetime.now() - timedelta(days=days_back)).strftime("%Y-%m-%d")
        awaiting_path = INBOX_DIR / f"awaiting-{date_str_back}.json"
        if awaiting_path.exists():
            try:
                with open(awaiting_path) as f:
                    data = json.load(f)
                if isinstance(data, list):
                    awaiting_items.extend(data)
            except Exception:
                continue

    if awaiting_items:
        context_parts.append(f"\n=== WAITING ON OTHERS ({len(awaiting_items)} items) ===")
        for item in awaiting_items:
            context_parts.append(f"  [{item.get('project', '')}] {item.get('owner', '?')} owes: {item.get('task', '')} (from {item.get('meeting', '')} on {item.get('meeting_date', '')})")

    if captured_notes:
        context_parts.append(f"\n=== SEAN'S CAPTURED NOTES ({len(captured_notes)} items) ===")
        for note in captured_notes:
            project = note.get("project", "Personal")
            content = note.get("content", "")
            ntype = note.get("type", "note")
            due = note.get("action_due", "")
            due_str = f" (due {due})" if due else ""
            context_parts.append(f"  [{project}] ({ntype}) {content}{due_str}")

    # Gather intelligence from all analytics engines
    log("Gathering intelligence from analytics...")
    intel_html = ""
    try:
        import briefing_intelligence
        intel_data = briefing_intelligence.gather_intelligence()
        intel_context = intel_data.get("context_for_ai", "")
        intel_html = briefing_intelligence.format_intelligence_html(intel_data.get("intelligence", {}))
        log(f"  {intel_data.get('section_count', 0)} intelligence sections loaded")
        if intel_context:
            context_parts.append(intel_context)
    except Exception as e:
        log(f"  Intelligence gathering failed (non-critical): {e}")

    if not context_parts:
        log("No data to report. Skipping briefing.")
        return

    full_context = "\n".join(context_parts)

    # Ask AI to analyze and structure
    log("Analyzing with AI...")
    today_str = datetime.now().strftime("%A, %B %d, %Y")

    # Load style template based on client type
    full_config = aria_ai.get_full_config()
    client_type = full_config.get("client", {}).get("type", "consulting")
    client_name = full_config.get("client", {}).get("contact_name", "")
    template_map = {
        "dental": "dental-briefing-email.md",
        "legal": "daily-briefing-email.md",  # TODO: legal-specific template
        "accounting": "daily-briefing-email.md",  # TODO: accounting-specific template
        "consulting": "daily-briefing-email.md",
        "general": "daily-briefing-email.md",
    }
    template_file = template_map.get(client_type, "daily-briefing-email.md")
    template_path = PROJECT_DIR / "templates" / template_file
    style_example = ""
    if template_path.exists():
        with open(template_path) as f:
            style_example = f.read()

    # Build project list for prompt
    projects = full_config.get("projects", full_config.get("known_projects", []))
    projects_str = ", ".join(projects) if projects else "all tracked projects"

    # Determine identity based on config
    if client_name:
        identity = f"You are ARIA, the AI assistant for {full_config.get('client', {}).get('name', 'this practice')}. Generate a Daily Brief for {client_name}."
    else:
        identity = "You are ARIA, an executive assistant AI. Generate a Presidential Daily Brief covering all tracked projects."

    system_prompt = f"""{identity}

TODAY IS: {today_str}

This is a CEO-grade morning briefing. Not a task list. Every item needs a "so what" explaining why it matters.

CRITICAL RULES:
1. NEVER invent or embellish details. Only report what is explicitly in the source data.
2. Meetings from the MEETINGS section are PAST meetings. Today's schedule comes from CALENDAR/CALENDLY sections only.
3. For meeting summaries, focus on decisions, commitments, and strategic implications.
4. If data is sparse, have fewer bullets. Do NOT pad with generic items.
5. The BLUF is the most important part. It should tell {client_name} the #1 thing they need to know today.
6. Commitments tracker: look at action items from meetings where {client_name} promised to do something. Flag anything more than 2 days old.
7. Decisions needed: only items where {client_name} must make a call. Include deadline and what happens if they don't decide.

Respond with ONLY a valid JSON object. No markdown, no code blocks, no thinking tags.

JSON format:
{{
  "bluf": "2-3 sentences max. The single most important thing today. What kind of day is it. What's at risk.",
  "decisions_needed": ["What needs to be decided, deadline, context, and suggested action. Include 'so what' for each."],
  "todays_schedule": ["time: Meeting (attendees). Context: what you last discussed, what to expect, your open items with them."],
  "commitments_you_owe": ["What you promised, to whom, when promised, days elapsed. Flag overdue items."],
  "waiting_on_others": ["Name: what they owe, project, how long outstanding, what it blocks."],
  "project_pulse": ["Project: one-line status (on track / needs attention / blocked). Only expand on what changed."],
  "overnight_comms": ["Source: one-line summary with 'so what'. Only briefing-worthy items that passed triage."],
  "strategic_radar": ["Optional. Patterns across projects, emerging themes, important-but-not-urgent items. Omit if nothing to flag."],
  "closing": "One line."
}}

TRIAGE FILTER (only include items that match one of these):
1. Requires {client_name}'s decision or action -> decisions_needed or commitments_you_owe
2. Someone else's delay is blocking progress -> waiting_on_others
3. Changes the status of a project -> project_pulse
4. Meeting today needs strategic prep -> todays_schedule
5. None of the above -> don't include it

Known projects: {projects_str}.

STYLE: Direct, builder tone. No fluff. No em dashes. Each bullet has context and consequence, not just a label.

STYLE EXAMPLE:
{style_example}"""

    response = call_ai(system_prompt, full_context)

    if not response:
        log("AI inference failed. Generating fallback briefing with raw data.")
        sections = {
            "bluf": f"ARIA collected {len(notifications)} notifications, {len(emails)} emails, {len(slack_channels)} Slack channels, and {len(meetings)} meetings but could not analyze them.",
            "decisions_needed": [],
            "todays_schedule": [],
            "commitments_you_owe": [],
            "waiting_on_others": [],
            "project_pulse": [],
            "overnight_comms": [],
            "strategic_radar": [],
            "closing": "Check back tomorrow.",
        }
    else:
        try:
            # Try parsing the full response as JSON first
            try:
                sections = json.loads(response)
            except json.JSONDecodeError:
                # Try extracting JSON from markdown code blocks or mixed text
                json_match = __import__('re').search(r'\{[\s\S]*\}', response)
                if json_match:
                    sections = json.loads(json_match.group(0))
                else:
                    raise ValueError("No JSON in response")
            # Validate the BLUF isn't itself JSON (double-encoded)
            bluf = sections.get("bluf", "")
            if isinstance(bluf, str) and bluf.strip().startswith("{"):
                try:
                    inner = json.loads(bluf)
                    if isinstance(inner, dict) and "bluf" in inner:
                        sections = inner  # The AI returned nested JSON; use the inner one
                except (json.JSONDecodeError, ValueError):
                    pass
        except (json.JSONDecodeError, ValueError) as e:
            log(f"Failed to parse AI response: {e}")
            # Strip JSON artifacts from the fallback text
            import re as _re
            clean = _re.sub(r'[{}\[\]"]+', '', response[:500]).strip()
            clean = _re.sub(r'\b(bluf|decisions_needed|todays_schedule)\b\s*:', '', clean).strip()
            sections = {
                "bluf": clean[:300] if clean else "ARIA could not generate today's briefing. Check the logs for details.",
                "decisions_needed": [],
                "todays_schedule": [],
                "commitments_you_owe": [],
                "waiting_on_others": [],
                "project_pulse": [],
                "overnight_comms": [],
                "strategic_radar": [],
                "closing": "",
            }

    # Generate HTML email with proper bullets
    log("Generating email...")
    day_name = datetime.now().strftime("%A, %B %d")
    subject = f"ARIA Daily Brief: {day_name}"

    def flatten_item(item):
        """Convert a dict or string into a readable bullet string."""
        if isinstance(item, str):
            return item
        if isinstance(item, dict):
            # Try common patterns from Ollama's structured output
            parts = []
            # Decision format
            if 'decision' in item:
                parts.append(f"<b>{item['decision']}</b>")
                if item.get('deadline'): parts.append(f"Deadline: {item['deadline']}.")
                if item.get('context'): parts.append(item['context'])
                if item.get('so_what'): parts.append(f"<i>{item['so_what']}</i>")
            # Schedule format
            elif 'time' in item and ('meeting' in item or 'name' in item):
                meeting = item.get('meeting', item.get('name', ''))
                parts.append(f"<b>{item['time']}: {meeting}</b>")
                if item.get('context'): parts.append(item['context'])
                if item.get('open_items'): parts.append(f"Your open items: {item['open_items']}")
            # Commitment format
            elif 'what' in item and 'to_whom' in item:
                overdue = " (OVERDUE)" if item.get('overdue') else ""
                parts.append(f"<b>{item['what']}</b> to {item['to_whom']}")
                if item.get('when_promised'): parts.append(f"Promised {item['when_promised']}, {item.get('days_elapsed', '?')} days ago{overdue}")
            # Waiting format
            elif 'name' in item and 'what' in item:
                parts.append(f"<b>{item['name']}</b>: {item['what']}")
                if item.get('outstanding'): parts.append(f"({item['outstanding']} outstanding)")
                if item.get('blocks'): parts.append(f"Blocks: {item['blocks']}")
            # Project pulse format
            elif 'project' in item and 'status' in item:
                parts.append(f"<b>{item['project']}</b>: {item['status']}.")
                if item.get('change'): parts.append(item['change'])
            # Comms format
            elif 'source' in item and 'summary' in item:
                parts.append(f"<b>{item['source']}</b>: {item['summary']}")
                if item.get('so_what'): parts.append(f"<i>{item['so_what']}</i>")
            else:
                # Generic fallback: join all values
                parts = [str(v) for v in item.values() if v]
            return " ".join(parts)
        return str(item)

    def bullets_html(items, empty_msg="Nothing to report."):
        if not items:
            return f"<p style='color:#6B7280;font-style:italic;margin:4px 0;'>{empty_msg}</p>"
        return "<ul style='margin:4px 0 16px 0;padding-left:24px;'>" + "".join(f"<li style='margin-bottom:6px;'>{flatten_item(item)}</li>" for item in items) + "</ul>"

    # Build sections, omitting empty optional ones
    sections_html = []

    # BLUF - always present, styled distinctly
    bluf = sections.get('bluf', '')
    sections_html.append(f"""<div style="background:#F8FAFC;border-left:4px solid #1E40AF;padding:12px 16px;margin-bottom:20px;border-radius:0 6px 6px 0;">
<p style="margin:0;font-size:14px;color:#1E293B;line-height:1.6;"><b>{bluf}</b></p>
</div>""")

    # Decisions - always present (empty = good signal)
    sections_html.append(f"""<p><b>Decisions Needed</b></p>
{bullets_html(sections.get('decisions_needed', []), "No decisions needed today.")}""")

    # Today's Schedule
    schedule = sections.get('todays_schedule', [])
    sections_html.append(f"""<p><b>Today's Schedule + Prep</b></p>
{bullets_html(schedule, "No meetings scheduled.")}""")

    # Commitments You Owe
    commitments = sections.get('commitments_you_owe', [])
    if commitments:
        sections_html.append(f"""<p><b>Commitments Tracker (You Owe)</b></p>
{bullets_html(commitments)}""")

    # Waiting On Others
    waiting = sections.get('waiting_on_others', [])
    if waiting:
        sections_html.append(f"""<p><b>Waiting On Others</b></p>
{bullets_html(waiting)}""")

    # Project Pulse
    pulse = sections.get('project_pulse', [])
    if pulse:
        sections_html.append(f"""<p><b>Project Pulse</b></p>
{bullets_html(pulse)}""")

    # Overnight Comms
    comms = sections.get('overnight_comms', [])
    if comms:
        sections_html.append(f"""<p><b>Overnight Comms</b></p>
{bullets_html(comms)}""")

    # Strategic Radar - only if present
    radar = sections.get('strategic_radar', [])
    if radar:
        sections_html.append(f"""<p><b>Strategic Radar</b></p>
{bullets_html(radar)}""")

    # Intelligence sections (from analytics engines)
    if intel_html:
        sections_html.append(f"""<hr style="border:none;border-top:1px solid #E5E7EB;margin:20px 0">
<p style="font-size:12px;color:#6B7280;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:8px">Intelligence Layer</p>
{intel_html}""")

    closing = sections.get('closing', 'Have a good one.')

    email_html = f"""<div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; color: #1a1a1a; line-height: 1.6;">

{"".join(sections_html)}

<p>{closing}</p>

</div>"""

    # Save HTML version
    briefing_path = BRIEFINGS_DIR / f"{date_str}.html"
    with open(briefing_path, "w") as f:
        f.write(email_html)
    log(f"Saved to {briefing_path}")

    # Save raw structured data for reply handler
    data_path = BRIEFINGS_DIR / f"{date_str}.json"
    with open(data_path, "w") as f:
        json.dump({
            "date": date_str,
            "sections": sections,
            "notification_count": len(notifications),
            "email_count": len(emails),
            "slack_channel_count": len(slack_channels),
            "calendar_event_count": len(all_calendar_events),
            "notion_task_count": len(notion_tasks),
            "meeting_count": len(meetings),
            "generated_at": datetime.now().isoformat(),
        }, f, indent=2)

    # Send briefing email (n8n first, SMTP fallback)
    import aria_email
    recipient = full_config.get("email", "")
    if recipient:
        log(f"Sending briefing email to {recipient}...")
        success, method = aria_email.send_briefing_email(recipient, subject, email_html)
        if success:
            log(f"Email sent via {method}")
        else:
            log("Email delivery failed (both n8n and SMTP)")
    else:
        log("No email address configured. Briefing saved to file only.")

    # Cleanup old briefings (older than 14 days)
    cutoff = datetime.now() - timedelta(days=14)
    for f in BRIEFINGS_DIR.glob("*"):
        if f.suffix in (".html", ".json"):
            try:
                file_date = datetime.strptime(f.stem, "%Y-%m-%d")
                if file_date < cutoff:
                    f.unlink()
                    log(f"Cleaned up old briefing: {f.name}")
            except ValueError:
                continue

    # Process any pending model action requests from briefing replies
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "process_model_actions",
            PROJECT_DIR / "scripts" / "process-model-actions.py"
        )
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        count = mod.process_actions()
        if count > 0:
            log(f"Processed {count} pending model actions")
    except Exception as e:
        log(f"Model action processing error: {e}")

    log("Briefing complete!")


if __name__ == "__main__":
    main()
