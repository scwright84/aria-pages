#!/usr/bin/env python3
"""
ARIA Multi-Timezone Support (FEAT-102)
Handles timezone conversion for distributed teams.

Features:
  - Convert event times to client's local timezone
  - Display "their time / your time" in meeting preps
  - Support multiple team members in different timezones
  - Briefing delivery timed to each recipient's local time

Config in aria.json:
  "team_timezones": {
    "Sean": "America/Chicago",
    "Kirsten": "America/Los_Angeles",
    "Lakshmi": "Asia/Kolkata"
  }

Used by: briefing generators, meeting prep, calendar sync.
"""

import json
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

PROJECT_DIR = Path(__file__).parent.parent
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def get_client_timezone():
    """Get the primary client timezone."""
    config = load_config()
    tz_name = config.get("timezone", "America/Chicago")
    try:
        return ZoneInfo(tz_name)
    except Exception:
        return ZoneInfo("America/Chicago")


def get_team_timezones():
    """Get all team member timezones."""
    config = load_config()
    team = config.get("team_timezones", {})
    result = {}
    for name, tz_name in team.items():
        try:
            result[name] = ZoneInfo(tz_name)
        except Exception:
            pass
    return result


def convert_time(dt, from_tz=None, to_tz=None):
    """Convert a datetime between timezones."""
    if from_tz is None:
        from_tz = get_client_timezone()
    if to_tz is None:
        to_tz = get_client_timezone()

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=from_tz)
    return dt.astimezone(to_tz)


def format_multi_tz(dt, label=None):
    """Format a time showing it in all team timezones."""
    client_tz = get_client_timezone()
    team = get_team_timezones()

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=client_tz)

    lines = []
    # Client time first
    config = load_config()
    client_name = config.get("client", {}).get("contact_name", "You")
    abbr = config.get("timezone_abbr", "")
    lines.append(f"{client_name}: {dt.astimezone(client_tz).strftime('%I:%M %p')} {abbr}")

    # Team times
    for name, tz in team.items():
        converted = dt.astimezone(tz)
        tz_abbr = converted.strftime("%Z")
        lines.append(f"{name}: {converted.strftime('%I:%M %p')} {tz_abbr}")

    return lines


def get_time_difference(tz1_name, tz2_name):
    """Get the hour difference between two timezones right now."""
    try:
        tz1 = ZoneInfo(tz1_name)
        tz2 = ZoneInfo(tz2_name)
        now = datetime.now(timezone.utc)
        offset1 = now.astimezone(tz1).utcoffset().total_seconds() / 3600
        offset2 = now.astimezone(tz2).utcoffset().total_seconds() / 3600
        return offset2 - offset1
    except Exception:
        return None


def suggest_meeting_time(attendee_timezones):
    """Suggest a meeting time that works for all attendees (9am-5pm local for each)."""
    if not attendee_timezones:
        return None

    # Find overlapping business hours (9am-5pm) across all timezones
    now = datetime.now(timezone.utc)
    overlap_start = 0
    overlap_end = 24

    for tz_name in attendee_timezones:
        try:
            tz = ZoneInfo(tz_name)
            offset = now.astimezone(tz).utcoffset().total_seconds() / 3600
            # Business hours in UTC
            biz_start_utc = (9 - offset) % 24
            biz_end_utc = (17 - offset) % 24

            if biz_start_utc < biz_end_utc:
                overlap_start = max(overlap_start, biz_start_utc)
                overlap_end = min(overlap_end, biz_end_utc)
        except Exception:
            pass

    if overlap_start < overlap_end:
        # Suggest middle of overlap
        suggested_utc = (overlap_start + overlap_end) / 2
        return {
            "suggested_utc_hour": round(suggested_utc),
            "overlap_hours": round(overlap_end - overlap_start, 1),
            "note": f"{round(overlap_end - overlap_start, 1)} hours of overlap in business hours",
        }
    else:
        return {
            "suggested_utc_hour": None,
            "overlap_hours": 0,
            "note": "No overlapping business hours. Someone will need to accommodate.",
        }


def main():
    """Display timezone information."""
    config = load_config()
    client_tz = get_client_timezone()
    team = get_team_timezones()

    now = datetime.now(client_tz)
    print(f"ARIA Timezone Support\n")
    print(f"Client timezone: {config.get('timezone')} ({config.get('timezone_abbr', '')})")
    print(f"Current time: {now.strftime('%I:%M %p %Z')}\n")

    if team:
        print("Team timezones:")
        for name, tz in team.items():
            team_now = now.astimezone(tz)
            diff = get_time_difference(str(client_tz), str(tz))
            diff_str = f"+{diff:.0f}h" if diff and diff > 0 else f"{diff:.0f}h" if diff else ""
            print(f"  {name}: {team_now.strftime('%I:%M %p %Z')} ({diff_str})")

        print("\nMeeting time suggestion:")
        all_tzs = [str(client_tz)] + [str(tz) for tz in team.values()]
        suggestion = suggest_meeting_time(all_tzs)
        if suggestion:
            print(f"  {suggestion['note']}")
            if suggestion['suggested_utc_hour']:
                print(f"  Best time: ~{suggestion['suggested_utc_hour']}:00 UTC")
    else:
        print("No team timezones configured.")
        print("Add to aria.json: \"team_timezones\": {\"Name\": \"Timezone\"}")


if __name__ == "__main__":
    main()
