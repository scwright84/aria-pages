#!/bin/bash
# ARIA - Tailscale Remote Access Setup
# Installs and configures Tailscale for remote client support.
#
# What Tailscale does:
#   - Creates an encrypted point-to-point VPN between machines
#   - No port forwarding, no public IPs, no firewall holes
#   - Sean can SSH into client machines for support
#   - Client's ARIA dashboard accessible remotely at http://<tailscale-ip>:8643
#   - All traffic encrypted, never routed through Tailscale's servers (DERP relay as fallback only)
#
# Run on the client's machine during setup, or on Sean's machines.
# Both sides need Tailscale installed and logged into the same tailnet.

set -euo pipefail

BOLD='\033[1m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${GREEN}[TAILSCALE]${NC} $1"; }
warn() { echo -e "${YELLOW}[TAILSCALE]${NC} $1"; }
err()  { echo -e "${RED}[TAILSCALE]${NC} $1"; }
step() { echo -e "\n${BOLD}=== $1 ===${NC}"; }

step "Tailscale Installation"

# Check if already installed
if command -v tailscale &>/dev/null; then
    STATUS=$(tailscale status --json 2>/dev/null | python3 -c "import sys,json; print(json.load(sys.stdin).get('BackendState','unknown'))" 2>/dev/null || echo "unknown")
    log "Tailscale already installed. Status: $STATUS"
    if [ "$STATUS" = "Running" ]; then
        IP=$(tailscale ip -4 2>/dev/null || echo "unknown")
        log "Tailscale IP: $IP"
        log "Already connected. Nothing to do."
        exit 0
    fi
else
    # Install via Mac App Store CLI or brew
    if command -v brew &>/dev/null; then
        log "Installing Tailscale via Homebrew..."
        brew install --cask tailscale
    else
        err "Homebrew not found. Install Tailscale manually from https://tailscale.com/download/mac"
        err "Or install Homebrew first: /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
        exit 1
    fi
fi

step "Tailscale Configuration"

log "Starting Tailscale..."
log ""
log "A browser window will open to authenticate."
log "Log in with the Wright Advisors Tailscale account."
log ""

# Open Tailscale app (it's a macOS app, not just CLI)
open -a Tailscale 2>/dev/null || {
    warn "Could not open Tailscale app. Open it manually from Applications."
}

echo ""
log "After logging in, run these commands to verify:"
echo ""
echo "  tailscale status          # Should show 'Connected'"
echo "  tailscale ip -4           # Shows this machine's Tailscale IP"
echo "  tailscale ping <other-ip> # Test connectivity to another machine"
echo ""

step "Post-Setup Checklist"

echo ""
echo "  [ ] Tailscale app running and connected"
echo "  [ ] Machine shows up in Tailscale admin (https://login.tailscale.com/admin)"
echo "  [ ] Can ping other machines on the tailnet"
echo "  [ ] SSH access works: ssh user@<tailscale-ip>"
echo "  [ ] Dashboard accessible: http://<tailscale-ip>:8643 (if ARIA dashboard is running)"
echo ""

step "Security Notes"

echo ""
echo "  - Tailscale uses WireGuard encryption (state of the art)"
echo "  - Traffic is peer-to-peer when possible (not routed through Tailscale)"
echo "  - ACLs can restrict which machines can talk to which (configure in admin)"
echo "  - MagicDNS gives friendly hostnames (e.g., aria-client1 instead of 100.x.y.z)"
echo "  - Key expiry: set to 90 days for client machines (admin > Machines > Key expiry)"
echo ""
warn "For client deployments: create a separate Tailscale user per client for isolation."
warn "Or use Tailscale ACL tags to segment access."
