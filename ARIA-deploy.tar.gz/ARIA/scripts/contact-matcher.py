#!/usr/bin/env python3
"""
ARIA Contact Introduction Matcher (FEAT-104)
Network intelligence: find connections between your contacts across projects.

"You know X who does Y. Your client Z needs Y. Should you connect them?"

Logic:
  - Analyze contact profiles for skills/expertise (from email subjects/topics)
  - Analyze project needs (from tasks, commitments, email threads)
  - Find matches where a contact's expertise maps to another project's need
  - Also finds: mutual connections, shared industries, complementary businesses

Output: briefings/YYYY-MM-DD-introductions.json
Runs weekly.
"""

import json
import re
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent
CONTACTS_FILE = PROJECT_DIR / "config" / "contacts.json"
TASKS_FILE = PROJECT_DIR / "config" / "tasks.json"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
LOG_FILE = PROJECT_DIR / "logs" / "contact-matcher.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_json(path):
    if Path(path).exists():
        try:
            with open(path) as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def extract_expertise(contact):
    """Infer a contact's expertise from their email topics and projects."""
    topics = contact.get("topics", [])
    projects = contact.get("projects", [])
    name = contact.get("name", "")

    keywords = set()
    for topic in topics:
        words = set(re.findall(r'\b[a-z]{4,}\b', topic.lower()))
        keywords.update(words)

    return {
        "name": name,
        "projects": projects,
        "keywords": list(keywords)[:20],
        "relationship_score": contact.get("relationship_score", 0),
    }


def extract_project_needs(config, tasks):
    """Identify what each project needs based on open tasks and config."""
    needs = defaultdict(set)

    # From tasks
    for task in tasks.get("tasks", []):
        if task.get("status") != "open":
            continue
        project = task.get("project")
        if not project:
            continue
        title = task.get("title", "").lower()
        words = set(re.findall(r'\b[a-z]{4,}\b', title))
        needs[project].update(words)

    return {k: list(v) for k, v in needs.items()}


def find_matches(contacts, project_needs):
    """Find contacts whose expertise matches a project's needs."""
    matches = []

    for key, contact in contacts.items():
        expertise = extract_expertise(contact)
        if not expertise["keywords"]:
            continue

        for project, needs in project_needs.items():
            # Don't match a contact to their own project
            if project in expertise["projects"]:
                continue

            overlap = set(expertise["keywords"]) & set(needs)
            if len(overlap) >= 2:  # At least 2 keyword matches
                matches.append({
                    "contact": expertise["name"] or key,
                    "contact_projects": expertise["projects"],
                    "target_project": project,
                    "matching_keywords": list(overlap)[:5],
                    "match_strength": len(overlap),
                    "relationship_score": expertise["relationship_score"],
                    "suggestion": f"Connect {expertise['name'] or key} ({', '.join(expertise['projects'][:2])}) with {project} team - shared interest in {', '.join(list(overlap)[:3])}",
                })

    return sorted(matches, key=lambda m: -m["match_strength"])


def find_cross_project_connections(contacts):
    """Find contacts who appear in multiple projects (natural connectors)."""
    connectors = []
    for key, contact in contacts.items():
        projects = contact.get("projects", [])
        if len(projects) >= 2:
            connectors.append({
                "name": contact.get("name", key),
                "projects": projects,
                "email_count": contact.get("email_count", 0),
                "relationship_score": contact.get("relationship_score", 0),
                "note": f"Active across {len(projects)} projects: {', '.join(projects)}",
            })

    return sorted(connectors, key=lambda c: -len(c["projects"]))


def main():
    log("Starting contact introduction matching")

    contacts = load_json(CONTACTS_FILE)
    tasks = load_json(TASKS_FILE)
    config = load_json(CONFIG_FILE)

    if not contacts:
        log("No contacts to analyze")
        return

    project_needs = extract_project_needs(config, tasks)
    log(f"Project needs: {json.dumps({k: len(v) for k, v in project_needs.items()})}")

    matches = find_matches(contacts, project_needs)
    log(f"Introduction matches: {len(matches)}")

    connectors = find_cross_project_connections(contacts)
    log(f"Cross-project connectors: {len(connectors)}")

    # Save
    date_str = datetime.now().strftime("%Y-%m-%d")
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)

    output = {
        "date": date_str,
        "introduction_suggestions": matches[:10],
        "cross_project_connectors": connectors[:10],
        "project_needs_analyzed": len(project_needs),
        "contacts_analyzed": len(contacts),
    }

    with open(BRIEFINGS_DIR / f"{date_str}-introductions.json", "w") as f:
        json.dump(output, f, indent=2, default=str)

    for m in matches[:5]:
        log(f"  MATCH: {m['suggestion']}")
    for c in connectors[:5]:
        log(f"  CONNECTOR: {c['name']} spans {', '.join(c['projects'])}")

    log("Contact matching complete")


if __name__ == "__main__":
    main()
