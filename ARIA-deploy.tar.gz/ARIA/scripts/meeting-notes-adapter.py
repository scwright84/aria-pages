#!/usr/bin/env python3
"""
ARIA Meeting Notes Integration Adapter (FEAT-101)
Supports multiple meeting note providers beyond Granola.

Supported:
  - Granola (existing, api.granola.ai)
  - Otter.ai (API or email export)
  - Fireflies.ai (API or email digest)
  - Manual (paste notes via Telegram or webhook)

Each adapter normalizes data to a common format:
  {
    "title": "Meeting name",
    "date": "YYYY-MM-DD",
    "attendees": ["name1", "name2"],
    "summary": "Key points...",
    "action_items": ["item1", "item2"],
    "commitments": [{"task": "...", "owner": "...", "deadline": "..."}],
    "raw_text": "Full transcript if available",
    "source": "granola|otter|fireflies|manual"
  }

Output: inbox/meetings-YYYY-MM-DD.json (standard format)
"""

import json
import re
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
LOG_FILE = PROJECT_DIR / "logs" / "meeting-notes-adapter.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def normalize_meeting(raw, source):
    """Normalize meeting data from any provider to standard format."""
    if source == "granola":
        return {
            "title": raw.get("title") or raw.get("meeting", "Untitled"),
            "date": raw.get("date") or raw.get("meeting_date", ""),
            "attendees": raw.get("attendees", []),
            "summary": raw.get("summary", ""),
            "action_items": raw.get("action_items", []),
            "commitments": raw.get("commitments", []),
            "raw_text": raw.get("content", ""),
            "source": "granola",
        }

    elif source == "otter":
        return {
            "title": raw.get("title") or raw.get("otterTitle", "Untitled"),
            "date": raw.get("date") or raw.get("start_time", "")[:10],
            "attendees": raw.get("speakers", raw.get("attendees", [])),
            "summary": raw.get("summary", raw.get("auto_summary", "")),
            "action_items": raw.get("action_items", []),
            "commitments": [],
            "raw_text": raw.get("transcript", raw.get("text", "")),
            "source": "otter",
        }

    elif source == "fireflies":
        return {
            "title": raw.get("title", "Untitled"),
            "date": raw.get("date", ""),
            "attendees": raw.get("participants", raw.get("attendees", [])),
            "summary": raw.get("overview", raw.get("summary", "")),
            "action_items": raw.get("action_items", raw.get("tasks", [])),
            "commitments": [],
            "raw_text": raw.get("transcript", ""),
            "source": "fireflies",
        }

    elif source == "manual":
        # Extract action items from text
        text = raw.get("text", "")
        action_items = re.findall(r'(?:TODO|ACTION|FOLLOW.?UP)[:]\s*(.+)', text, re.IGNORECASE)

        return {
            "title": raw.get("title", "Manual Meeting Notes"),
            "date": raw.get("date", datetime.now().strftime("%Y-%m-%d")),
            "attendees": raw.get("attendees", []),
            "summary": text[:500],
            "action_items": action_items,
            "commitments": [],
            "raw_text": text,
            "source": "manual",
        }

    # Unknown source: best effort
    return {
        "title": raw.get("title", "Unknown Meeting"),
        "date": raw.get("date", ""),
        "attendees": raw.get("attendees", []),
        "summary": raw.get("summary", str(raw)[:500]),
        "action_items": raw.get("action_items", []),
        "commitments": raw.get("commitments", []),
        "raw_text": raw.get("text", raw.get("transcript", "")),
        "source": source,
    }


def save_meeting(meeting):
    """Save a normalized meeting to the inbox."""
    INBOX_DIR.mkdir(parents=True, exist_ok=True)
    date_str = meeting.get("date", datetime.now().strftime("%Y-%m-%d"))[:10]
    path = INBOX_DIR / f"meetings-{date_str}.json"

    existing = []
    if path.exists():
        try:
            with open(path) as f:
                existing = json.load(f)
        except Exception:
            pass

    if isinstance(existing, list):
        existing.append(meeting)
    else:
        existing = [existing, meeting]

    with open(path, "w") as f:
        json.dump(existing, f, indent=2, default=str)

    return path.name


def ingest_from_email(emails):
    """Detect meeting note emails (Otter, Fireflies) and ingest them."""
    meetings = []
    for e in emails:
        sender = (e.get("from") or "").lower()
        subject = (e.get("subject") or "")
        snippet = e.get("snippet", "")

        if "otter.ai" in sender or "otter" in sender:
            meetings.append(normalize_meeting({
                "title": re.sub(r'^.*notes?:?\s*', '', subject, flags=re.IGNORECASE).strip() or subject,
                "date": datetime.now().strftime("%Y-%m-%d"),
                "summary": snippet[:500],
                "text": snippet,
            }, "otter"))

        elif "fireflies" in sender:
            meetings.append(normalize_meeting({
                "title": re.sub(r'^.*recap:?\s*', '', subject, flags=re.IGNORECASE).strip() or subject,
                "date": datetime.now().strftime("%Y-%m-%d"),
                "summary": snippet[:500],
                "text": snippet,
            }, "fireflies"))

    return meetings


def main():
    """Run as a standalone ingestion tool."""
    import argparse
    parser = argparse.ArgumentParser(description="ARIA Meeting Notes Adapter")
    parser.add_argument("--source", choices=["granola", "otter", "fireflies", "manual"], required=True)
    parser.add_argument("--file", help="JSON file to ingest")
    parser.add_argument("--text", help="Raw text for manual notes")
    parser.add_argument("--title", help="Meeting title")
    args = parser.parse_args()

    if args.file:
        with open(args.file) as f:
            raw = json.load(f)
        if isinstance(raw, list):
            for item in raw:
                meeting = normalize_meeting(item, args.source)
                filename = save_meeting(meeting)
                log(f"Ingested: {meeting['title'][:50]} -> {filename}")
        else:
            meeting = normalize_meeting(raw, args.source)
            filename = save_meeting(meeting)
            log(f"Ingested: {meeting['title'][:50]} -> {filename}")

    elif args.text:
        meeting = normalize_meeting({
            "text": args.text,
            "title": args.title or "Manual Notes",
        }, "manual")
        filename = save_meeting(meeting)
        log(f"Ingested manual notes: {meeting['title'][:50]} -> {filename}")

    else:
        print("Provide --file or --text")
        return 1

    log("Meeting notes ingestion complete")
    return 0


if __name__ == "__main__":
    sys.exit(main())
