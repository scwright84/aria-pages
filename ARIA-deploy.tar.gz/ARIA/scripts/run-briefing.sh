#!/bin/bash
# Generate and send morning briefing
# Runs at 7:05am via launchd, after syncs have completed

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
VENV="$PROJECT_DIR/.venv/bin/python3"
LOG="$PROJECT_DIR/logs/briefing.log"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Briefing generation starting" >> "$LOG"

# Wait a moment for syncs to finish forwarding to n8n
sleep 30

"$VENV" "$SCRIPT_DIR/generate-briefing.py" >> "$LOG" 2>&1
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Briefing generation complete" >> "$LOG"
