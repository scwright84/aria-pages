#!/usr/bin/env python3
"""
ARIA Email Thread Summarizer
Groups emails by thread (subject line), condenses long chains to:
  - Key points
  - Decision(s) made
  - Action items
  - Current status (waiting on who?)

Identifies threads that are:
  - Long (5+ emails) - definitely need summarizing
  - Stale (started but no resolution)
  - Hot (high reply frequency)

Output: briefings/YYYY-MM-DD-threads.json
Runs daily after email sync.
"""

import json
import re
import sys
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import aria_ai

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
LOG_FILE = PROJECT_DIR / "logs" / "thread-summarizer.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def normalize_subject(subject):
    """Strip Re:/Fwd: prefixes to get the thread root subject."""
    cleaned = re.sub(r'^(re|fwd|fw)\s*:\s*', '', subject, flags=re.IGNORECASE).strip()
    return cleaned.lower()


def load_emails(days_back=14):
    all_emails = []
    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        path = INBOX_DIR / f"emails-{date.strftime('%Y-%m-%d')}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                all_emails.extend(data if isinstance(data, list) else [data])
            except Exception:
                pass
    return all_emails


def group_threads(emails):
    """Group emails into threads by normalized subject."""
    threads = defaultdict(list)
    for e in emails:
        subject = e.get("subject", "")
        if not subject:
            continue
        thread_key = normalize_subject(subject)
        threads[thread_key].append(e)

    # Sort each thread by date
    for key in threads:
        threads[key].sort(key=lambda e: str(e.get("date") or e.get("processed_at") or ""))

    return dict(threads)


def classify_thread(thread_key, emails):
    """Classify a thread by length, status, and heat."""
    count = len(emails)
    senders = set(e.get("from", "")[:30] for e in emails)
    has_action = any(e.get("action_needed") for e in emails)
    projects = set(e.get("detected_project") for e in emails if e.get("detected_project"))

    # Latest email info
    latest = emails[-1]
    latest_from = latest.get("from", "")

    classification = {
        "thread_subject": emails[0].get("subject", thread_key),
        "email_count": count,
        "unique_senders": len(senders),
        "has_action_needed": has_action,
        "projects": list(projects),
        "latest_from": latest_from,
        "latest_summary": latest.get("summary", "")[:200],
    }

    # Thread type
    if count >= 5:
        classification["type"] = "long"
        classification["needs_summary"] = True
    elif count >= 3:
        classification["type"] = "active"
        classification["needs_summary"] = True
    else:
        classification["type"] = "short"
        classification["needs_summary"] = False

    return classification


def summarize_thread(thread_key, emails):
    """Use AI to summarize a long thread."""
    # Build context from all emails in thread
    parts = []
    for e in emails:
        sender = e.get("from", "?")
        if "<" in sender:
            sender = sender.split("<")[0].strip().strip('"')
        summary = e.get("summary") or e.get("snippet", "")
        subject = e.get("subject", "")
        parts.append(f"From {sender}: {summary[:150]}")

    context = f"Email thread: {emails[0].get('subject', thread_key)}\n{len(emails)} emails\n\n" + "\n---\n".join(parts)

    result = aria_ai.chat_json(
        """Summarize this email thread as a JSON object:
{
  "key_points": ["point 1", "point 2"],
  "decision": "what was decided (or 'no decision yet')",
  "action_items": ["action 1", "action 2"],
  "status": "waiting on [person]" or "resolved" or "ongoing",
  "one_line": "one sentence summary"
}
Be specific. Use names. Keep it brief.""",
        context,
        fast=True,
        timeout=30,
    )

    return result


def main():
    log("Starting thread summarization")
    emails = load_emails(days_back=14)
    log(f"Loaded {len(emails)} emails")

    threads = group_threads(emails)
    log(f"Found {len(threads)} unique threads")

    results = []
    summarized = 0

    for thread_key, thread_emails in sorted(threads.items(), key=lambda x: -len(x[1])):
        classification = classify_thread(thread_key, thread_emails)

        if classification["needs_summary"] and classification["email_count"] >= 3:
            summary = summarize_thread(thread_key, thread_emails)
            if summary:
                classification["summary"] = summary
                summarized += 1
                log(f"  Summarized ({classification['email_count']} emails): {classification['thread_subject'][:60]}")
                if isinstance(summary, dict) and summary.get("one_line"):
                    log(f"    → {summary['one_line']}")

        results.append(classification)

    # Save
    date_str = datetime.now().strftime("%Y-%m-%d")
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)

    # Sort: long threads first, then by email count
    results.sort(key=lambda x: (-x["email_count"]))

    output = {
        "date": date_str,
        "total_threads": len(results),
        "summarized": summarized,
        "long_threads": [r for r in results if r.get("type") == "long"],
        "active_threads": [r for r in results if r.get("type") == "active"],
        "all_threads": results,
    }

    with open(BRIEFINGS_DIR / f"{date_str}-threads.json", "w") as f:
        json.dump(output, f, indent=2, default=str)

    log(f"Threads: {len(results)} total, {summarized} summarized")
    log(f"Long threads (5+ emails): {len(output['long_threads'])}")
    log(f"Active threads (3-4 emails): {len(output['active_threads'])}")
    log("Thread summarization complete")


if __name__ == "__main__":
    main()
