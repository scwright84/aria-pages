#!/usr/bin/env python3
"""
ARIA Notification Sync (one-shot)
Reads all new notifications since last run and forwards them to n8n.
Designed to be called on a schedule by launchd.
"""

import sqlite3
import plistlib
import json
import os
import sys
import requests
from datetime import datetime
from pathlib import Path

NOTIFICATION_DB = os.path.expanduser(
    "~/Library/Group Containers/group.com.apple.usernoted/db2/db"
)

WATCHED_APPS = {
    "com.apple.mobilesms": "iMessage",
    "com.apple.ichat": "Messages",
    "desktop.whatsapp": "WhatsApp",
    "net.whatsapp.whatsapp": "WhatsApp",
    "org.whispersystems.signal-desktop": "Signal",
    "com.tdesktop.telegram": "Telegram",
    "com.tinyspeck.slackmacgap": "Slack",
    "com.microsoft.teams2": "Teams",
    "com.hnc.discord": "Discord",
    "com.apple.mail": "Apple Mail",
    "com.microsoft.outlook": "Outlook",
    "com.apple.facetime": "FaceTime",
}

N8N_WEBHOOK_URL = os.environ.get(
    "ARIA_WEBHOOK_URL", "http://localhost:5678/webhook/aria-notifications"
)

STATE_FILE = Path(__file__).parent.parent / "logs" / "watcher-state.json"


def load_state():
    if STATE_FILE.exists():
        with open(STATE_FILE) as f:
            return json.load(f)
    return {"last_rec_id": 0}


def save_state(state):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f)


def decode_notification_data(raw_data):
    try:
        plist = plistlib.loads(raw_data)
        req = plist.get("req", {})
        return {
            "body": req.get("body", ""),
            "title": req.get("titl", ""),
            "subtitle": req.get("subt", ""),
            "thread_id": req.get("thre", ""),
            "category": req.get("cate", ""),
            "deep_link": req.get("durl", ""),
            "people": req.get("peop", []),
            "identifier": req.get("iden", ""),
        }
    except Exception as e:
        return {"error": str(e), "body": "", "title": ""}


def get_new_notifications(last_rec_id):
    app_ids_str = ", ".join(f"'{app}'" for app in WATCHED_APPS.keys())
    conn = sqlite3.connect(f"file:{NOTIFICATION_DB}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(f"""
        SELECT r.rec_id, a.identifier, r.data, r.delivered_date, r.presented
        FROM record r
        JOIN app a ON r.app_id = a.app_id
        WHERE a.identifier IN ({app_ids_str})
          AND r.rec_id > ?
        ORDER BY r.rec_id ASC
    """, (last_rec_id,))
    results = []
    for row in cursor.fetchall():
        notification = decode_notification_data(row["data"])
        notification["rec_id"] = row["rec_id"]
        notification["app_identifier"] = row["identifier"]
        notification["app_name"] = WATCHED_APPS.get(row["identifier"], row["identifier"])
        notification["delivered_date"] = row["delivered_date"]
        notification["presented"] = bool(row["presented"])
        if row["delivered_date"]:
            unix_ts = row["delivered_date"] + 978307200
            notification["timestamp"] = datetime.fromtimestamp(unix_ts).isoformat()
        results.append(notification)
    conn.close()
    return results


def main():
    state = load_state()

    # First run: skip existing to avoid replaying history
    if state["last_rec_id"] == 0:
        notifications = get_new_notifications(0)
        if notifications:
            state["last_rec_id"] = notifications[-1]["rec_id"]
            save_state(state)
            print(f"First run: skipped {len(notifications)} existing, starting from rec_id {state['last_rec_id']}")
        else:
            print("First run: no existing notifications")
        return

    notifications = get_new_notifications(state["last_rec_id"])
    if not notifications:
        print("No new notifications")
        return

    print(f"Processing {len(notifications)} new notifications")
    forwarded = 0
    errors = 0

    for n in notifications:
        if not n.get("body") and not n.get("title"):
            state["last_rec_id"] = n["rec_id"]
            continue

        print(f"  [{n['app_name']}] {n.get('title', '?')}: {n.get('body', '')[:80]}")
        try:
            resp = requests.post(N8N_WEBHOOK_URL, json=n, timeout=10)
            if resp.status_code == 200:
                forwarded += 1
            else:
                print(f"    n8n responded {resp.status_code}")
                errors += 1
        except requests.exceptions.ConnectionError:
            print("    n8n not reachable")
            errors += 1
        except Exception as e:
            print(f"    Error: {e}")
            errors += 1

        state["last_rec_id"] = n["rec_id"]
        save_state(state)

    print(f"Done: {forwarded} forwarded, {errors} errors")


if __name__ == "__main__":
    main()
