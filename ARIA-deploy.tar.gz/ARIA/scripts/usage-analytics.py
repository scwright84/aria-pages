#!/usr/bin/env python3
"""
ARIA Usage Analytics (FEAT-093)
Tracks how much the client actually uses ARIA.
Shows engagement levels to predict churn and prove value.

Metrics:
  - Telegram queries per day/week
  - Briefings generated and (presumably) read
  - Draft approvals via Telegram
  - Semantic searches performed
  - Tasks completed
  - Days since last Telegram interaction

Output: config/usage-analytics.json (persistent)
        briefings/YYYY-MM-DD-usage.json (snapshot)
"""

import json
import os
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
LOGS_DIR = PROJECT_DIR / "logs"
CONFIG_DIR = PROJECT_DIR / "config"
USAGE_FILE = CONFIG_DIR / "usage-analytics.json"
LOG_FILE = LOGS_DIR / "usage-analytics.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_usage():
    if USAGE_FILE.exists():
        try:
            with open(USAGE_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"daily": {}, "totals": {}}


def save_usage(data):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(USAGE_FILE, "w") as f:
        json.dump(data, f, indent=2, default=str)


def count_telegram_interactions():
    """Count Telegram bot interactions from the bot log."""
    count = 0
    log_path = LOGS_DIR / "launchd-telegram-bot.log"
    if not log_path.exists():
        return 0
    today = datetime.now().strftime("%Y-%m-%d")
    try:
        with open(log_path) as f:
            for line in f:
                if today in line and ("handle_message" in line.lower() or "received" in line.lower() or "query" in line.lower()):
                    count += 1
    except Exception:
        pass
    return count


def count_briefings_generated(days_back=7):
    """Count briefings generated in the past N days."""
    count = 0
    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        date_str = date.strftime("%Y-%m-%d")
        for suffix in [".html", ".json", "-debrief.html", "-weekly.html"]:
            if (BRIEFINGS_DIR / f"{date_str}{suffix}").exists():
                count += 1
    return count


def count_drafts_approved():
    """Count approved drafts."""
    drafts_file = CONFIG_DIR / "pending-drafts.json"
    if drafts_file.exists():
        try:
            with open(drafts_file) as f:
                data = json.load(f)
            return sum(1 for d in data.get("drafts", []) if d.get("status") == "approved")
        except Exception:
            pass
    return 0


def count_searches():
    """Count semantic searches from memory index log."""
    count = 0
    log_path = LOGS_DIR / "memory-index.log"
    if not log_path.exists():
        return 0
    today = datetime.now().strftime("%Y-%m-%d")
    try:
        with open(log_path) as f:
            for line in f:
                if today in line and "searching" in line.lower():
                    count += 1
    except Exception:
        pass
    return count


def count_tasks_completed():
    """Count completed tasks."""
    tasks_file = CONFIG_DIR / "tasks.json"
    if tasks_file.exists():
        try:
            with open(tasks_file) as f:
                data = json.load(f)
            return len(data.get("completed", []))
        except Exception:
            pass
    return 0


def count_audit_actions():
    """Count today's audit log entries."""
    audit_file = LOGS_DIR / "audit.jsonl"
    if not audit_file.exists():
        return 0
    today = datetime.now().strftime("%Y-%m-%d")
    count = 0
    try:
        with open(audit_file) as f:
            for line in f:
                if today in line:
                    count += 1
    except Exception:
        pass
    return count


def calculate_engagement_score(metrics):
    """Score client engagement 0-100."""
    score = 0
    if metrics.get("telegram_queries", 0) > 0:
        score += 30
    if metrics.get("briefings_generated", 0) > 3:
        score += 20
    if metrics.get("drafts_approved", 0) > 0:
        score += 20
    if metrics.get("searches", 0) > 0:
        score += 15
    if metrics.get("tasks_completed", 0) > 0:
        score += 15
    return min(100, score)


def main():
    log("Starting usage analytics")
    data = load_usage()
    date_str = datetime.now().strftime("%Y-%m-%d")

    today = {
        "telegram_queries": count_telegram_interactions(),
        "briefings_generated": count_briefings_generated(days_back=1),
        "drafts_approved": count_drafts_approved(),
        "searches": count_searches(),
        "tasks_completed": count_tasks_completed(),
        "audit_actions": count_audit_actions(),
    }
    today["engagement_score"] = calculate_engagement_score(today)

    data["daily"][date_str] = today

    # Keep only last 90 days
    dates = sorted(data["daily"].keys())
    if len(dates) > 90:
        for old in dates[:-90]:
            del data["daily"][old]

    # Update totals
    data["totals"] = {
        "total_days_tracked": len(data["daily"]),
        "avg_engagement": round(sum(d.get("engagement_score", 0) for d in data["daily"].values()) / max(len(data["daily"]), 1)),
        "total_telegram_queries": sum(d.get("telegram_queries", 0) for d in data["daily"].values()),
        "total_briefings": count_briefings_generated(days_back=30),
        "last_updated": date_str,
    }

    save_usage(data)

    # Save snapshot
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    with open(BRIEFINGS_DIR / f"{date_str}-usage.json", "w") as f:
        json.dump({"date": date_str, "today": today, "totals": data["totals"]}, f, indent=2)

    log(f"Today: engagement={today['engagement_score']}, telegram={today['telegram_queries']}, briefings={today['briefings_generated']}")
    log("Usage analytics complete")


if __name__ == "__main__":
    main()
