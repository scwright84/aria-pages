#!/usr/bin/env python3
"""
ARIA Expense/Invoice Tracker
Parses financial emails (Stripe, invoices, receipts, subscriptions) to
track spending per project/client.

Detects:
  - Stripe payment notifications
  - Invoice/receipt emails (from vendors)
  - Subscription renewal notices
  - Refund notifications

Categorizes by:
  - Project (from email classification)
  - Type (subscription, one-time, invoice, refund)
  - Vendor (extracted from sender)

Output: config/expenses.json (persistent)
        briefings/YYYY-MM-DD-expenses.json (monthly summary)
Runs weekly or on demand.
"""

import json
import re
import sys
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
EXPENSES_FILE = PROJECT_DIR / "config" / "expenses.json"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
LOG_FILE = PROJECT_DIR / "logs" / "expense-tracker.log"

# Financial email patterns
FINANCIAL_PATTERNS = {
    "stripe": {
        "senders": ["stripe.com", "notifications@stripe.com"],
        "subjects": [r"payment.*(?:received|succeeded|failed)", r"invoice", r"subscription", r"receipt"],
        "type": "payment_processor",
    },
    "paypal": {
        "senders": ["paypal.com"],
        "subjects": [r"receipt", r"payment", r"invoice"],
        "type": "payment_processor",
    },
    "invoice": {
        "senders": [],
        "subjects": [r"invoice\s*#?\d+", r"bill\s+(?:for|from)", r"payment\s+(?:due|reminder)", r"amount\s+due"],
        "type": "invoice",
    },
    "receipt": {
        "senders": [],
        "subjects": [r"receipt", r"order\s+confirm", r"purchase\s+confirm", r"thank you for your (?:order|purchase)"],
        "type": "receipt",
    },
    "subscription": {
        "senders": [],
        "subjects": [r"subscription\s+(?:renew|confirm|start|cancel)", r"your\s+(?:plan|membership)", r"auto.?pay", r"recurring\s+(?:payment|charge)"],
        "type": "subscription",
    },
}

# Amount extraction patterns
AMOUNT_PATTERNS = [
    r'\$[\d,]+\.?\d{0,2}',
    r'USD\s*[\d,]+\.?\d{0,2}',
    r'(?:amount|total|charge|payment)(?:\s*:?\s*)\$?[\d,]+\.?\d{0,2}',
]


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_expenses():
    if EXPENSES_FILE.exists():
        try:
            with open(EXPENSES_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"expenses": [], "subscriptions": []}


def save_expenses(data):
    EXPENSES_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(EXPENSES_FILE, "w") as f:
        json.dump(data, f, indent=2, default=str)


def extract_amount(text):
    """Try to extract a dollar amount from text."""
    for pattern in AMOUNT_PATTERNS:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            amount_str = match.group()
            # Clean up
            amount_str = re.sub(r'[^\d.]', '', amount_str.replace(',', ''))
            try:
                amount = float(amount_str)
                if 0.01 < amount < 1000000:  # Sanity check
                    return amount
            except ValueError:
                pass
    return None


def classify_financial_email(email):
    """Determine if an email is financial and classify it."""
    sender = (email.get("from") or "").lower()
    subject = (email.get("subject") or "").lower()
    snippet = (email.get("snippet") or "").lower()
    text = f"{subject} {snippet}"

    for category, patterns in FINANCIAL_PATTERNS.items():
        # Check sender
        if any(s in sender for s in patterns["senders"]):
            return category, patterns["type"]
        # Check subject
        for pattern in patterns["subjects"]:
            if re.search(pattern, text, re.IGNORECASE):
                return category, patterns["type"]

    return None, None


def extract_vendor(email):
    """Extract vendor name from email sender."""
    sender = email.get("from", "")
    if "<" in sender:
        name = sender.split("<")[0].strip().strip('"')
        if name:
            return name
    # Fall back to domain
    match = re.search(r'@([\w.-]+)', sender)
    if match:
        domain = match.group(1)
        return domain.split(".")[0].capitalize()
    return "Unknown"


def process_emails(days_back=30):
    """Scan emails for financial transactions."""
    found = []
    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        date_str = date.strftime("%Y-%m-%d")
        path = INBOX_DIR / f"emails-{date_str}.json"
        if not path.exists():
            continue
        try:
            with open(path) as f:
                emails = json.load(f)
            for e in emails:
                category, fin_type = classify_financial_email(e)
                if not category:
                    continue

                amount = extract_amount(f"{e.get('subject', '')} {e.get('snippet', '')}")
                vendor = extract_vendor(e)

                found.append({
                    "date": date_str,
                    "vendor": vendor,
                    "category": category,
                    "type": fin_type,
                    "amount": amount,
                    "subject": e.get("subject", ""),
                    "project": e.get("detected_project"),
                    "message_id": e.get("message_id"),
                })
        except Exception:
            pass

    return found


def generate_summary(expenses):
    """Generate spending summary."""
    by_project = defaultdict(float)
    by_vendor = defaultdict(float)
    by_type = defaultdict(float)
    by_month = defaultdict(float)

    total = 0
    for exp in expenses:
        amount = exp.get("amount") or 0
        total += amount
        by_project[exp.get("project") or "Unclassified"] += amount
        by_vendor[exp.get("vendor", "Unknown")] += amount
        by_type[exp.get("type", "unknown")] += amount
        month = exp.get("date", "")[:7]
        if month:
            by_month[month] += amount

    return {
        "total": round(total, 2),
        "transaction_count": len(expenses),
        "by_project": {k: round(v, 2) for k, v in sorted(by_project.items(), key=lambda x: -x[1])},
        "by_vendor": {k: round(v, 2) for k, v in sorted(by_vendor.items(), key=lambda x: -x[1])[:10]},
        "by_type": {k: round(v, 2) for k, v in by_type.items()},
        "by_month": {k: round(v, 2) for k, v in sorted(by_month.items())},
    }


def main():
    log("Starting expense tracking")

    new_expenses = process_emails(days_back=30)
    log(f"Found {len(new_expenses)} financial emails")

    # Merge with existing
    data = load_expenses()
    existing_ids = set(e.get("message_id") for e in data["expenses"] if e.get("message_id"))
    added = 0
    for exp in new_expenses:
        if exp.get("message_id") not in existing_ids:
            data["expenses"].append(exp)
            existing_ids.add(exp.get("message_id"))
            added += 1

    save_expenses(data)

    # Generate summary
    summary = generate_summary(data["expenses"])

    date_str = datetime.now().strftime("%Y-%m-%d")
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    output = {
        "date": date_str,
        "new_transactions": added,
        "summary": summary,
        "recent": new_expenses[:10],
    }
    with open(BRIEFINGS_DIR / f"{date_str}-expenses.json", "w") as f:
        json.dump(output, f, indent=2, default=str)

    log(f"Added {added} new transactions (total: {len(data['expenses'])})")
    log(f"Total tracked: ${summary['total']:.2f}")
    if summary["by_project"]:
        log(f"By project: {json.dumps(summary['by_project'])}")
    for exp in new_expenses[:5]:
        amount_str = f"${exp['amount']:.2f}" if exp.get("amount") else "amount unknown"
        log(f"  {exp['vendor']}: {exp['subject'][:50]} ({amount_str})")

    log("Expense tracking complete")


if __name__ == "__main__":
    main()
