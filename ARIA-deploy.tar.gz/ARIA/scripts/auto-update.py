#!/usr/bin/env python3
"""
ARIA Auto-Updater
Checks for updates from the GitHub repo and applies them.

Can run:
  - Manually: python3 scripts/auto-update.py
  - Via command center: /api/update/check and /api/update/apply
  - Via launchd: daily check

Requires git to be installed and the ARIA directory to be a git repo
(or have a .aria-update-url file pointing to the tar.gz download).
"""

import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent
UPDATE_STATE_FILE = PROJECT_DIR / "logs" / "update-state.json"
LOG_FILE = PROJECT_DIR / "logs" / "auto-update.log"
VERSION_FILE = PROJECT_DIR / "VERSION"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def get_current_version():
    """Read current version from VERSION file or git."""
    if VERSION_FILE.exists():
        return VERSION_FILE.read_text().strip()
    # Fall back to git commit hash
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True, text=True, timeout=10,
            cwd=str(PROJECT_DIR),
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return "unknown"


def load_state():
    if UPDATE_STATE_FILE.exists():
        try:
            with open(UPDATE_STATE_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"last_check": None, "update_available": False, "latest_version": None}


def save_state(state):
    UPDATE_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(UPDATE_STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def is_git_repo():
    """Check if ARIA directory is a git repo."""
    return (PROJECT_DIR / ".git").exists()


def check_for_updates():
    """Check if there are new commits on the remote."""
    state = load_state()
    current = get_current_version()

    if not is_git_repo():
        log("Not a git repo. Auto-update requires git clone installation.")
        state["last_check"] = datetime.now().isoformat()
        state["update_available"] = False
        state["current_version"] = current
        save_state(state)
        return state

    try:
        # Fetch remote without merging
        result = subprocess.run(
            ["git", "fetch", "origin", "--quiet"],
            capture_output=True, text=True, timeout=30,
            cwd=str(PROJECT_DIR),
        )
        if result.returncode != 0:
            log(f"Git fetch failed: {result.stderr[:200]}")
            state["last_check"] = datetime.now().isoformat()
            state["error"] = result.stderr[:200]
            save_state(state)
            return state

        # Check if local is behind remote
        result = subprocess.run(
            ["git", "rev-list", "--count", "HEAD..origin/main"],
            capture_output=True, text=True, timeout=10,
            cwd=str(PROJECT_DIR),
        )
        behind = int(result.stdout.strip()) if result.returncode == 0 else 0

        # Get latest remote version
        result = subprocess.run(
            ["git", "rev-parse", "--short", "origin/main"],
            capture_output=True, text=True, timeout=10,
            cwd=str(PROJECT_DIR),
        )
        remote_version = result.stdout.strip() if result.returncode == 0 else "unknown"

        state["last_check"] = datetime.now().isoformat()
        state["current_version"] = current
        state["latest_version"] = remote_version
        state["update_available"] = behind > 0
        state["commits_behind"] = behind
        state.pop("error", None)

        if behind > 0:
            # Get commit messages for what's new
            result = subprocess.run(
                ["git", "log", "--oneline", "HEAD..origin/main"],
                capture_output=True, text=True, timeout=10,
                cwd=str(PROJECT_DIR),
            )
            state["changes"] = result.stdout.strip().split("\n")[:10] if result.returncode == 0 else []
            log(f"Update available: {behind} commits behind ({current} -> {remote_version})")
        else:
            state["changes"] = []
            log(f"Up to date ({current})")

        save_state(state)
        return state

    except Exception as e:
        log(f"Update check failed: {e}")
        state["last_check"] = datetime.now().isoformat()
        state["error"] = str(e)
        save_state(state)
        return state


def apply_update():
    """Pull latest changes and restart services."""
    if not is_git_repo():
        return {"error": "Not a git repo. Cannot auto-update."}

    log("Applying update...")

    try:
        # Stash any local changes (config files, etc.)
        subprocess.run(
            ["git", "stash", "--include-untracked"],
            capture_output=True, text=True, timeout=10,
            cwd=str(PROJECT_DIR),
        )

        # Pull latest
        result = subprocess.run(
            ["git", "pull", "origin", "main", "--ff-only"],
            capture_output=True, text=True, timeout=60,
            cwd=str(PROJECT_DIR),
        )
        if result.returncode != 0:
            log(f"Git pull failed: {result.stderr[:300]}")
            # Restore stash
            subprocess.run(["git", "stash", "pop"], capture_output=True, cwd=str(PROJECT_DIR))
            return {"error": f"Pull failed: {result.stderr[:200]}"}

        # Pop stash (restore local config)
        subprocess.run(
            ["git", "stash", "pop"],
            capture_output=True, text=True, timeout=10,
            cwd=str(PROJECT_DIR),
        )

        # Reinstall dependencies if requirements changed
        req_file = PROJECT_DIR / "requirements.txt"
        if req_file.exists():
            log("Updating dependencies...")
            subprocess.run(
                [str(PROJECT_DIR / ".venv" / "bin" / "pip"), "install", "-r", str(req_file), "--quiet"],
                capture_output=True, timeout=120,
                cwd=str(PROJECT_DIR),
            )

        # Restart the command center
        log("Restarting command center...")
        subprocess.run(
            ["launchctl", "kickstart", "-k", "gui/" + str(os.getuid()) + "/com.aria.command-center"],
            capture_output=True, timeout=10,
        )

        new_version = get_current_version()
        log(f"Update complete: now at {new_version}")

        # Update state
        state = load_state()
        state["update_available"] = False
        state["current_version"] = new_version
        state["last_update"] = datetime.now().isoformat()
        save_state(state)

        return {"status": "updated", "version": new_version}

    except Exception as e:
        log(f"Update failed: {e}")
        return {"error": str(e)}


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "apply":
        result = apply_update()
        print(json.dumps(result, indent=2))
    else:
        state = check_for_updates()
        print(json.dumps(state, indent=2))
