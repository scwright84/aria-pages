#!/usr/bin/env python3
"""
ARIA Memory Indexer
Indexes all communication data into the semantic search layer.

Usage:
  python3 scripts/memory-index.py              # Index last 7 days
  python3 scripts/memory-index.py --days 30    # Index last 30 days
  python3 scripts/memory-index.py --search "What did we discuss about HIPAA?"
  python3 scripts/memory-index.py --search "Jac proposal" --project Conceivable
  python3 scripts/memory-index.py --stats      # Show collection stats

Runs weekly via launchd, or on demand.
"""

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import aria_memory

PROJECT_DIR = Path(__file__).parent.parent
LOG_FILE = PROJECT_DIR / "logs" / "memory-index.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def cmd_index(days_back):
    log(f"Starting memory indexing (last {days_back} days)")

    if not aria_memory.ensure_collection():
        log("ERROR: Could not create/access Qdrant collection. Is Qdrant running?")
        return 1

    result = aria_memory.index_inbox(days_back=days_back)
    log(f"Indexed {result['new']} new documents, skipped {result['skipped']} (already indexed)")
    log(f"Total documents in memory: {result['total_indexed']}")

    stats = aria_memory.get_collection_stats()
    log(f"Qdrant collection: {stats['points_count']} points, status={stats['status']}")

    return 0


def cmd_search(query, project=None, source=None, limit=5):
    log(f"Searching: '{query}'" + (f" (project={project})" if project else "") + (f" (source={source})" if source else ""))

    results = aria_memory.search(query, limit=limit, project_filter=project, source_filter=source)

    if not results:
        print("\nNo results found.")
        return

    print(f"\n{'='*70}")
    print(f"Search: \"{query}\"")
    print(f"Results: {len(results)}")
    print(f"{'='*70}\n")

    for i, r in enumerate(results, 1):
        score_bar = "=" * int(r["score"] * 20)
        print(f"  [{i}] Score: {r['score']:.3f} |{score_bar}|")
        print(f"      Source: {r['source']} | Project: {r.get('project') or '-'} | Date: {r.get('date') or '-'}")
        if r.get("from"):
            print(f"      From: {r['from']}")
        if r.get("subject"):
            print(f"      Subject: {r['subject']}")
        # Wrap text at 70 chars
        text = r["text"][:300]
        lines = [text[i:i+70] for i in range(0, len(text), 70)]
        for line in lines:
            print(f"      {line}")
        print()


def cmd_stats():
    stats = aria_memory.get_collection_stats()
    state = aria_memory._load_state()

    print(f"\nARIA Memory Stats")
    print(f"  Collection: {aria_memory.COLLECTION_NAME}")
    print(f"  Points: {stats['points_count']}")
    print(f"  Status: {stats['status']}")
    print(f"  Indexed hashes: {len(state.get('indexed_hashes', []))}")
    print(f"  Last index: {state.get('last_index', 'never')}")
    print(f"  Embedding model: {aria_memory.EMBEDDING_MODEL}")
    print(f"  Embedding dim: {aria_memory.EMBEDDING_DIM}")
    print()


def main():
    parser = argparse.ArgumentParser(description="ARIA Memory Indexer & Search")
    parser.add_argument("--days", type=int, default=7, help="Days of data to index")
    parser.add_argument("--search", type=str, help="Search query")
    parser.add_argument("--project", type=str, help="Filter by project")
    parser.add_argument("--source", type=str, help="Filter by source (email, slack, commitment, briefing)")
    parser.add_argument("--limit", type=int, default=5, help="Max results")
    parser.add_argument("--stats", action="store_true", help="Show collection stats")
    args = parser.parse_args()

    if args.stats:
        cmd_stats()
    elif args.search:
        cmd_search(args.search, project=args.project, source=args.source, limit=args.limit)
    else:
        return cmd_index(args.days)

    return 0


if __name__ == "__main__":
    sys.exit(main())
