#!/usr/bin/env python3
"""
ARIA Smart Follow-Up Reminders
Cross-references commitments (what was promised) with communications (what was done)
to find dropped balls, overdue items, and things that need a nudge.

Logic:
  1. Load all commitments from awaiting-*.json
  2. For each commitment, search recent emails/Slack for evidence of follow-through
  3. Flag commitments where no follow-through is detected
  4. Score urgency based on deadline proximity and importance

Output: briefings/YYYY-MM-DD-followups.json + HTML
Runs daily after inbox sync.
"""

import json
import re
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
LOG_FILE = PROJECT_DIR / "logs" / "follow-up-reminders.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_inbox_files(prefix, days_back=30):
    all_data = []
    for day_offset in range(days_back):
        date = datetime.now() - timedelta(days=day_offset)
        date_str = date.strftime("%Y-%m-%d")
        path = INBOX_DIR / f"{prefix}-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                if isinstance(data, list):
                    all_data.extend(data)
            except (json.JSONDecodeError, IOError):
                pass
    return all_data


def extract_keywords(text):
    """Extract meaningful keywords from a commitment description."""
    if not text:
        return set()
    # Remove common words
    stop_words = {"the", "a", "an", "to", "for", "and", "or", "in", "on", "at", "is", "are",
                  "was", "were", "be", "been", "being", "have", "has", "had", "do", "does",
                  "did", "will", "would", "could", "should", "may", "might", "shall", "can",
                  "need", "needs", "with", "from", "this", "that", "these", "those", "not"}
    words = set(re.findall(r'\b[a-zA-Z]{3,}\b', text.lower()))
    return words - stop_words


def search_communications(keywords, project, days_back=14):
    """Search emails and Slack for evidence that a commitment was addressed."""
    if not keywords:
        return False, []

    evidence = []

    # Search emails
    emails = load_inbox_files("emails", days_back)
    for e in emails:
        if project and e.get("detected_project") != project:
            continue
        text = f"{e.get('subject', '')} {e.get('snippet', '')} {e.get('summary', '')}".lower()
        matches = keywords & set(re.findall(r'\b[a-zA-Z]{3,}\b', text))
        if len(matches) >= 2:  # At least 2 keyword matches
            evidence.append({
                "type": "email",
                "subject": e.get("subject", ""),
                "from": e.get("from", ""),
                "match_keywords": list(matches),
            })

    # Search Slack
    slack = load_inbox_files("slack", days_back)
    for s in slack:
        if project and s.get("project") != project:
            continue
        text = f"{s.get('summary', '')} {' '.join(s.get('key_topics', []))}".lower()
        matches = keywords & set(re.findall(r'\b[a-zA-Z]{3,}\b', text))
        if len(matches) >= 2:
            evidence.append({
                "type": "slack",
                "channel": s.get("channel_name", ""),
                "match_keywords": list(matches),
            })

    return len(evidence) > 0, evidence


def analyze_commitments():
    """Analyze all commitments and find ones that need follow-up."""
    commitments = load_inbox_files("awaiting", days_back=30)
    today = datetime.now()
    reminders = []

    for c in commitments:
        task = c.get("task", "")
        owner = c.get("owner", "")
        deadline = c.get("deadline", "")
        project = c.get("project")
        meeting = c.get("meeting", "")
        meeting_date = c.get("meeting_date", "")

        if not task or len(task) < 10:
            continue

        # Parse deadline
        deadline_dt = None
        is_overdue = False
        days_until = None
        if deadline and deadline not in ("none", "TBD", ""):
            try:
                deadline_dt = datetime.strptime(deadline, "%Y-%m-%d")
                days_until = (deadline_dt - today).days
                is_overdue = days_until < 0
            except ValueError:
                pass

        # Parse meeting date to know how old the commitment is
        commitment_age = None
        if meeting_date:
            try:
                md = datetime.strptime(meeting_date, "%Y-%m-%d")
                commitment_age = (today - md).days
            except ValueError:
                pass

        # Search for evidence of follow-through
        keywords = extract_keywords(task)
        addressed, evidence = search_communications(keywords, project)

        if addressed:
            status = "likely_addressed"
            urgency = "low"
        elif is_overdue:
            status = "overdue"
            urgency = "high"
        elif days_until is not None and days_until <= 2:
            status = "due_soon"
            urgency = "high"
        elif days_until is not None and days_until <= 7:
            status = "upcoming"
            urgency = "medium"
        elif commitment_age and commitment_age > 7:
            status = "aging"
            urgency = "medium"
        else:
            status = "open"
            urgency = "normal"

        reminder = {
            "task": task[:200],
            "owner": owner[:100],
            "project": project,
            "meeting": meeting,
            "deadline": deadline,
            "days_until_deadline": days_until,
            "is_overdue": is_overdue,
            "commitment_age_days": commitment_age,
            "status": status,
            "urgency": urgency,
            "addressed": addressed,
            "evidence_count": len(evidence),
            "evidence": evidence[:3],  # Keep top 3
        }

        # Only include items that need attention
        if status != "likely_addressed":
            reminders.append(reminder)

    return sorted(reminders, key=lambda r: (
        0 if r["urgency"] == "high" else 1 if r["urgency"] == "medium" else 2,
        r.get("days_until_deadline") or 999
    ))


def generate_html(reminders, date_str):
    """Generate HTML follow-up reminder list."""
    urgency_colors = {"high": "#ef4444", "medium": "#f97316", "normal": "#6b7280", "low": "#22c55e"}
    status_labels = {
        "overdue": "OVERDUE", "due_soon": "DUE SOON", "upcoming": "UPCOMING",
        "aging": "AGING", "open": "OPEN", "likely_addressed": "DONE?"
    }

    rows = ""
    for r in reminders:
        color = urgency_colors.get(r["urgency"], "#6b7280")
        status_label = status_labels.get(r["status"], r["status"])
        deadline_display = r["deadline"] or "-"
        if r["is_overdue"]:
            deadline_display = f'<span style="color:#ef4444;font-weight:700">{deadline_display} ({abs(r["days_until_deadline"])}d overdue)</span>'
        elif r["days_until_deadline"] is not None and r["days_until_deadline"] <= 3:
            deadline_display = f'<span style="color:#f97316;font-weight:600">{deadline_display} ({r["days_until_deadline"]}d)</span>'

        rows += f"""
        <tr>
            <td style="color:{color};font-weight:700;font-size:12px">{status_label}</td>
            <td><strong>{r["task"][:80]}</strong><br><span style="font-size:12px;color:#6b7280">From: {r["meeting"] or r["owner"]}</span></td>
            <td>{r["project"] or "-"}</td>
            <td>{deadline_display}</td>
        </tr>"""

    high_count = sum(1 for r in reminders if r["urgency"] == "high")
    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>ARIA Follow-Up Reminders - {date_str}</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 900px; margin: 0 auto; padding: 20px; background: #f9fafb; }}
  h1 {{ font-size: 20px; color: #111827; margin-bottom: 4px; }}
  .subtitle {{ color: #6b7280; font-size: 14px; margin-bottom: 16px; }}
  .alert {{ background: #fef2f2; border-left: 4px solid #ef4444; padding: 10px 14px; border-radius: 4px; margin-bottom: 16px; font-size: 14px; }}
  table {{ width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }}
  th {{ background: #111827; color: white; padding: 10px 12px; text-align: left; font-size: 12px; text-transform: uppercase; }}
  td {{ padding: 10px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px; }}
  tr:hover {{ background: #f3f4f6; }}
</style>
</head>
<body>
<h1>Follow-Up Reminders</h1>
<p class="subtitle">{date_str} | {len(reminders)} items need attention | Generated by ARIA</p>
{"<div class='alert'><strong>" + str(high_count) + " items are overdue or due soon.</strong></div>" if high_count > 0 else ""}
<table>
  <thead><tr><th>Status</th><th>Commitment</th><th>Project</th><th>Deadline</th></tr></thead>
  <tbody>{rows if rows else "<tr><td colspan='4' style='text-align:center;color:#22c55e'>No follow-ups needed. You're caught up.</td></tr>"}</tbody>
</table>
</body>
</html>"""
    return html


def main():
    log("Starting follow-up reminder analysis")
    date_str = datetime.now().strftime("%Y-%m-%d")

    reminders = analyze_commitments()
    log(f"Found {len(reminders)} items needing follow-up")

    # Save JSON
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    json_path = BRIEFINGS_DIR / f"{date_str}-followups.json"
    with open(json_path, "w") as f:
        json.dump(reminders, f, indent=2, default=str)
    log(f"Saved: {json_path}")

    # Save HTML
    html_path = BRIEFINGS_DIR / f"{date_str}-followups.html"
    html = generate_html(reminders, date_str)
    with open(html_path, "w") as f:
        f.write(html)
    log(f"Saved: {html_path}")

    # Summary
    for r in reminders:
        overdue_tag = " [OVERDUE]" if r["is_overdue"] else ""
        log(f"  {r['urgency'].upper():>6} | {r['status']:>10} | {r['project'] or 'no project':>15} | {r['task'][:60]}{overdue_tag}")

    log("Follow-up reminders complete")


if __name__ == "__main__":
    main()
