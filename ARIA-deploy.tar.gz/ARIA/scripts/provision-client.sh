#!/bin/bash
# ARIA Multi-Tenant Client Provisioning
# Creates an isolated client instance on a shared Mac Studio.
#
# Each client gets:
#   - Dedicated macOS user account
#   - Own ARIA installation (~/ARIA/)
#   - Own data directories (inbox, briefings, config)
#   - Own port assignments (offset from base)
#   - Own launchd services
#   - Own Telegram bot
#   - Complete data isolation from other clients
#
# Usage:
#   sudo ./scripts/provision-client.sh \
#     --name "Lakeway Dental" \
#     --username lakeway \
#     --type dental \
#     --contact "Dr. Smith" \
#     --email drsmith@lakewaydentalcare.com
#
# Port assignment:
#   Base ports: 8640-8649 (Sean's reference deployment)
#   Client 1:   8650-8659
#   Client 2:   8660-8669
#   etc.

set -euo pipefail

BOLD='\033[1m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${GREEN}[PROVISION]${NC} $1"; }
warn() { echo -e "${YELLOW}[PROVISION]${NC} $1"; }
err()  { echo -e "${RED}[PROVISION]${NC} $1"; }
step() { echo -e "\n${BOLD}=== $1 ===${NC}"; }

# Parse arguments
CLIENT_NAME=""
USERNAME=""
CLIENT_TYPE="general"
CONTACT_NAME=""
CONTACT_EMAIL=""
PASSWORD=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --name) CLIENT_NAME="$2"; shift 2;;
        --username) USERNAME="$2"; shift 2;;
        --type) CLIENT_TYPE="$2"; shift 2;;
        --contact) CONTACT_NAME="$2"; shift 2;;
        --email) CONTACT_EMAIL="$2"; shift 2;;
        --password) PASSWORD="$2"; shift 2;;
        *) err "Unknown option: $1"; exit 1;;
    esac
done

if [[ -z "$CLIENT_NAME" || -z "$USERNAME" || -z "$CONTACT_EMAIL" ]]; then
    echo "Usage: sudo $0 --name 'Client Name' --username clientuser --email client@email.com"
    echo ""
    echo "Required:"
    echo "  --name        Client business name"
    echo "  --username    macOS username (lowercase, no spaces)"
    echo "  --email       Primary contact email"
    echo ""
    echo "Optional:"
    echo "  --type        Business type: dental, legal, accounting, consulting, general (default: general)"
    echo "  --contact     Primary contact name"
    echo "  --password    macOS password (will prompt if not provided)"
    exit 1
fi

# Must run as root for user creation
if [[ "$(id -u)" -ne 0 ]]; then
    err "Must run as root (sudo) to create user accounts."
    exit 1
fi

CONTACT_NAME="${CONTACT_NAME:-$CLIENT_NAME}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ADMIN_ARIA_DIR="$(dirname "$SCRIPT_DIR")"

step "Provisioning: $CLIENT_NAME"
log "Username: $USERNAME"
log "Type: $CLIENT_TYPE"
log "Contact: $CONTACT_NAME <$CONTACT_EMAIL>"

# ============================================================
step "1. Create macOS user"
# ============================================================

if id "$USERNAME" &>/dev/null; then
    warn "User '$USERNAME' already exists. Skipping creation."
else
    if [[ -z "$PASSWORD" ]]; then
        read -sp "  Set password for '$USERNAME': " PASSWORD
        echo ""
    fi

    # Find next available UID
    NEXT_UID=$(dscl . -list /Users UniqueID | awk '{print $2}' | sort -n | tail -1 | awk '{print $1+1}')

    sysadminctl -addUser "$USERNAME" -fullName "$CLIENT_NAME" -password "$PASSWORD" -UID "$NEXT_UID" 2>/dev/null
    # Ensure non-admin
    dseditgroup -o edit -d "$USERNAME" -t user admin 2>/dev/null || true

    log "User '$USERNAME' created (UID: $NEXT_UID, non-admin)"
fi

CLIENT_HOME="/Users/$USERNAME"

# ============================================================
step "2. Determine port assignments"
# ============================================================

# Count existing ARIA client users to determine port offset
EXISTING_CLIENTS=$(dscl . -list /Users | grep -v '^_' | grep -v 'root\|daemon\|nobody' | wc -l | tr -d ' ')
PORT_BASE=$((8640 + (EXISTING_CLIENTS * 10)))

PORTS=(
    "$((PORT_BASE + 2)):onboarding"
    "$((PORT_BASE + 3)):dashboard"
    "$((PORT_BASE + 4)):status"
    "$((PORT_BASE + 5)):admin"
    "$((PORT_BASE + 6)):portal"
    "$((PORT_BASE + 7)):billing"
    "$((PORT_BASE + 8)):webhook"
)

log "Port range: $PORT_BASE - $((PORT_BASE + 9))"
for p in "${PORTS[@]}"; do
    port="${p%%:*}"
    name="${p##*:}"
    log "  $port: $name"
done

# ============================================================
step "3. Copy ARIA installation"
# ============================================================

CLIENT_ARIA="$CLIENT_HOME/ARIA"

if [[ -d "$CLIENT_ARIA" ]]; then
    warn "ARIA already exists at $CLIENT_ARIA. Updating..."
else
    log "Copying ARIA to $CLIENT_ARIA..."
fi

# Use the deployment packager if available, otherwise rsync
if [[ -x "$ADMIN_ARIA_DIR/scripts/package-deploy.sh" ]]; then
    # Create temp package
    TEMP_PKG=$(mktemp -d)/ARIA-deploy.tar.gz
    sudo -u "$(stat -f %Su "$ADMIN_ARIA_DIR")" "$ADMIN_ARIA_DIR/scripts/package-deploy.sh" "$TEMP_PKG" >/dev/null 2>&1
    mkdir -p "$CLIENT_ARIA"
    tar xzf "$TEMP_PKG" -C "$CLIENT_ARIA" --strip-components=1 2>/dev/null
    rm -f "$TEMP_PKG"
else
    # Direct rsync (exclude data, credentials, logs)
    rsync -a --exclude='inbox/' --exclude='briefings/' --exclude='logs/' \
        --exclude='.env' --exclude='config/credentials.json' \
        --exclude='.venv/' --exclude='__pycache__/' \
        --exclude='.git/' --exclude='exports/' \
        "$ADMIN_ARIA_DIR/" "$CLIENT_ARIA/"
fi

# Create client directories
mkdir -p "$CLIENT_ARIA"/{inbox,briefings,logs,config,exports}

log "ARIA copied to $CLIENT_ARIA"

# ============================================================
step "4. Generate client config"
# ============================================================

# Timezone (default CT)
TZ_NAME="America/Chicago"
TZ_ABBR="CT"

cat > "$CLIENT_ARIA/config/aria.json" << CONFIGEOF
{
  "client": {
    "name": "$CLIENT_NAME",
    "type": "$CLIENT_TYPE",
    "contact_name": "$CONTACT_NAME",
    "contact_email": "$CONTACT_EMAIL"
  },
  "timezone": "$TZ_NAME",
  "timezone_abbr": "$TZ_ABBR",
  "email": "$CONTACT_EMAIL",
  "n8n_base_url": "http://localhost:5678",
  "ai": {
    "inference_url": "http://localhost:11434/v1/chat/completions",
    "default_model": "mlx-community/Qwen3-8B-4bit",
    "fast_model": "mlx-community/Qwen3-4B-4bit",
    "timeout": 120,
    "cloud_model": "claude-sonnet-4-5-20241022",
    "cloud_url": "https://api.anthropic.com/v1/messages",
    "cloud_api_key_env": "ANTHROPIC_API_KEY",
    "cloud_timeout": 180,
    "cloud_max_tokens": 4096,
    "embedding_model": "nomic-embed-text",
    "embedding_dim": 768,
    "inference_engine": "mlx"
  },
  "telegram": {
    "token_env": "ARIA_TELEGRAM_TOKEN",
    "authorized_users": []
  },
  "known_projects": [],
  "client_tiers": {
    "active": [],
    "product": [],
    "on_hold": []
  },
  "schedules": {
    "morning_briefing": "07:30",
    "evening_debrief": "21:30",
    "weekly_rollup": "Sunday 19:00"
  },
  "retention": {
    "inbox_days": 30,
    "briefings_days": 14
  },
  "branding": {
    "company_name": "$CLIENT_NAME",
    "product_name": "ARIA",
    "primary_color": "#3b82f6",
    "powered_by": true
  },
  "demo_mode": false
}
CONFIGEOF

# Create empty .env
cat > "$CLIENT_ARIA/.env" << ENVEOF
# ARIA Environment Variables for $CLIENT_NAME
# This file is loaded by aria_ai.py. Do NOT share.

ARIA_TELEGRAM_TOKEN=
ANTHROPIC_API_KEY=
ARIA_PORTAL_TOKEN=$(openssl rand -hex 16)
ARIA_WEBHOOK_TOKEN=$(openssl rand -hex 16)
ENVEOF

chmod 600 "$CLIENT_ARIA/.env"
log "Client config generated"

# ============================================================
step "5. Set up Python environment"
# ============================================================

log "Creating Python venv..."
sudo -u "$USERNAME" python3 -m venv "$CLIENT_ARIA/.venv" 2>/dev/null || python3 -m venv "$CLIENT_ARIA/.venv"
"$CLIENT_ARIA/.venv/bin/pip" install --quiet --upgrade pip
"$CLIENT_ARIA/.venv/bin/pip" install --quiet requests python-telegram-bot flask rumps qdrant-client \
    google-auth google-auth-oauthlib google-auth-httplib2 google-api-python-client \
    mlx-lm sentence-transformers einops
log "Python environment ready"

# ============================================================
step "6. Set ownership and permissions"
# ============================================================

chown -R "$USERNAME:staff" "$CLIENT_ARIA"
chmod 700 "$CLIENT_ARIA"
chmod 600 "$CLIENT_ARIA/.env"
chmod 600 "$CLIENT_ARIA/config/aria.json"

log "Ownership set to $USERNAME, permissions locked"

# ============================================================
step "7. Install launchd services"
# ============================================================

CLIENT_AGENTS="/Users/$USERNAME/Library/LaunchAgents"
mkdir -p "$CLIENT_AGENTS"

# Run the service manager as the client user to generate plists
sudo -u "$USERNAME" "$CLIENT_ARIA/scripts/aria-services.sh" install 2>/dev/null || warn "Service install had issues (may need manual review)"

chown -R "$USERNAME:staff" "$CLIENT_AGENTS"
log "launchd services installed for $USERNAME"

# ============================================================
step "8. Register in clients registry"
# ============================================================

REGISTRY="$ADMIN_ARIA_DIR/config/clients-registry.json"
if [[ -f "$REGISTRY" ]]; then
    # Add new client to registry
    python3 -c "
import json
with open('$REGISTRY') as f:
    reg = json.load(f)
reg['clients'].append({
    'id': '$USERNAME',
    'name': '$CLIENT_NAME',
    'type': '$CLIENT_TYPE',
    'contact': '$CONTACT_NAME',
    'deployment': 'shared',
    'hardware': 'Mac Studio (shared)',
    'status_url': 'http://localhost:$((PORT_BASE + 4))/api/status',
    'dashboard_url': 'http://localhost:$((PORT_BASE + 3))',
    'tailscale_ip': None,
    'phase': 'onboarding',
    'monthly_fee': 750,
    'setup_date': '$(date +%Y-%m-%d)',
    'username': '$USERNAME',
    'port_base': $PORT_BASE,
    'notes': 'Provisioned via provision-client.sh'
})
with open('$REGISTRY', 'w') as f:
    json.dump(reg, f, indent=2)
print('Client added to registry')
"
    log "Added to clients registry"
else
    warn "Clients registry not found. Add manually."
fi

# ============================================================
step "Provisioning Complete"
# ============================================================

echo ""
echo -e "${GREEN}${BOLD}Client provisioned successfully!${NC}"
echo ""
echo "  Client:    $CLIENT_NAME"
echo "  Username:  $USERNAME"
echo "  Home:      $CLIENT_HOME"
echo "  ARIA:      $CLIENT_ARIA"
echo "  Ports:     $PORT_BASE - $((PORT_BASE + 9))"
echo ""
echo "  Next steps:"
echo "    1. Log in as '$USERNAME' to complete setup"
echo "    2. Edit $CLIENT_ARIA/.env with Telegram token and API key"
echo "    3. Run: cd $CLIENT_ARIA && ./scripts/aria-services.sh start"
echo "    4. Open http://localhost:$((PORT_BASE + 2)) for onboarding wizard"
echo "    5. Connect email and calendar accounts"
echo ""
echo "  For remote onboarding:"
echo "    python3 scripts/generate-onboarding-email.py \\"
echo "      --name '$CONTACT_NAME' \\"
echo "      --email '$CONTACT_EMAIL' \\"
echo "      --business '$CLIENT_NAME'"
echo ""
