#!/usr/bin/env python3
"""
ARIA Revenue & Business Dashboard
Sean and Kelly's view of the business. MRR, churn, client health, LTV.

Metrics:
  - MRR (monthly recurring revenue)
  - Client count (active, onboarding, churned)
  - Average revenue per client
  - Client health scores (from engagement + sentiment + usage)
  - Churn risk prediction
  - LTV projection
  - Revenue trend

Sources: config/clients-registry.json, config/billing/billing.json, usage analytics

Output: briefings/YYYY-MM-DD-revenue.json + HTML
Port 8649 (web dashboard)
"""

import json
import sys
from datetime import datetime, timedelta
from pathlib import Path

from flask import Flask, Response

PROJECT_DIR = Path(__file__).parent.parent
CONFIG_DIR = PROJECT_DIR / "config"
BILLING_DIR = CONFIG_DIR / "billing"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
LOG_FILE = PROJECT_DIR / "logs" / "revenue-dashboard.log"

app = Flask(__name__)


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_json(path):
    if Path(path).exists():
        try:
            with open(path) as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def compute_business_metrics():
    """Compute all business metrics from available data."""
    registry = load_json(CONFIG_DIR / "clients-registry.json")
    billing = load_json(BILLING_DIR / "billing.json")
    clients = registry.get("clients", [])

    now = datetime.now()

    # Client counts
    active = [c for c in clients if c.get("phase") in ("active", "onboarding")]
    churned = [c for c in clients if c.get("phase") == "churned"]

    # MRR
    mrr = sum(c.get("monthly_fee", 0) for c in active)

    # Revenue collected
    total_collected = 0
    if billing.get("clients"):
        for cid, cdata in billing["clients"].items():
            for payment in cdata.get("payments", []):
                if payment.get("status") == "succeeded":
                    total_collected += payment.get("amount", 0) / 100  # cents to dollars

    # Average revenue per client
    arpc = mrr / len(active) if active else 0

    # Client health (from scorecards and sentiment)
    client_health = []
    for client in active:
        health = {
            "name": client.get("name"),
            "monthly_fee": client.get("monthly_fee", 0),
            "setup_date": client.get("setup_date", ""),
            "phase": client.get("phase", ""),
        }

        # Calculate days as client
        if client.get("setup_date"):
            try:
                setup = datetime.strptime(client["setup_date"], "%Y-%m-%d")
                health["days_active"] = (now - setup).days
                health["months_active"] = round((now - setup).days / 30, 1)
            except ValueError:
                health["days_active"] = 0
                health["months_active"] = 0

        # Churn risk (simplified model)
        # Risk increases with: low usage, negative sentiment, long time since last interaction
        usage = load_json(CONFIG_DIR / "usage-analytics.json")
        engagement = usage.get("totals", {}).get("avg_engagement", 50)

        if engagement < 20:
            health["churn_risk"] = "high"
            health["churn_score"] = 80
        elif engagement < 40:
            health["churn_risk"] = "medium"
            health["churn_score"] = 50
        else:
            health["churn_risk"] = "low"
            health["churn_score"] = 20

        # LTV projection (monthly_fee * expected months)
        expected_months = {"low": 18, "medium": 9, "high": 3}
        health["projected_ltv"] = client.get("monthly_fee", 0) * expected_months.get(health.get("churn_risk", "low"), 12)

        client_health.append(health)

    # LTV aggregate
    total_projected_ltv = sum(h.get("projected_ltv", 0) for h in client_health)

    # Revenue trend (simple: current MRR * 12 annualized)
    arr = mrr * 12

    return {
        "date": now.strftime("%Y-%m-%d"),
        "summary": {
            "mrr": mrr,
            "arr": arr,
            "active_clients": len(active),
            "onboarding": len([c for c in clients if c.get("phase") == "onboarding"]),
            "churned": len(churned),
            "total_collected": total_collected,
            "arpc": round(arpc),
            "total_projected_ltv": total_projected_ltv,
        },
        "clients": client_health,
        "pricing": {
            "setup_fee": 5000,
            "monthly_retainer": 750,
        },
        "projections": {
            "3_month_revenue": mrr * 3 + (len([c for c in clients if c.get("phase") == "onboarding"]) * 5000),
            "6_month_revenue": mrr * 6,
            "12_month_revenue": arr,
        },
    }


def render_dashboard(metrics):
    s = metrics["summary"]
    now = datetime.now()

    # Client rows
    client_rows = ""
    for c in metrics["clients"]:
        risk_color = {"low": "#22c55e", "medium": "#f97316", "high": "#ef4444"}.get(c.get("churn_risk", "low"), "#6b7280")
        client_rows += f"""
        <tr>
            <td style="font-weight:600">{c.get('name', '?')}</td>
            <td style="text-align:center">${c.get('monthly_fee', 0)}/mo</td>
            <td style="text-align:center">{c.get('months_active', 0)} mo</td>
            <td style="text-align:center;color:{risk_color};font-weight:600">{c.get('churn_risk', '?').upper()}</td>
            <td style="text-align:center">${c.get('projected_ltv', 0):,.0f}</td>
            <td style="text-transform:capitalize">{c.get('phase', '?')}</td>
        </tr>"""

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="300">
<title>ARIA Revenue Dashboard</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #0f172a; color: #e2e8f0; }}
  .container {{ max-width: 1000px; margin: 0 auto; padding: 24px 16px; }}
  h1 {{ font-size: 20px; font-weight: 600; margin-bottom: 4px; }}
  .subtitle {{ color: #64748b; font-size: 13px; margin-bottom: 24px; }}
  .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; margin-bottom: 24px; }}
  .metric {{ background: #1e293b; border-radius: 10px; padding: 16px; text-align: center; }}
  .metric .value {{ font-size: 32px; font-weight: 800; }}
  .metric .label {{ font-size: 11px; color: #64748b; margin-top: 4px; text-transform: uppercase; letter-spacing: 0.5px; }}
  .metric .sub {{ font-size: 12px; color: #94a3b8; margin-top: 2px; }}
  table {{ width: 100%; border-collapse: collapse; background: #1e293b; border-radius: 8px; overflow: hidden; }}
  th {{ background: #334155; padding: 10px 12px; text-align: left; font-size: 11px; text-transform: uppercase; color: #94a3b8; }}
  td {{ padding: 12px; border-bottom: 1px solid #334155; font-size: 14px; }}
  tr:last-child td {{ border-bottom: none; }}
  .section-title {{ font-size: 14px; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.5px; margin: 24px 0 12px; }}
</style>
</head>
<body>
<div class="container">
  <h1>ARIA Revenue Dashboard</h1>
  <p class="subtitle">{now.strftime('%B %d, %Y')} | Sean & Kelly's view of the business</p>

  <div class="grid">
    <div class="metric"><div class="value" style="color:#22c55e">${s['mrr']:,.0f}</div><div class="label">MRR</div><div class="sub">${s['arr']:,.0f} ARR</div></div>
    <div class="metric"><div class="value">{s['active_clients']}</div><div class="label">Active Clients</div><div class="sub">{s['onboarding']} onboarding</div></div>
    <div class="metric"><div class="value">${s['arpc']:,.0f}</div><div class="label">Avg Rev/Client</div><div class="sub">per month</div></div>
    <div class="metric"><div class="value">${s['total_collected']:,.0f}</div><div class="label">Total Collected</div><div class="sub">all time</div></div>
    <div class="metric"><div class="value">${s['total_projected_ltv']:,.0f}</div><div class="label">Projected LTV</div><div class="sub">all clients</div></div>
    <div class="metric"><div class="value">{s['churned']}</div><div class="label">Churned</div><div class="sub">all time</div></div>
  </div>

  <p class="section-title">Client Health & Churn Risk</p>
  <table>
    <thead><tr><th>Client</th><th style="text-align:center">MRR</th><th style="text-align:center">Tenure</th><th style="text-align:center">Churn Risk</th><th style="text-align:center">Proj. LTV</th><th>Phase</th></tr></thead>
    <tbody>{client_rows if client_rows else '<tr><td colspan="6" style="text-align:center;color:#64748b">No clients yet. Kelly, go sell!</td></tr>'}</tbody>
  </table>

  <p class="section-title">Revenue Projections</p>
  <div class="grid">
    <div class="metric"><div class="value">${metrics['projections']['3_month_revenue']:,.0f}</div><div class="label">Next 3 Months</div></div>
    <div class="metric"><div class="value">${metrics['projections']['6_month_revenue']:,.0f}</div><div class="label">Next 6 Months</div></div>
    <div class="metric"><div class="value">${metrics['projections']['12_month_revenue']:,.0f}</div><div class="label">Next 12 Months</div></div>
  </div>

  <p style="text-align:center;font-size:11px;color:#475569;margin-top:24px">ARIA Revenue Dashboard | Wright Advisors & Kelly Kelley</p>
</div>
</body>
</html>"""
    return html


@app.route("/")
def index():
    metrics = compute_business_metrics()
    return Response(render_dashboard(metrics), mimetype="text/html")


@app.route("/api/metrics")
def api_metrics():
    metrics = compute_business_metrics()
    return json.dumps(metrics, indent=2, default=str), 200, {"Content-Type": "application/json"}


@app.route("/healthz")
def healthz():
    return "ok", 200


def main():
    # Also save a snapshot
    metrics = compute_business_metrics()
    date_str = datetime.now().strftime("%Y-%m-%d")
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    with open(BRIEFINGS_DIR / f"{date_str}-revenue.json", "w") as f:
        json.dump(metrics, f, indent=2, default=str)

    print(f"ARIA Revenue Dashboard running at http://localhost:8649")
    print(f"MRR: ${metrics['summary']['mrr']:,.0f} | Clients: {metrics['summary']['active_clients']} | ARR: ${metrics['summary']['arr']:,.0f}")
    app.run(host="127.0.0.1", port=8649, debug=False)


if __name__ == "__main__":
    main()
