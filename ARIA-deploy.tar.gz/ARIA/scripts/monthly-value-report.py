#!/usr/bin/env python3
"""
ARIA Monthly Client Value Report
Proves ROI by quantifying what ARIA did for the user this month.

Metrics:
  - Emails processed and organized
  - Junk/noise filtered out (time saved)
  - Briefings delivered
  - Draft responses generated (time saved per draft)
  - Tasks extracted and tracked
  - Commitments monitored
  - Meetings prepped
  - Dropped balls caught (follow-up reminders)
  - Outreach alerts generated
  - Decisions logged
  - Estimated hours saved

Time savings model (conservative):
  - Each email organized: 15 seconds saved (no manual filing)
  - Each junk email filtered: 30 seconds saved (no reading/deleting)
  - Each draft response: 5 minutes saved (no writing from scratch)
  - Each briefing: 20 minutes saved (no manual inbox review)
  - Each meeting prep: 10 minutes saved (no manual context gathering)
  - Each follow-up reminder: 15 minutes saved (no manual tracking)

Output: briefings/YYYY-MM-value-report.json + HTML
Runs monthly (1st of month for previous month) or on demand.
"""

import json
import sys
from datetime import datetime, timedelta
from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
CONFIG_DIR = PROJECT_DIR / "config"
LOG_FILE = PROJECT_DIR / "logs" / "value-report.log"

# Time savings estimates (in minutes)
TIME_SAVINGS = {
    "email_organized": 0.25,       # 15 seconds per email organized
    "junk_filtered": 0.5,          # 30 seconds per junk email
    "draft_generated": 5.0,        # 5 minutes per draft
    "briefing_delivered": 20.0,    # 20 minutes per briefing
    "meeting_prepped": 10.0,       # 10 minutes per meeting prep
    "followup_caught": 15.0,       # 15 minutes per dropped ball caught
    "task_extracted": 2.0,         # 2 minutes per task identified
    "outreach_alert": 5.0,         # 5 minutes per proactive alert
}


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def count_inbox_files(prefix, month_str):
    """Count items in inbox files for a given month."""
    total = 0
    for f in INBOX_DIR.glob(f"{prefix}-{month_str}-*.json"):
        try:
            with open(f) as fh:
                data = json.load(fh)
            total += len(data) if isinstance(data, list) else 1
        except Exception:
            pass
    return total


def count_briefing_files(pattern, month_str):
    """Count briefing files matching a pattern for a given month."""
    count = 0
    for f in BRIEFINGS_DIR.glob(f"{month_str}-*{pattern}*"):
        count += 1
    return count


def load_json_file(path):
    if Path(path).exists():
        try:
            with open(path) as f:
                return json.load(f)
        except Exception:
            pass
    return None


def gather_monthly_stats(year, month):
    """Gather all stats for a given month."""
    month_str = f"{year}-{month:02d}"

    stats = {
        "period": f"{month_str}",
        "period_display": datetime(year, month, 1).strftime("%B %Y"),
    }

    # Emails processed
    stats["emails_processed"] = count_inbox_files("emails", month_str)

    # Slack channels summarized
    stats["slack_summaries"] = count_inbox_files("slack", month_str)

    # Calendar events synced
    stats["calendar_events"] = count_inbox_files("calendar", month_str)

    # Commitments tracked
    stats["commitments_tracked"] = count_inbox_files("awaiting", month_str)

    # Notifications processed
    stats["notifications_processed"] = count_inbox_files("notifications", month_str)

    # Briefings delivered
    stats["morning_briefings"] = len(list(BRIEFINGS_DIR.glob(f"{month_str}-??.html")))
    stats["evening_debriefs"] = len(list(BRIEFINGS_DIR.glob(f"{month_str}-*-debrief.html")))
    stats["weekly_rollups"] = len(list(BRIEFINGS_DIR.glob(f"{month_str}-*-weekly.html")))
    stats["total_briefings"] = stats["morning_briefings"] + stats["evening_debriefs"] + stats["weekly_rollups"]

    # Scorecards generated
    stats["scorecards"] = len(list(BRIEFINGS_DIR.glob(f"{month_str}-*-scorecard.json")))

    # Task extraction
    tasks_data = load_json_file(CONFIG_DIR / "tasks.json")
    stats["tasks_extracted"] = len(tasks_data.get("tasks", [])) if tasks_data else 0

    # Follow-up reminders
    stats["followups_generated"] = count_briefing_files("followups", month_str)

    # Outreach alerts
    stats["outreach_alerts"] = count_briefing_files("outreach", month_str)

    # Decisions logged
    decisions_data = load_json_file(CONFIG_DIR / "decisions.json")
    stats["decisions_logged"] = len(decisions_data.get("decisions", [])) if decisions_data else 0

    # Contacts tracked
    contacts_data = load_json_file(CONFIG_DIR / "contacts.json")
    stats["contacts_tracked"] = len(contacts_data) if contacts_data else 0

    # Knowledge base entries
    kb_data = load_json_file(CONFIG_DIR / "knowledge-base.json")
    stats["knowledge_entries"] = len(kb_data.get("entries", [])) if kb_data else 0

    # Junk filtered (estimate: ~10% of emails are junk based on our testing)
    stats["junk_filtered"] = round(stats["emails_processed"] * 0.1)

    # Draft responses (estimate from draft manager)
    drafts_data = load_json_file(CONFIG_DIR / "pending-drafts.json")
    stats["drafts_generated"] = len(drafts_data.get("drafts", [])) if drafts_data else 0

    # Meeting preps
    stats["meeting_preps"] = count_briefing_files("meeting-", month_str)

    return stats


def calculate_time_saved(stats):
    """Calculate estimated time saved in minutes."""
    time_saved = {}
    time_saved["email_organizing"] = stats["emails_processed"] * TIME_SAVINGS["email_organized"]
    time_saved["junk_filtering"] = stats["junk_filtered"] * TIME_SAVINGS["junk_filtered"]
    time_saved["draft_responses"] = stats["drafts_generated"] * TIME_SAVINGS["draft_generated"]
    time_saved["briefing_review"] = stats["total_briefings"] * TIME_SAVINGS["briefing_delivered"]
    time_saved["meeting_prep"] = stats["meeting_preps"] * TIME_SAVINGS["meeting_prepped"]
    time_saved["followup_tracking"] = stats["followups_generated"] * TIME_SAVINGS["followup_caught"]
    time_saved["task_extraction"] = stats["tasks_extracted"] * TIME_SAVINGS["task_extracted"]
    time_saved["outreach_alerts"] = stats["outreach_alerts"] * TIME_SAVINGS["outreach_alert"]

    total_minutes = sum(time_saved.values())
    total_hours = total_minutes / 60

    return {
        "breakdown_minutes": {k: round(v, 1) for k, v in time_saved.items()},
        "total_minutes": round(total_minutes),
        "total_hours": round(total_hours, 1),
        "equivalent_workdays": round(total_hours / 8, 1),
    }


def generate_html(stats, time_saved):
    """Generate HTML value report."""
    ts = time_saved

    # Big number cards
    cards = f"""
    <div class="grid">
      <div class="metric big"><div class="value">{ts['total_hours']}h</div><div class="label">Time Saved</div></div>
      <div class="metric big"><div class="value">{stats['emails_processed']}</div><div class="label">Emails Processed</div></div>
      <div class="metric big"><div class="value">{stats['total_briefings']}</div><div class="label">Briefings Delivered</div></div>
      <div class="metric big"><div class="value">{stats['contacts_tracked']}</div><div class="label">Contacts Tracked</div></div>
    </div>"""

    # Detailed stats
    detail_rows = ""
    details = [
        ("Emails organized into folders", stats["emails_processed"], f"{ts['breakdown_minutes'].get('email_organizing', 0)} min saved"),
        ("Junk/spam filtered", stats["junk_filtered"], f"{ts['breakdown_minutes'].get('junk_filtering', 0)} min saved"),
        ("Draft responses generated", stats["drafts_generated"], f"{ts['breakdown_minutes'].get('draft_responses', 0)} min saved"),
        ("Morning briefings", stats["morning_briefings"], f"{ts['breakdown_minutes'].get('briefing_review', 0)} min saved"),
        ("Evening debriefs", stats["evening_debriefs"], ""),
        ("Weekly rollups", stats["weekly_rollups"], ""),
        ("Meeting preps auto-generated", stats["meeting_preps"], f"{ts['breakdown_minutes'].get('meeting_prep', 0)} min saved"),
        ("Tasks auto-extracted", stats["tasks_extracted"], f"{ts['breakdown_minutes'].get('task_extraction', 0)} min saved"),
        ("Follow-up reminders", stats["followups_generated"], f"{ts['breakdown_minutes'].get('followup_tracking', 0)} min saved"),
        ("Outreach alerts", stats["outreach_alerts"], f"{ts['breakdown_minutes'].get('outreach_alerts', 0)} min saved"),
        ("Decisions logged", stats["decisions_logged"], ""),
        ("Commitments tracked", stats["commitments_tracked"], ""),
        ("Knowledge base entries", stats["knowledge_entries"], ""),
        ("Slack channels summarized", stats["slack_summaries"], ""),
        ("Calendar events synced", stats["calendar_events"], ""),
    ]

    for label, value, savings in details:
        savings_html = f'<span style="color:#22c55e;font-size:12px">{savings}</span>' if savings else ""
        detail_rows += f'<tr><td>{label}</td><td style="text-align:right;font-weight:600">{value}</td><td style="text-align:right">{savings_html}</td></tr>'

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>ARIA Monthly Value Report - {stats['period_display']}</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 800px; margin: 0 auto; padding: 24px; background: #f9fafb; }}
  h1 {{ font-size: 24px; color: #111827; margin-bottom: 4px; }}
  .subtitle {{ color: #6b7280; font-size: 14px; margin-bottom: 24px; }}
  .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 12px; margin-bottom: 24px; }}
  .metric {{ background: white; border-radius: 10px; padding: 16px; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }}
  .metric.big .value {{ font-size: 36px; font-weight: 800; color: #111827; }}
  .metric .label {{ font-size: 12px; color: #6b7280; margin-top: 4px; }}
  .card {{ background: white; border-radius: 10px; padding: 20px; margin-bottom: 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }}
  .card h2 {{ font-size: 15px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 14px; }}
  table {{ width: 100%; border-collapse: collapse; }}
  td {{ padding: 8px 4px; font-size: 14px; border-bottom: 1px solid #f3f4f6; }}
  tr:last-child td {{ border-bottom: none; }}
  .highlight {{ background: #f0fdf4; border: 2px solid #22c55e; border-radius: 10px; padding: 20px; text-align: center; margin-bottom: 24px; }}
  .highlight .number {{ font-size: 48px; font-weight: 800; color: #22c55e; }}
  .highlight .text {{ font-size: 16px; color: #374151; margin-top: 4px; }}
  .footer {{ text-align: center; font-size: 12px; color: #9ca3af; margin-top: 24px; }}
</style>
</head>
<body>
<h1>Your ARIA Value Report</h1>
<p class="subtitle">{stats['period_display']} | What your AI operating system did for you</p>

<div class="highlight">
  <div class="number">{ts['total_hours']} hours</div>
  <div class="text">estimated time saved this month ({ts['equivalent_workdays']} workdays)</div>
</div>

{cards}

<div class="card">
  <h2>Detailed Activity</h2>
  <table>{detail_rows}</table>
</div>

<div class="card">
  <h2>How Time Savings Are Calculated</h2>
  <p style="font-size:13px;color:#6b7280;line-height:1.7">
    These are conservative estimates based on average time to perform each task manually:
    filing an email (15 sec), reading junk (30 sec), writing a response (5 min),
    reviewing all inboxes for a briefing (20 min), gathering meeting context (10 min),
    tracking a commitment manually (15 min), identifying a task (2 min).
    Actual savings may be higher since ARIA catches things humans miss.
  </p>
</div>

<div class="footer">
  <p>Generated by ARIA | Your data stays on your computer</p>
  <p>Wright Advisors | <a href="mailto:sean@wrightadvisorsatx.com" style="color:#3b82f6;text-decoration:none">sean@wrightadvisorsatx.com</a></p>
</div>
</body>
</html>"""
    return html


def main():
    log("Starting monthly value report generation")

    # Default to previous month
    now = datetime.now()
    if now.day <= 5:
        # If early in the month, report on last month
        last_month = now.replace(day=1) - timedelta(days=1)
        year, month = last_month.year, last_month.month
    else:
        # Otherwise report on current month so far
        year, month = now.year, now.month

    stats = gather_monthly_stats(year, month)
    time_saved = calculate_time_saved(stats)

    month_str = f"{year}-{month:02d}"
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)

    # Save JSON
    output = {"stats": stats, "time_saved": time_saved, "generated": now.isoformat()}
    with open(BRIEFINGS_DIR / f"{month_str}-value-report.json", "w") as f:
        json.dump(output, f, indent=2, default=str)

    # Save HTML
    html = generate_html(stats, time_saved)
    with open(BRIEFINGS_DIR / f"{month_str}-value-report.html", "w") as f:
        f.write(html)

    log(f"Period: {stats['period_display']}")
    log(f"Emails processed: {stats['emails_processed']}")
    log(f"Briefings delivered: {stats['total_briefings']}")
    log(f"Time saved: {time_saved['total_hours']} hours ({time_saved['equivalent_workdays']} workdays)")
    log(f"Saved to briefings/{month_str}-value-report.html")
    log("Monthly value report complete")


if __name__ == "__main__":
    main()
