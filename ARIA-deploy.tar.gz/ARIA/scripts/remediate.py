#!/usr/bin/env python3
"""
ARIA Automated Remediation
Self-healing layer that sits between health checks and alerting.

When a service is down, this script tries to fix it before alerting Sean.
Only escalates to Telegram if remediation fails after retries.

Remediation actions:
  - Docker containers down → restart Docker Compose stack
  - n8n unreachable → restart n8n container
  - Inference engine down → restart oMLX/Ollama service
  - Telegram bot crashed → restart via launchd
  - Briefing missing → trigger briefing generation
  - Stale data (no inbox update in 24h) → re-run sync scripts

Runs every 5 minutes via launchd (replaces raw health-check for production).
Calls health-check internally, then attempts fixes before alerting.
"""

import json
import os
import subprocess
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

PROJECT_DIR = Path(__file__).parent.parent
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
LOG_FILE = PROJECT_DIR / "logs" / "remediation.log"
STATE_FILE = PROJECT_DIR / "logs" / "remediation-state.json"
ENV_FILE = PROJECT_DIR / ".env"

# Import health check functions
import importlib.util
hc_spec = importlib.util.spec_from_file_location("health_check", PROJECT_DIR / "scripts" / "health-check.py")
hc = importlib.util.module_from_spec(hc_spec)
hc_spec.loader.exec_module(hc)

MAX_RETRIES = 2
RETRY_WAIT_SECONDS = 15
DOCKER_COMPOSE_DIR = Path.home() / "self-hosted-ai-starter-kit"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_state():
    if STATE_FILE.exists():
        try:
            with open(STATE_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"remediation_history": [], "consecutive_failures": {}}


def save_state(state):
    # Keep only last 50 history entries
    state["remediation_history"] = state.get("remediation_history", [])[-50:]
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def run_cmd(cmd, timeout=30):
    """Run a shell command, return (success, output)."""
    try:
        result = subprocess.run(
            cmd, shell=isinstance(cmd, str), capture_output=True,
            text=True, timeout=timeout
        )
        return result.returncode == 0, result.stdout + result.stderr
    except subprocess.TimeoutExpired:
        return False, "Command timed out"
    except Exception as e:
        return False, str(e)


# --- Remediation Actions ---

def fix_docker():
    """Restart Docker Compose stack."""
    log("  Remediation: Restarting Docker Compose stack...")
    if not DOCKER_COMPOSE_DIR.exists():
        return False, "Docker Compose directory not found"

    ok, out = run_cmd(
        f"cd '{DOCKER_COMPOSE_DIR}' && docker compose up postgres n8n -d",
        timeout=60
    )
    if ok:
        time.sleep(10)  # Give containers time to start
        return True, "Docker stack restarted"
    return False, f"Docker restart failed: {out[:200]}"


def fix_n8n():
    """Restart just the n8n container."""
    log("  Remediation: Restarting n8n container...")
    ok, out = run_cmd("docker restart n8n", timeout=30)
    if ok:
        time.sleep(8)
        return True, "n8n container restarted"
    # If container restart fails, try full stack
    return fix_docker()


def fix_inference():
    """Restart oMLX/Ollama inference service."""
    log("  Remediation: Restarting inference engine...")

    # Try Ollama restart (most common)
    ok, _ = run_cmd("pgrep -x ollama", timeout=5)
    if ok:
        run_cmd("pkill -x ollama", timeout=5)
        time.sleep(2)
        ok, out = run_cmd("ollama serve &", timeout=5)
        time.sleep(5)
        return True, "Ollama restarted"

    # Try starting Ollama fresh
    ok, out = run_cmd("ollama serve &", timeout=5)
    if ok:
        time.sleep(5)
        return True, "Ollama started"

    # Try oMLX (if that's what's configured)
    ok, out = run_cmd("pgrep -f omlx", timeout=5)
    if ok:
        run_cmd("pkill -f omlx", timeout=5)
        time.sleep(2)

    return False, "Could not restart inference engine"


def fix_telegram_bot():
    """Restart Telegram bot via launchd."""
    log("  Remediation: Restarting Telegram bot...")

    # Try launchd restart
    ok, out = run_cmd(
        "launchctl kickstart -k gui/$(id -u)/com.aria.telegram-bot",
        timeout=10
    )
    if ok:
        time.sleep(3)
        return True, "Telegram bot restarted via launchd"

    # Direct restart as fallback
    ok, out = run_cmd(
        f"cd '{PROJECT_DIR}' && .venv/bin/python3 scripts/aria-telegram-bot.py &",
        timeout=5
    )
    if ok:
        return True, "Telegram bot started directly"

    return False, "Could not restart Telegram bot"


def fix_briefing():
    """Generate missing briefing."""
    log("  Remediation: Generating missing briefing...")
    ok, out = run_cmd(
        f"cd '{PROJECT_DIR}' && .venv/bin/python3 scripts/generate-briefing.py",
        timeout=300  # Briefing generation can take a while
    )
    if ok:
        return True, "Briefing generated"
    return False, f"Briefing generation failed: {out[:200]}"


def fix_stale_data():
    """Re-run sync scripts if inbox data is stale."""
    log("  Remediation: Re-running data sync scripts...")
    results = []

    for script in ["notification-sync.py", "granola-sync.py"]:
        script_path = PROJECT_DIR / "scripts" / script
        if script_path.exists():
            ok, out = run_cmd(
                f"cd '{PROJECT_DIR}' && .venv/bin/python3 scripts/{script}",
                timeout=120
            )
            results.append((script, ok))
            if ok:
                log(f"    {script}: success")
            else:
                log(f"    {script}: failed")

    successes = sum(1 for _, ok in results if ok)
    return successes > 0, f"{successes}/{len(results)} sync scripts succeeded"


# Map check names to remediation functions
REMEDIATION_MAP = {
    "docker": fix_docker,
    "n8n": fix_n8n,
    "inference": fix_inference,
    "telegram_bot": fix_telegram_bot,
    "briefing": fix_briefing,
}


def check_stale_data():
    """Additional check: is inbox data fresh?"""
    inbox_dir = PROJECT_DIR / "inbox"
    if not inbox_dir.exists():
        return {"ok": False, "detail": "Inbox directory missing"}

    latest = None
    for f in inbox_dir.glob("*.json"):
        mtime = datetime.fromtimestamp(f.stat().st_mtime)
        if latest is None or mtime > latest:
            latest = mtime

    if latest is None:
        return {"ok": False, "detail": "No inbox files found"}

    hours_old = (datetime.now() - latest).total_seconds() / 3600
    if hours_old > 24:
        return {"ok": False, "detail": f"Newest inbox file is {hours_old:.0f}h old"}

    return {"ok": True, "detail": f"Inbox data is {hours_old:.1f}h old"}


def main():
    log("Starting remediation cycle")
    config = hc.load_config()
    state = load_state()

    # Run all health checks
    checks = {
        "inference": hc.check_inference,
        "n8n": hc.check_n8n,
        "docker": hc.check_docker,
        "briefing": hc.check_briefing,
        "telegram_bot": hc.check_telegram_bot,
        "stale_data": check_stale_data,
    }

    failures = []
    unresolved = []

    for name, check_fn in checks.items():
        result = check_fn()
        if result["ok"]:
            log(f"  OK: {name} — {result['detail']}")
            # Clear consecutive failure counter on recovery
            if name in state.get("consecutive_failures", {}):
                del state["consecutive_failures"][name]
            continue

        log(f"  FAIL: {name} — {result['detail']}")
        failures.append(name)

        # Get remediation function
        fix_fn = REMEDIATION_MAP.get(name)
        if name == "stale_data":
            fix_fn = fix_stale_data

        if not fix_fn:
            log(f"  No remediation available for {name}")
            unresolved.append({"name": name, "detail": result["detail"]})
            continue

        # Attempt remediation with retries
        fixed = False
        for attempt in range(1, MAX_RETRIES + 1):
            log(f"  Attempt {attempt}/{MAX_RETRIES} to fix {name}...")
            success, detail = fix_fn()
            if success:
                # Verify the fix worked
                time.sleep(3)
                verify = check_fn()
                if verify["ok"]:
                    log(f"  FIXED: {name} — {detail}")
                    fixed = True
                    state["remediation_history"].append({
                        "timestamp": datetime.now().isoformat(),
                        "check": name,
                        "action": detail,
                        "result": "fixed",
                        "attempts": attempt,
                    })
                    break
                else:
                    log(f"  Fix applied but verification failed: {verify['detail']}")
            else:
                log(f"  Fix attempt failed: {detail}")

            if attempt < MAX_RETRIES:
                log(f"  Waiting {RETRY_WAIT_SECONDS}s before retry...")
                time.sleep(RETRY_WAIT_SECONDS)

        if not fixed:
            log(f"  UNRESOLVED: {name} — remediation failed after {MAX_RETRIES} attempts")
            unresolved.append({"name": name, "detail": result["detail"]})

            # Track consecutive failures
            consec = state.get("consecutive_failures", {})
            consec[name] = consec.get(name, 0) + 1
            state["consecutive_failures"] = consec

            state["remediation_history"].append({
                "timestamp": datetime.now().isoformat(),
                "check": name,
                "action": "remediation_failed",
                "result": "unresolved",
                "attempts": MAX_RETRIES,
            })

    # Only alert Sean for issues that couldn't be auto-fixed
    if unresolved:
        hc_state = hc.load_state()
        alert_items = []
        for item in unresolved:
            if hc.should_alert(hc_state, item["name"]):
                alert_items.append(item)
                hc.record_alert(hc_state, item["name"])

        if alert_items:
            consec = state.get("consecutive_failures", {})
            lines = ["*ARIA Health Alert* (auto-fix failed)\n"]
            for item in alert_items:
                count = consec.get(item["name"], 1)
                lines.append(f"  *{item['name']}*: {item['detail']}")
                if count > 1:
                    lines.append(f"    ({count} consecutive failures)")
            lines.append(f"\n_Remediation attempted {MAX_RETRIES}x before escalating._")
            lines.append(f"_Checked at {datetime.now().strftime('%H:%M')}_")
            message = "\n".join(lines)
            sent = hc.send_telegram_alert(message, config)
            if sent:
                log(f"Escalated to Sean: {', '.join(i['name'] for i in alert_items)}")
            else:
                log(f"ALERT FAILED TO SEND for: {', '.join(i['name'] for i in alert_items)}")

        hc.save_state(hc_state)

    # Summary
    fixed_count = len(failures) - len(unresolved)
    save_state(state)

    total = len(checks)
    healthy = total - len(failures)
    log(f"Remediation complete: {healthy}/{total} healthy, {fixed_count} auto-fixed, {len(unresolved)} unresolved")

    return 0 if not unresolved else 1


if __name__ == "__main__":
    sys.exit(main())
