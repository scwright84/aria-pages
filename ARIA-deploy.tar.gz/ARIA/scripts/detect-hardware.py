#!/usr/bin/env python3
"""
ARIA Hardware Detection
Detects Mac hardware specs and recommends the optimal AI configuration.
Called during installation to auto-configure the right models and cloud/local split.

Returns JSON with specs and recommendations.
"""

import json
import subprocess
import sys
import platform


def get_chip_info():
    """Get Apple Silicon chip details."""
    try:
        result = subprocess.run(["sysctl", "-n", "machdep.cpu.brand_string"],
                                capture_output=True, text=True, timeout=5)
        brand = result.stdout.strip()
    except Exception:
        brand = platform.processor()

    # Detect specific chip
    chip = "unknown"
    chip_tier = "base"
    if "M4 Ultra" in brand:
        chip, chip_tier = "M4 Ultra", "ultra"
    elif "M4 Max" in brand:
        chip, chip_tier = "M4 Max", "max"
    elif "M4 Pro" in brand:
        chip, chip_tier = "M4 Pro", "pro"
    elif "M4" in brand:
        chip, chip_tier = "M4", "base"
    elif "M3 Ultra" in brand:
        chip, chip_tier = "M3 Ultra", "ultra"
    elif "M3 Max" in brand:
        chip, chip_tier = "M3 Max", "max"
    elif "M3 Pro" in brand:
        chip, chip_tier = "M3 Pro", "pro"
    elif "M3" in brand:
        chip, chip_tier = "M3", "base"
    elif "M2 Ultra" in brand:
        chip, chip_tier = "M2 Ultra", "ultra"
    elif "M2 Max" in brand:
        chip, chip_tier = "M2 Max", "max"
    elif "M2 Pro" in brand:
        chip, chip_tier = "M2 Pro", "pro"
    elif "M2" in brand:
        chip, chip_tier = "M2", "base"
    elif "M1 Ultra" in brand:
        chip, chip_tier = "M1 Ultra", "ultra"
    elif "M1 Max" in brand:
        chip, chip_tier = "M1 Max", "max"
    elif "M1 Pro" in brand:
        chip, chip_tier = "M1 Pro", "pro"
    elif "M1" in brand:
        chip, chip_tier = "M1", "base"
    elif "Intel" in brand:
        chip, chip_tier = "Intel", "intel"

    return chip, chip_tier, brand


def get_ram_gb():
    """Get total RAM in GB."""
    try:
        result = subprocess.run(["sysctl", "-n", "hw.memsize"],
                                capture_output=True, text=True, timeout=5)
        return int(result.stdout.strip()) // (1024 ** 3)
    except Exception:
        return 0


def get_disk_free_gb():
    """Get free disk space in GB."""
    try:
        result = subprocess.run(["df", "-g", "/"],
                                capture_output=True, text=True, timeout=5)
        lines = result.stdout.strip().split("\n")
        if len(lines) >= 2:
            return int(lines[1].split()[3])
    except Exception:
        pass
    return 0


def get_mac_model():
    """Get the Mac model name."""
    try:
        result = subprocess.run(["sysctl", "-n", "hw.model"],
                                capture_output=True, text=True, timeout=5)
        model_id = result.stdout.strip()

        # Try to get the marketing name
        result2 = subprocess.run(
            ["system_profiler", "SPHardwareDataType", "-json"],
            capture_output=True, text=True, timeout=10)
        data = json.loads(result2.stdout)
        items = data.get("SPHardwareDataType", [{}])
        if items:
            return items[0].get("machine_name", model_id)
        return model_id
    except Exception:
        return "Unknown Mac"


def recommend_config(ram_gb, chip_tier):
    """Recommend AI configuration based on hardware."""

    if chip_tier == "intel":
        return {
            "tier": "cloud-only",
            "tier_name": "Cloud Only",
            "description": "Intel Macs cannot run local AI models efficiently. ARIA will use cloud AI (Claude) for all processing.",
            "local_percentage": 0,
            "cloud_percentage": 100,
            "default_model": None,
            "fast_model": None,
            "cloud_model": "claude-sonnet-4-5-20241022",
            "estimated_monthly_cost": "$30-80",
            "requires_api_key": True,
            "install_ollama": False,
        }

    if ram_gb >= 128:
        return {
            "tier": "studio",
            "tier_name": "Studio (Full Local)",
            "description": "Your Mac can run frontier-class models locally. Virtually no cloud AI needed.",
            "local_percentage": 98,
            "cloud_percentage": 2,
            "default_model": "mlx-community/Qwen3-30B-A3B-4bit",
            "fast_model": "mlx-community/Qwen3-8B-4bit",
            "large_model": "mlx-community/Qwen3-235B-A22B-4bit",
            "cloud_model": "claude-sonnet-4-5-20241022",
            "estimated_monthly_cost": "$5-15 (cloud for edge cases only)",
            "requires_api_key": False,
            "install_ollama": True,
        }

    if ram_gb >= 64:
        return {
            "tier": "enterprise",
            "tier_name": "Enterprise",
            "description": "Your Mac can run 70B models. Excellent local AI with minimal cloud fallback.",
            "local_percentage": 95,
            "cloud_percentage": 5,
            "default_model": "mlx-community/Qwen3-30B-A3B-4bit",
            "fast_model": "mlx-community/Qwen3-8B-4bit",
            "cloud_model": "claude-sonnet-4-5-20241022",
            "estimated_monthly_cost": "$10-30",
            "requires_api_key": False,
            "install_ollama": True,
        }

    if ram_gb >= 48:
        return {
            "tier": "professional",
            "tier_name": "Professional (Recommended)",
            "description": "Your Mac can run 32B models at conversation speed. Great balance of quality and privacy.",
            "local_percentage": 90,
            "cloud_percentage": 10,
            "default_model": "mlx-community/Qwen3-8B-4bit",
            "fast_model": "mlx-community/Qwen3-4B-4bit",
            "cloud_model": "claude-sonnet-4-5-20241022",
            "estimated_monthly_cost": "$20-50",
            "requires_api_key": False,
            "install_ollama": True,
        }

    if ram_gb >= 24:
        return {
            "tier": "starter",
            "tier_name": "Starter",
            "description": "Your Mac can run 8B models well. Local AI handles triage and summarization. Cloud AI for complex tasks.",
            "local_percentage": 75,
            "cloud_percentage": 25,
            "default_model": "mlx-community/Qwen3-8B-4bit",
            "fast_model": "mlx-community/Qwen3-4B-4bit",
            "cloud_model": "claude-sonnet-4-5-20241022",
            "estimated_monthly_cost": "$40-80",
            "requires_api_key": True,
            "install_ollama": True,
        }

    if ram_gb >= 16:
        return {
            "tier": "lite",
            "tier_name": "Lite",
            "description": "Your Mac can run small local models. Cloud AI recommended for best quality.",
            "local_percentage": 50,
            "cloud_percentage": 50,
            "default_model": "mlx-community/Qwen3-4B-4bit",
            "fast_model": "mlx-community/Qwen3-4B-4bit",
            "cloud_model": "claude-sonnet-4-5-20241022",
            "estimated_monthly_cost": "$60-120",
            "requires_api_key": True,
            "install_ollama": True,
        }

    # Under 16GB
    return {
        "tier": "cloud-primary",
        "tier_name": "Cloud Primary",
        "description": "Limited RAM for local AI. ARIA will primarily use cloud AI with local models for basic triage only.",
        "local_percentage": 20,
        "cloud_percentage": 80,
        "default_model": "mlx-community/Qwen3-4B-4bit",
        "fast_model": None,
        "cloud_model": "claude-sonnet-4-5-20241022",
        "estimated_monthly_cost": "$80-150",
        "requires_api_key": True,
        "install_ollama": True,
    }


def detect():
    """Run full hardware detection and return recommendation."""
    chip, chip_tier, brand = get_chip_info()
    ram_gb = get_ram_gb()
    disk_free = get_disk_free_gb()
    mac_model = get_mac_model()
    config = recommend_config(ram_gb, chip_tier)

    result = {
        "hardware": {
            "mac_model": mac_model,
            "chip": chip,
            "chip_tier": chip_tier,
            "cpu_brand": brand,
            "ram_gb": ram_gb,
            "disk_free_gb": disk_free,
            "arch": platform.machine(),
            "macos_version": platform.mac_ver()[0],
        },
        "recommendation": config,
    }

    return result


def main():
    result = detect()
    hw = result["hardware"]
    rec = result["recommendation"]

    print(f"\n  Hardware Detected:")
    print(f"  {hw['mac_model']} ({hw['chip']}, {hw['ram_gb']}GB RAM)")
    print(f"  macOS {hw['macos_version']}, {hw['disk_free_gb']}GB free")
    print()
    print(f"  Recommended Configuration: {rec['tier_name']}")
    print(f"  {rec['description']}")
    print()
    print(f"  Local AI: {rec['local_percentage']}% of tasks")
    print(f"  Cloud AI: {rec['cloud_percentage']}% of tasks")
    if rec.get('default_model'):
        print(f"  Local model: {rec['default_model']}")
    print(f"  Estimated monthly cost: {rec['estimated_monthly_cost']}")
    if rec['requires_api_key']:
        print(f"  Note: Cloud API key recommended for best results")
    print()

    # Also output JSON for programmatic use
    json.dump(result, sys.stdout, indent=2)
    print()


if __name__ == "__main__":
    main()
