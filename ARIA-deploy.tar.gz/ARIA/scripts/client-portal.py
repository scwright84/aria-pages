#!/usr/bin/env python3
"""
ARIA Client Portal
Client-facing web app for managing their ARIA subscription.

Features:
  - View system status (embeds status-page data)
  - View recent briefings
  - Connected accounts overview
  - Request support (creates a support ticket)
  - Subscription details and billing history (when Stripe is connected)
  - View contact profiles and engagement scorecard

Runs on port 8646. Designed for the client to bookmark.
Protected by a simple token auth (client gets a unique URL with token).
"""

import json
import os
import sys
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path

import requests
from flask import Flask, Response, request, abort

PROJECT_DIR = Path(__file__).parent.parent
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
INBOX_DIR = PROJECT_DIR / "inbox"
SUPPORT_DIR = PROJECT_DIR / "logs" / "support-tickets"

app = Flask(__name__)

# Simple token auth - in production this would be per-client
PORTAL_TOKEN = os.environ.get("ARIA_PORTAL_TOKEN", "aria-client-2026")


def require_token(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.args.get("token") or request.headers.get("X-Portal-Token")
        if token != PORTAL_TOKEN:
            return Response(
                "<h1>Access Denied</h1><p>Invalid or missing access token. Check your bookmark URL.</p>",
                status=403, mimetype="text/html"
            )
        return f(*args, **kwargs)
    return decorated


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def get_status():
    """Get system status from the status page API."""
    try:
        resp = requests.get("http://localhost:8644/api/status", timeout=3)
        if resp.status_code == 200:
            return resp.json()
    except Exception:
        pass
    # Fallback: compute basic status locally
    return {"overall": "unknown", "overall_text": "Status service not running", "stats": {}}


def get_recent_briefings(count=7):
    """Get the most recent briefings."""
    briefings = []
    for f in sorted(BRIEFINGS_DIR.glob("*.html"), reverse=True):
        name = f.stem
        # Skip scorecards, contacts, etc - just main briefings
        if name.count("-") == 2 and not any(s in name for s in ["scorecard", "contacts", "debrief", "weekly", "conceivable"]):
            mtime = datetime.fromtimestamp(f.stat().st_mtime)
            briefings.append({
                "date": name,
                "filename": f.name,
                "generated": mtime.strftime("%b %d, %I:%M %p"),
                "size": f.stat().st_size,
            })
        if len(briefings) >= count:
            break
    return briefings


def get_data_summary():
    """Quick summary of ingested data."""
    sources = {}
    for prefix in ["emails", "slack", "calendar", "calendly", "awaiting", "notifications"]:
        files = list(INBOX_DIR.glob(f"{prefix}-*.json"))
        if files:
            latest = max(files, key=lambda f: f.stat().st_mtime)
            mtime = datetime.fromtimestamp(latest.stat().st_mtime)
            try:
                with open(latest) as f:
                    data = json.load(f)
                count = len(data) if isinstance(data, list) else 1
            except Exception:
                count = 0
            sources[prefix] = {
                "file_count": len(files),
                "latest_date": mtime.strftime("%b %d"),
                "latest_items": count,
            }
    return sources


def render_portal(token):
    """Render the client portal page."""
    config = load_config()
    status = get_status()
    briefings = get_recent_briefings()
    data = get_data_summary()
    now = datetime.now()

    client_name = config.get("client", {}).get("name", "ARIA")
    overall = status.get("overall", "unknown")

    colors = {"green": "#22c55e", "yellow": "#eab308", "red": "#ef4444", "unknown": "#9ca3af"}
    status_color = colors.get(overall, colors["unknown"])

    # Briefing list
    briefing_rows = ""
    for b in briefings:
        briefing_rows += f"""
        <tr>
            <td>{b["date"]}</td>
            <td>{b["generated"]}</td>
            <td><a href="/briefing/{b['filename']}?token={token}">View</a></td>
        </tr>"""

    # Data sources
    data_rows = ""
    source_labels = {
        "emails": "Email", "slack": "Slack", "calendar": "Calendar",
        "calendly": "Calendly", "awaiting": "Commitments", "notifications": "Notifications"
    }
    for prefix, info in data.items():
        label = source_labels.get(prefix, prefix)
        data_rows += f"""
        <tr>
            <td>{label}</td>
            <td>{info["latest_items"]} items</td>
            <td>{info["latest_date"]}</td>
        </tr>"""

    # Schedules
    schedules = config.get("schedules", {})
    schedule_html = ""
    schedule_labels = {
        "morning_briefing": "Morning Briefing",
        "evening_debrief": "Evening Debrief",
        "weekly_rollup": "Weekly Rollup",
    }
    for key, label in schedule_labels.items():
        time_str = schedules.get(key, "-")
        schedule_html += f"<tr><td>{label}</td><td>{time_str}</td></tr>"

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ARIA Portal - {client_name}</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #f9fafb; }}
  .container {{ max-width: 800px; margin: 0 auto; padding: 24px 16px; }}
  h1 {{ font-size: 22px; color: #111827; margin-bottom: 4px; }}
  .subtitle {{ color: #6b7280; font-size: 13px; margin-bottom: 24px; }}
  .status-banner {{ background: white; border-left: 4px solid {status_color}; border-radius: 8px; padding: 16px 20px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); display: flex; align-items: center; gap: 16px; }}
  .status-dot {{ width: 16px; height: 16px; border-radius: 50%; background: {status_color}; flex-shrink: 0; }}
  .status-text {{ font-size: 16px; font-weight: 600; color: #111827; }}
  .status-sub {{ font-size: 13px; color: #6b7280; }}
  .card {{ background: white; border-radius: 8px; padding: 16px; margin-bottom: 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }}
  .card h2 {{ font-size: 14px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 12px; }}
  table {{ width: 100%; border-collapse: collapse; }}
  td {{ padding: 6px 8px; font-size: 14px; border-bottom: 1px solid #f3f4f6; }}
  tr:last-child td {{ border-bottom: none; }}
  a {{ color: #2563eb; text-decoration: none; }}
  a:hover {{ text-decoration: underline; }}
  .support-btn {{ display: inline-block; background: #2563eb; color: white; padding: 10px 20px; border-radius: 6px; font-size: 14px; font-weight: 500; text-decoration: none; margin-top: 8px; }}
  .support-btn:hover {{ background: #1d4ed8; text-decoration: none; }}
  .footer {{ text-align: center; font-size: 11px; color: #9ca3af; margin-top: 24px; }}
</style>
</head>
<body>
<div class="container">
  <h1>{client_name}</h1>
  <p class="subtitle">Your ARIA system | {now.strftime('%b %d, %Y')}</p>

  <div class="status-banner">
    <div class="status-dot"></div>
    <div>
      <div class="status-text">{status.get("overall_text", "Checking...")}</div>
      <div class="status-sub">Last checked: {status.get("checked_at", now.strftime('%I:%M %p'))}</div>
    </div>
  </div>

  <div class="card">
    <h2>Recent Briefings</h2>
    <table>{briefing_rows if briefing_rows else "<tr><td>No briefings yet</td></tr>"}</table>
  </div>

  <div class="card">
    <h2>Connected Data Sources</h2>
    <table>{data_rows if data_rows else "<tr><td>No data sources connected</td></tr>"}</table>
  </div>

  <div class="card">
    <h2>Schedule</h2>
    <table>{schedule_html}</table>
  </div>

  <div class="card">
    <h2>Need Help?</h2>
    <p style="font-size:14px;color:#374151;margin-bottom:8px">If something doesn't look right, or you have a question about your ARIA system:</p>
    <a href="/support?token={token}" class="support-btn">Request Support</a>
  </div>

  <div class="footer">
    Powered by ARIA | Wright Advisors | Your data stays on this computer
  </div>
</div>
</body>
</html>"""
    return html


@app.route("/")
@require_token
def index():
    token = request.args.get("token", "")
    return Response(render_portal(token), mimetype="text/html")


@app.route("/briefing/<filename>")
@require_token
def view_briefing(filename):
    """Serve a briefing HTML file."""
    # Sanitize filename
    if ".." in filename or "/" in filename:
        abort(400)
    path = BRIEFINGS_DIR / filename
    if not path.exists():
        abort(404)
    return Response(path.read_text(), mimetype="text/html")


@app.route("/support")
@require_token
def support_form():
    token = request.args.get("token", "")
    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ARIA Support Request</title>
<style>
  body {{ font-family: -apple-system, sans-serif; background: #f9fafb; }}
  .container {{ max-width: 600px; margin: 0 auto; padding: 24px 16px; }}
  h1 {{ font-size: 20px; margin-bottom: 16px; }}
  label {{ display: block; font-size: 14px; font-weight: 500; color: #374151; margin-bottom: 4px; margin-top: 12px; }}
  input, textarea, select {{ width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px; font-family: inherit; }}
  textarea {{ height: 120px; resize: vertical; }}
  button {{ background: #2563eb; color: white; border: none; padding: 10px 24px; border-radius: 6px; font-size: 14px; cursor: pointer; margin-top: 16px; }}
  button:hover {{ background: #1d4ed8; }}
  a {{ color: #2563eb; text-decoration: none; }}
</style>
</head>
<body>
<div class="container">
  <h1>Request Support</h1>
  <form method="POST" action="/support/submit?token={token}">
    <label>What's the issue?</label>
    <select name="category">
      <option>Briefing not received</option>
      <option>Data looks wrong or outdated</option>
      <option>Telegram bot not responding</option>
      <option>System seems slow</option>
      <option>Question about a feature</option>
      <option>Other</option>
    </select>
    <label>Details</label>
    <textarea name="details" placeholder="Describe what you're seeing..."></textarea>
    <label>How urgent is this?</label>
    <select name="urgency">
      <option>Normal (within 24 hours)</option>
      <option>High (within a few hours)</option>
      <option>Critical (system is down)</option>
    </select>
    <button type="submit">Submit Request</button>
  </form>
  <p style="margin-top:16px;font-size:13px;color:#6b7280"><a href="/?token={token}">Back to portal</a></p>
</div>
</body>
</html>"""
    return Response(html, mimetype="text/html")


@app.route("/support/submit", methods=["POST"])
@require_token
def support_submit():
    token = request.args.get("token", "")
    category = request.form.get("category", "")
    details = request.form.get("details", "")
    urgency = request.form.get("urgency", "Normal")

    # Save ticket
    SUPPORT_DIR.mkdir(parents=True, exist_ok=True)
    ticket = {
        "timestamp": datetime.now().isoformat(),
        "category": category,
        "details": details,
        "urgency": urgency,
        "status": "open",
    }
    ticket_file = SUPPORT_DIR / f"{datetime.now().strftime('%Y-%m-%d_%H%M%S')}.json"
    with open(ticket_file, "w") as f:
        json.dump(ticket, f, indent=2)

    # Try to alert Sean via Telegram
    try:
        sys.path.insert(0, str(Path(__file__).parent))
        import aria_ai
        tg_token = aria_ai.get_telegram_token()
        users = aria_ai.get_telegram_authorized_users()
        if tg_token and users:
            msg = f"*Support Request*\n\nCategory: {category}\nUrgency: {urgency}\nDetails: {details[:200]}"
            for uid in users:
                requests.post(
                    f"https://api.telegram.org/bot{tg_token}/sendMessage",
                    json={"chat_id": uid, "text": msg, "parse_mode": "Markdown"},
                    timeout=5
                )
    except Exception:
        pass

    html = f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Request Submitted</title>
<style>body {{ font-family: -apple-system, sans-serif; background: #f9fafb; }} .container {{ max-width: 600px; margin: 0 auto; padding: 40px 16px; text-align: center; }}</style>
</head>
<body><div class="container">
<h1 style="color:#22c55e">Request Submitted</h1>
<p style="margin:16px 0;color:#374151">We've received your support request and will get back to you shortly.</p>
<p><a href="/?token={token}" style="color:#2563eb">Back to portal</a></p>
</div></body></html>"""
    return Response(html, mimetype="text/html")


@app.route("/api/status")
@require_token
def api_status():
    return json.dumps(get_status(), default=str), 200, {"Content-Type": "application/json"}


@app.route("/healthz")
def healthz():
    return "ok", 200


def main():
    print(f"ARIA Client Portal running at http://localhost:8646?token={PORTAL_TOKEN}")
    print("Client-facing. Share the token URL with the client.")
    app.run(host="127.0.0.1", port=8646, debug=False)


if __name__ == "__main__":
    main()
