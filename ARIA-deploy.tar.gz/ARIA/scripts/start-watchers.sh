#!/bin/bash
# Start all ARIA watchers
# Usage: cd ~/Desktop/dev\ projects/ARIA && ./scripts/start-watchers.sh

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
VENV="$PROJECT_DIR/.venv/bin/python3"

echo "Starting ARIA watchers..."
echo "Project: $PROJECT_DIR"
echo ""

# Kill any existing watchers
pkill -f "notification-watcher.py" 2>/dev/null
pkill -f "granola-watcher.py" 2>/dev/null
sleep 1

# Start notification watcher
echo "Starting notification watcher..."
"$VENV" "$SCRIPT_DIR/notification-watcher.py" &
NOTIF_PID=$!
echo "  PID: $NOTIF_PID"

# Start Granola watcher
echo "Starting Granola watcher..."
"$VENV" "$SCRIPT_DIR/granola-watcher.py" &
GRANOLA_PID=$!
echo "  PID: $GRANOLA_PID"

echo ""
echo "Both watchers running. Logs:"
echo "  Notifications: $PROJECT_DIR/logs/watcher.log"
echo "  Granola:       $PROJECT_DIR/logs/granola-watcher.log"
echo ""
echo "Press Ctrl+C to stop both."

# Wait for either to exit
trap "echo 'Stopping watchers...'; kill $NOTIF_PID $GRANOLA_PID 2>/dev/null; exit 0" INT TERM
wait
