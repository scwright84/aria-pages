#!/usr/bin/env python3
"""
ARIA Data Export
Generate CSV or HTML reports from any ARIA data for board meetings,
investor updates, or client reviews.

Available reports:
  --report scorecard     Engagement scorecard (per project health)
  --report time          Time allocation breakdown
  --report contacts      Contact directory
  --report expenses      Expense summary
  --report tasks         Open task list
  --report decisions     Decision log
  --report goals         Goal progress
  --report relationships Relationship strength scores
  --report weekly        Combined weekly executive summary
  --report all           Generate all reports

Output formats:
  --format csv           CSV (importable to Excel/Sheets)
  --format html          HTML (printable, email-ready)
  --format json          Raw JSON

Output: exports/YYYY-MM-DD-<report>.<format>
"""

import csv
import json
import sys
from datetime import datetime
from io import StringIO
from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
CONFIG_DIR = PROJECT_DIR / "config"
EXPORT_DIR = PROJECT_DIR / "exports"
LOG_FILE = PROJECT_DIR / "logs" / "data-export.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_latest_briefing(suffix):
    """Load the most recent briefing file with given suffix."""
    for d in range(7):
        date = datetime.now()
        from datetime import timedelta
        date = date - timedelta(days=d)
        path = BRIEFINGS_DIR / f"{date.strftime('%Y-%m-%d')}-{suffix}.json"
        if path.exists():
            with open(path) as f:
                return json.load(f)
    return None


def load_config_file(name):
    path = CONFIG_DIR / name
    if path.exists():
        with open(path) as f:
            return json.load(f)
    return None


def to_csv(headers, rows):
    """Convert to CSV string."""
    output = StringIO()
    writer = csv.writer(output)
    writer.writerow(headers)
    writer.writerows(rows)
    return output.getvalue()


def export_scorecard(fmt):
    data = load_latest_briefing("scorecard")
    if not data:
        return None, "No scorecard data found"

    if fmt == "csv":
        headers = ["Project", "Tier", "Grade", "Score", "Emails", "Trend", "Actions", "Commitments", "Overdue", "Flags"]
        rows = []
        for name, m in data.items():
            rows.append([name, m.get("tier"), m.get("health_grade"), m.get("health_score"),
                        m.get("email_count"), m.get("trend"), m.get("actions_needed"),
                        m.get("commitments_total"), m.get("commitments_overdue"),
                        "; ".join(m.get("health_flags", []))])
        return to_csv(headers, rows), None
    elif fmt == "json":
        return json.dumps(data, indent=2, default=str), None
    return None, "Unsupported format"


def export_contacts(fmt):
    data = load_config_file("contacts.json")
    if not data:
        return None, "No contacts data found"

    if fmt == "csv":
        headers = ["Name", "Emails", "Projects", "Email Count", "Slack Mentions", "Meetings", "Relationship Score", "Last Contact"]
        rows = []
        for key, c in sorted(data.items(), key=lambda x: -(x[1].get("email_count", 0))):
            rows.append([
                c.get("name", key), "; ".join(c.get("emails", [])),
                "; ".join(c.get("projects", [])), c.get("email_count", 0),
                c.get("slack_mentions", 0), c.get("meetings", 0),
                c.get("relationship_score", ""), c.get("last_contact", ""),
            ])
        return to_csv(headers, rows), None
    elif fmt == "json":
        return json.dumps(data, indent=2, default=str), None
    return None, "Unsupported format"


def export_expenses(fmt):
    data = load_config_file("expenses.json")
    if not data:
        return None, "No expense data found"

    if fmt == "csv":
        headers = ["Date", "Vendor", "Category", "Type", "Amount", "Project", "Subject"]
        rows = []
        for e in data.get("expenses", []):
            rows.append([e.get("date"), e.get("vendor"), e.get("category"),
                        e.get("type"), e.get("amount", ""), e.get("project", ""),
                        e.get("subject", "")[:60]])
        return to_csv(headers, rows), None
    elif fmt == "json":
        return json.dumps(data, indent=2, default=str), None
    return None, "Unsupported format"


def export_tasks(fmt):
    data = load_config_file("tasks.json")
    if not data:
        return None, "No task data found"

    tasks = [t for t in data.get("tasks", []) if t.get("status") == "open"]

    if fmt == "csv":
        headers = ["Priority", "Source", "Title", "Project", "Date", "Status"]
        rows = []
        for t in tasks:
            rows.append([t.get("priority"), t.get("source"), t.get("title", "")[:80],
                        t.get("project", ""), t.get("date", ""), t.get("status")])
        return to_csv(headers, rows), None
    elif fmt == "json":
        return json.dumps(tasks, indent=2, default=str), None
    return None, "Unsupported format"


def export_decisions(fmt):
    data = load_config_file("decisions.json")
    if not data:
        return None, "No decision data found"

    if fmt == "csv":
        headers = ["Date", "Decision", "Source", "Project", "Status", "Context"]
        rows = []
        for d in data.get("decisions", []):
            rows.append([d.get("date"), d.get("decision", "")[:80], d.get("source"),
                        d.get("project", ""), d.get("status"), d.get("context", "")[:60]])
        return to_csv(headers, rows), None
    elif fmt == "json":
        return json.dumps(data, indent=2, default=str), None
    return None, "Unsupported format"


def export_goals(fmt):
    data = load_config_file("goals.json")
    if not data:
        return None, "No goals data found"

    goals = [g for g in data.get("goals", []) if g.get("status") == "active"]

    if fmt == "csv":
        headers = ["Goal", "Type", "Project", "Progress", "Target Date", "Signals"]
        rows = []
        for g in goals:
            rows.append([g.get("title"), g.get("type"), g.get("project", ""),
                        f"{g.get('progress', 0)}%", g.get("target_date", ""),
                        "; ".join(g.get("signals", []))])
        return to_csv(headers, rows), None
    elif fmt == "json":
        return json.dumps(goals, indent=2, default=str), None
    return None, "Unsupported format"


def export_time(fmt):
    data = load_latest_briefing("time")
    if not data:
        return None, "No time data found"

    if fmt == "csv":
        headers = ["Metric", "Value"]
        rows = []
        s = data.get("summary", {})
        rows.append(["Total Meetings", s.get("total_meetings")])
        rows.append(["Meeting Hours", s.get("total_meeting_hours")])
        rows.append(["Deep Work Hours", s.get("deep_work_hours")])
        rows.append(["Meeting Ratio", f"{s.get('meeting_ratio', 0)}%"])
        rows.append(["Avg Meeting Length", f"{s.get('avg_meeting_length_min', 0)} min"])
        rows.append(["", ""])
        rows.append(["Project", "Hours"])
        for proj, hours in data.get("by_project", {}).items():
            rows.append([proj, hours])
        return to_csv(headers, rows), None
    elif fmt == "json":
        return json.dumps(data, indent=2, default=str), None
    return None, "Unsupported format"


def export_relationships(fmt):
    data = load_config_file("contacts.json")
    if not data:
        return None, "No contacts data found"

    scored = [(k, c) for k, c in data.items() if c.get("relationship_score")]
    scored.sort(key=lambda x: -x[1].get("relationship_score", 0))

    if fmt == "csv":
        headers = ["Name", "Score", "Label", "Projects", "Emails", "Last Contact"]
        rows = []
        for key, c in scored:
            rows.append([c.get("name", key), c.get("relationship_score"),
                        c.get("relationship_label", ""), "; ".join(c.get("projects", [])),
                        c.get("email_count", 0), c.get("last_contact", "")])
        return to_csv(headers, rows), None
    elif fmt == "json":
        return json.dumps([{"name": c.get("name", k), **c} for k, c in scored], indent=2, default=str), None
    return None, "Unsupported format"


REPORT_MAP = {
    "scorecard": export_scorecard,
    "contacts": export_contacts,
    "expenses": export_expenses,
    "tasks": export_tasks,
    "decisions": export_decisions,
    "goals": export_goals,
    "time": export_time,
    "relationships": export_relationships,
}


def main():
    import argparse
    parser = argparse.ArgumentParser(description="ARIA Data Export")
    parser.add_argument("--report", required=True, choices=list(REPORT_MAP.keys()) + ["all"],
                       help="Report type to generate")
    parser.add_argument("--format", default="csv", choices=["csv", "html", "json"],
                       help="Output format")
    args = parser.parse_args()

    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    date_str = datetime.now().strftime("%Y-%m-%d")

    reports = [args.report] if args.report != "all" else list(REPORT_MAP.keys())

    for report_name in reports:
        export_fn = REPORT_MAP[report_name]
        content, error = export_fn(args.format)

        if error:
            log(f"SKIP {report_name}: {error}")
            continue

        ext = args.format
        output_path = EXPORT_DIR / f"{date_str}-{report_name}.{ext}"
        with open(output_path, "w") as f:
            f.write(content)

        log(f"Exported: {output_path.name} ({len(content)} bytes)")

    log("Export complete")


if __name__ == "__main__":
    main()
