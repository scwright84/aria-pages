#!/usr/bin/env python3
"""
ARIA Notification Watcher
Polls the macOS notification center database for new messages from
messaging apps and forwards them to n8n via webhook.

Requires: Full Disk Access for the terminal running this script.
"""

import sqlite3
import plistlib
import json
import time
import os
import sys
import requests
from datetime import datetime
from pathlib import Path

# --- Configuration ---

NOTIFICATION_DB = os.path.expanduser(
    "~/Library/Group Containers/group.com.apple.usernoted/db2/db"
)

# Apps we care about for message ingestion
WATCHED_APPS = {
    "com.apple.mobilesms": "iMessage",
    "com.apple.ichat": "Messages",
    "desktop.whatsapp": "WhatsApp",
    "net.whatsapp.whatsapp": "WhatsApp",
    "org.whispersystems.signal-desktop": "Signal",
    "com.tdesktop.telegram": "Telegram",
    "com.tinyspeck.slackmacgap": "Slack",
    "com.microsoft.teams2": "Teams",
    "com.hnc.discord": "Discord",
    "com.apple.mail": "Apple Mail",
    "com.microsoft.outlook": "Outlook",
    "com.apple.facetime": "FaceTime",
}

# n8n webhook URL (set this after creating the workflow)
N8N_WEBHOOK_URL = os.environ.get("ARIA_WEBHOOK_URL", "http://localhost:5678/webhook/aria-notifications")

# Poll interval in seconds
POLL_INTERVAL = int(os.environ.get("ARIA_POLL_INTERVAL", "3600"))

# State file to track last seen notification
STATE_FILE = Path(__file__).parent.parent / "logs" / "watcher-state.json"

LOG_FILE = Path(__file__).parent.parent / "logs" / "watcher.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_state():
    if STATE_FILE.exists():
        with open(STATE_FILE) as f:
            return json.load(f)
    return {"last_rec_id": 0}


def save_state(state):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f)


def decode_notification_data(raw_data):
    """Decode the binary plist notification data into a dict."""
    try:
        plist = plistlib.loads(raw_data)
        req = plist.get("req", {})
        return {
            "body": req.get("body", ""),
            "title": req.get("titl", ""),
            "subtitle": req.get("subt", ""),
            "thread_id": req.get("thre", ""),
            "category": req.get("cate", ""),
            "deep_link": req.get("durl", ""),
            "people": req.get("peop", []),
            "identifier": req.get("iden", ""),
        }
    except Exception as e:
        return {"error": str(e), "body": "", "title": ""}


def get_new_notifications(last_rec_id):
    """Query the notification DB for new messages from watched apps."""
    app_ids_str = ", ".join(f"'{app}'" for app in WATCHED_APPS.keys())

    conn = sqlite3.connect(f"file:{NOTIFICATION_DB}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute(f"""
        SELECT r.rec_id, a.identifier, r.data, r.delivered_date, r.presented
        FROM record r
        JOIN app a ON r.app_id = a.app_id
        WHERE a.identifier IN ({app_ids_str})
          AND r.rec_id > ?
        ORDER BY r.rec_id ASC
    """, (last_rec_id,))

    results = []
    for row in cursor.fetchall():
        notification = decode_notification_data(row["data"])
        notification["rec_id"] = row["rec_id"]
        notification["app_identifier"] = row["identifier"]
        notification["app_name"] = WATCHED_APPS.get(row["identifier"], row["identifier"])
        notification["delivered_date"] = row["delivered_date"]
        notification["presented"] = bool(row["presented"])

        # Convert Core Data timestamp to ISO format
        if row["delivered_date"]:
            # macOS Core Data timestamps are seconds since 2001-01-01
            unix_ts = row["delivered_date"] + 978307200
            notification["timestamp"] = datetime.fromtimestamp(unix_ts).isoformat()

        results.append(notification)

    conn.close()
    return results


def forward_to_n8n(notification):
    """Send a notification to n8n webhook."""
    try:
        resp = requests.post(
            N8N_WEBHOOK_URL,
            json=notification,
            timeout=5,
        )
        if resp.status_code == 200:
            log(f"  -> Forwarded to n8n (200 OK)")
        else:
            log(f"  -> n8n responded {resp.status_code}: {resp.text[:100]}")
    except requests.exceptions.ConnectionError:
        log(f"  -> n8n not reachable (is the webhook workflow active?)")
    except Exception as e:
        log(f"  -> Error forwarding: {e}")


def main():
    log("ARIA Notification Watcher starting...")
    log(f"Watching {len(WATCHED_APPS)} apps")
    log(f"Polling every {POLL_INTERVAL}s")
    log(f"Webhook: {N8N_WEBHOOK_URL}")
    log(f"DB: {NOTIFICATION_DB}")

    # Verify DB access
    try:
        conn = sqlite3.connect(f"file:{NOTIFICATION_DB}?mode=ro", uri=True)
        conn.close()
        log("DB access confirmed")
    except Exception as e:
        log(f"FATAL: Cannot access notification DB: {e}")
        log("Make sure your terminal has Full Disk Access in System Settings > Privacy & Security")
        sys.exit(1)

    state = load_state()
    log(f"Resuming from rec_id {state['last_rec_id']}")

    # If first run, set to current max to avoid replaying history
    if state["last_rec_id"] == 0:
        notifications = get_new_notifications(0)
        if notifications:
            state["last_rec_id"] = notifications[-1]["rec_id"]
            save_state(state)
            log(f"First run: skipping {len(notifications)} existing notifications, starting from rec_id {state['last_rec_id']}")
        else:
            log("First run: no existing notifications found")

    try:
        while True:
            notifications = get_new_notifications(state["last_rec_id"])

            for n in notifications:
                # Skip empty notifications
                if not n.get("body") and not n.get("title"):
                    state["last_rec_id"] = n["rec_id"]
                    continue

                log(f"[{n['app_name']}] {n.get('title', '?')}: {n.get('body', '')[:80]}")
                forward_to_n8n(n)
                state["last_rec_id"] = n["rec_id"]
                save_state(state)

            time.sleep(POLL_INTERVAL)

    except KeyboardInterrupt:
        log("Watcher stopped by user")
        save_state(state)


if __name__ == "__main__":
    main()
