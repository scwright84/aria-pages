#!/usr/bin/env python3
"""
ARIA Time Allocation Tracker
Analyzes calendar data to show where time actually goes.

Metrics:
  - Hours per project/client per week
  - Meeting vs deep work ratio
  - Meeting load by day of week
  - Trend over time (are meetings increasing?)
  - Top meeting partners (who do you spend most time with?)
  - Meeting efficiency (short vs long meetings)

Output: briefings/YYYY-MM-DD-time.json + HTML
Runs weekly (Sunday) or on demand.
"""

import json
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
LOG_FILE = PROJECT_DIR / "logs" / "time-tracker.log"

WORK_HOURS_PER_DAY = 8
WORK_DAYS_PER_WEEK = 5


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def load_calendar_data(days_back=7):
    """Load calendar + calendly events for the past N days."""
    events = []
    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        date_str = date.strftime("%Y-%m-%d")
        for prefix in ["calendar", "calendly"]:
            path = INBOX_DIR / f"{prefix}-{date_str}.json"
            if path.exists():
                try:
                    with open(path) as f:
                        data = json.load(f)
                    for item in (data if isinstance(data, list) else [data]):
                        event = parse_event(item, prefix)
                        if event:
                            events.append(event)
                except Exception:
                    pass
    return events


def parse_event(item, source):
    """Parse a calendar event into a standard format."""
    start_str = item.get("start") or item.get("start_time") or item.get("start_local", "")
    end_str = item.get("end") or item.get("end_time") or item.get("end_local", "")

    try:
        start = datetime.fromisoformat(start_str.replace("Z", "+00:00")).replace(tzinfo=None)
    except (ValueError, TypeError):
        return None

    try:
        end = datetime.fromisoformat(end_str.replace("Z", "+00:00")).replace(tzinfo=None)
    except (ValueError, TypeError):
        end = start + timedelta(hours=1)  # Default 1 hour

    duration_min = (end - start).total_seconds() / 60
    if duration_min <= 0 or duration_min > 480:  # Skip invalid or 8+ hour events
        return None

    summary = item.get("summary") or item.get("name") or "Untitled"
    attendees = item.get("attendees") or item.get("invitee_names") or []
    if isinstance(attendees, list) and attendees and isinstance(attendees[0], dict):
        attendees = [a.get("name") or a.get("email", "?") for a in attendees]

    return {
        "summary": summary,
        "start": start,
        "end": end,
        "duration_min": duration_min,
        "day_of_week": start.strftime("%A"),
        "date": start.strftime("%Y-%m-%d"),
        "attendees": attendees,
        "attendee_count": len(attendees),
        "source": source,
        "project": detect_project(summary, item),
    }


def detect_project(summary, item):
    """Try to detect which project a meeting belongs to."""
    config = load_config()
    known = config.get("known_projects", [])
    text = summary.lower()
    for project in known:
        if project.lower() in text:
            return project
    # Check account name
    account = item.get("account", "")
    if account:
        for project in known:
            if project.lower() in account.lower():
                return project
    return None


def analyze(events, config):
    """Generate time allocation analysis."""
    if not events:
        return {"error": "No calendar events found for analysis period"}

    total_meeting_min = sum(e["duration_min"] for e in events)
    total_meeting_hours = total_meeting_min / 60
    work_hours = WORK_HOURS_PER_DAY * WORK_DAYS_PER_WEEK
    deep_work_hours = max(0, work_hours - total_meeting_hours)

    # Per-project
    by_project = defaultdict(float)
    for e in events:
        proj = e["project"] or "Unclassified"
        by_project[proj] += e["duration_min"] / 60

    # Per day of week
    by_day = defaultdict(lambda: {"count": 0, "hours": 0})
    for e in events:
        by_day[e["day_of_week"]]["count"] += 1
        by_day[e["day_of_week"]]["hours"] += e["duration_min"] / 60

    # Top meeting partners
    partner_counter = Counter()
    for e in events:
        for att in e["attendees"]:
            if isinstance(att, str):
                partner_counter[att] += 1

    # Meeting length distribution
    short = sum(1 for e in events if e["duration_min"] <= 30)
    medium = sum(1 for e in events if 30 < e["duration_min"] <= 60)
    long = sum(1 for e in events if e["duration_min"] > 60)

    # Busiest day
    busiest = max(by_day.items(), key=lambda x: x[1]["hours"]) if by_day else (None, {"hours": 0})

    # Meeting-free days
    dates_with_meetings = set(e["date"] for e in events)
    week_dates = set()
    for d in range(7):
        date = datetime.now() - timedelta(days=d)
        if date.weekday() < 5:  # Weekdays only
            week_dates.add(date.strftime("%Y-%m-%d"))
    free_days = week_dates - dates_with_meetings

    analysis = {
        "period": "last 7 days",
        "generated": datetime.now().isoformat(),
        "summary": {
            "total_meetings": len(events),
            "total_meeting_hours": round(total_meeting_hours, 1),
            "deep_work_hours": round(deep_work_hours, 1),
            "meeting_ratio": round(total_meeting_hours / work_hours * 100) if work_hours > 0 else 0,
            "avg_meeting_length_min": round(total_meeting_min / len(events)) if events else 0,
        },
        "by_project": {k: round(v, 1) for k, v in sorted(by_project.items(), key=lambda x: -x[1])},
        "by_day": {day: {"count": v["count"], "hours": round(v["hours"], 1)} for day, v in by_day.items()},
        "busiest_day": busiest[0],
        "meeting_free_days": len(free_days),
        "meeting_length_distribution": {
            "short_30min_or_less": short,
            "medium_30_60min": medium,
            "long_over_60min": long,
        },
        "top_meeting_partners": dict(partner_counter.most_common(10)),
        "recommendations": [],
    }

    # Generate recommendations
    ratio = analysis["summary"]["meeting_ratio"]
    if ratio > 60:
        analysis["recommendations"].append(f"Meeting load is {ratio}% of work hours. Consider declining or shortening some meetings to protect deep work time.")
    if long > short and len(events) > 3:
        analysis["recommendations"].append(f"{long} of {len(events)} meetings are over an hour. Consider 45-minute defaults to create buffer time.")
    if analysis["meeting_free_days"] == 0:
        analysis["recommendations"].append("No meeting-free days this week. Block at least one day for focused work.")
    if busiest[1]["hours"] > 5:
        analysis["recommendations"].append(f"{busiest[0]} had {busiest[1]['hours']:.1f}h of meetings. Consider spreading meetings more evenly.")

    return analysis


def generate_html(analysis):
    """Generate HTML time allocation report."""
    s = analysis["summary"]

    # Project bars
    project_bars = ""
    max_hours = max(analysis["by_project"].values()) if analysis["by_project"] else 1
    colors = ["#3b82f6", "#22c55e", "#f97316", "#8b5cf6", "#ec4899", "#14b8a6", "#f59e0b"]
    for i, (project, hours) in enumerate(analysis["by_project"].items()):
        width = max(5, int(hours / max_hours * 100))
        color = colors[i % len(colors)]
        project_bars += f'<div style="margin:4px 0"><span style="display:inline-block;width:130px;font-size:13px">{project}</span><span style="display:inline-block;width:{width}%;background:{color};height:20px;border-radius:3px;vertical-align:middle"></span> <span style="font-size:12px;color:#6b7280">{hours}h</span></div>'

    # Day breakdown
    day_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
    day_bars = ""
    for day in day_order:
        info = analysis["by_day"].get(day, {"count": 0, "hours": 0})
        bar_width = max(2, int(info["hours"] / 8 * 100))
        color = "#ef4444" if info["hours"] > 5 else "#f97316" if info["hours"] > 3 else "#22c55e"
        day_bars += f'<div style="margin:3px 0"><span style="display:inline-block;width:100px;font-size:13px">{day}</span><span style="display:inline-block;width:{bar_width}%;background:{color};height:18px;border-radius:3px;vertical-align:middle"></span> <span style="font-size:12px;color:#6b7280">{info["hours"]}h ({info["count"]} mtgs)</span></div>'

    # Recommendations
    rec_html = ""
    for r in analysis.get("recommendations", []):
        rec_html += f'<div style="background:#f0f9ff;border-left:3px solid #3b82f6;padding:8px 12px;margin:4px 0;border-radius:4px;font-size:13px">{r}</div>'

    # Top partners
    partners_html = ""
    for name, count in list(analysis["top_meeting_partners"].items())[:7]:
        partners_html += f'<div style="font-size:13px;padding:2px 0">{name}: {count} meetings</div>'

    # Meeting ratio gauge
    ratio = s["meeting_ratio"]
    ratio_color = "#ef4444" if ratio > 60 else "#f97316" if ratio > 40 else "#22c55e"

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>ARIA Time Allocation</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; background: #f9fafb; }}
  h1 {{ font-size: 22px; color: #111827; margin-bottom: 4px; }}
  .subtitle {{ color: #6b7280; font-size: 14px; margin-bottom: 20px; }}
  .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 10px; margin-bottom: 20px; }}
  .metric {{ background: white; border-radius: 8px; padding: 14px; text-align: center; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }}
  .metric .value {{ font-size: 28px; font-weight: 700; }}
  .metric .label {{ font-size: 11px; color: #6b7280; margin-top: 2px; }}
  .card {{ background: white; border-radius: 8px; padding: 16px; margin-bottom: 14px; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }}
  .card h2 {{ font-size: 14px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 12px; }}
</style>
</head>
<body>
<h1>Time Allocation</h1>
<p class="subtitle">{analysis["period"]} | Generated by ARIA</p>

<div class="grid">
  <div class="metric"><div class="value">{s["total_meetings"]}</div><div class="label">Meetings</div></div>
  <div class="metric"><div class="value">{s["total_meeting_hours"]}h</div><div class="label">In Meetings</div></div>
  <div class="metric"><div class="value">{s["deep_work_hours"]}h</div><div class="label">Deep Work Available</div></div>
  <div class="metric"><div class="value" style="color:{ratio_color}">{ratio}%</div><div class="label">Meeting Load</div></div>
</div>

{f'<div style="margin-bottom:16px">{rec_html}</div>' if rec_html else ''}

<div class="card">
  <h2>Time by Project</h2>
  {project_bars if project_bars else '<p style="color:#6b7280">No project data</p>'}
</div>

<div class="card">
  <h2>Daily Meeting Load</h2>
  {day_bars}
</div>

<div class="card">
  <h2>Top Meeting Partners</h2>
  {partners_html if partners_html else '<p style="color:#6b7280">No attendee data</p>'}
</div>

<div class="card">
  <h2>Meeting Length</h2>
  <div style="font-size:14px">
    <span style="color:#22c55e;font-weight:600">{analysis['meeting_length_distribution']['short_30min_or_less']}</span> short (30 min or less) |
    <span style="color:#f97316;font-weight:600">{analysis['meeting_length_distribution']['medium_30_60min']}</span> medium (30-60 min) |
    <span style="color:#ef4444;font-weight:600">{analysis['meeting_length_distribution']['long_over_60min']}</span> long (60+ min)
  </div>
</div>

<p style="text-align:center;font-size:11px;color:#9ca3af;margin-top:20px">Generated by ARIA | Protect your deep work time</p>
</body>
</html>"""
    return html


def main():
    log("Starting time allocation analysis")
    config = load_config()
    date_str = datetime.now().strftime("%Y-%m-%d")

    events = load_calendar_data(days_back=7)
    log(f"Loaded {len(events)} calendar events")

    analysis = analyze(events, config)

    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    with open(BRIEFINGS_DIR / f"{date_str}-time.json", "w") as f:
        json.dump(analysis, f, indent=2, default=str)

    html = generate_html(analysis)
    with open(BRIEFINGS_DIR / f"{date_str}-time.html", "w") as f:
        f.write(html)

    s = analysis["summary"]
    log(f"Meetings: {s['total_meetings']} ({s['total_meeting_hours']}h)")
    log(f"Deep work available: {s['deep_work_hours']}h")
    log(f"Meeting load: {s['meeting_ratio']}%")
    for r in analysis.get("recommendations", []):
        log(f"  REC: {r}")
    log(f"Saved to briefings/{date_str}-time.html")
    log("Time allocation complete")


if __name__ == "__main__":
    main()
