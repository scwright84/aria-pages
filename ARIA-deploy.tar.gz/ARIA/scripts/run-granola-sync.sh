#!/bin/bash
# One-shot Granola sync: reads new/updated meeting notes and forwards to n8n
# Called by launchd on schedule

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
VENV="$PROJECT_DIR/.venv/bin/python3"
LOG="$PROJECT_DIR/logs/granola-sync.log"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Granola sync starting" >> "$LOG"
"$VENV" "$SCRIPT_DIR/granola-sync.py" >> "$LOG" 2>&1
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Granola sync complete" >> "$LOG"
