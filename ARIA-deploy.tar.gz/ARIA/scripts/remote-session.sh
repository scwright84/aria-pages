#!/bin/bash
# ARIA Remote Onboarding Session
# Run this from YOUR machine (Sean's) to connect to a client's Mac for setup.
#
# Prerequisites:
#   - Both machines on Tailscale
#   - Client has completed Steps 1-3 of remote-onboarding.html
#   - Client has Screen Sharing enabled (System Settings > General > Sharing)
#
# Usage:
#   ./scripts/remote-session.sh <client-tailscale-ip-or-hostname>
#   ./scripts/remote-session.sh 100.64.0.5
#   ./scripts/remote-session.sh aria-client1

set -euo pipefail

BOLD='\033[1m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'

CLIENT="${1:?Usage: remote-session.sh <client-tailscale-ip-or-hostname>}"

echo -e "${BOLD}ARIA Remote Onboarding Session${NC}"
echo "Client: $CLIENT"
echo "$(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# Step 1: Verify Tailscale connectivity
echo -e "${CYAN}[1/5] Testing connection...${NC}"
if tailscale ping "$CLIENT" --timeout 5s &>/dev/null; then
    echo -e "  ${GREEN}Connected to $CLIENT via Tailscale${NC}"
else
    echo -e "  ${RED}Cannot reach $CLIENT${NC}"
    echo "  Make sure:"
    echo "    - Both machines are on Tailscale"
    echo "    - The client completed Step 3 (Tailscale login)"
    echo "    - You're using the right IP/hostname"
    echo ""
    echo "  Check available machines: tailscale status"
    exit 1
fi

# Step 2: Check SSH access
echo ""
echo -e "${CYAN}[2/5] Checking SSH access...${NC}"
if ssh -o ConnectTimeout=5 -o BatchMode=yes "$CLIENT" "echo ok" &>/dev/null 2>&1; then
    echo -e "  ${GREEN}SSH access working${NC}"
    SSH_OK=true
else
    echo -e "  ${YELLOW}SSH not available (client may need to enable Remote Login)${NC}"
    SSH_OK=false
fi

# Step 3: Check Screen Sharing
echo ""
echo -e "${CYAN}[3/5] Checking Screen Sharing...${NC}"
if command -v open &>/dev/null; then
    echo "  Attempting to open Screen Sharing..."
    echo ""
    echo -e "  ${YELLOW}If Screen Sharing doesn't connect, ask the client to:${NC}"
    echo "    1. Open System Settings"
    echo "    2. Go to General > Sharing"
    echo "    3. Turn on Screen Sharing"
    echo "    4. Also turn on Remote Management if available"
    echo ""
    read -p "  Open Screen Sharing now? (y/n): " open_vnc
    if [[ "$open_vnc" == "y" || "$open_vnc" == "Y" ]]; then
        open "vnc://$CLIENT" 2>/dev/null || echo -e "  ${YELLOW}Could not open Screen Sharing. Try manually: open vnc://$CLIENT${NC}"
    fi
fi

# Step 4: Remote setup checklist
echo ""
echo -e "${CYAN}[4/5] Remote Setup Checklist${NC}"
echo ""
echo "  Once connected to the client's screen, walk them through:"
echo ""
echo -e "  ${BOLD}a) Open the ARIA onboarding wizard${NC}"
echo "     Browser: http://localhost:8642"
echo "     (This should have opened at the end of the installer)"
echo ""
echo -e "  ${BOLD}b) Connect email accounts${NC}"
echo "     Click 'Add Gmail Account' for each email"
echo "     Client clicks 'Allow' on Google's consent screen"
echo "     Repeat for Outlook if needed"
echo ""
echo -e "  ${BOLD}c) Connect calendar${NC}"
echo "     Click 'Add Calendar' for each Google Calendar"
echo "     Client clicks 'Allow'"
echo ""
echo -e "  ${BOLD}d) Configure Telegram bot${NC}"
echo "     Enter the bot token (you created this ahead of time)"
echo "     Enter the client's Telegram user ID"
echo "     Test: have client send 'hello' to the bot"
echo ""
echo -e "  ${BOLD}e) Set briefing schedule${NC}"
echo "     Morning briefing time (default 7:30am)"
echo "     Evening debrief time (default 9:30pm)"
echo "     Client's timezone"
echo ""
echo -e "  ${BOLD}f) Set up email labels/folders${NC}"
echo "     The organizer will create ARIA/* labels in Gmail"
echo "     Confirm the client is OK with this"
echo ""

if [ "$SSH_OK" = true ]; then
    echo -e "${CYAN}[5/5] Remote Verification${NC}"
    echo ""
    read -p "  Run remote verification? (y/n): " run_verify
    if [[ "$run_verify" == "y" || "$run_verify" == "Y" ]]; then
        echo ""
        echo -e "  ${BOLD}Running ARIA tests on client machine...${NC}"
        echo ""

        # Run the test suite remotely
        ssh "$CLIENT" "cd ~/ARIA && ./scripts/test-all.sh" 2>&1 | while IFS= read -r line; do
            echo "  [REMOTE] $line"
        done

        echo ""
        echo -e "  ${BOLD}Running a test briefing...${NC}"
        ssh "$CLIENT" "cd ~/ARIA && .venv/bin/python3 scripts/generate-briefing.py" 2>&1 | tail -5 | while IFS= read -r line; do
            echo "  [REMOTE] $line"
        done

        echo ""
        echo -e "  ${BOLD}Checking services...${NC}"
        ssh "$CLIENT" "cd ~/ARIA && ./scripts/aria-services.sh status" 2>&1 | while IFS= read -r line; do
            echo "  [REMOTE] $line"
        done
    fi
fi

echo ""
echo -e "${GREEN}${BOLD}Remote session complete.${NC}"
echo ""
echo "Post-session checklist:"
echo "  [ ] All email accounts connected and syncing"
echo "  [ ] Calendar connected"
echo "  [ ] Telegram bot responds to messages"
echo "  [ ] test-all.sh passes on client machine"
echo "  [ ] Briefing generates successfully"
echo "  [ ] Client knows to check http://localhost:8643 (dashboard)"
echo "  [ ] Client knows to check http://localhost:8644 (status)"
echo "  [ ] Client understands briefing schedule"
echo "  [ ] Screen Sharing can be disabled now (only needed during setup)"
echo ""
echo "  Add client to config/clients-registry.json on your machine."
echo ""
