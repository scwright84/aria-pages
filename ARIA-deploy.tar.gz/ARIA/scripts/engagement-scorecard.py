#!/usr/bin/env python3
"""
ARIA Client Engagement Scorecard
Generates weekly per-project engagement metrics from inbox data.

Metrics per project:
  - Email volume (inbound count)
  - Action items pending (from emails + slack)
  - Commitments outstanding (from awaiting)
  - Commitments overdue (past deadline)
  - Days since last communication
  - Communication trend (up/down/flat vs prior week)
  - Urgency score (weighted average of email priority + slack urgency)
  - Health grade (A-F based on composite score)

Outputs:
  - briefings/YYYY-MM-DD-scorecard.json (structured data)
  - briefings/YYYY-MM-DD-scorecard.html (rendered for email/print)

Runs weekly (Sunday, after inbox sync) or manually.
"""

import json
import os
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

# Add scripts dir to path for aria_ai import
sys.path.insert(0, str(Path(__file__).parent))
import aria_ai

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
LOG_FILE = PROJECT_DIR / "logs" / "engagement-scorecard.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def load_inbox_files(prefix, days_back=7):
    """Load all inbox files matching prefix for the past N days."""
    all_data = []
    for day_offset in range(days_back):
        date = datetime.now() - timedelta(days=day_offset)
        date_str = date.strftime("%Y-%m-%d")
        path = INBOX_DIR / f"{prefix}-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                if isinstance(data, list):
                    all_data.extend(data)
            except (json.JSONDecodeError, IOError) as e:
                log(f"Warning: could not load {path}: {e}")
    return all_data


def compute_project_metrics(config, days_back=7):
    """Compute engagement metrics for each known project."""
    known_projects = config.get("known_projects", [])
    client_tiers = config.get("client_tiers", {})
    active_clients = client_tiers.get("active", [])
    thresholds = config.get("thresholds", {})

    # Load data
    emails = load_inbox_files("emails", days_back)
    slack = load_inbox_files("slack", days_back)
    awaiting = load_inbox_files("awaiting", days_back)

    # Also load prior week for trend comparison
    emails_prior = load_inbox_files("emails", days_back * 2)
    emails_prior_only = [e for e in emails_prior if e not in emails]

    today = datetime.now()
    metrics = {}

    for project in known_projects:
        # Email metrics
        proj_emails = [e for e in emails if e.get("detected_project") == project]
        proj_emails_prior = [e for e in emails_prior_only if e.get("detected_project") == project]

        email_count = len(proj_emails)
        email_count_prior = len(proj_emails_prior)

        # Action items from emails
        actions_needed = sum(1 for e in proj_emails if e.get("action_needed"))

        # Priority distribution
        priorities = Counter(e.get("priority", "normal") for e in proj_emails)

        # Days since last email
        last_email_date = None
        for e in proj_emails:
            date_str = e.get("date", "")
            try:
                d = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
                if last_email_date is None or d > last_email_date:
                    last_email_date = d
            except (ValueError, TypeError):
                pass

        days_since_last = None
        if last_email_date:
            days_since_last = (today - last_email_date.replace(tzinfo=None)).days

        # Slack metrics
        proj_slack = [s for s in slack if s.get("project") == project]
        slack_actions = sum(len(s.get("action_items", [])) for s in proj_slack)
        slack_messages = sum(s.get("message_count", 0) for s in proj_slack)

        # Commitment metrics
        proj_commitments = [a for a in awaiting if a.get("project") == project]
        commitments_total = len(proj_commitments)
        commitments_overdue = 0
        for c in proj_commitments:
            deadline = c.get("deadline", "")
            if deadline and deadline != "none" and deadline != "TBD":
                try:
                    dl = datetime.strptime(deadline, "%Y-%m-%d")
                    if dl < today:
                        commitments_overdue += 1
                except ValueError:
                    pass

        # Trend
        if email_count_prior == 0:
            trend = "new" if email_count > 0 else "silent"
        elif email_count > email_count_prior * 1.2:
            trend = "up"
        elif email_count < email_count_prior * 0.8:
            trend = "down"
        else:
            trend = "flat"

        # Urgency score (0-10)
        urgency = 0
        if email_count > 0:
            priority_weights = {"urgent": 10, "high": 7, "normal": 3, "low": 1}
            weighted = sum(priority_weights.get(p, 3) * c for p, c in priorities.items())
            urgency = min(10, round(weighted / email_count, 1))

        # Health grade
        health_score = _compute_health_score(
            email_count=email_count,
            actions_needed=actions_needed,
            commitments_overdue=commitments_overdue,
            days_since_last=days_since_last,
            trend=trend,
            is_active=project in active_clients,
            thresholds=thresholds,
        )

        metrics[project] = {
            "project": project,
            "tier": _get_tier(project, client_tiers),
            "email_count": email_count,
            "email_count_prior_week": email_count_prior,
            "trend": trend,
            "actions_needed": actions_needed,
            "slack_messages": slack_messages,
            "slack_actions": slack_actions,
            "commitments_total": commitments_total,
            "commitments_overdue": commitments_overdue,
            "days_since_last_email": days_since_last,
            "urgency_score": urgency,
            "health_grade": health_score["grade"],
            "health_score": health_score["score"],
            "health_flags": health_score["flags"],
        }

    return metrics


def _get_tier(project, client_tiers):
    for tier, projects in client_tiers.items():
        if project in projects:
            return tier
    return "unknown"


def _compute_health_score(email_count, actions_needed, commitments_overdue,
                          days_since_last, trend, is_active, thresholds):
    """Compute a health grade (A-F) from composite signals."""
    score = 100
    flags = []

    outreach_days = thresholds.get("outreach_active_client_days", 5)

    # Overdue commitments are the biggest red flag
    if commitments_overdue > 0:
        score -= commitments_overdue * 15
        flags.append(f"{commitments_overdue} overdue commitment(s)")

    # Pending actions pile up
    if actions_needed > 5:
        score -= 10
        flags.append(f"{actions_needed} actions pending")
    elif actions_needed > 2:
        score -= 5

    # Gone dark (active client with no recent contact)
    if is_active and days_since_last is not None and days_since_last > outreach_days:
        score -= 20
        flags.append(f"No contact in {days_since_last} days (threshold: {outreach_days})")
    elif is_active and days_since_last is None:
        score -= 10
        flags.append("No emails this period")

    # Declining engagement
    if trend == "down":
        score -= 10
        flags.append("Communication trending down")
    elif trend == "silent":
        score -= 15
        flags.append("No communication detected")

    # Clamp
    score = max(0, min(100, score))

    # Grade
    if score >= 90:
        grade = "A"
    elif score >= 75:
        grade = "B"
    elif score >= 60:
        grade = "C"
    elif score >= 40:
        grade = "D"
    else:
        grade = "F"

    return {"grade": grade, "score": score, "flags": flags}


def generate_html(metrics, date_str):
    """Generate HTML scorecard."""
    # Sort: active clients first, then by health score ascending (worst first)
    sorted_projects = sorted(
        metrics.values(),
        key=lambda m: (
            0 if m["tier"] == "active" else 1 if m["tier"] == "product" else 2,
            m["health_score"]
        )
    )

    grade_colors = {
        "A": "#22c55e", "B": "#84cc16", "C": "#eab308",
        "D": "#f97316", "F": "#ef4444"
    }
    trend_icons = {
        "up": "&#x25B2;", "down": "&#x25BC;", "flat": "&#x25CF;",
        "new": "&#x2605;", "silent": "&#x25CB;"
    }

    rows = ""
    for m in sorted_projects:
        # Skip projects with zero activity unless they're active clients
        if m["email_count"] == 0 and m["tier"] not in ("active", "product"):
            continue

        color = grade_colors.get(m["health_grade"], "#6b7280")
        trend_icon = trend_icons.get(m["trend"], "")
        flags_html = "<br>".join(m["health_flags"]) if m["health_flags"] else "No issues"

        rows += f"""
        <tr>
            <td style="font-weight:600">{m["project"]}</td>
            <td style="text-transform:capitalize">{m["tier"]}</td>
            <td style="text-align:center;font-size:24px;font-weight:700;color:{color}">{m["health_grade"]}</td>
            <td style="text-align:center">{m["email_count"]} {trend_icon}</td>
            <td style="text-align:center">{m["actions_needed"]}</td>
            <td style="text-align:center">{m["commitments_total"]}{'  (' + str(m["commitments_overdue"]) + ' overdue)' if m["commitments_overdue"] > 0 else ''}</td>
            <td style="text-align:center">{m["days_since_last_email"] if m["days_since_last_email"] is not None else '-'}</td>
            <td style="font-size:12px;color:#6b7280">{flags_html}</td>
        </tr>"""

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>ARIA Engagement Scorecard - {date_str}</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 1100px; margin: 0 auto; padding: 20px; background: #f9fafb; }}
  h1 {{ font-size: 20px; color: #111827; margin-bottom: 4px; }}
  .subtitle {{ color: #6b7280; font-size: 14px; margin-bottom: 20px; }}
  table {{ width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }}
  th {{ background: #111827; color: white; padding: 10px 12px; text-align: left; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; }}
  td {{ padding: 10px 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px; }}
  tr:last-child td {{ border-bottom: none; }}
  tr:hover {{ background: #f3f4f6; }}
  .legend {{ margin-top: 16px; font-size: 12px; color: #6b7280; }}
</style>
</head>
<body>
<h1>Engagement Scorecard</h1>
<p class="subtitle">Week ending {date_str} | Generated by ARIA</p>
<table>
  <thead>
    <tr>
      <th>Project</th>
      <th>Tier</th>
      <th>Health</th>
      <th>Emails</th>
      <th>Actions</th>
      <th>Commitments</th>
      <th>Days Silent</th>
      <th>Flags</th>
    </tr>
  </thead>
  <tbody>
    {rows}
  </tbody>
</table>
<p class="legend">
  Health: A (90-100) B (75-89) C (60-74) D (40-59) F (0-39) |
  Trend: &#x25B2; up &#x25BC; down &#x25CF; flat &#x2605; new &#x25CB; silent
</p>
</body>
</html>"""
    return html


def main():
    log("Starting engagement scorecard generation")
    config = load_config()
    date_str = datetime.now().strftime("%Y-%m-%d")

    metrics = compute_project_metrics(config, days_back=7)
    log(f"Computed metrics for {len(metrics)} projects")

    # Save JSON
    json_path = BRIEFINGS_DIR / f"{date_str}-scorecard.json"
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    with open(json_path, "w") as f:
        json.dump(metrics, f, indent=2, default=str)
    log(f"Saved JSON: {json_path}")

    # Save HTML
    html_path = BRIEFINGS_DIR / f"{date_str}-scorecard.html"
    html = generate_html(metrics, date_str)
    with open(html_path, "w") as f:
        f.write(html)
    log(f"Saved HTML: {html_path}")

    # Print summary
    for name, m in sorted(metrics.items(), key=lambda x: x[1]["health_score"]):
        if m["email_count"] > 0 or m["tier"] in ("active", "product"):
            flags = ", ".join(m["health_flags"]) if m["health_flags"] else "OK"
            log(f"  {m['health_grade']} | {name} ({m['tier']}) | {m['email_count']} emails | {flags}")

    log("Scorecard complete")


if __name__ == "__main__":
    main()
