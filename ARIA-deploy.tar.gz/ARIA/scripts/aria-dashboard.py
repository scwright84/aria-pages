#!/usr/bin/env python3
"""
ARIA Dashboard
Persistent local web UI showing today's briefing, system health,
connected accounts, and recent activity.

Runs as a background service on port 8643.
Access at http://localhost:8643

This is the daily interface. The onboarding server (port 8642) is for setup only.
"""

import json
import os
import subprocess
from datetime import datetime, timedelta
from pathlib import Path

from flask import Flask, render_template_string, redirect, url_for

PROJECT_DIR = Path(__file__).parent.parent
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
CREDENTIALS_FILE = PROJECT_DIR / "config" / "credentials.json"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
INBOX_DIR = PROJECT_DIR / "inbox"
LOG_DIR = PROJECT_DIR / "logs"
ENV_FILE = PROJECT_DIR / ".env"

DASHBOARD_PORT = 8643

app = Flask(__name__)


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def load_credentials():
    if CREDENTIALS_FILE.exists():
        with open(CREDENTIALS_FILE) as f:
            return json.load(f)
    return {"accounts": []}


def get_todays_briefing():
    """Load today's briefing HTML if it exists."""
    date_str = datetime.now().strftime("%Y-%m-%d")
    html_path = BRIEFINGS_DIR / f"{date_str}.html"
    if html_path.exists():
        with open(html_path) as f:
            return f.read()
    return None


def get_briefing_dates():
    """Get list of available briefing dates (most recent first)."""
    dates = []
    if BRIEFINGS_DIR.exists():
        for f in sorted(BRIEFINGS_DIR.glob("*.html"), reverse=True):
            date_str = f.stem
            try:
                dt = datetime.strptime(date_str, "%Y-%m-%d")
                dates.append({"date": date_str, "display": dt.strftime("%A, %B %d")})
            except ValueError:
                pass
    return dates[:14]  # Last 2 weeks


def get_inbox_stats():
    """Get counts of today's inbox data."""
    date_str = datetime.now().strftime("%Y-%m-%d")
    stats = {}
    for source in ["emails", "calendar", "slack", "notifications", "awaiting"]:
        path = INBOX_DIR / f"{source}-{date_str}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                stats[source] = len(data) if isinstance(data, list) else 1
            except Exception:
                stats[source] = 0
        else:
            stats[source] = 0
    return stats


def get_health_status():
    """Read latest health check results."""
    state_file = LOG_DIR / "health-check-state.json"
    if state_file.exists():
        try:
            with open(state_file) as f:
                state = json.load(f)
            active_alerts = state.get("last_alerts", {})
            last_clear = state.get("last_all_clear")
            if active_alerts:
                return {"status": "warning", "issues": list(active_alerts.keys()), "last_clear": last_clear}
            return {"status": "healthy", "issues": [], "last_clear": last_clear}
        except Exception:
            pass
    return {"status": "unknown", "issues": [], "last_clear": None}


def get_connected_accounts():
    creds = load_credentials()
    return [
        {
            "email": a.get("email", "Unknown"),
            "services": a.get("services", []),
            "status": "connected" if a.get("refresh_token") else "expired",
        }
        for a in creds.get("accounts", [])
    ]


def get_recent_logs(n=10):
    """Get last N lines from the briefing log."""
    log_file = LOG_DIR / "briefing.log"
    if log_file.exists():
        with open(log_file) as f:
            lines = f.readlines()
        return [l.strip() for l in lines[-n:]]
    return []


DASHBOARD_HTML = """
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="300">
<title>ARIA Dashboard</title>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Inter', sans-serif; background: #f8f9fb; color: #1a1a2e; }
    .nav {
        background: linear-gradient(135deg, #0096FF 0%, #0066cc 100%);
        padding: 16px 24px; display: flex; align-items: center; justify-content: space-between;
    }
    .nav-brand { font-size: 20px; font-weight: 800; color: #fff; letter-spacing: -0.5px; }
    .nav-status { font-size: 12px; font-weight: 600; padding: 4px 12px; border-radius: 12px; }
    .nav-status.healthy { background: rgba(255,255,255,0.2); color: #fff; }
    .nav-status.warning { background: #fef3c7; color: #92400e; }
    .nav-status.unknown { background: rgba(255,255,255,0.1); color: rgba(255,255,255,0.7); }
    .container { max-width: 960px; margin: 0 auto; padding: 24px 20px; }
    .grid { display: grid; grid-template-columns: 1fr 320px; gap: 20px; }
    .card { background: #fff; border-radius: 12px; border: 1px solid #e5e7eb; padding: 20px; margin-bottom: 16px; }
    .card h2 { font-size: 14px; font-weight: 700; color: #6b7280; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 12px; }
    .stat-row { display: flex; gap: 12px; margin-bottom: 16px; }
    .stat { flex: 1; background: #f8f9fb; border-radius: 8px; padding: 14px; text-align: center; }
    .stat-num { font-size: 24px; font-weight: 800; color: #0096FF; }
    .stat-label { font-size: 11px; color: #6b7280; font-weight: 500; margin-top: 2px; }
    .briefing-frame { border: none; width: 100%; min-height: 500px; border-radius: 8px; background: #fff; }
    .briefing-nav { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 12px; }
    .briefing-link { font-size: 12px; padding: 4px 10px; border-radius: 6px; text-decoration: none; color: #374151; background: #f3f4f6; }
    .briefing-link.active { background: #0096FF; color: #fff; }
    .account-row { display: flex; align-items: center; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #f3f4f6; font-size: 13px; }
    .account-row:last-child { border-bottom: none; }
    .status-dot { width: 8px; height: 8px; border-radius: 50%; display: inline-block; margin-right: 6px; }
    .status-dot.ok { background: #10b981; }
    .status-dot.warn { background: #f59e0b; }
    .status-dot.err { background: #ef4444; }
    .log-entry { font-size: 11px; color: #6b7280; font-family: monospace; padding: 2px 0; border-bottom: 1px solid #f9fafb; }
    .empty-state { text-align: center; padding: 40px 20px; color: #9ca3af; }
    .empty-state h3 { font-size: 16px; color: #6b7280; margin-bottom: 8px; }
    .empty-state p { font-size: 14px; }
    a.setup-link { color: #0096FF; text-decoration: none; font-weight: 600; }
    @media (max-width: 768px) { .grid { grid-template-columns: 1fr; } }
</style>
</head>
<body>

<div class="nav">
    <div class="nav-brand">ARIA</div>
    <div>
        <span class="nav-status {{ health.status }}">
            {% if health.status == 'healthy' %}All Systems Healthy
            {% elif health.status == 'warning' %}Issues: {{ health.issues | join(', ') }}
            {% else %}Status Unknown{% endif %}
        </span>
    </div>
</div>

<div class="container">
    <!-- Stats -->
    <div class="stat-row">
        <div class="stat">
            <div class="stat-num">{{ stats.get('emails', 0) }}</div>
            <div class="stat-label">Emails Today</div>
        </div>
        <div class="stat">
            <div class="stat-num">{{ stats.get('calendar', 0) }}</div>
            <div class="stat-label">Events</div>
        </div>
        <div class="stat">
            <div class="stat-num">{{ stats.get('slack', 0) }}</div>
            <div class="stat-label">Slack</div>
        </div>
        <div class="stat">
            <div class="stat-num">{{ stats.get('notifications', 0) }}</div>
            <div class="stat-label">Notifications</div>
        </div>
        <div class="stat">
            <div class="stat-num">{{ accounts | length }}</div>
            <div class="stat-label">Accounts</div>
        </div>
    </div>

    <div class="grid">
        <!-- Main: Briefing -->
        <div>
            <div class="card">
                <h2>Today's Briefing</h2>
                {% if briefing_dates %}
                <div class="briefing-nav">
                    {% for bd in briefing_dates[:7] %}
                    <a href="/briefing/{{ bd.date }}" class="briefing-link {{ 'active' if bd.date == current_date else '' }}">{{ bd.display }}</a>
                    {% endfor %}
                </div>
                {% endif %}
                {% if briefing_html %}
                <iframe srcdoc="{{ briefing_html | e }}" class="briefing-frame" sandbox="allow-same-origin"></iframe>
                {% else %}
                <div class="empty-state">
                    <h3>No briefing yet today</h3>
                    <p>{% if not accounts %}Connect your accounts first: <a href="http://localhost:8642" class="setup-link">Open Setup</a>
                    {% else %}Your morning briefing will arrive at {{ briefing_time }}{% endif %}</p>
                </div>
                {% endif %}
            </div>
        </div>

        <!-- Sidebar -->
        <div>
            <!-- Connected Accounts -->
            <div class="card">
                <h2>Connected Accounts</h2>
                {% if accounts %}
                {% for acct in accounts %}
                <div class="account-row">
                    <span><span class="status-dot {{ 'ok' if acct.status == 'connected' else 'warn' }}"></span>{{ acct.email }}</span>
                    <span style="font-size:11px;color:#9ca3af;">{{ acct.services | join(', ') }}</span>
                </div>
                {% endfor %}
                {% else %}
                <p style="font-size:13px;color:#9ca3af;">No accounts connected. <a href="http://localhost:8642" class="setup-link">Open Setup</a></p>
                {% endif %}
            </div>

            <!-- System Health -->
            <div class="card">
                <h2>System Health</h2>
                {% for service in ['inference', 'n8n', 'docker', 'briefing', 'telegram_bot'] %}
                <div class="account-row">
                    <span>
                        <span class="status-dot {{ 'warn' if service in health.issues else 'ok' }}"></span>
                        {{ service | replace('_', ' ') | title }}
                    </span>
                    <span style="font-size:11px;color:#9ca3af;">{{ 'Issue' if service in health.issues else 'OK' }}</span>
                </div>
                {% endfor %}
            </div>

            <!-- Recent Activity -->
            <div class="card">
                <h2>Recent Logs</h2>
                {% if logs %}
                {% for entry in logs %}
                <div class="log-entry">{{ entry }}</div>
                {% endfor %}
                {% else %}
                <p style="font-size:13px;color:#9ca3af;">No recent activity</p>
                {% endif %}
            </div>

            <!-- Quick Links -->
            <div class="card">
                <h2>Quick Links</h2>
                <div style="display:flex;flex-direction:column;gap:8px;">
                    <a href="http://localhost:8642" class="setup-link" style="font-size:13px;">Account Setup</a>
                    <a href="http://localhost:5678" class="setup-link" style="font-size:13px;">n8n Workflows</a>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
"""


@app.route("/")
def dashboard():
    config = load_config()
    date_str = datetime.now().strftime("%Y-%m-%d")

    return render_template_string(DASHBOARD_HTML,
        health=get_health_status(),
        stats=get_inbox_stats(),
        accounts=get_connected_accounts(),
        briefing_html=get_todays_briefing(),
        briefing_dates=get_briefing_dates(),
        current_date=date_str,
        briefing_time=config.get("schedules", {}).get("morning_briefing", "07:30"),
        logs=get_recent_logs(),
    )


@app.route("/briefing/<date>")
def view_briefing(date):
    config = load_config()
    html_path = BRIEFINGS_DIR / f"{date}.html"
    briefing_html = None
    if html_path.exists():
        with open(html_path) as f:
            briefing_html = f.read()

    return render_template_string(DASHBOARD_HTML,
        health=get_health_status(),
        stats=get_inbox_stats(),
        accounts=get_connected_accounts(),
        briefing_html=briefing_html,
        briefing_dates=get_briefing_dates(),
        current_date=date,
        briefing_time=config.get("schedules", {}).get("morning_briefing", "07:30"),
        logs=get_recent_logs(),
    )


if __name__ == "__main__":
    print(f"\n  ARIA Dashboard")
    print(f"  Open: http://localhost:{DASHBOARD_PORT}\n")
    app.run(host="127.0.0.1", port=DASHBOARD_PORT, debug=False)
