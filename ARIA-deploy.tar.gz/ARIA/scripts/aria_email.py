"""
ARIA Email Sender — SMTP fallback for briefing delivery.

Primary: sends via n8n webhook (BriefingEmail001 workflow).
Fallback: sends directly via SMTP if n8n is unreachable.

All ARIA generators should use send_briefing_email() from this module
instead of calling the n8n webhook directly.
"""

import json
import logging
import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from pathlib import Path

import requests

logger = logging.getLogger("aria_email")

PROJECT_DIR = Path(__file__).parent.parent
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"
ENV_FILE = PROJECT_DIR / ".env"


def _load_env():
    """Load environment variables from .env."""
    if ENV_FILE.exists():
        with open(ENV_FILE) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, value = line.partition("=")
                    key = key.strip()
                    value = value.strip().strip("'\"")
                    if key and key not in os.environ:
                        os.environ[key] = value


def _load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def send_via_n8n(to, subject, html_body, webhook_url=None):
    """Send email via n8n webhook (primary method)."""
    config = _load_config()
    if webhook_url is None:
        base = config.get("n8n_base_url", "http://localhost:5678")
        webhook_url = f"{base}/webhook/aria-send-email"

    try:
        resp = requests.post(webhook_url, json={
            "to": to,
            "subject": subject,
            "html": html_body,
        }, timeout=15)
        if resp.status_code == 200:
            return True
        logger.warning(f"n8n webhook returned {resp.status_code}")
        return False
    except requests.exceptions.ConnectionError:
        logger.warning("n8n not reachable for email delivery")
        return False
    except Exception as e:
        logger.warning(f"n8n email failed: {e}")
        return False


def send_via_smtp(to, subject, html_body):
    """Send email directly via SMTP (fallback method)."""
    _load_env()

    smtp_host = os.environ.get("ARIA_SMTP_HOST", "smtp.gmail.com")
    smtp_port = int(os.environ.get("ARIA_SMTP_PORT", "587"))
    smtp_user = os.environ.get("ARIA_SMTP_USER")
    smtp_pass = os.environ.get("ARIA_SMTP_PASS")

    if not smtp_user or not smtp_pass:
        logger.error("SMTP credentials not configured. Set ARIA_SMTP_USER and ARIA_SMTP_PASS in .env")
        return False

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = smtp_user
    msg["To"] = to

    msg.attach(MIMEText(html_body, "html"))

    try:
        with smtplib.SMTP(smtp_host, smtp_port) as server:
            server.starttls()
            server.login(smtp_user, smtp_pass)
            server.sendmail(smtp_user, [to], msg.as_string())
        return True
    except Exception as e:
        logger.error(f"SMTP send failed: {e}")
        return False


def send_briefing_email(to, subject, html_body, webhook_url=None):
    """
    Send a briefing email. Tries n8n first, falls back to SMTP.

    Args:
        to: recipient email address
        subject: email subject
        html_body: HTML content
        webhook_url: optional n8n webhook URL override

    Returns:
        tuple: (success: bool, method: str)
    """
    # Try n8n first
    if send_via_n8n(to, subject, html_body, webhook_url):
        return True, "n8n"

    logger.info("n8n failed, attempting SMTP fallback...")

    # Fall back to SMTP
    if send_via_smtp(to, subject, html_body):
        return True, "smtp_fallback"

    logger.error("Both n8n and SMTP failed. Email not sent.")
    return False, "failed"
