#!/usr/bin/env python3
"""
ARIA Knowledge Base Auto-Builder
Extracts processes, FAQs, decisions, and tribal knowledge from
communications and organizes into a searchable knowledge base.

Captures:
  - Decisions made (from decision journal)
  - Processes described in emails ("here's how we do X")
  - Recurring questions (same topic asked multiple times)
  - Technical details (architecture decisions, API keys, configs)
  - Client preferences (how they like things done)

Output: config/knowledge-base.json (persistent, grows over time)
        Searchable via semantic memory (Qdrant)
Runs weekly to capture new knowledge.
"""

import json
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import aria_ai

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
KB_FILE = PROJECT_DIR / "config" / "knowledge-base.json"
DECISIONS_FILE = PROJECT_DIR / "config" / "decisions.json"
LOG_FILE = PROJECT_DIR / "logs" / "knowledge-base.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_kb():
    if KB_FILE.exists():
        try:
            with open(KB_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"entries": [], "categories": {}}


def save_kb(data):
    KB_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(KB_FILE, "w") as f:
        json.dump(data, f, indent=2, default=str)


def load_inbox(prefix, days_back=7):
    all_data = []
    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        path = INBOX_DIR / f"{prefix}-{date.strftime('%Y-%m-%d')}.json"
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                all_data.extend(data if isinstance(data, list) else [data])
            except Exception:
                pass
    return all_data


def extract_process_knowledge(emails):
    """Find emails that describe processes or how-to information."""
    process_keywords = re.compile(
        r"here'?s how|step[s]?\s+\d|process for|procedure|workflow|checklist|make sure to|always|never|important to note|fyi.*going forward",
        re.IGNORECASE
    )

    entries = []
    for e in emails:
        text = f"{e.get('subject', '')} {e.get('summary', '')} {e.get('snippet', '')}"
        if process_keywords.search(text):
            entries.append({
                "type": "process",
                "title": e.get("subject", "")[:100],
                "content": (e.get("summary") or e.get("snippet", ""))[:500],
                "source": "email",
                "project": e.get("detected_project"),
                "from": e.get("from", ""),
                "date": datetime.now().strftime("%Y-%m-%d"),
            })

    return entries


def extract_decisions(decisions_file):
    """Pull decisions from the decision journal."""
    if not decisions_file.exists():
        return []

    try:
        with open(decisions_file) as f:
            data = json.load(f)
    except Exception:
        return []

    entries = []
    for d in data.get("decisions", []):
        if d.get("status") in ("decided", "pending"):
            entries.append({
                "type": "decision",
                "title": d.get("decision", "")[:100],
                "content": f"Decision: {d.get('decision', '')}\nContext: {d.get('context', '')}\nSo what: {d.get('so_what', '')}",
                "source": d.get("source", "unknown"),
                "project": d.get("project"),
                "date": d.get("date", ""),
            })

    return entries


def extract_recurring_topics(emails):
    """Find topics that come up repeatedly (potential FAQ candidates)."""
    # Extract key phrases from subjects
    subjects = [e.get("subject", "").lower() for e in emails]
    subject_roots = [re.sub(r'^(re|fwd|fw)\s*:\s*', '', s).strip() for s in subjects]

    # Count recurring themes
    word_pairs = Counter()
    for s in subject_roots:
        words = re.findall(r'\b[a-z]{4,}\b', s)
        for i in range(len(words) - 1):
            pair = f"{words[i]} {words[i+1]}"
            word_pairs[pair] += 1

    entries = []
    for pair, count in word_pairs.most_common(5):
        if count >= 3:
            entries.append({
                "type": "recurring_topic",
                "title": f"Frequently discussed: {pair}",
                "content": f"This topic appeared {count} times in recent email subjects. Consider documenting the standard answer or process.",
                "source": "pattern_detection",
                "date": datetime.now().strftime("%Y-%m-%d"),
            })

    return entries


def extract_client_preferences(slack):
    """Extract client preferences from Slack discussions."""
    entries = []
    preference_keywords = re.compile(
        r"prefer|always want|make sure|don'?t forget|important|standard|default|usually|typically",
        re.IGNORECASE
    )

    for s in slack:
        summary = s.get("summary", "")
        if preference_keywords.search(summary):
            entries.append({
                "type": "preference",
                "title": f"{s.get('project', 'Unknown')} preference: {summary[:60]}",
                "content": summary[:300],
                "source": "slack",
                "project": s.get("project"),
                "date": datetime.now().strftime("%Y-%m-%d"),
            })

    return entries


def deduplicate(kb, new_entries):
    """Add new entries, skip duplicates."""
    existing_titles = set(e.get("title", "")[:50].lower() for e in kb.get("entries", []))
    added = 0
    for entry in new_entries:
        key = entry.get("title", "")[:50].lower()
        if key and key not in existing_titles:
            import hashlib
            entry["id"] = hashlib.md5(f"{entry['type']}:{entry['title']}".encode()).hexdigest()[:10]
            kb["entries"].append(entry)
            existing_titles.add(key)
            added += 1
    return added


def update_categories(kb):
    """Organize entries by category for easy browsing."""
    categories = defaultdict(int)
    for entry in kb.get("entries", []):
        categories[entry.get("type", "unknown")] += 1
    kb["categories"] = dict(categories)


def main():
    log("Starting knowledge base update")
    kb = load_kb()

    # Extract from all sources
    emails = load_inbox("emails", days_back=7)
    slack = load_inbox("slack", days_back=7)

    process_entries = extract_process_knowledge(emails)
    log(f"Process knowledge: {len(process_entries)}")

    decision_entries = extract_decisions(DECISIONS_FILE)
    log(f"Decisions: {len(decision_entries)}")

    recurring_entries = extract_recurring_topics(emails)
    log(f"Recurring topics: {len(recurring_entries)}")

    preference_entries = extract_client_preferences(slack)
    log(f"Client preferences: {len(preference_entries)}")

    all_new = process_entries + decision_entries + recurring_entries + preference_entries
    added = deduplicate(kb, all_new)
    update_categories(kb)
    kb["last_updated"] = datetime.now().isoformat()
    save_kb(kb)

    # Save snapshot
    date_str = datetime.now().strftime("%Y-%m-%d")
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)
    with open(BRIEFINGS_DIR / f"{date_str}-knowledge.json", "w") as f:
        json.dump({
            "date": date_str,
            "new_entries": added,
            "total_entries": len(kb["entries"]),
            "categories": kb["categories"],
            "recent": kb["entries"][-10:],
        }, f, indent=2, default=str)

    log(f"Added {added} new entries (total: {len(kb['entries'])})")
    log(f"Categories: {json.dumps(kb['categories'])}")
    log("Knowledge base update complete")


if __name__ == "__main__":
    main()
