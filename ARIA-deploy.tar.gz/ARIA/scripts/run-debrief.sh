#!/bin/bash
# Generate and send evening debrief
# Runs at 9:30pm via launchd

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
VENV="$PROJECT_DIR/.venv/bin/python3"
LOG="$PROJECT_DIR/logs/debrief.log"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Debrief generation starting" >> "$LOG"

"$VENV" "$SCRIPT_DIR/generate-debrief.py" >> "$LOG" 2>&1
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Debrief generation complete" >> "$LOG"
