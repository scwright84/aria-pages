#!/usr/bin/env python3
"""
Process model action requests from ARIA briefing replies.
Creates feature documentation in PippaExplorer/docs/ for test/evaluate actions.
Updates model-tracker state for skip/watch actions.

Called from generate-briefing.py and generate-debrief.py after each run.
"""

import json
import re
from datetime import datetime, timedelta
from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
LOG_FILE = PROJECT_DIR / "logs" / "model-actions.log"
PIPPA_DOCS = Path.home() / "Desktop" / "dev projects" / "PippaExplorer" / "docs"
CONFIG_FILE = PROJECT_DIR / "config" / "model-tracker.json"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def slugify(model_id):
    """Convert model ID to a filename-safe slug."""
    slug = model_id.replace("fal-ai/", "").replace("/", "-")
    slug = re.sub(r'[^a-zA-Z0-9\-]', '-', slug)
    slug = re.sub(r'-+', '-', slug).strip('-').upper()
    return slug


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def create_feature_doc(action):
    """Create a FEATURE-MODEL-TEST doc in PippaExplorer/docs/."""
    model_id = action["model_id"]
    slug = slugify(model_id)
    filename = f"FEATURE-MODEL-TEST-{slug}.md"
    filepath = PIPPA_DOCS / filename

    if filepath.exists():
        log(f"  Feature doc already exists: {filename}")
        return filepath

    config = load_config()
    current_stack = config.get("current_stack", {})

    category = action.get("category", "unknown")
    provider = action.get("provider", "fal.ai")

    # Determine comparison targets
    compare_to = ""
    if category in ("image_generation", "image_editing"):
        primary = current_stack.get("image", {}).get("primary", "fal-ai/flux-2-pro/edit")
        fallback = current_stack.get("image", {}).get("fallback", "fal-ai/flux-2/edit")
        compare_to = f"- Current primary: `{primary}`\n- Current fallback: `{fallback}`"
    elif category in ("video_generation", "image_to_video"):
        primary = current_stack.get("video", {}).get("primary", "fal-ai/kling-video/v3/pro/image-to-video")
        fallback = current_stack.get("video", {}).get("fallback", "fal-ai/minimax/hailuo-02-fast/image-to-video")
        compare_to = f"- Current primary: `{primary}`\n- Current fallback: `{fallback}`"
    elif category in ("lip_sync", "avatar"):
        primary = current_stack.get("lip_sync", {}).get("primary", "fal-ai/kling-video/lipsync/audio-to-video")
        compare_to = f"- Current primary: `{primary}`"

    content = f"""# Model Test: {model_id}

> Source: ARIA Model Tracker
> Created: {datetime.now().strftime("%Y-%m-%d")}
> Status: **PENDING TEST**
> Category: {category.replace('_', ' ').title()}
> Provider: {provider}
> Score: {action.get('score', 'N/A')} -- {action.get('score_reason', '')}

## Context

{compare_to}

Sean's direction: "{action.get('reply_text', '').strip()}"

## What to Test

1. **Quality comparison**: Generate the same scene with this model and current primary. Compare output quality.
2. **Style consistency**: Does it maintain animation style across multiple generations?
3. **Speed**: Generation time vs current models.
4. **Cost**: Price per generation vs current models.
5. **API compatibility**: Does it work with fal.ai's standard API pattern?

## Integration Notes

### Files to Modify (if approved)

| File | Change |
|------|--------|
| `src/lib/providers/fal.ts` | Add model constant and generation function |
| `src/lib/prompt/modelPromptFormats.ts` | Add prompt formatter (if image model) |
| `src/lib/prompt/videoModelPromptFormats.ts` | Add video formatter (if video model) |
| `src/lib/storyboard/selectBestModel.ts` | Update auto-routing rules |
| `src/lib/usage/costs.ts` | Add token cost entry |
| `src/lib/providers/fal-fallbacks.ts` | Add to fallback chain |
| `docs/MODEL-REFERENCE.md` | Add to model tables |

## Test Results

_Run tests and document results here._

| Metric | This Model | Current Primary |
|--------|-----------|----------------|
| Quality | | |
| Speed | | |
| Cost/generation | | |
| Style consistency | | |
| Ref image handling | | |

## Decision

- [ ] **Integrate**: Add to Pippa's model stack
- [ ] **Watch**: Promising but not ready. Re-evaluate later.
- [ ] **Skip**: Not suitable for Pippa.
"""

    PIPPA_DOCS.mkdir(parents=True, exist_ok=True)
    with open(filepath, "w") as f:
        f.write(content)

    log(f"  Created feature doc: {filename}")
    return filepath


def process_actions():
    """Process unprocessed model actions from inbox. Returns count processed."""
    processed_count = 0

    for days_back in range(3):
        date_str = (datetime.now() - timedelta(days=days_back)).strftime("%Y-%m-%d")
        actions_path = INBOX_DIR / f"model-actions-{date_str}.json"

        if not actions_path.exists():
            continue

        try:
            with open(actions_path) as f:
                actions = json.load(f)
        except Exception:
            continue

        modified = False
        for action in actions:
            if action.get("processed"):
                continue

            action_type = action.get("action", "")
            model_id = action.get("model_id", "")

            log(f"Processing: {action_type} {model_id}")

            if action_type in ("test", "evaluate", "integrate"):
                create_feature_doc(action)

            action["processed"] = True
            action["processed_at"] = datetime.now().isoformat()
            modified = True
            processed_count += 1

            if action_type in ("skip", "watch"):
                log(f"  Marked as {action_type}: {model_id}")

        if modified:
            with open(actions_path, "w") as f:
                json.dump(actions, f, indent=2)

    return processed_count


def main():
    log("Processing model actions...")
    count = process_actions()
    log(f"Processed {count} model actions.")


if __name__ == "__main__":
    main()
