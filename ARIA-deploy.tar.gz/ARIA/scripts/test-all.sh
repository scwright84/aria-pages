#!/bin/bash
# ARIA Full Integration Test Suite
# Run after install to verify every component works.
# Tests all scripts, services, outputs, and data flows.
#
# Usage: ./scripts/test-all.sh

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
VENV="$PROJECT_DIR/.venv/bin/python3"

BOLD='\033[1m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'

PASS=0
FAIL=0
WARN=0

pass() { echo -e "  ${GREEN}PASS${NC} $1"; PASS=$((PASS + 1)); }
fail() { echo -e "  ${RED}FAIL${NC} $1"; FAIL=$((FAIL + 1)); }
warn() { echo -e "  ${YELLOW}WARN${NC} $1"; WARN=$((WARN + 1)); }
section() { echo -e "\n${BOLD}${CYAN}=== $1 ===${NC}"; }

echo -e "${BOLD}ARIA Full Integration Test Suite${NC}"
echo "$(date '+%Y-%m-%d %H:%M:%S')"
echo "Project: $PROJECT_DIR"
echo ""

# ============================================================
section "1. Project Structure"
# ============================================================

for dir in inbox briefings config logs scripts templates workflows install modules; do
    if [ -d "$PROJECT_DIR/$dir" ]; then
        pass "$dir/ exists"
    else
        fail "$dir/ missing"
    fi
done

for f in CLAUDE.md .env config/aria.json config/contacts.json config/clients-registry.json config/docker-compose.production.yml; do
    if [ -f "$PROJECT_DIR/$f" ]; then
        pass "$f exists"
    else
        warn "$f missing"
    fi
done

# ============================================================
section "2. Python Environment"
# ============================================================

if [ -f "$VENV" ]; then
    pass "Python venv exists"
    PY_VERSION=$("$VENV" --version 2>&1)
    pass "Python: $PY_VERSION"
else
    fail "Python venv not found at $VENV"
fi

# Check key packages
for pkg in flask requests; do
    if "$VENV" -c "import $pkg" 2>/dev/null; then
        pass "Package: $pkg"
    else
        fail "Package missing: $pkg (pip install $pkg)"
    fi
done

# ============================================================
section "3. Core Scripts (import test)"
# ============================================================

for script in aria_ai aria_email; do
    if "$VENV" -c "import sys; sys.path.insert(0,'$PROJECT_DIR/scripts'); import $script" 2>/dev/null; then
        pass "Import: $script"
    else
        fail "Import failed: $script"
    fi
done

# ============================================================
section "4. AI Router"
# ============================================================

"$VENV" -c "
import sys; sys.path.insert(0,'$PROJECT_DIR/scripts')
import aria_ai
cfg = aria_ai.get_config()
assert 'cloud_model' in cfg
assert 'claude' in aria_ai.get_model(cloud=True)
assert aria_ai.get_model(fast=True) != aria_ai.get_model()
print('  All routing tests passed')
" 2>/dev/null && pass "AI router config and routing" || fail "AI router"

# ============================================================
section "5. Generators (dry run)"
# ============================================================

for script in engagement-scorecard.py contact-profiles.py; do
    if "$VENV" "$PROJECT_DIR/scripts/$script" >/dev/null 2>&1; then
        pass "Run: $script"
    else
        fail "Run failed: $script"
    fi
done

# ============================================================
section "6. Output Verification"
# ============================================================

TODAY=$(date '+%Y-%m-%d')

for output in "$TODAY.html" "$TODAY.json"; do
    if [ -f "$PROJECT_DIR/briefings/$output" ]; then
        pass "Briefing: $output"
    else
        warn "Missing: briefings/$output (may not have been generated yet today)"
    fi
done

for output in "$TODAY-scorecard.json" "$TODAY-scorecard.html" "$TODAY-contacts.html"; do
    if [ -f "$PROJECT_DIR/briefings/$output" ]; then
        pass "Output: $output"
    else
        warn "Missing: briefings/$output"
    fi
done

if [ -f "$PROJECT_DIR/config/contacts.json" ]; then
    COUNT=$("$VENV" -c "import json; print(len(json.load(open('$PROJECT_DIR/config/contacts.json'))))" 2>/dev/null || echo 0)
    pass "Contacts: $COUNT profiles"
else
    warn "No contacts.json yet"
fi

# ============================================================
section "7. Infrastructure Services"
# ============================================================

# Docker
if docker ps --format "{{.Names}}" 2>/dev/null | grep -q "n8n"; then
    pass "Docker: n8n running"
else
    warn "Docker: n8n not running"
fi

if docker ps --format "{{.Names}}" 2>/dev/null | grep -q "postgres"; then
    pass "Docker: postgres running"
else
    warn "Docker: postgres not running"
fi

# Inference
if curl -s -o /dev/null -w "%{http_code}" "http://localhost:11434/v1/models" 2>/dev/null | grep -q "200"; then
    pass "Inference engine responding"
else
    warn "Inference engine not responding"
fi

# n8n
if curl -s -o /dev/null -w "%{http_code}" "http://localhost:5678/healthz" 2>/dev/null | grep -q "200"; then
    pass "n8n API responding"
else
    warn "n8n not responding"
fi

# ============================================================
section "8. Background Processes"
# ============================================================

if pgrep -f "aria-telegram-bot" >/dev/null 2>&1; then
    pass "Telegram bot running"
else
    warn "Telegram bot not running"
fi

if pgrep -f "aria-menubar" >/dev/null 2>&1; then
    pass "Menu bar app running"
else
    warn "Menu bar app not running"
fi

# ============================================================
section "9. Data Freshness"
# ============================================================

for prefix in emails slack; do
    latest=$(ls -t "$PROJECT_DIR/inbox/${prefix}-"*.json 2>/dev/null | head -1 || true)
    if [ -n "$latest" ] && [ -f "$latest" ]; then
        age=$(( ($(date +%s) - $(stat -f %m "$latest" 2>/dev/null || echo 0)) / 3600 ))
        if [ "$age" -lt 24 ]; then
            pass "$prefix data fresh (${age}h old)"
        else
            warn "$prefix data stale (${age}h old)"
        fi
    else
        warn "No $prefix data"
    fi
done

# ============================================================
section "10. Backup"
# ============================================================

if "$PROJECT_DIR/scripts/backup.sh" >/dev/null 2>&1; then
    LATEST_BACKUP=$(ls -td ~/ARIA-backups/aria-* 2>/dev/null | head -1 || true)
    if [ -n "$LATEST_BACKUP" ]; then
        SIZE=$(du -sh "$LATEST_BACKUP" 2>/dev/null | cut -f1)
        pass "Backup successful ($SIZE)"
        # Verify no credentials in backup
        if [ ! -f "$LATEST_BACKUP/config/credentials.json" ]; then
            pass "Credentials excluded from backup"
        else
            fail "Credentials found in backup!"
        fi
    else
        fail "Backup ran but no output found"
    fi
else
    fail "Backup script failed"
fi

# ============================================================
section "11. Remediation Engine"
# ============================================================

if "$VENV" "$PROJECT_DIR/scripts/remediate.py" >/dev/null 2>&1; then
    pass "Remediation engine runs clean"
else
    warn "Remediation engine had issues (check logs)"
fi

# ============================================================
section "12. Service Manager"
# ============================================================

if [ -x "$PROJECT_DIR/scripts/aria-services.sh" ]; then
    pass "Service manager exists and is executable"
else
    fail "Service manager missing or not executable"
fi

# Check plists installed
PLIST_COUNT=$(ls ~/Library/LaunchAgents/com.aria.*.plist 2>/dev/null | wc -l | tr -d ' ')
if [ "$PLIST_COUNT" -gt 15 ]; then
    pass "launchd plists installed ($PLIST_COUNT)"
else
    warn "Only $PLIST_COUNT launchd plists (expected 19+)"
fi

# ============================================================
section "13. Modules (OpenClaw + Comms)"
# ============================================================

for f in modules/openclaw/soul.md modules/openclaw/repos.json modules/openclaw/SETUP_RUNBOOK.md \
         modules/comms/README.md modules/comms/scripts/sync-data.sh modules/comms/scripts/send-task.sh; do
    if [ -f "$PROJECT_DIR/$f" ]; then
        pass "$f"
    else
        warn "$f missing"
    fi
done

# ============================================================
section "14. Documentation"
# ============================================================

for doc in docs/PRODUCT_SPEC.md docs/ARCHITECTURE.md docs/BUG_TRACKER.md docs/QA_CHECKLIST.md; do
    if [ -f "$PROJECT_DIR/$doc" ]; then
        pass "$doc"
    else
        warn "$doc missing"
    fi
done

# ============================================================
echo ""
echo -e "${BOLD}============================================${NC}"
echo -e "${BOLD}  ARIA Integration Test Results${NC}"
echo -e "${BOLD}============================================${NC}"
echo ""
echo -e "  ${GREEN}Passed:   $PASS${NC}"
echo -e "  ${YELLOW}Warnings: $WARN${NC}"
echo -e "  ${RED}Failed:   $FAIL${NC}"
echo -e "  Total:   $((PASS + WARN + FAIL))"
echo ""

if [ "$FAIL" -eq 0 ] && [ "$WARN" -eq 0 ]; then
    echo -e "${GREEN}All systems go. ARIA is ready for deployment.${NC}"
elif [ "$FAIL" -eq 0 ]; then
    echo -e "${YELLOW}No failures. $WARN warnings to review before deployment.${NC}"
else
    echo -e "${RED}$FAIL failure(s) must be fixed before deployment.${NC}"
fi

echo ""
exit $FAIL
