"""
ARIA Briefing Intelligence Aggregator
Collects all intelligence outputs and formats them for inclusion in the
morning briefing. Called by generate-briefing.py.

Gathers from:
  - Priority inbox (top 5 most important emails)
  - Outreach alerts (silent clients)
  - Goal progress (alignment/misalignment)
  - Sentiment alerts (concerning mood trends)
  - Follow-up reminders (dropped balls)
  - Schedule insights (deep work days, meeting load)
  - Weekly wins (accomplishments)
  - Relationship alerts (weakening contacts)
  - Expense alerts (unusual spending)
  - Competitive intel (market signals)

Returns structured data for AI context AND pre-formatted HTML sections
for direct injection into the briefing.
"""

import json
from datetime import datetime, timedelta
from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
CONFIG_DIR = PROJECT_DIR / "config"


def _load_latest(suffix, days_back=2):
    """Load the most recent briefing JSON file with given suffix."""
    for d in range(days_back):
        date = datetime.now() - timedelta(days=d)
        path = BRIEFINGS_DIR / f"{date.strftime('%Y-%m-%d')}-{suffix}.json"
        if path.exists():
            try:
                with open(path) as f:
                    return json.load(f)
            except Exception:
                pass
    return None


def _load_config(name):
    path = CONFIG_DIR / name
    if path.exists():
        try:
            with open(path) as f:
                return json.load(f)
        except Exception:
            pass
    return None


def get_enabled_sections():
    """Get which intelligence sections are enabled."""
    try:
        from customizable_briefing import get_enabled_sections
        return get_enabled_sections()
    except ImportError:
        # Default: all enabled
        return {
            "priority_inbox": True, "outreach_alerts": True,
            "goal_progress": True, "sentiment_alerts": True,
            "relationship_alerts": True, "weekly_wins": True,
            "expense_summary": True, "competitive_intel": True,
        }


def gather_intelligence():
    """Gather all available intelligence for the briefing."""
    enabled = get_enabled_sections()
    intel = {}
    context_parts = []

    # Priority inbox
    if enabled.get("priority_inbox"):
        data = _load_latest("priority-inbox")
        if data and data.get("top_5"):
            intel["priority_inbox"] = data["top_5"]
            context_parts.append("\n=== PRIORITY INBOX (Top 5 most important emails right now) ===")
            for i, e in enumerate(data["top_5"], 1):
                context_parts.append(f"{i}. [{e.get('composite_score', 0)}] {e.get('from', '?')[:30]} | {e.get('subject', '?')[:50]} | {e.get('project', 'N/A')}")

    # Outreach alerts
    if enabled.get("outreach_alerts"):
        data = _load_latest("outreach")
        if data:
            alerts = data.get("project_alerts", [])
            if alerts:
                intel["outreach_alerts"] = alerts
                context_parts.append(f"\n=== OUTREACH ALERTS ({len(alerts)} clients going silent) ===")
                for a in alerts:
                    context_parts.append(f"  {a['project']} ({a['tier']}): {a['days_silent']} days silent (threshold: {a['threshold']}). {a.get('suggestion', '')}")

    # Goal progress
    if enabled.get("goal_progress"):
        data = _load_latest("goals")
        if data:
            goals = data.get("goals", [])
            misalignments = data.get("misalignments", [])
            if goals:
                intel["goal_progress"] = {"goals": goals, "misalignments": misalignments}
                context_parts.append(f"\n=== GOAL PROGRESS ===")
                for g in goals:
                    context_parts.append(f"  {g['title']}: {g.get('progress', 0)}% | Signals: {', '.join(g.get('signals', [])) or 'none'}")
                if misalignments:
                    context_parts.append("  MISALIGNMENTS:")
                    for m in misalignments:
                        context_parts.append(f"    {m['goal']}: {m['issue']}")

    # Sentiment alerts
    if enabled.get("sentiment_alerts"):
        data = _load_latest("sentiment")
        if data:
            concerning = [p for p in data.get("projects", []) if p.get("mood_label") == "concerning"]
            cooling = [p for p in data.get("projects", []) if p.get("trend") == "cooling"]
            if concerning or cooling:
                intel["sentiment_alerts"] = {"concerning": concerning, "cooling": cooling}
                context_parts.append(f"\n=== SENTIMENT ALERTS ===")
                for p in concerning:
                    context_parts.append(f"  CONCERNING: {p['project']} mood score {p['mood_score']}/100")
                for p in cooling:
                    context_parts.append(f"  COOLING: {p['project']} sentiment trending down")

    # Follow-up reminders (already collected via awaiting, but this adds the cross-reference analysis)
    followups = _load_latest("followups")
    if followups:
        urgent = [f for f in (followups if isinstance(followups, list) else []) if f.get("urgency") in ("high", "medium")]
        if urgent:
            intel["followup_reminders"] = urgent
            context_parts.append(f"\n=== FOLLOW-UP REMINDERS ({len(urgent)} items need attention) ===")
            for f in urgent[:5]:
                context_parts.append(f"  [{f.get('status', '?').upper()}] {f.get('task', '')[:60]} | Project: {f.get('project', '?')}")

    # Relationship alerts
    if enabled.get("relationship_alerts"):
        data = _load_latest("relationships")
        if data:
            needs_attention = data.get("needs_attention", [])
            if needs_attention:
                intel["relationship_alerts"] = needs_attention
                context_parts.append(f"\n=== RELATIONSHIPS NEEDING ATTENTION ===")
                for r in needs_attention[:5]:
                    context_parts.append(f"  {r['name']}: score {r['score']} ({r['label']}), projects: {', '.join(r.get('projects', []))}")

    # Weekly wins (only on Monday or in weekly briefs)
    if enabled.get("weekly_wins") and datetime.now().weekday() == 0:  # Monday
        data = _load_latest("wins")
        if data and data.get("wins"):
            intel["weekly_wins"] = data["wins"][:5]
            context_parts.append(f"\n=== LAST WEEK'S WINS ({data.get('count', 0)} total) ===")
            for w in data["wins"][:5]:
                context_parts.append(f"  [{w.get('source', '?')}] {w.get('text', '')[:60]}")

    # Expense summary
    if enabled.get("expense_summary"):
        data = _load_latest("expenses")
        if data and data.get("summary", {}).get("total", 0) > 0:
            intel["expense_summary"] = data["summary"]
            context_parts.append(f"\n=== FINANCIAL ACTIVITY ===")
            context_parts.append(f"  Total tracked: ${data['summary']['total']:.2f}")
            for proj, amount in list(data["summary"].get("by_project", {}).items())[:3]:
                context_parts.append(f"  {proj}: ${amount:.2f}")

    # Competitive intel
    if enabled.get("competitive_intel"):
        data = _load_latest("intel")
        if data and data.get("total_signals", 0) > 0:
            intel["competitive_intel"] = data
            context_parts.append(f"\n=== COMPETITIVE INTELLIGENCE ({data['total_signals']} signals) ===")
            for insight in data.get("insights", [])[:3]:
                context_parts.append(f"  {insight}")

    # Schedule insights
    schedule = _load_latest("schedule-insights")
    if schedule:
        patterns = schedule.get("patterns", {})
        day_types = patterns.get("day_types", {})
        today_name = datetime.now().strftime("%A")
        today_type = day_types.get(today_name, "unknown")
        intel["schedule_type"] = today_type
        if today_type in ("heavy", "free"):
            context_parts.append(f"\n=== SCHEDULE NOTE ===")
            if today_type == "heavy":
                context_parts.append(f"  Today ({today_name}) is typically a heavy meeting day. Minimize non-essential commitments.")
            elif today_type == "free":
                context_parts.append(f"  Today ({today_name}) is typically meeting-free. Good day for deep work.")

    return {
        "intelligence": intel,
        "context_for_ai": "\n".join(context_parts),
        "section_count": len(intel),
    }


def format_intelligence_html(intel):
    """Format intelligence data as HTML sections for direct injection into the briefing."""
    sections = []

    # Priority inbox
    if intel.get("priority_inbox"):
        items = "".join(f"<li><b>{e.get('from', '?')[:25]}</b>: {e.get('subject', '?')[:50]} <span style='color:#6B7280'>({e.get('project', '')})</span></li>"
                        for e in intel["priority_inbox"][:5])
        sections.append(f"<p><b>Priority Inbox (Top 5)</b></p><ul style='margin:4px 0 16px 0;padding-left:24px'>{items}</ul>")

    # Outreach alerts
    if intel.get("outreach_alerts"):
        items = "".join(f"<li><b>{a['project']}</b>: {a['days_silent']}d silent. <i>{a.get('suggestion', '')[:60]}</i></li>"
                        for a in intel["outreach_alerts"][:3])
        sections.append(f"<p><b>Outreach Needed</b></p><ul style='margin:4px 0 16px 0;padding-left:24px'>{items}</ul>")

    # Goal progress
    if intel.get("goal_progress"):
        goals = intel["goal_progress"].get("goals", [])
        items = ""
        for g in goals[:4]:
            color = "#22c55e" if g.get("progress", 0) >= 50 else "#f97316" if g.get("progress", 0) >= 20 else "#ef4444"
            items += f"<li>{g['title']}: <span style='color:{color};font-weight:600'>{g.get('progress', 0)}%</span></li>"
        if intel["goal_progress"].get("misalignments"):
            for m in intel["goal_progress"]["misalignments"]:
                items += f"<li style='color:#ef4444'><b>Misalignment:</b> {m['goal']}: {m['issue']}</li>"
        sections.append(f"<p><b>Goal Progress</b></p><ul style='margin:4px 0 16px 0;padding-left:24px'>{items}</ul>")

    # Sentiment alerts
    if intel.get("sentiment_alerts"):
        items = ""
        for p in intel["sentiment_alerts"].get("concerning", []):
            items += f"<li style='color:#ef4444'><b>{p['project']}</b>: mood {p['mood_score']}/100 (concerning)</li>"
        for p in intel["sentiment_alerts"].get("cooling", []):
            items += f"<li style='color:#f97316'><b>{p['project']}</b>: sentiment cooling</li>"
        sections.append(f"<p><b>Sentiment Alerts</b></p><ul style='margin:4px 0 16px 0;padding-left:24px'>{items}</ul>")

    # Relationship alerts
    if intel.get("relationship_alerts"):
        items = "".join(f"<li>{r['name']}: score {r['score']} ({r['label']})</li>" for r in intel["relationship_alerts"][:5])
        sections.append(f"<p><b>Relationships Needing Attention</b></p><ul style='margin:4px 0 16px 0;padding-left:24px'>{items}</ul>")

    # Weekly wins (Monday only)
    if intel.get("weekly_wins"):
        items = "".join(f"<li>{w.get('text', '')[:60]}</li>" for w in intel["weekly_wins"][:5])
        sections.append(f"<p><b>Last Week's Wins</b></p><ul style='margin:4px 0 16px 0;padding-left:24px'>{items}</ul>")

    return "\n".join(sections)
