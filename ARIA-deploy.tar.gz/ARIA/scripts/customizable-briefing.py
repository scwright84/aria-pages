#!/usr/bin/env python3
"""
ARIA Customizable Briefing Sections (FEAT-095)
Lets clients choose what goes in their morning brief via config.

Config in aria.json under "briefing_sections":
  {
    "briefing_sections": {
      "bluf": true,              # Bottom line up front (always on)
      "decisions_needed": true,
      "todays_schedule": true,
      "commitments_you_owe": true,
      "waiting_on_others": true,
      "project_pulse": true,
      "overnight_comms": true,
      "strategic_radar": true,
      "priority_inbox": false,    # New: top 5 priority emails
      "outreach_alerts": false,   # New: silent client alerts
      "goal_progress": false,     # New: goal tracking
      "relationship_alerts": false # New: weakening relationships
    }
  }

This module provides get_enabled_sections() which briefing generators call
to determine what to include.
"""

import json
from pathlib import Path

PROJECT_DIR = Path(__file__).parent.parent
CONFIG_FILE = PROJECT_DIR / "config" / "aria.json"

DEFAULT_SECTIONS = {
    "bluf": True,
    "decisions_needed": True,
    "todays_schedule": True,
    "commitments_you_owe": True,
    "waiting_on_others": True,
    "project_pulse": True,
    "overnight_comms": True,
    "strategic_radar": True,
    "priority_inbox": False,
    "outreach_alerts": False,
    "goal_progress": False,
    "relationship_alerts": False,
    "weekly_wins": False,
    "sentiment_alerts": False,
    "expense_summary": False,
    "competitive_intel": False,
}

SECTION_DESCRIPTIONS = {
    "bluf": "Bottom Line Up Front - one paragraph summary of what matters most",
    "decisions_needed": "Decisions that need your input today, with context",
    "todays_schedule": "Today's meetings with prep context",
    "commitments_you_owe": "Things you said you'd do that aren't done yet",
    "waiting_on_others": "Things others promised you that haven't arrived",
    "project_pulse": "One-line status per project/client",
    "overnight_comms": "Important messages that came in since last brief",
    "strategic_radar": "Longer-term items to keep in mind",
    "priority_inbox": "Top 5 most important emails right now",
    "outreach_alerts": "Clients or contacts who've gone silent",
    "goal_progress": "How your weekly/monthly goals are tracking",
    "relationship_alerts": "Relationships that are weakening and need attention",
    "weekly_wins": "Accomplishments detected this week (weekly brief only)",
    "sentiment_alerts": "Projects where communication tone is concerning",
    "expense_summary": "Financial activity detected in email",
    "competitive_intel": "Competitor mentions and market signals",
}


def get_enabled_sections():
    """Get the list of enabled briefing sections from config."""
    try:
        with open(CONFIG_FILE) as f:
            config = json.load(f)
    except Exception:
        config = {}

    configured = config.get("briefing_sections", {})

    # Merge with defaults
    result = dict(DEFAULT_SECTIONS)
    result.update(configured)

    return {section: enabled for section, enabled in result.items() if enabled}


def get_all_sections():
    """Get all available sections with descriptions and current status."""
    enabled = get_enabled_sections()
    return [
        {
            "section": section,
            "description": SECTION_DESCRIPTIONS.get(section, ""),
            "enabled": section in enabled,
            "default": DEFAULT_SECTIONS.get(section, False),
        }
        for section in DEFAULT_SECTIONS
    ]


def main():
    """Display current briefing configuration."""
    sections = get_all_sections()
    enabled = [s for s in sections if s["enabled"]]
    disabled = [s for s in sections if not s["enabled"]]

    print("ARIA Briefing Sections Configuration\n")
    print(f"Enabled ({len(enabled)}):")
    for s in enabled:
        print(f"  [x] {s['section']}: {s['description']}")

    print(f"\nDisabled ({len(disabled)}):")
    for s in disabled:
        print(f"  [ ] {s['section']}: {s['description']}")

    print(f"\nTo change: edit 'briefing_sections' in config/aria.json")


if __name__ == "__main__":
    main()
