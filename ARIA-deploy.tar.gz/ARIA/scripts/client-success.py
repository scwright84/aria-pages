#!/usr/bin/env python3
"""
ARIA Client Success Automation
Monitors client engagement and proactively prevents churn.

Kelly's early warning system:
  - Tracks usage trends per client (engagement score over time)
  - Detects drops in engagement (fewer Telegram queries, skipped briefings)
  - Sends alerts to Kelly when a client needs attention
  - Auto-generates check-in email drafts for Kelly to send
  - Tracks satisfaction through reply patterns

Thresholds:
  - Green: engagement > 60, regular briefing opens, active Telegram use
  - Yellow: engagement 30-60, declining trend, or 5+ days no interaction
  - Red: engagement < 30, or 10+ days no interaction

Output: briefings/YYYY-MM-DD-client-success.json
Kelly gets alerts via Telegram (separate from client alerts).
"""

import json
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import aria_ai

PROJECT_DIR = Path(__file__).parent.parent
CONFIG_DIR = PROJECT_DIR / "config"
BRIEFINGS_DIR = PROJECT_DIR / "briefings"
LOG_FILE = PROJECT_DIR / "logs" / "client-success.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_json(path):
    if Path(path).exists():
        try:
            with open(path) as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def assess_client_health(client, usage_data, sentiment_data):
    """Assess a single client's health and churn risk."""
    name = client.get("name", "Unknown")
    setup_date = client.get("setup_date", "")
    monthly_fee = client.get("monthly_fee", 0)

    # Calculate tenure
    days_active = 0
    if setup_date:
        try:
            days_active = (datetime.now() - datetime.strptime(setup_date, "%Y-%m-%d")).days
        except ValueError:
            pass

    # Usage metrics
    usage = usage_data.get("totals", {})
    avg_engagement = usage.get("avg_engagement", 0)
    total_telegram = usage.get("total_telegram_queries", 0)

    # Recent engagement trend
    daily = usage_data.get("daily", {})
    recent_days = sorted(daily.keys())[-7:] if daily else []
    recent_scores = [daily[d].get("engagement_score", 0) for d in recent_days]
    trend = "stable"
    if len(recent_scores) >= 3:
        first_half = sum(recent_scores[:len(recent_scores)//2]) / max(len(recent_scores)//2, 1)
        second_half = sum(recent_scores[len(recent_scores)//2:]) / max(len(recent_scores) - len(recent_scores)//2, 1)
        if second_half < first_half * 0.7:
            trend = "declining"
        elif second_half > first_half * 1.3:
            trend = "improving"

    # Determine status
    if avg_engagement >= 60 and trend != "declining":
        status = "green"
        risk = "low"
        action = None
    elif avg_engagement >= 30 or trend == "declining":
        status = "yellow"
        risk = "medium"
        action = f"Check in with {name}. Engagement is {'declining' if trend == 'declining' else 'moderate'}."
    else:
        status = "red"
        risk = "high"
        action = f"URGENT: {name} is disengaging. Schedule a call this week."

    # New client grace period (first 14 days, don't flag)
    if days_active < 14:
        status = "green"
        risk = "low"
        action = None

    return {
        "client": name,
        "status": status,
        "risk": risk,
        "engagement": avg_engagement,
        "trend": trend,
        "days_active": days_active,
        "monthly_fee": monthly_fee,
        "total_telegram_queries": total_telegram,
        "action": action,
        "revenue_at_risk": monthly_fee * 12 if risk == "high" else monthly_fee * 6 if risk == "medium" else 0,
    }


def generate_checkin_draft(client_health):
    """Generate a check-in email draft for Kelly to send."""
    name = client_health["client"]
    status = client_health["status"]

    if status == "red":
        subject = f"Checking in - {name}"
        body = f"""Hi there,

I wanted to reach out and check in on how ARIA is working for your practice.

We noticed you haven't been using some of the features recently, and I want to make sure everything is set up the way you need it.

Would you have 15 minutes this week for a quick call? I'd love to hear what's working and what we can improve.

Best,
Kelly Kelley
ARIA Co-Founder"""
    elif status == "yellow":
        subject = f"Quick update from ARIA - {name}"
        body = f"""Hi,

Just a quick note to let you know about some new features we've added to ARIA that you might find useful.

[Kelly: mention 1-2 relevant features based on their usage patterns]

Let me know if you'd like a quick walkthrough. Happy to hop on a call anytime.

Best,
Kelly Kelley"""
    else:
        return None

    return {"to": name, "subject": subject, "body": body}


def main():
    log("Starting client success assessment")

    registry = load_json(CONFIG_DIR / "clients-registry.json")
    clients = registry.get("clients", [])
    usage = load_json(CONFIG_DIR / "usage-analytics.json")
    sentiment = load_json(CONFIG_DIR / "sentiment-history.json")

    assessments = []
    alerts = []
    drafts = []

    for client in clients:
        if client.get("phase") not in ("active", "onboarding"):
            continue

        health = assess_client_health(client, usage, sentiment)
        assessments.append(health)

        if health["action"]:
            alerts.append(health)

        # Generate check-in draft for yellow/red clients
        draft = generate_checkin_draft(health)
        if draft:
            drafts.append(draft)

    # Save report
    date_str = datetime.now().strftime("%Y-%m-%d")
    BRIEFINGS_DIR.mkdir(parents=True, exist_ok=True)

    report = {
        "date": date_str,
        "assessments": assessments,
        "alerts": alerts,
        "drafts_generated": len(drafts),
        "revenue_at_risk": sum(a.get("revenue_at_risk", 0) for a in assessments),
        "summary": {
            "green": sum(1 for a in assessments if a["status"] == "green"),
            "yellow": sum(1 for a in assessments if a["status"] == "yellow"),
            "red": sum(1 for a in assessments if a["status"] == "red"),
        },
    }

    with open(BRIEFINGS_DIR / f"{date_str}-client-success.json", "w") as f:
        json.dump(report, f, indent=2, default=str)

    # Add check-in drafts to the draft queue
    if drafts:
        try:
            import draft_manager
            for d in drafts:
                draft_manager.add_draft(
                    to=d["to"],
                    subject=d["subject"],
                    body=d["body"],
                    project="Client Success",
                )
            log(f"Added {len(drafts)} check-in drafts to queue")
        except Exception as e:
            log(f"Could not add drafts: {e}")

    # Send alert to Kelly via Telegram if needed
    if alerts:
        try:
            config = aria_ai.get_full_config()
            token = aria_ai.get_telegram_token()
            users = aria_ai.get_telegram_authorized_users()
            if token and users:
                import requests
                msg_lines = ["*Client Success Alert*\n"]
                for a in alerts:
                    emoji = {"red": "🔴", "yellow": "🟡"}.get(a["status"], "⚪")
                    msg_lines.append(f"{emoji} *{a['client']}*: {a['action']}")
                    if a.get("revenue_at_risk"):
                        msg_lines.append(f"  Revenue at risk: ${a['revenue_at_risk']:,.0f}")
                msg = "\n".join(msg_lines)
                for uid in users:
                    requests.post(
                        f"https://api.telegram.org/bot{token}/sendMessage",
                        json={"chat_id": uid, "text": msg, "parse_mode": "Markdown"},
                        timeout=10,
                    )
                log(f"Sent alert to Kelly via Telegram")
        except Exception as e:
            log(f"Could not send Telegram alert: {e}")

    # Summary
    log(f"Assessed {len(assessments)} clients")
    log(f"  Green: {report['summary']['green']}, Yellow: {report['summary']['yellow']}, Red: {report['summary']['red']}")
    log(f"  Revenue at risk: ${report['revenue_at_risk']:,.0f}")
    log(f"  Alerts: {len(alerts)}")
    log(f"  Check-in drafts: {len(drafts)}")
    log("Client success assessment complete")


if __name__ == "__main__":
    main()
