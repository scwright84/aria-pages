# Google OAuth Setup: Quick Version

Do this once. Takes 10 minutes. Both machines (Pro and Air) use the same credentials.

## Open These URLs

You'll need 4 browser tabs:

1. **Create project:** https://console.cloud.google.com/projectcreate
2. **Enable APIs:** https://console.cloud.google.com/apis/library
3. **Consent screen:** https://console.cloud.google.com/apis/credentials/consent
4. **Create credentials:** https://console.cloud.google.com/apis/credentials

## Steps

### Tab 1: Create Project
- Project name: **ARIA**
- Click **Create**
- Wait 10 seconds for it to provision

### Tab 2: Enable APIs (make sure ARIA project is selected in top dropdown)
- Search **Gmail API** → Click → Click **Enable**
- Search **Google Calendar API** → Click → Click **Enable**
- Search **Google People API** → Click → Click **Enable**

### Tab 3: Consent Screen
- User type: **External** → Create
- App name: **ARIA**
- User support email: **sean@wrightadvisorsatx.com**
- App domain:
  - Homepage: **https://scwright84.github.io/aria-pages**
  - Privacy policy: **https://scwright84.github.io/aria-pages/privacy-policy.html**
  - Terms of service: **https://scwright84.github.io/aria-pages/terms-of-service.html**
- Developer contact: **sean@wrightadvisorsatx.com**
- Click **Save and Continue**
- Scopes page: Click **Add or Remove Scopes**
  - Check: `gmail.readonly`
  - Check: `gmail.labels`
  - Check: `calendar.readonly`
  - Check: `userinfo.email`
  - Check: `userinfo.profile`
  - Click **Update** → **Save and Continue**
- Test users: Click **Add Users**
  - Add: **scwright84@gmail.com** (your personal)
  - Add any other Gmail addresses you want to connect
  - Click **Save and Continue**
- Click **Back to Dashboard**

### Tab 4: Create Credentials
- Click **Create Credentials** → **OAuth client ID**
- Application type: **Web application**
- Name: **ARIA Local**
- Authorized redirect URIs: Click **Add URI**
  - Add: `http://localhost:8642/oauth/google/callback`
- Click **Create**
- A popup shows your Client ID and Client Secret
- Click **Download JSON**

### Save the JSON File
```bash
# Copy the downloaded file to ARIA's config directory
cp ~/Downloads/client_secret_*.json "/Users/seanwright/Desktop/dev projects/ARIA/config/google-oauth-client.json"

# Lock permissions
chmod 600 "/Users/seanwright/Desktop/dev projects/ARIA/config/google-oauth-client.json"
```

### Verify It Works
```bash
# Start the onboarding server
cd "/Users/seanwright/Desktop/dev projects/ARIA"
.venv/bin/python3 scripts/onboarding-server.py
```
- Open http://localhost:8642
- The "Google OAuth client file" step should show a green checkmark
- Click **Connect Gmail** → Authorize → Should redirect back with success
- Click **Connect Calendar** → Authorize → Should redirect back with success

## For the MacBook Air
Copy the same JSON file:
```bash
scp "/Users/seanwright/Desktop/dev projects/ARIA/config/google-oauth-client.json" aria@macbook-air.local:~/ARIA/config/
```
Both machines use the same OAuth client. Each machine gets its own access tokens when the user authorizes.

## Adding Test Users Later
When you onboard Kelly's brother or other pilot clients:
1. Go to https://console.cloud.google.com/apis/credentials/consent
2. Click **Test users** → **Add Users**
3. Add their Gmail address
4. They can now authorize through the ARIA onboarding wizard

Limit: 100 test users before you need production verification.
