# Zoom OAuth Setup (One-Time, by Sean)

Like Google and Microsoft, you register ONE Zoom app. Every customer clicks "Connect Zoom" and authorizes.

## Steps

1. Go to https://marketplace.zoom.us/
2. Click **Develop** > **Build App** (top right)
3. Choose **General App**
4. App name: **ARIA**
5. Click **Create**

### App Credentials
On the app page:
- Copy the **Client ID**
- Copy the **Client Secret**

### Redirect URL
Under **OAuth** settings:
- Add redirect URL: `https://scwright84.github.io/aria-pages/zoom-callback.html`
- Add allow list URL: `https://scwright84.github.io/aria-pages/zoom-callback.html`

### Scopes
Click **Scopes** and add:
- `meeting:read` (View meetings)
- `recording:read` (View recordings)
- `user:read` (View user info)

### Activation
- Click **Activation** tab
- Add the redirect URL to the allow list if prompted
- The app should be ready for use

### Save to ARIA
Enter the Client ID and Client Secret in the ARIA onboarding wizard at:
http://localhost:8642/setup/zoom
