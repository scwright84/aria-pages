# ARIA Bug & Feature Tracker

Last updated: 2026-03-24

## How to Use This Tracker
- **Priority:** P0 (system down), P1 (blocking pilot), P2 (important), P3 (nice to have)
- **Status flow:** open → in progress → QA → closed
- **Source:** Where the issue was identified (session date or context)

---

## Open Bugs

| # | Bug | Priority | Status | Source |
|---|-----|----------|--------|--------|
| BUG-004 | Granola cache path in CLAUDE.md says cache-v4.json but actual is cache-v6.json | P3 | **closed** | Already fixed in CLAUDE.md |

---

## Open Features (Phase 1: Foundation)

| # | Feature | Priority | Status | Source | Notes |
|---|---------|----------|--------|--------|-------|
| FEAT-001 | Swap Ollama to oMLX inference engine | P0 | **closed** | 2026-03-24 | scripts/migrate-to-mlx.sh. MLX running natively on Apple Silicon. Qwen3-8B-4bit + Qwen3-4B-4bit. Same port, same API. Embeddings via sentence-transformers (Python-native). Rollback available. |
| FEAT-010 | AI router (decide local vs. cloud per task) | P2 | **closed** | 2026-03-24 | aria_ai.py: cloud=True (direct), escalate=True (fallback). Config in aria.json. |

All other Phase 1 features are closed. See Implemented section.

---

## Open Features (Phase 1.5: Pilot Readiness)

Built during 2026-03-24 sessions. These fill the gap between "infrastructure done" and "ready to hand to Kelly's brother."

| # | Feature | Priority | Status | Source | Notes |
|---|---------|----------|--------|--------|-------|
| FEAT-012 | Local dashboard (web UI for today's briefing, health, activity) | P1 | **closed** | 2026-03-24 | scripts/aria-dashboard.py, Flask on port 8643 |
| FEAT-013 | macOS menu bar app (health status, quick access) | P2 | **closed** | 2026-03-24 | scripts/aria-menubar.py, uses rumps library |
| FEAT-014 | Maintenance/cleanup script (retention enforcement, log rotation) | P1 | **closed** | 2026-03-24 | scripts/maintenance.py, daily via launchd |
| FEAT-015 | Deployment packager (clean archive for new machines) | P1 | **closed** | 2026-03-24 | scripts/package-deploy.sh, excludes data/creds |
| FEAT-016 | Double-click installer for clients | P1 | **closed** | 2026-03-24 | install/ARIA-Install.command, full Mac setup wizard |
| FEAT-017 | Legal docs (Terms of Service, Privacy Policy) | P1 | **closed** | 2026-03-24 | install/terms-of-service.html, install/privacy-policy.html |
| FEAT-018 | Download/landing page for installer | P2 | **closed** | 2026-03-24 | install/download.html |
| FEAT-019 | Workflow optimization engine (Kelly's north star insight) | P1 | **closed** | 2026-03-24 | scripts/workflow-optimizer.py. Analyzes patterns, recommends automations. Weekly report. |
| FEAT-040 | Google Cloud project for ARIA OAuth (production) | P0 | in progress | 2026-03-24 | Being set up on other terminal |
| FEAT-041 | New Telegram bot token (revoke old, generate new) | P0 | in progress | 2026-03-24 | Being set up on other terminal |

---

## Open Features (Phase 1.75: Intelligence Layer)

New intelligence features that make ARIA proactive, not just reactive.

| # | Feature | Priority | Status | Source | Notes |
|---|---------|----------|--------|--------|-------|
| FEAT-060 | Proactive outreach alerts (silence detection) | P2 | **closed** | 2026-03-24 | scripts/outreach-alerts.py. Uses aria.json thresholds. 3 real alerts found. |
| FEAT-061 | Auto task extraction (emails + Slack + commitments) | P1 | **closed** | 2026-03-24 | scripts/task-extractor.py. 11 tasks extracted. Persistent config/tasks.json. |
| FEAT-062 | Smart follow-up reminders (dropped ball detection) | P1 | **closed** | 2026-03-24 | scripts/follow-up-reminders.py. Cross-refs commitments with actual comms. |
| FEAT-063 | Daily communication digest (patterns + anomalies) | P2 | **closed** | 2026-03-24 | scripts/comms-digest.py. Headlines, project bars, anomaly detection. |
| FEAT-064 | Service manager (start/stop/status all 20 services) | P0 | **closed** | 2026-03-24 | scripts/aria-services.sh. Also generates/installs all launchd plists. |
| FEAT-065 | Full integration test suite (53 checks) | P0 | **closed** | 2026-03-24 | scripts/test-all.sh. 53/53 passing. |
| FEAT-066 | Super ARIA email permission model (soul file) | P1 | **closed** | 2026-03-24 | modules/openclaw/soul.md. Reads all, sends from own email only. |
| FEAT-067 | Email auto-organizer (Gmail labels + Outlook folders) | P1 | **closed** | 2026-03-24 | scripts/email-organizer.py. Labels by project/priority, archives non-action, keeps action in inbox. Gmail + Outlook. |
| FEAT-068 | Qdrant semantic memory (144 docs indexed) | P1 | **closed** | 2026-03-24 | scripts/aria_memory.py + memory-index.py. Cross-source natural language search. nomic-embed-text. |
| FEAT-069 | Junk mail filter (3-layer: known + AI + learned) | P1 | **closed** | 2026-03-24 | scripts/junk_filter.py. Caught 7/83 junk on Layer 1 alone. Integrates with email-organizer.py. Configurable in aria.json. |
| FEAT-070 | Remote onboarding system (3-stage guided setup) | P1 | **closed** | 2026-03-24 | install/remote-onboarding.html (client guide), scripts/remote-session.sh (admin tool), scripts/generate-onboarding-email.py (personalized welcome email). Installer updated with Tailscale + embedding model. |
| FEAT-071 | Weekly planner (proactive week-ahead planning) | P1 | **closed** | 2026-03-24 | scripts/weekly-planner.py. Calendar + tasks + commitments + outreach. Deep work day detection. |
| FEAT-072 | Smart Telegram commands (drafts, tasks, search, scorecard, plan) | P1 | **closed** | 2026-03-24 | scripts/telegram_commands.py + draft_manager.py. 12 new commands: /drafts /approve /reject /edit /tasks /plan /scorecard /outreach /digest /search /memory /approveall |
| FEAT-073 | Notification intelligence (priority routing) | P2 | **closed** | 2026-03-24 | scripts/notification-intelligence.py. Classifies iMessage/WhatsApp/Signal/Slack. Urgent→alert, important→brief, noise→suppress. |
| FEAT-074 | Time allocation tracker (where does time go) | P2 | **closed** | 2026-03-24 | scripts/time-tracker.py. Per-project hours, meeting load %, deep work available, partner analysis, recommendations. |
| FEAT-075 | Email writing style learner | P2 | **closed** | 2026-03-24 | scripts/style-learner.py. Analyzes 12 sent emails. Profile: medium length, professional, direct (no greeting), punchy. config/writing-style.json. |
| FEAT-076 | Relationship strength scoring (0-100 per contact) | P2 | **closed** | 2026-03-24 | scripts/relationship-scorer.py. 41 contacts scored. Decays daily. 11 healthy, 15 moderate, 15 weakening. |
| FEAT-077 | Decision journal (extract + track decisions) | P2 | **closed** | 2026-03-24 | scripts/decision-journal.py. 5 decisions from briefings. Tracks outcomes, patterns. config/decisions.json. |
| FEAT-078 | Goal tracker (alignment detection) | P1 | **closed** | 2026-03-24 | scripts/goal-tracker.py. Auto-creates from projects. Conceivable 100%, Wild Monkey Bar 0% (flagged misalignment). |
| FEAT-079 | Priority inbox reranking | P1 | **closed** | 2026-03-24 | scripts/priority-inbox.py. 53 emails ranked by sender + project + action + goal relevance. Top 5 for briefs. |
| FEAT-080 | Meeting debrief auto-capture | P2 | **closed** | 2026-03-24 | scripts/meeting-debrief.py. Auto-generates summary + action items after each meeting from calendar + notes + emails. |
| FEAT-081 | Smart scheduling assistant | P2 | **closed** | 2026-03-24 | scripts/schedule-optimizer.py. 4 weeks of patterns: day types, meeting preference, free block detection, recommendations. |
| FEAT-082 | Per-client communication templates | P2 | **closed** | 2026-03-24 | scripts/client-templates.py. 5 templates per client (update, follow-up, request, check-in, good news). Tone-matched. |
| FEAT-083 | Expense/invoice tracker from email | P2 | **closed** | 2026-03-24 | scripts/expense-tracker.py. Parses Stripe/invoice/receipt emails. 7 transactions found. Per-project spending. |
| FEAT-084 | Auto weekly client update emails | P2 | **closed** | 2026-03-24 | scripts/client-weekly-update.py. AI-generated drafts per active client. Goes to draft queue for approval via Telegram. |
| FEAT-085 | Competitive intelligence | P2 | **closed** | 2026-03-24 | scripts/competitive-intel.py. Scans email/Slack/news for competitors + trends. 2 signals found (ChatGPT, Claude mentions). |
| FEAT-086 | Email thread summarizer | P2 | **closed** | 2026-03-24 | scripts/thread-summarizer.py. Groups by thread, summarizes long chains. 98 threads, 2 long, 3 active. |
| FEAT-087 | Sentiment tracker per client | P2 | **closed** | 2026-03-24 | scripts/sentiment-tracker.py. Mood scores 0-100 per project. Conceivable flagged concerning (37). Trends over time. |
| FEAT-088 | Weekly wins report | P2 | **closed** | 2026-03-24 | scripts/weekly-wins.py. Auto-detects accomplishments. 17 wins found. HTML report. |
| FEAT-089 | Email response time monitor | P2 | **closed** | 2026-03-24 | scripts/response-monitor.py. Tracks reply speed per project. 13 stale emails (3+ days) flagged. |
| FEAT-090 | Knowledge base auto-builder | P2 | **closed** | 2026-03-24 | scripts/knowledge-base.py. 12 entries: processes, decisions, recurring topics. Grows over time. |
| FEAT-091 | Data export (CSV reports) | P2 | **closed** | 2026-03-24 | scripts/data-export.py. 8 report types (scorecard, contacts, expenses, tasks, decisions, goals, time, relationships). CSV/JSON. |
| FEAT-092 | Monthly client value report ("ARIA saved you X hours") | P1 | **closed** | 2026-03-24 | scripts/monthly-value-report.py. 7.3h saved in March from 130 emails + 17 briefings. HTML report with time savings breakdown. |
| FEAT-093 | Usage analytics (client engagement with ARIA) | P2 | **closed** | 2026-03-24 | scripts/usage-analytics.py. Engagement score, Telegram queries, briefings, drafts, searches. 90-day retention. |
| FEAT-094 | Audit log (everything ARIA does, timestamped) | P1 | **closed** | 2026-03-24 | scripts/aria_audit.py. JSONL format, log_action() API for all scripts. Queryable, Telegram-ready. |
| FEAT-095 | Customizable briefing sections | P2 | **closed** | 2026-03-24 | scripts/customizable-briefing.py. 16 sections, 8 default on, 8 optional. Config-driven in aria.json. |
| FEAT-096 | Smart unsubscribe suggestions | P3 | **closed** | 2026-03-24 | scripts/smart-unsubscribe.py. 14 suggestions, could eliminate 69 emails/mo. Detects never-replied senders. |
| FEAT-097 | Super ARIA presidential brief generator + email sender | P1 | **closed** | 2026-03-24 | modules/openclaw/scripts/generate-super-brief.py. Gathers all ARIA intel, builds HTML brief, sends from dedicated email. Reply-to-act loop. |
| FEAT-098 | Onboarding questionnaire (structured client intake) | P2 | **closed** | 2026-03-24 | scripts/onboarding-questionnaire.py. 12 questions, generates aria.json from answers. CLI or web. |
| FEAT-099 | Webhook API endpoints (inbound data from other tools) | P3 | **closed** | 2026-03-24 | scripts/webhook-api.py. Port 8648, 5 endpoints (email, note, event, task, generic). Bearer token auth. |
| FEAT-100 | Client data isolation verification (multi-tenant safety) | P2 | **closed** | 2026-03-24 | scripts/data-isolation-check.py. 6 checks: permissions, env, dirs, cross-contamination, Docker, Qdrant. |
| FEAT-101 | Meeting notes integration (Otter.ai, Fireflies, beyond Granola) | P3 | **closed** | 2026-03-24 | scripts/meeting-notes-adapter.py. Normalizes Granola/Otter/Fireflies/manual to standard format. |
| FEAT-102 | Multi-timezone support for distributed teams | P3 | **closed** | 2026-03-24 | scripts/timezone-support.py. Team timezone config, time conversion, meeting time suggestion, multi-tz display. |
| FEAT-103 | AI inference request queuing | P3 | open | 2026-03-24 | Queue AI requests to prevent model overload during batch operations. Not needed for typical usage patterns. |
| FEAT-104 | Contact introduction matcher ("You know X, client needs X") | P3 | **closed** | 2026-03-24 | scripts/contact-matcher.py. Cross-project expertise matching, connector detection. |
| FEAT-105 | White-label theming system | P1 | **closed** | 2026-03-24 | scripts/aria_theme.py. Config-driven branding: colors, logo, company name, footers. Used by all UI scripts. |
| FEAT-106 | Demo mode with sample dental practice data | P1 | **closed** | 2026-03-24 | scripts/demo-mode.py. Realistic emails, calendar, briefing, scorecard, tasks, contacts. --enable/--disable toggle. |
| FEAT-107 | Multi-tenant client provisioning (shared Mac Studio) | P0 | **closed** | 2026-03-24 | scripts/provision-client.sh. Creates isolated macOS user, ARIA install, config, ports, launchd, registry entry. |
| FEAT-108 | Briefing intelligence integration | P0 | **closed** | 2026-03-24 | scripts/briefing_intelligence.py. All analytics wired into morning brief. 8 intelligence sections. |
| FEAT-109 | Email reply processor (Super ARIA feedback loop) | P0 | **closed** | 2026-03-24 | modules/openclaw/scripts/process-reply.py. Natural language → actions. 3/3 tested. |
| FEAT-110 | Revenue/business dashboard | P1 | **closed** | 2026-03-24 | scripts/revenue-dashboard.py. Port 8649. MRR, ARR, churn risk, LTV. |
| FEAT-111 | Training data collector | P1 | **closed** | 2026-03-24 | scripts/training-collector.py. JSONL pairs for LoRA fine-tuning. |
| FEAT-112 | Client success automation | P1 | **closed** | 2026-03-24 | scripts/client-success.py. Churn prevention. Alerts Kelly, auto check-in drafts. |

---

## Open Features (Phase 2: Low-Touch)

| # | Feature | Priority | Status | Source | Notes |
|---|---------|----------|--------|--------|-------|
| FEAT-020 | Practice management integration (Dentrix/Eaglesoft/Open Dental) | P2 | open | 2026-03-23 pilot Phase B | Research APIs first |
| FEAT-021 | Insurance form processing via vision model | P3 | open | 2026-03-23 pilot Phase C | Qwen2.5-VL-32B |
| FEAT-022 | Client fine-tuning pipeline (LoRA on email data) | P3 | open | 2026-03-23 architecture decision | Needs ~6 months of data |
| FEAT-023 | Qdrant memory layer (semantic search) | P3 | **closed** | 2026-03-24 | scripts/aria_memory.py + memory-index.py. 144 docs indexed, nomic-embed-text, Qdrant. Cross-source search works. |
| FEAT-024 | Contact profiles (per-person relationship data) | P3 | **closed** | 2026-03-24 | scripts/contact-profiles.py. Extracts from email/Slack/calendar. Persistent config/contacts.json. |
| FEAT-025 | Client engagement scorecard | P3 | **closed** | 2026-03-24 | scripts/engagement-scorecard.py. Per-project health grades, trends, flags. JSON + HTML output. |

## Open Features (Phase 2.5: Multi-Machine / OpenClaw)

| # | Feature | Priority | Status | Source | Notes |
|---|---------|----------|--------|--------|-------|
| FEAT-050 | OpenClaw agent module (soul file, config, setup, hardening) | P2 | **closed** | 2026-03-24 | modules/openclaw/. Full setup runbook + verify script. |
| FEAT-051 | Bidirectional comms system (Pro/Air via GitHub repo) | P2 | **closed** | 2026-03-24 | modules/comms/. send-task, send-update, pull-updates, sync-data scripts. |
| FEAT-052 | ARIA repo on GitHub (enables Air to clone, comms to work) | P1 | open | 2026-03-24 | Blocker for multi-machine setup. ARIA not yet a git repo. |
| FEAT-053 | MacBook Air setup (dedicated user, OpenClaw, data sync) | P2 | open | 2026-03-24 | Blocked by FEAT-052, FEAT-040, FEAT-041. Runbook ready at modules/openclaw/SETUP_RUNBOOK.md |

## Open Features (Phase 3: Self-Serve)

| # | Feature | Priority | Status | Source | Notes |
|---|---------|----------|--------|--------|-------|
| FEAT-030 | Self-serve installer (client runs on fresh Mac Mini) | P2 | **closed** | 2026-03-24 | install/ARIA-Install.command (double-click). Evolved from setup-client.sh. |
| FEAT-031 | Web-based onboarding wizard (connect accounts, set preferences) | P2 | **closed** | 2026-03-24 | scripts/onboarding-server.py (Flask, port 8642). Full OAuth flow. |
| FEAT-032 | Client portal (view status, briefings, data sources, support requests) | P2 | **closed** | 2026-03-24 | scripts/client-portal.py. Port 8646, token auth, support tickets alert via Telegram. |
| FEAT-033 | Stripe billing integration (SaaS subscriptions) | P2 | **closed** | 2026-03-24 | scripts/billing.py. Port 8647, Checkout sessions, subscriptions, webhooks, pricing config. |
| FEAT-034 | Hardware pre-configuration and shipping pipeline | P3 | open | 2026-03-23 trajectory decision | Image Mac Minis, ship direct |
| FEAT-035 | Automated remediation (self-healing before alerting Sean) | P3 | **closed** | 2026-03-24 | scripts/remediate.py. Auto-fix Docker, n8n, inference, Telegram, briefing, stale data. 2 retries then escalate. |
| FEAT-036 | Client-facing status page ("Your system is healthy") | P3 | **closed** | 2026-03-24 | scripts/status-page.py. Flask on port 8644, auto-refresh, services + data freshness. API at /api/status. |
| FEAT-037 | Multi-tenant management dashboard (Sean's view of all clients) | P3 | **closed** | 2026-03-24 | scripts/admin-dashboard.py. Port 8645, polls client status APIs, KPIs, dark theme. config/clients-registry.json. |

---

## Infrastructure

| # | Item | Priority | Status | Trigger | Notes |
|---|------|----------|--------|---------|-------|
| INFRA-001 | Run ARIA 24/7 on Sean's system as reference deployment | P0 | open | Immediate | Must be stable before client deploy |
| INFRA-002 | Docker Compose hardened config (restart policies, resource limits) | P1 | **closed** | 2026-03-24 | config/docker-compose.production.yml. Resource limits, health checks, log rotation, loopback-only ports. |
| INFRA-003 | Remote access solution (Tailscale for client support) | P2 | **closed** | 2026-03-24 | scripts/setup-tailscale.sh. Installs Tailscale, WireGuard encrypted P2P VPN. |
| INFRA-004 | Backup strategy for client inbox/briefing data | P2 | **closed** | 2026-03-24 | scripts/backup.sh. Daily rsync to ~/ARIA-backups/, 7-day retention, credentials excluded. Tested: 664K. |
| INFRA-005 | ARIA into GitHub repo (private) | P0 | open | Immediate | Required for multi-machine, deployment packaging, version control |

---

## Deferred

| # | Item | Priority | Reason |
|---|------|----------|--------|
| DEF-001 | Full HIPAA compliance (BAAs, audit logging, encryption at rest) | P2 | Requires legal work. Not needed for pilot. Revisit after first 3 clients. |
| DEF-002 | Multi-user support (different briefings for different team members) | P3 | V2 feature. Pilot is single-user (practice owner). |
| DEF-003 | Client-facing status dashboard | P3 | Superseded by FEAT-012 (local dashboard) and FEAT-036 (client status page). |

---

## Implemented (2026-03-24)

| # | Item | Type | Notes |
|---|------|------|-------|
| BUG-001 | Timezone fixed (Montevideo → Chicago) | Bug | config/aria.json |
| BUG-002 | Telegram token moved to .env | Bug | aria-telegram-bot.py + .env |
| BUG-003 | Authorized users set from config | Bug | aria-telegram-bot.py + aria.json |
| FEAT-002 | Health monitoring (5-min checks, Telegram alerts) | Feature | scripts/health-check.py + launchd |
| FEAT-003 | Auto-restart (stack-start RunAtLoad, stack-stop removed) | Feature | launchd plists |
| FEAT-004 | Graceful degradation (all generators have fallback) | Feature | Already existed, verified |
| FEAT-005 | One-command setup script | Feature | scripts/setup-client.sh |
| FEAT-006 | SMTP fallback for email delivery | Feature | scripts/aria_email.py |
| FEAT-007 | Config-driven deployment | Feature | config/client-schema.json + scripts/generate-client-config.py |
| FEAT-008 | Per-client Telegram bot provisioning | Feature | Bot reads config from aria.json + .env |
| FEAT-009 | OAuth onboarding flow | Feature | scripts/onboarding-server.py (Flask), email-sync.py, calendar-sync.py |
| FEAT-011 | Dental practice briefing template | Feature | templates/dental-briefing-email.md |
| FEAT-012 | Local dashboard (Flask web UI) | Feature | scripts/aria-dashboard.py, port 8643 |
| FEAT-013 | macOS menu bar app | Feature | scripts/aria-menubar.py, rumps |
| FEAT-014 | Maintenance/cleanup script | Feature | scripts/maintenance.py |
| FEAT-015 | Deployment packager | Feature | scripts/package-deploy.sh |
| FEAT-016 | Double-click installer | Feature | install/ARIA-Install.command |
| FEAT-017 | Legal docs (ToS, Privacy Policy) | Feature | install/terms-of-service.html, install/privacy-policy.html |
| FEAT-018 | Download/landing page | Feature | install/download.html |
| FEAT-019 | Workflow optimization engine | Feature | scripts/workflow-optimizer.py (Kelly's north star) |
| FEAT-030 | Self-serve installer | Feature | Closed early: install/ARIA-Install.command |
| FEAT-031 | Web-based onboarding wizard | Feature | Closed early: scripts/onboarding-server.py |
| FEAT-050 | OpenClaw agent module | Feature | modules/openclaw/ |
| FEAT-051 | Bidirectional comms system | Feature | modules/comms/ |
| FEAT-010 | AI router (local vs cloud, 85/15 split) | Feature | aria_ai.py: cloud=True, escalate=True, config-driven |
| — | Shared AI client module (aria_ai.py) | Infrastructure | All scripts + config centralized |
| — | All scripts migrated to OpenAI-compatible API | Infrastructure | 8 Python scripts + 7 n8n workflows |
| — | 24/7 operation (no scheduled shutdown) | Infrastructure | launchd changes |

---

## Stats

| Category | Open | In Progress | Closed | Total |
|----------|------|-------------|--------|-------|
| Bugs | 0 | 0 | 4 | 4 |
| Features (Phase 1 Foundation) | 0 | 0 | 10 | 11 |
| Features (Phase 1.5 Pilot Readiness) | 0 | 2 | 10 | 12 |
| Features (Phase 1.75 Intelligence) | 0 | 0 | 7 | 7 |
| Features (Phase 2 Low-Touch) | 3 | 0 | 3 | 6 |
| Features (Phase 2.5 OpenClaw) | 2 | 0 | 2 | 4 |
| Features (Phase 3 Self-Serve) | 0 | 0 | 6 | 6 |
| Infrastructure | 2 | 0 | 3 | 5 |
| Deferred | 3 | - | - | 3 |
| **Totals** | **10** | **2** | **45** | **58** |
