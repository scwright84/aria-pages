# Dental Software Integration Research

Last updated: 2026-03-25. Research for pilot with Dr. Paul Kelley (Forest Hills Prosthodontics).

## Paul's Software Stack

| Software | Category | API Available | Realistic Path | Effort | Timeline |
|----------|----------|--------------|----------------|--------|----------|
| Dentrix | Practice management | COM/DLL (G) or REST (Ascend) | CSV export (fast) or developer program (slow) | Medium-High | Days (CSV) or 2-4 months (API) |
| Dexis | Digital X-ray | Partner-only (new, undocumented) | Folder watching for exports | Medium | Days |
| Romexis (Planmeca) | CBCT, panoramic, 3D | No API, full DICOM support | DICOM listener (pydicom/pynetdicom) | Medium | 1-2 weeks |
| Medit Link | Intraoral scanner | Full REST API + OAuth2 + Webhooks | Apply as partner, build integration | Low | 1-2 weeks (5-7 day partner approval) |
| Shining 3D | Intraoral scanner | None | Folder watching for STL/OBJ exports | Low | Days |
| Practice By Numbers | Analytics | No public API | CSV/PDF report export ingestion | Low | Days |
| Overjet | AI X-ray analysis | None (enterprise only) | Read results from PMS, not Overjet directly | N/A | N/A |

## Detailed Findings

### Dentrix (Practice Management) — THE KEY INTEGRATION

**Dentrix G (On-Premise — most likely what Paul runs):**
- Henry Schein One runs a developer program for integrations
- Primary API is **DAPI** — a COM-based Windows DLL, not REST. Local only.
- Access: patient demographics, appointments/schedules, treatment plans, insurance/claims, billing/ledger, provider info. Clinical notes are limited.
- Developer program requires: partnership agreement, NDA, certification/QA process
- Cost: ~$2,000-5,000 for SDK + annual maintenance (negotiable)
- Timeline: 2-4 months from application to certified integration
- Database: Faircom c-tree (proprietary). Direct access not supported and risks voiding support.
- **Dentrix Enterprise** tier has SQL Server views — cleanest local data access but requires Enterprise license

**Dentrix Ascend (Cloud — less likely for independent practice):**
- REST API with OAuth 2.0 — much more modern
- Also gated behind Henry Schein developer program
- Multi-location native (built for DSOs)
- Lower market penetration than G for independent practices

**Pragmatic path for pilot:**
1. **Immediate (days):** Configure Dentrix to export daily schedule/claims reports as CSV to a watched folder. ARIA ingests automatically. Zero API needed.
2. **Near-term (month 2):** Apply to Henry Schein developer program. Use CSV export while waiting.
3. **Long-term (month 4+):** Certified DAPI integration for real-time data.

**CRITICAL QUESTION FOR PAUL:** Which version — Dentrix G or Dentrix Ascend? And which tier (Standard, Professional, Enterprise)?

### Medit Link (Intraoral Scanner) — BEST INTEGRATION STORY

Full OpenAPI with OAuth2 authentication. Documented at api-doc.meditlink.com.

**Available endpoints:**
- User and Group management
- Case search and retrieval (GET /v1/cases/search, GET /v1/cases/{caseUuid})
- File download and upload (GET /v1/files/{fileUuid}, POST /v1/files/upload)
- Order management (search, accept, reject, cancel)
- Webhooks for real-time event notifications

**Scopes:** USER, GROUP, CASE, FILE, FILE:MANAGE, ORDER, ORDER:MANAGE, WEBHOOK:MANAGE
**Auth:** OAuth2 (Authorization Code, Implicit, Password, Client Credentials)
**File formats:** STL, OBJ, PLY, proprietary meditmesh
**Partner application:** medit.com/partner-application, 5-7 business days

### Romexis / Planmeca (CBCT, Panoramic, 3D) — DICOM PATH

No REST API, but full DICOM 3.0 support:
- Import/Export, Storage SCU/SCP, Worklist SCU, Query/Retrieve SCU/SCP, Storage Commitment SCU, MPPS
- Conformance statement published
- File export: JPEG, TIFF, PNG, BMP (2D); STL, PLY, OBJ (3D); DICOM for both
- Also supports "Generic 3D/2D/portal launch" — command-line-style integrations
- Python libraries pydicom and pynetdicom make DICOM listener straightforward

### Dexis (Digital X-Ray) — LIMITED

- New API announced Feb 2026 but no public docs — partner-level only
- TWAIN interface available but costs $1,500/installation for third-party module
- STL export for jaws/teeth available
- Realistic path: folder watching for exported images
- Overjet integrates with Dexis 9 and 10, so AI X-ray findings flow through to PMS

### Practice By Numbers — ANALYTICS LAYER

- No public developer API
- Connects inbound FROM practice management systems (Dentrix, Eaglesoft, Open Dental, etc.)
- Report exports available (CSV/PDF)
- KPIs tracked: production (by provider/procedure), collections, case acceptance, new patient flow, scheduling efficiency, AR aging, treatment plan conversion, hygiene reappointment rates
- Pragmatic path: scheduled CSV report export into ARIA inbox folder

### Overjet (AI X-Ray Analysis) — DON'T INTEGRATE DIRECTLY

- No public API, enterprise partnerships only
- Integrates with: Dentrix G5+, Dentrix Enterprise, Eaglesoft, Open Dental, CareStack, Denticon
- Imaging integrations: Apteryx, CareStream, DEXIS 9/10, Eaglesoft Imaging, and others
- Renders AI overlays directly on radiographs within existing imaging software
- Results sync into PMS automatically
- **ARIA strategy:** Read Overjet findings from the PMS side, not from Overjet directly

### Shining 3D (Intraoral Scanner) — FILE EXPORT ONLY

- No public API or developer SDK
- Exports STL, OBJ, PLY (open formats)
- Cloud platform for clinic-to-lab data transmission (closed ecosystem)
- Folder watching is the only realistic path

## Insurance Claims Integration

### Standard Format
- **HIPAA-mandated ASC X12 837D** (dental claims)
- Current version: X12 005010X224A2
- Related transactions: 276/277 (claim status), 270/271 (eligibility), 835 (remittance/payment)

### Clearinghouses

| Clearinghouse | Notes |
|---------------|-------|
| DentalXChange (Henry Schein One) | Largest dental-specific. Full 837D, 270/271, 276/277. Requires trading partner agreement. |
| Tesia / Vyne Dental (formerly NEA) | Strong on attachments (X-rays, perio charts). Full clearinghouse now. |
| Availity | Free for providers. REST API. Strong with BCBS, Humana. |
| Change Healthcare (Optum/UHC) | Massive. Full API suite. Hit by ransomware Feb 2024. |
| Apex EDI | Smaller, developer-friendly REST APIs. |

### Fastest Path: Abstraction Layer APIs

These abstract away clearinghouse complexity — no X12 knowledge needed:

| Service | What It Does | Cost |
|---------|-------------|------|
| **Eligible** (eligible.com) | REST/JSON API for eligibility verification. Dental-specific support. | Pay-per-transaction |
| **PVerify** | REST API for eligibility. Dental support. | Pay-per-transaction |
| **Stedi** | X12-to-JSON translation layer. Developer-friendly healthcare EDI. | Pay-per-transaction |
| **Candid Health** | Revenue cycle API platform. | Enterprise pricing |

Per-transaction costs: $0.10-0.75 per eligibility check or claim status query.
Setup: Sign BAA, integrate their API, live in weeks not months.

### Pre-Authorization Reality
- Submitted as 837D with claim frequency code "3" (predetermination)
- Status checked via 276/277 transaction through clearinghouses
- No carrier offers a direct public API — everything goes through clearinghouses
- CMS Prior Authorization Rule (CMS-0057-F) requires payers to implement FHIR APIs by Jan 2027, but only for Medicare Advantage/Medicaid/CHIP — commercial dental not directly covered

### Carrier-Specific Notes

| Carrier | Electronic Pre-Auth | Access Method |
|---------|-------------------|---------------|
| Delta Dental | Yes | Through clearinghouses only. ~80M enrollees, largest dental carrier. State plans may differ. |
| MetLife | Yes | Clearinghouses. Provider portal supports pre-auth status. |
| Cigna | Yes | Clearinghouses. Provider portal available. |
| Aetna | Yes | Clearinghouses. Moving toward real-time. |
| Guardian | Yes | Clearinghouses. Modern provider portal. |
| BCBS | Varies by plan | Each plan independent. Most route through Availity. |
| United Healthcare Dental | Yes | Through Change Healthcare/Optum. |

## The "AI Employee" Integration Strategy

The core insight: **ARIA doesn't need APIs if it can be a user.** With the office's cooperation, we treat ARIA like a new hire — it gets login credentials, folder access, and email forwarding. Browser automation + folder watching + email parsing covers 80% of what formal API integrations would provide, and the office can set it up in an afternoon.

This is the primary integration strategy for the pilot. Formal API integrations (Medit Link, Dentrix DAPI, clearinghouse connections) are Phase C optimizations — nice to have, not required.

### Integration Method #1: Folder Watching

ARIA monitors specific directories on the office server/workstations for new or changed files. Zero software changes required — just configure the existing software to export where ARIA can see it.

| Software | What to Watch | What ARIA Gets |
|----------|--------------|----------------|
| **Dentrix** | Report scheduler output folder, Letters merge export folder | Daily schedule, patient lists, aging claims reports, production summaries |
| **Dentrix** | `C:\Dentrix\Data\` export area (if Enterprise: SQL Views via scheduled query dumps) | Treatment plans, insurance info, ledger data |
| **Dexis** | Image storage directory (organized per patient) | New X-rays taken today, which patients had imaging |
| **Romexis** | DICOM auto-export folder (configure in Romexis settings) | New CBCT scans, panoramic images, 3D studies |
| **Medit Link** | Local scan export folder (STL/OBJ files) | New intraoral scans, case completions |
| **Shining 3D** | STL/OBJ export directory | Same as Medit — new scans |
| **Overjet** | Not needed — results flow into Dentrix | Read Overjet AI findings from Dentrix reports |
| **Any software** | PDF printer output folder (CUPS-PDF or similar) | Any report from any software that can print |

**Setup:** One-time configuration per workstation. Staff workflow doesn't change — software just exports to a folder ARIA watches instead of (or in addition to) the default location.

**The print-to-file trick:** For any software that can print but can't export, install a PDF virtual printer that saves to ARIA's watched folder. Staff "prints" a report, ARIA ingests the PDF. Works with literally anything.

### Integration Method #2: Browser Automation

ARIA gets its own login credentials for web-based portals and uses browser automation (Playwright) to log in, navigate, and extract data on a schedule. Runs on the Mac Mini alongside everything else.

| Portal | What ARIA Does | What the Briefing Gets |
|--------|---------------|----------------------|
| **Insurance carrier portals** (Delta Dental, MetLife, Cigna, Aetna, Guardian, BCBS, UHC) | Logs in daily, checks claim status dashboard, downloads EOBs | Claim status changes, new denials, payment received, pre-auth approvals/expirations |
| **Practice By Numbers** | Logs in, scrapes KPI dashboard, exports weekly production report | Production, collections, case acceptance rate, scheduling efficiency, AR aging |
| **Dentrix Ascend** (if cloud version) | Logs in, pulls schedule and claims data | Same as Dentrix G folder watching but via browser |
| **Lab portals** (if Marotta/Aurum have online tracking) | Checks case status, delivery dates | Lab case progress, shipping confirmations, ETAs |
| **Overjet dashboard** (if web-based) | Scrapes AI findings and flagged X-rays | AI-detected issues surfaced in morning briefing |

**Setup:** Office creates an ARIA user account on each portal. We store credentials securely in ARIA's encrypted config. Playwright runs headless on the Mac Mini on a cron schedule (e.g., 6 AM before the briefing).

**Resilience:** Portal UIs change occasionally. Each scraper is a simple Python script — easy to update when a portal redesigns. We monitor for login failures and alert in the health dashboard.

### Integration Method #3: Email Parsing

A huge amount of dental admin flows through email. ARIA already ingests email — it just needs dental-specific parsing rules.

| Email Source | What ARIA Extracts |
|-------------|-------------------|
| **Insurance companies** | EOBs (Explanation of Benefits), claim status updates, pre-auth approvals/denials, payment notifications |
| **Labs** (Marotta, Aurum) | Shipping confirmations, tracking numbers, case status updates, remake notifications |
| **Patient inquiry forms** | New patient name, referral source, reason for visit, contact info |
| **Appointment reminders** (if using a patient communication tool) | Confirmation replies, cancellation notices |
| **Vendor invoices** | Supply orders, equipment service notifications |

**Setup:** Forward the office email to ARIA (or give ARIA read access via OAuth). Add dental-specific parsing templates that extract structured data from common email formats (insurance EOBs follow predictable layouts).

**The lab email trick:** Lab shipping confirmations almost always include a tracking number and case description. ARIA parses these and cross-references with the patient schedule to flag "case arriving today, patient at 3:30 PM."

### Integration Method #4: Formal APIs (Phase C Optimization)

These are the "real" integrations to pursue once the pilot proves value. They replace the scrappy methods above with more reliable, real-time connections.

| Integration | Method | When |
|-------------|--------|------|
| **Medit Link** | REST API + OAuth2 + Webhooks | Month 1-2 (partner approval: 5-7 days) |
| **Eligible / PVerify** | REST API for insurance eligibility | Month 1-2 (sign BAA, integrate) |
| **Dentrix DAPI** | COM/DLL via developer program | Month 3-4 (apply now, use folder watching meanwhile) |
| **Clearinghouse** (DentalXChange) | EDI 276/277 for claim status | Month 4+ (trading partner agreement) |
| **FHIR** | Emerging standard, payer APIs | 2027+ (CMS mandate coming) |

### What the Office Needs to Do (Onboarding Checklist)

This is what we walk Paul through during setup:

1. **Create an ARIA user account** on: Dentrix, insurance carrier portals, Practice By Numbers, lab portals (if web-based)
2. **Configure Dentrix report scheduler** to export daily schedule + aging claims report to a shared folder
3. **Set up a PDF virtual printer** on one workstation for ad-hoc report capture
4. **Forward office email** to ARIA (or grant OAuth read access)
5. **Configure Romexis DICOM auto-export** to ARIA's watched folder (one-time setting)
6. **Share credentials securely** via ARIA's encrypted onboarding flow (never stored in plaintext)

Total setup time: ~1 hour with someone at the front desk. No IT contractor needed.

## Phased Integration Plan

### Phase A: Pilot Deploy (Weeks 1-4)
- Email + Calendar + Morning Briefing + Telegram
- **Folder watching:** Dentrix scheduled report exports (daily schedule, aging claims)
- **Email parsing:** Lab shipping confirmations, insurance EOBs from office inbox
- **PDF printer:** Set up on one workstation for ad-hoc report ingestion
- Value: morning briefing with real schedule + claims data. No APIs needed.

### Phase B: Browser Automation + Quick APIs (Month 1-2)
- **Browser automation:** Insurance carrier portals (claim status, pre-auth tracking)
- **Browser automation:** Practice By Numbers KPI scraping
- **Medit Link API:** Real integration — case tracking, scan status, webhooks
- **Eligible/PVerify API:** Real-time insurance eligibility verification
- **DICOM listener:** Romexis auto-export for new imaging studies
- Value: briefing now includes live claim status, practice metrics, and scan tracking.

### Phase C: Formal Integrations (Month 3+)
- **Dentrix DAPI:** Apply to developer program now, certified integration by month 3-4
- **Clearinghouse connection:** DentalXChange for 276/277 claim status (replaces browser scraping)
- **Denial management:** AI-drafted appeal letters with attached documentation
- **Revenue cycle analytics:** Production vs. collection trends in weekly rollup
- Value: replaces scrappy methods with reliable real-time connections. Browser automation becomes the fallback, not the primary path.

## Questions for Discovery Call (3/26, 3:30 PM ET)

1. Which Dentrix version — G (installed in office) or Ascend (cloud/browser)?
2. Which Dentrix tier — Standard, Professional, or Enterprise?
3. Who manages IT? In-house or outsourced?
4. What's the biggest daily pain? Schedule gaps? Claim follow-ups? Patient recall?
5. How many claims per month? What percentage get denied?
6. Which insurance carriers make up the bulk of patients?
7. How many lab cases per week? Which labs?
8. Would a scheduled report export be acceptable as a starting point?
9. What does "winning" look like in 90 days?
