# Dental Software Integration Research

Last updated: 2026-03-25. Research for pilot with Dr. Paul Kelley (Forest Hills Prosthodontics).

## Paul's Software Stack

| Software | Category | API Available | Realistic Path | Effort | Timeline |
|----------|----------|--------------|----------------|--------|----------|
| Dentrix | Practice management | COM/DLL (G) or REST (Ascend) | CSV export (fast) or developer program (slow) | Medium-High | Days (CSV) or 2-4 months (API) |
| Dexis | Digital X-ray | Partner-only (new, undocumented) | Folder watching for exports | Medium | Days |
| Romexis (Planmeca) | CBCT, panoramic, 3D | No API, full DICOM support | DICOM listener (pydicom/pynetdicom) | Medium | 1-2 weeks |
| Medit Link | Intraoral scanner | Full REST API + OAuth2 + Webhooks | Apply as partner, build integration | Low | 1-2 weeks (5-7 day partner approval) |
| Shining 3D | Intraoral scanner | None | Folder watching for STL/OBJ exports | Low | Days |
| Practice By Numbers | Analytics | No public API | CSV/PDF report export ingestion | Low | Days |
| Overjet | AI X-ray analysis | None (enterprise only) | Read results from PMS, not Overjet directly | N/A | N/A |

## Detailed Findings

### Dentrix (Practice Management) — THE KEY INTEGRATION

**Dentrix G (On-Premise — most likely what Paul runs):**
- Henry Schein One runs a developer program for integrations
- Primary API is **DAPI** — a COM-based Windows DLL, not REST. Local only.
- Access: patient demographics, appointments/schedules, treatment plans, insurance/claims, billing/ledger, provider info. Clinical notes are limited.
- Developer program requires: partnership agreement, NDA, certification/QA process
- Cost: ~$2,000-5,000 for SDK + annual maintenance (negotiable)
- Timeline: 2-4 months from application to certified integration
- Database: Faircom c-tree (proprietary). Direct access not supported and risks voiding support.
- **Dentrix Enterprise** tier has SQL Server views — cleanest local data access but requires Enterprise license

**Dentrix Ascend (Cloud — less likely for independent practice):**
- REST API with OAuth 2.0 — much more modern
- Also gated behind Henry Schein developer program
- Multi-location native (built for DSOs)
- Lower market penetration than G for independent practices

**Pragmatic path for pilot:**
1. **Immediate (days):** Configure Dentrix to export daily schedule/claims reports as CSV to a watched folder. ARIA ingests automatically. Zero API needed.
2. **Near-term (month 2):** Apply to Henry Schein developer program. Use CSV export while waiting.
3. **Long-term (month 4+):** Certified DAPI integration for real-time data.

**CRITICAL QUESTION FOR PAUL:** Which version — Dentrix G or Dentrix Ascend? And which tier (Standard, Professional, Enterprise)?

### Medit Link (Intraoral Scanner) — BEST INTEGRATION STORY

Full OpenAPI with OAuth2 authentication. Documented at api-doc.meditlink.com.

**Available endpoints:**
- User and Group management
- Case search and retrieval (GET /v1/cases/search, GET /v1/cases/{caseUuid})
- File download and upload (GET /v1/files/{fileUuid}, POST /v1/files/upload)
- Order management (search, accept, reject, cancel)
- Webhooks for real-time event notifications

**Scopes:** USER, GROUP, CASE, FILE, FILE:MANAGE, ORDER, ORDER:MANAGE, WEBHOOK:MANAGE
**Auth:** OAuth2 (Authorization Code, Implicit, Password, Client Credentials)
**File formats:** STL, OBJ, PLY, proprietary meditmesh
**Partner application:** medit.com/partner-application, 5-7 business days

### Romexis / Planmeca (CBCT, Panoramic, 3D) — DICOM PATH

No REST API, but full DICOM 3.0 support:
- Import/Export, Storage SCU/SCP, Worklist SCU, Query/Retrieve SCU/SCP, Storage Commitment SCU, MPPS
- Conformance statement published
- File export: JPEG, TIFF, PNG, BMP (2D); STL, PLY, OBJ (3D); DICOM for both
- Also supports "Generic 3D/2D/portal launch" — command-line-style integrations
- Python libraries pydicom and pynetdicom make DICOM listener straightforward

### Dexis (Digital X-Ray) — LIMITED

- New API announced Feb 2026 but no public docs — partner-level only
- TWAIN interface available but costs $1,500/installation for third-party module
- STL export for jaws/teeth available
- Realistic path: folder watching for exported images
- Overjet integrates with Dexis 9 and 10, so AI X-ray findings flow through to PMS

### Practice By Numbers — ANALYTICS LAYER

- No public developer API
- Connects inbound FROM practice management systems (Dentrix, Eaglesoft, Open Dental, etc.)
- Report exports available (CSV/PDF)
- KPIs tracked: production (by provider/procedure), collections, case acceptance, new patient flow, scheduling efficiency, AR aging, treatment plan conversion, hygiene reappointment rates
- Pragmatic path: scheduled CSV report export into ARIA inbox folder

### Overjet (AI X-Ray Analysis) — DON'T INTEGRATE DIRECTLY

- No public API, enterprise partnerships only
- Integrates with: Dentrix G5+, Dentrix Enterprise, Eaglesoft, Open Dental, CareStack, Denticon
- Imaging integrations: Apteryx, CareStream, DEXIS 9/10, Eaglesoft Imaging, and others
- Renders AI overlays directly on radiographs within existing imaging software
- Results sync into PMS automatically
- **ARIA strategy:** Read Overjet findings from the PMS side, not from Overjet directly

### Shining 3D (Intraoral Scanner) — FILE EXPORT ONLY

- No public API or developer SDK
- Exports STL, OBJ, PLY (open formats)
- Cloud platform for clinic-to-lab data transmission (closed ecosystem)
- Folder watching is the only realistic path

## Insurance Claims Integration

### Standard Format
- **HIPAA-mandated ASC X12 837D** (dental claims)
- Current version: X12 005010X224A2
- Related transactions: 276/277 (claim status), 270/271 (eligibility), 835 (remittance/payment)

### Clearinghouses

| Clearinghouse | Notes |
|---------------|-------|
| DentalXChange (Henry Schein One) | Largest dental-specific. Full 837D, 270/271, 276/277. Requires trading partner agreement. |
| Tesia / Vyne Dental (formerly NEA) | Strong on attachments (X-rays, perio charts). Full clearinghouse now. |
| Availity | Free for providers. REST API. Strong with BCBS, Humana. |
| Change Healthcare (Optum/UHC) | Massive. Full API suite. Hit by ransomware Feb 2024. |
| Apex EDI | Smaller, developer-friendly REST APIs. |

### Fastest Path: Abstraction Layer APIs

These abstract away clearinghouse complexity — no X12 knowledge needed:

| Service | What It Does | Cost |
|---------|-------------|------|
| **Eligible** (eligible.com) | REST/JSON API for eligibility verification. Dental-specific support. | Pay-per-transaction |
| **PVerify** | REST API for eligibility. Dental support. | Pay-per-transaction |
| **Stedi** | X12-to-JSON translation layer. Developer-friendly healthcare EDI. | Pay-per-transaction |
| **Candid Health** | Revenue cycle API platform. | Enterprise pricing |

Per-transaction costs: $0.10-0.75 per eligibility check or claim status query.
Setup: Sign BAA, integrate their API, live in weeks not months.

### Pre-Authorization Reality
- Submitted as 837D with claim frequency code "3" (predetermination)
- Status checked via 276/277 transaction through clearinghouses
- No carrier offers a direct public API — everything goes through clearinghouses
- CMS Prior Authorization Rule (CMS-0057-F) requires payers to implement FHIR APIs by Jan 2027, but only for Medicare Advantage/Medicaid/CHIP — commercial dental not directly covered

### Carrier-Specific Notes

| Carrier | Electronic Pre-Auth | Access Method |
|---------|-------------------|---------------|
| Delta Dental | Yes | Through clearinghouses only. ~80M enrollees, largest dental carrier. State plans may differ. |
| MetLife | Yes | Clearinghouses. Provider portal supports pre-auth status. |
| Cigna | Yes | Clearinghouses. Provider portal available. |
| Aetna | Yes | Clearinghouses. Moving toward real-time. |
| Guardian | Yes | Clearinghouses. Modern provider portal. |
| BCBS | Varies by plan | Each plan independent. Most route through Availity. |
| United Healthcare Dental | Yes | Through Change Healthcare/Optum. |

## Phased Integration Plan

### Phase A: Pilot (Weeks 1-4) — No Software Integration
- Email + Calendar + Morning Briefing + Telegram
- Value: saves 30 min/day, zero integration needed

### Phase B: Quick Wins (Month 1-2)
- Dentrix CSV export ingestion (folder watching) — schedule, patient lists, claims
- Real-time insurance eligibility via Eligible or PVerify API
- Medit Link API integration (case tracking, scan status)
- Practice By Numbers report ingestion (CSV export)

### Phase C: Deep Integration (Month 3+)
- Formal Dentrix developer program (DAPI or Ascend REST)
- DICOM listener for Romexis imaging
- Clearinghouse connection for claim status monitoring (276/277)
- Denial management + AI-drafted appeal letters
- Revenue cycle analytics in daily briefing

## Questions for Discovery Call (3/26, 3:30 PM ET)

1. Which Dentrix version — G (installed in office) or Ascend (cloud/browser)?
2. Which Dentrix tier — Standard, Professional, or Enterprise?
3. Who manages IT? In-house or outsourced?
4. What's the biggest daily pain? Schedule gaps? Claim follow-ups? Patient recall?
5. How many claims per month? What percentage get denied?
6. Which insurance carriers make up the bulk of patients?
7. How many lab cases per week? Which labs?
8. Would a scheduled report export be acceptable as a starting point?
9. What does "winning" look like in 90 days?
