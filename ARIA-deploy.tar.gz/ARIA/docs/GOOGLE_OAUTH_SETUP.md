# Google OAuth Setup (One-Time, by Sean)

This creates the Google Cloud project that ALL ARIA installations use. Do this once. Every client's installer uses the same client_id/client_secret.

## Step 1: Create Google Cloud Project

1. Go to https://console.cloud.google.com/projectcreate
2. Project name: **ARIA by Wright Advisors**
3. Organization: leave as "No organization" (or your org if you have one)
4. Click Create

## Step 2: Enable APIs

1. Go to APIs & Services > Library
2. Enable **Gmail API**
3. Enable **Google Calendar API**
4. Enable **Google People API** (for getting user email during OAuth)

## Step 3: Configure OAuth Consent Screen

1. Go to APIs & Services > OAuth consent screen
2. User type: **External**
3. Fill in:
   - App name: **ARIA**
   - User support email: sean@wrightadvisorsatx.com
   - App logo: upload ARIA logo (optional but recommended for trust)
   - App domain > Application home page: https://wrightadvisorsatx.com/aria (or wherever you host the download page)
   - App domain > Privacy policy: https://wrightadvisorsatx.com/aria/privacy-policy
   - App domain > Terms of service: https://wrightadvisorsatx.com/aria/terms-of-service
   - Developer contact email: sean@wrightadvisorsatx.com
4. Click Save and Continue

### Scopes
Add these scopes:
- `https://www.googleapis.com/auth/gmail.readonly`
- `https://www.googleapis.com/auth/gmail.labels`
- `https://www.googleapis.com/auth/calendar.readonly`
- `https://www.googleapis.com/auth/userinfo.email`
- `https://www.googleapis.com/auth/userinfo.profile`

### Test Users (for now)
Add your email and any pilot client emails as test users. Limit: 100.

## Step 4: Create OAuth Client Credentials

1. Go to APIs & Services > Credentials
2. Click "Create Credentials" > "OAuth client ID"
3. Application type: **Web application**
4. Name: **ARIA Local**
5. Authorized redirect URIs:
   - `http://localhost:8642/oauth/google/callback`
6. Click Create
7. **Download the JSON file**

## Step 5: Bundle with Installer

1. Rename the downloaded file to `google-oauth-client.json`
2. Place it in `ARIA/config/google-oauth-client.json`
3. This file ships with every installer

The `client_secret` in a "Web application" type credential is NOT truly secret (Google's own documentation acknowledges this for installed apps). The security comes from the OAuth flow itself (user must approve on Google's consent screen) and the redirect URI being locked to localhost.

## Step 6: Submit for Production Verification

When you're ready to go beyond 100 test users:

1. Go to APIs & Services > OAuth consent screen
2. Click "Publish App"
3. Google will ask for:
   - **Privacy Policy URL**: https://wrightadvisorsatx.com/aria/privacy-policy
   - **Terms of Service URL**: https://wrightadvisorsatx.com/aria/terms-of-service
   - **Justification for scopes**: See below
   - **Video demonstration**: Record a ~2 min screen recording showing the OAuth flow and how ARIA uses the data

### Scope Justification (copy-paste for Google's form)

**Gmail API (gmail.readonly, gmail.labels):**

ARIA is a locally-installed business productivity tool that generates daily briefings for small business owners. It reads the user's recent emails to:
1. Triage messages by priority (urgent, action needed, FYI, ignore)
2. Extract action items and commitments mentioned in email threads
3. Summarize key communications in a daily briefing email
4. Detect which business project or client each email relates to

All email processing occurs entirely on the user's local hardware using local AI models. Email content is never transmitted to external servers. ARIA requests read-only access and never sends, modifies, or deletes emails.

**Google Calendar API (calendar.readonly):**

ARIA reads calendar events to:
1. Include the user's daily schedule in their morning briefing
2. Generate meeting preparation notes (context on attendees, prior interactions)
3. Track commitments made in meetings against follow-through

All calendar processing occurs locally. ARIA never creates, modifies, or deletes calendar events.

**Userinfo (email, profile):**

Used solely to identify which Google account was authorized during the OAuth flow, so the user can see which accounts are connected in the ARIA dashboard.

### Video Demonstration Script

Record a 2-minute screen recording showing:
1. Open ARIA setup wizard in browser (localhost:8642)
2. Click "Connect Gmail"
3. Google consent screen appears, user approves
4. Redirected back to ARIA dashboard showing account connected
5. Show a generated briefing that uses the email data
6. Show the local file where data is stored (inbox/emails-*.json)
7. Emphasize: "All data stays on the user's computer. Nothing is uploaded."

## Step 7: Add Test Users for Pilot

Until production verification is approved:
1. Go to OAuth consent screen > Test users
2. Click "Add Users"
3. Add Kelly's brother's email
4. Add any other pilot client emails

## Ongoing Maintenance

- Monitor the Google Cloud Console for any quota issues
- OAuth tokens auto-refresh. If a user's token becomes invalid, the health check will detect it.
- If Google changes their API policies, the scopes and consent screen may need updating.
