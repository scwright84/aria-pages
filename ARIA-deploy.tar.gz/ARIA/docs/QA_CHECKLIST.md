# ARIA Pre-Deployment QA Checklist

Last updated: 2026-03-23
Use this checklist before deploying ARIA to any client. ALL items must pass.

---

## How This Works
- Run through each section sequentially
- Status: blank → `pass` → issues noted inline
- A deployment is blocked until all P0 and P1 items pass
- P2 items are recommended but not blocking

---

## Section 1: Infrastructure (P0)

| # | Test | What to Do | What You Should See | Status |
|---|------|------------|---------------------|--------|
| 1.1 | oMLX is running | `curl http://localhost:11434/v1/models` | JSON list of loaded models | |
| 1.2 | oMLX responds to queries | Send test prompt via API | Response within 10 seconds for 8B model | |
| 1.3 | n8n is running | Open http://localhost:5678 | n8n dashboard loads | |
| 1.4 | Postgres is running | `docker exec postgres pg_isready` | "accepting connections" | |
| 1.5 | Docker services restart on failure | `docker kill n8n` then wait 30s | n8n auto-restarts (restart policy) | |
| 1.6 | launchd jobs loaded | `launchctl list \| grep aria` | All expected jobs listed | |
| 1.7 | Python venv works | `.venv/bin/python3 -c "import requests"` | No error | |

## Section 2: Data Ingestion (P0)

| # | Test | What to Do | What You Should See | Status |
|---|------|------------|---------------------|--------|
| 2.1 | Email ingestion works | Trigger email workflow manually | inbox/emails-YYYY-MM-DD.json created with triaged emails | |
| 2.2 | Calendar sync works | Trigger calendar workflow manually | inbox/calendar-YYYY-MM-DD.json created with events | |
| 2.3 | Notification sync works | Run `scripts/notification-sync.py` | inbox/notifications-YYYY-MM-DD.json created | |
| 2.4 | Granola sync works | Run `scripts/granola-sync.py` | New meetings detected and forwarded | |
| 2.5 | Slack sync works (if configured) | Trigger Slack workflow manually | inbox/slack-YYYY-MM-DD.json with channel summaries | |
| 2.6 | No stale data | Check inbox/ file dates | All files from today or yesterday | |

## Section 3: Briefing Generation (P0)

| # | Test | What to Do | What You Should See | Status |
|---|------|------------|---------------------|--------|
| 3.1 | Morning briefing generates | Run `scripts/generate-briefing.py` | briefings/YYYY-MM-DD.html + .json created | |
| 3.2 | Briefing contains all sources | Open generated HTML | Sections for email, calendar, meetings, commitments | |
| 3.3 | AI analysis completes | Check briefing JSON | AI-generated summaries present (not raw data only) | |
| 3.4 | Briefing email sends | Trigger briefing email workflow | Email received in inbox | |
| 3.5 | Graceful degradation | Stop oMLX, run briefing generator | HTML generated with raw data (no AI analysis) but no crash | |
| 3.6 | SMTP fallback works | Stop n8n, trigger briefing | Email still sends via direct SMTP | |

## Section 4: Telegram Bot (P0)

| # | Test | What to Do | What You Should See | Status |
|---|------|------------|---------------------|--------|
| 4.1 | Bot responds to /start | Send /start in Telegram | Welcome message received | |
| 4.2 | Bot responds to /brief | Send /brief | Today's briefing summary | |
| 4.3 | Bot responds to free-form | Send "What's on my calendar today?" | Relevant response from AI | |
| 4.4 | Unauthorized user blocked | Send message from non-authorized Telegram account | No response or "unauthorized" message | |
| 4.5 | Bot auto-restarts | Kill bot process, wait 30s | Bot responds again (launchd KeepAlive) | |
| 4.6 | Bot token not in source code | Grep scripts for hardcoded token | Token loaded from config/env only | |

## Section 5: Health Monitoring (P1)

| # | Test | What to Do | What You Should See | Status |
|---|------|------------|---------------------|--------|
| 5.1 | Health check detects oMLX down | Stop oMLX | Alert received (Telegram or email to Sean) within 5 min | |
| 5.2 | Health check detects n8n down | Stop n8n | Alert received within 5 min | |
| 5.3 | Health check detects missed briefing | Delete today's briefing file | Alert received at briefing time + 15 min | |
| 5.4 | Health check doesn't false alarm | Run normally for 24 hours | No spurious alerts | |

## Section 6: Client Configuration (P1)

| # | Test | What to Do | What You Should See | Status |
|---|------|------------|---------------------|--------|
| 6.1 | Config file loads | Check config/aria.json | Client name, email accounts, timezone, briefing time all present | |
| 6.2 | Timezone is correct | Check briefing timestamps | Matches client's local time | |
| 6.3 | Email accounts match client | Check n8n email workflow | Only client's accounts, not Sean's | |
| 6.4 | Briefing time is correct | Check launchd plist | Matches client's preferred time | |
| 6.5 | Client name in briefing | Open generated briefing HTML | Client's practice name, not "Wright Advisors" | |

## Section 7: Security (P1)

| # | Test | What to Do | What You Should See | Status |
|---|------|------------|---------------------|--------|
| 7.1 | n8n not exposed to internet | Port scan from outside network | Port 5678 not reachable | |
| 7.2 | oMLX not exposed to internet | Port scan from outside network | Port 11434 not reachable | |
| 7.3 | No credentials in source files | Grep all scripts for tokens/passwords | None found (all in config/env) | |
| 7.4 | Telegram bot locked to client | Test from unknown Telegram account | Rejected | |
| 7.5 | Remote access requires approval | Attempt Screen Sharing connection | Client must accept prompt | |

## Section 8: Reliability (P2)

| # | Test | What to Do | What You Should See | Status |
|---|------|------------|---------------------|--------|
| 8.1 | System survives reboot | Restart Mac Mini | All services come back up, first briefing generates on time | |
| 8.2 | System survives internet outage | Disconnect Wi-Fi for 1 hour | Local processing continues, cloud escalation queued, reconnects cleanly | |
| 8.3 | System survives power loss | Hard power off, power back on | Same as reboot test | |
| 8.4 | 7-day stability test | Run continuously for 7 days | All briefings generated, no zombie processes, logs not filling disk | |

---

## Pre-Pilot Signoff

| Check | Signed Off | Date |
|-------|-----------|------|
| All P0 tests pass | | |
| All P1 tests pass | | |
| P2 tests reviewed (pass or deferred with reason) | | |
| Client config verified | | |
| Remote access tested | | |
| Sean has monitoring alerts configured | | |
