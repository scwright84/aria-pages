# ARIA Product Specification

Last updated: 2026-03-23
Status: Pre-build. Architecture locked. Pilot target: 4 weeks.

---

## What This Is

ARIA (Automated Routing & Intelligence Assistant) is an AI operating system that runs on a single piece of hardware in a client's office. It ingests all communication channels, processes them with local AI, and delivers daily intelligence: a Presidential Brief every morning, commitment tracking, draft responses, and mobile AI access via Telegram.

ARIA was built by Sean Wright as his own executive assistant. The product version packages this for deployment to small businesses, starting with dental practices as the beachhead vertical.

**One-liner:** "An AI chief of staff that runs on your hardware, learns your business, and never sends your data to the cloud."

---

## User Personas

### Primary: Practice Owner (Dental Beachhead)
- Runs a dental practice with 5-30 staff
- Drowning in email, team chat, patient follow-ups, insurance paperwork
- Knows AI exists but has no idea where to start
- Cares deeply about patient data privacy (HIPAA)
- Not technical. Will never SSH into anything.
- **Job to be done:** "Tell me what I need to know today so I can focus on patients."

### Secondary: Small Firm Principal (Attorneys, Accounting)
- Similar pain points: too many channels, nothing synthesized
- Less HIPAA sensitivity but still privacy-conscious (attorney-client privilege)
- May have a small IT person or managed service provider
- **Job to be done:** "Stop things from falling through the cracks."

### Tertiary: Solo Consultant / Fractional Executive
- Sean's own profile. Multiple clients, multiple channels per client.
- Needs per-client intelligence and cross-client awareness.
- More technical, more willing to customize.
- **Job to be done:** "Give me a unified view across all my clients."

---

## Product Layers

### Layer 1: Daily Intelligence (Entry Point)
The gateway drug. Every client starts here.

| Feature | Description | Status |
|---------|-------------|--------|
| Presidential Brief | Morning email: triaged emails, today's schedule with prep notes, commitments slipping, what's waiting on others | Built (Sean's version) |
| Evening Debrief | Compares morning plan vs. what actually happened. Surfaces what slipped. | Built (Sean's version) |
| Weekly Rollup | Per-project summary cards, decisions made, things falling through cracks | Built (Sean's version) |
| Mobile AI Access | Telegram bot. Ask anything: "What did we agree to last Tuesday?" | Built (Sean's version) |

### Layer 2: Communication Management
Layered in after the brief is part of their routine.

| Feature | Description | Status |
|---------|-------------|--------|
| Meeting Memory | Auto-extracts decisions, commitments, owners from meeting notes | Built (Granola integration) |
| Draft Response Queue | AI drafts replies for known contacts. Human approves/edits/tosses. | Built (Sean's version) |
| Commitment Tracker | "You owe" vs. "They owe you." Surfaces in briefings when items slip. | Built (Sean's version) |
| Follow-up Alerts | Proactive nudges when commitments are overdue | Built (basic version) |

### Layer 3: Document Generation
For clients who produce recurring documents.

| Feature | Description | Status |
|---------|-------------|--------|
| Proposal Generator | Intake conversation to branded multi-doc package | Built (WA consulting) |
| Investor/Board Updates | Monthly email + infographic from structured data | Built (Conceivable) |
| Assessments | Structured report cards (bilingual capable) | Built (KURBIS) |
| Branded Reports | Templated outputs with client branding | Built (WA design system) |

### Layer 4: Business Intelligence
For mature deployments.

| Feature | Description | Status |
|---------|-------------|--------|
| Financial Visibility | Budget vs. actuals, projections, variance narrative | Built (StartupCFO pattern) |
| Knowledge Base | Searchable history of all interactions, decisions, documents | Phase 3 (Qdrant) |
| Industry Monitoring | RSS + news feeds triaged by relevance | Partially built |
| Custom Workflows | Vertical-specific automation (insurance forms, case management) | Not started |

---

## Architecture

### Core Principle
85% of daily business interactions are structured, template-able, and low-stakes. These run on local AI (free, private). The 15% that need real judgment escalate to cloud AI (paid, high-quality). All data is stored locally on the client's hardware.

### Inference Engine
oMLX (Apple-native, MLX-based). Replaces Ollama. 2x faster token generation, 10x faster prompt processing. OpenAI-compatible API.

### Model Stack (48GB Mac Mini M4 Pro)
| Model | Role | Speed |
|-------|------|-------|
| Qwen3-30B-A3B (MoE) | Triage, routing, classification. Always-on. | 60-70 tok/s |
| Qwen3-32B | Draft responses, summarization. On-demand. | 15-22 tok/s |
| Qwen2.5-VL-32B | Vision: insurance forms, PDFs, scanned docs. On-demand. | 10-15 tok/s |
| Qwen3-8B + LoRA | Client-specific fine-tuned model. Personalized. | 40-55 tok/s |
| Claude API (cloud) | Customer-facing content, complex reasoning. Escalation only. | N/A |

### Fine-Tuning (The Moat)
After ~6 months of usage, fine-tune a local model on the client's communication patterns using MLX LoRA. A fine-tuned 8B model outperforms a generic 32B for that client's specific domain. Adapter files are tiny (tens of MB). Base model unchanged. This is unmatched by any cloud-only competitor.

### Orchestration
- n8n (self-hosted) for workflow automation, API integrations, scheduling
- launchd for local script execution (macOS)
- Python scripts for data sync (one-shot: run, process, exit)
- State files in logs/ prevent reprocessing

### Data Flow
```
Client Channels (Email, Calendar, Chat, Meetings)
  → Sync scripts pull data on schedule (launchd/n8n cron)
  → Triaged and saved as dated JSON in inbox/
  → Briefing generator collects all sources
  → oMLX analyzes, triages, extracts commitments
  → Output: HTML briefing email, Telegram responses, draft queue
  → All data stored locally on Mac Mini. Never leaves hardware.
  → Cloud API called ONLY for high-judgment tasks (15%)
```

### Deployment Model (Option C: Local Hardware, Cloud AI Fallback)
- Mac Mini sits in client's office (physical, tangible, owns the narrative)
- All business data stored locally (HIPAA-friendly, attorney-client privilege safe)
- 85-90% of AI processing runs locally via oMLX
- 10-15% escalates to Claude API for high-judgment tasks
- Internet required for cloud escalation and email/calendar API access
- Remote monitoring by Sean for health checks and troubleshooting

---

## Hardware Tiers

| Tier | Hardware | Price | Models | Audience |
|------|----------|-------|--------|----------|
| Starter | Mac Mini M4, 24GB | $999 | 8B models, fast triage | Solo practitioner, testing the waters |
| **Professional** | **Mac Mini M4 Pro, 48GB** | **$1,599** | **32B models, vision, fine-tuning** | **Small practice 5-30 (DEFAULT)** |
| Enterprise | Mac Mini M4 Pro, 64GB | $2,199 | 70B models, multi-model | Multi-location, large firm |
| Studio | Mac Studio M4 Max, 128GB | $3,499 | 235B MoE (frontier-competitive) | Full cloud replacement |

---

## Go-to-Market

### Vertical: Dental (Beachhead)
- **Design partner:** Kelly Kelley's brother (prosthodontist)
- **Distribution:** 7M download dentistry podcast (case study + feature)
- **Why dental:** HIPAA sensitivity makes "local AI" story especially compelling. Insurance form processing via vision model is a killer demo. Predictable practice structure makes deployment repeatable.
- **Expand to:** Attorneys, accounting firms, then general small business.

### Pilot Scope
- **Phase A (ships first):** Email + Calendar + Presidential Brief + Telegram mobile access
- **Phase B (promised, layered in):** Practice management integration (Dentrix/Eaglesoft/Open Dental), patient context in briefs
- **Phase C (future):** Insurance form processing via vision model, fine-tuned practice-specific model

### Pilot Timeline
| Phase | Timeline | Deliverable |
|-------|----------|-------------|
| Setup | Days 1-3 | Hardware configured, email/calendar integrated |
| First Intelligence | Days 4-7 | First Presidential Brief, team chat live, Telegram access |
| Full Capability | Week 2 | Meeting memory, draft responses, commitment tracking |
| Ongoing | Week 3+ | Refinement, feedback, case study content |

### Partnership: Kelly Kelley
- Structure TBD. Exploring during pilot.
- Options: sales channel, co-delivery, co-founder, or something else.
- Pilot IS the partnership trial.

---

## MVP Non-Negotiables (Before Any Client Deployment)

These must exist before the first external deployment:

1. **Health monitoring** - Alerts Sean when system is down (briefing didn't generate, oMLX not responding, n8n unreachable)
2. **Auto-restart on failure** - launchd KeepAlive on all services. System recovers without human intervention.
3. **Graceful degradation** - Briefing generates with raw data if AI analysis fails. Better than nothing.
4. **One-command setup** - Script that takes a fresh Mac Mini from unboxing to fully configured ARIA.
5. **Reliable briefing delivery** - Email lands every morning. SMTP fallback if n8n is flaky.
6. **Config-driven deployment** - Client name, email accounts, calendar accounts, channels, briefing time, timezone all in one config file.
7. **Per-client Telegram bot** - Separate bot instance per deployment.
8. **OAuth onboarding flow** - "Connect your Gmail" / "Connect your calendar" that a non-technical person can complete.

---

## Business Trajectory: Concierge → Low-Touch → Self-Serve

### Phase 1: Concierge (Months 1-6)
- Sean deploys everything personally
- Learning curve: Client 1 = 40 hrs, Client 5 = 8 hrs, Client 10 = 5 hrs
- Revenue: Setup fee ($5,000) + monthly retainer ($750)
- Target: 1-3 clients/month
- Gross margin: 40-50%
- **This is where we learn what every client needs**

### Phase 2: Low-Touch (Months 7-18)
- Deployment toolkit handles 90% of setup
- Sean does 1-hour onboarding call + remote config (2-5 hrs total)
- Revenue: Lower setup fee ($2,500) + same retainer ($750)
- Target: 3-8 clients/month
- Gross margin: 65-75%
- **This is where the product solidifies**

### Phase 3: Self-Serve (Month 18+)
- Client orders pre-configured Mac Mini from portal
- Runs installer, connects accounts through guided OAuth flow
- Revenue: Hardware markup ($700) + SaaS subscription ($500/mo)
- Target: 10+ clients/month
- Gross margin: 80-90%
- **This is where it becomes a real product business**

The entire build strategy is designed to move toward self-serve. Every piece of infrastructure built in Phase 1 should be architected with Phase 3 in mind: config-driven, no hardcoded values, automated health checks, guided onboarding.

## Build Phases (Phase 1 Detail)

| Phase | Timeline | Focus | Deliverable |
|-------|----------|-------|-------------|
| 1 | Week 1 | Harden core | Swap to oMLX, run ARIA 24/7, fix config issues, validate on Sean's system |
| 2 | Week 2 | Deployment kit | Setup script, health checks, auto-restart, alerting, SMTP fallback, graceful degradation |
| 3 | Week 3 | Generalize | Config-driven setup, OAuth onboarding, dental briefing template, per-client Telegram bot |
| 4 | Week 4 | Pilot deploy | Ship/configure Mac Mini for Kelly's brother, integrate channels, first briefing, remote monitoring |

---

## Competitive Positioning

| Competitor | What They Do | Why ARIA Wins |
|------------|-------------|---------------|
| Generic SaaS (Notion AI, etc.) | Cloud-based, per-seat pricing | Data leaves, expensive at scale, no customization |
| IT consultants | Custom builds, high hourly rates | Months of discovery, no product, just hours |
| AI automation agencies | Zapier/Make workflows | No local AI, no data privacy story, no fine-tuning |
| ChatGPT/Claude direct | Chat interface | No integration with their actual channels, no automation |

**ARIA's moat:** Local-first AI that learns their specific business. No cloud competitor can fine-tune on a dental practice's email patterns and run the model on hardware they own. The system gets smarter the longer it runs. That's not a feature, it's a flywheel.

---

## Pricing by Phase

### Phase 1: Concierge
- Hardware: passed through at cost (no markup, builds trust early)
- Setup fee: $5,000 (covers Sean's deployment time + margin)
- Monthly retainer: $750 (monitoring, support, updates, Claude API bundled)

### Phase 2: Low-Touch
- Hardware: passed through at cost
- Setup fee: $2,500 (toolkit does most work, lower time investment)
- Monthly retainer: $750 (same value, better margin)

### Phase 3: Self-Serve
- Hardware: marked up $500-700 (pre-configured, shipped ready to plug in)
- No setup fee (self-serve installer)
- Monthly SaaS subscription: $500/mo (automated billing, tier-based support)

### Breakeven Targets (See Financial Model)
- Phase 1: ~68 clients for $15K/mo target income (time-constrained before that)
- Phase 2: ~38 clients for $15K/mo (feasible with ~38 support hours/mo)
- Phase 3: ~49 clients for $15K/mo (12 support hours/mo, highly scalable)

**Philosophy:** Start accessible for the pilot. Use podcast case study as marketing ROI. Build toward self-serve where the real margins live. Every technical decision should reduce the cost and time of the next deployment.

---

## What NOT to Do

- **Don't expose technical architecture in sales conversations.** No model names, no oMLX, no LoRA. Say "AI engine" and "learns your practice."
- **Don't promise practice management integration before building it.** Dentrix/Eaglesoft APIs are messy. Promise it as Phase B, deliver Layer 1 first.
- **Don't lock partnership structure before the pilot.** Let the dynamic reveal itself.
- **Don't deploy without health monitoring.** Sean has experienced 12+ day outages he didn't notice. A paying client will notice in 12 hours.
- **Don't fine-tune before 6 months of data.** LoRA needs volume. Premature fine-tuning produces a worse model.
- **Don't claim HIPAA compliance.** Say "HIPAA-friendly" or "designed for healthcare privacy." Full compliance requires BAAs, audits, and documentation we don't have yet.
