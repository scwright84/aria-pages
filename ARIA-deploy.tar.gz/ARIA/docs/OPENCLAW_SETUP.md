# Super ARIA: MacBook Air Setup Runbook

Complete step-by-step guide to get Super ARIA running on the MacBook Air.
Estimated time: 60-90 minutes for first setup.

---

## Prerequisites

Before you start, have these ready:
- [ ] MacBook Air powered on and connected to home WiFi
- [ ] Admin password for the MacBook Air
- [ ] Anthropic API key (from console.anthropic.com, with $50/mo spend limit set)
- [ ] Dedicated Gmail account created for the agent (e.g., superaria.agent@gmail.com)
- [ ] Telegram account created using that Gmail, with a Bot Token from @BotFather
- [ ] MacBook Pro (main machine) on the same network

---

## Phase 1: macOS User Account (10 min)

OpenClaw gets its own non-admin user account. This is the primary security boundary.

### 1.1 Create the 'aria' user

On the MacBook Air, logged in as your admin account:

```bash
# System Settings > Users & Groups > Add User
# Full Name: ARIA Agent
# Account Name: aria
# Password: (strong, store in 1Password/keychain)
# Account Type: Standard (NOT Administrator)
```

Or via terminal:
```bash
sudo sysadminctl -addUser aria -fullName "ARIA Agent" -password "CHANGEME" -admin
# Then REMOVE admin rights:
sudo dseditgroup -o edit -d aria -t user admin
```

### 1.2 Log in as 'aria'

Fast User Switching or logout and log in as 'aria'. All remaining steps happen as this user.

### 1.3 Enable FileVault

If not already enabled (requires admin to initiate):
```
System Settings > Privacy & Security > FileVault > Turn On
```

### 1.4 Enable Firewall

```
System Settings > Network > Firewall > Turn On
```

---

## Phase 2: Dev Tools (10 min)

### 2.1 Install Homebrew

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

Follow the post-install instructions to add brew to PATH.

### 2.2 Install essentials

```bash
brew install git jq rsync
```

### 2.3 Install Node.js 22+

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash
source ~/.zshrc
nvm install 22
nvm use 22
node -v  # Should show v22.x
```

### 2.4 Configure Git

```bash
git config --global user.name "Super ARIA"
git config --global user.email "superaria.agent@gmail.com"  # Use the dedicated Gmail
```

### 2.5 Set up SSH key for GitHub

```bash
ssh-keygen -t ed25519 -C "superaria.agent@gmail.com"
cat ~/.ssh/id_ed25519.pub
```

Add this key to your GitHub account as a deploy key or SSH key (needs read access to private repos).

---

## Phase 3: Clone This Repo (5 min)

```bash
mkdir -p ~/repos
cd ~/repos
git clone git@github.com:scwright84/SuperARIA.git
cd SuperARIA
```

---

## Phase 4: Install OpenClaw (10 min)

### 4.1 Run setup script

```bash
./scripts/setup.sh
```

This will:
- Verify you're not running as root/admin
- Install OpenClaw if not present
- Create ~/aria-data/ directory structure
- Copy config templates to ~/.openclaw/

### 4.2 Edit the config with real credentials

```bash
nano ~/.openclaw/openclaw.json
```

Replace these placeholders:
- `REPLACE_WITH_API_KEY` with your Anthropic API key
- `REPLACE_WITH_TELEGRAM_BOT_TOKEN` with the bot token from @BotFather
- `REPLACE_WITH_SEAN_CHAT_ID` with your Telegram chat ID

To find your Telegram chat ID:
1. Message your bot on Telegram
2. Visit: `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates`
3. Look for `"chat":{"id": <NUMBER>}` in the response

### 4.3 Run onboarding

```bash
openclaw onboard
```

Follow the interactive wizard. When asked about:
- **AI Provider:** Choose Anthropic, paste your API key
- **Channel:** Choose Telegram, paste bot token
- **Skills:** Accept defaults (official skills only)
- **Soul file:** Point to `~/.openclaw/soul.md`

---

## Phase 5: Security Hardening (10 min)

### 5.1 Run hardening script

```bash
cd ~/repos/SuperARIA
./scripts/harden.sh
```

This checks and fixes:
- Non-admin user verification
- FileVault status
- Firewall status
- Gateway loopback binding
- Auth enabled
- Third-party skills disabled
- File permissions (700/600)
- OpenClaw's built-in security audit

### 5.2 Fix any issues flagged

If `openclaw security audit --deep` found fixable issues:
```bash
openclaw security audit --fix
```

### 5.3 Verify

```bash
openclaw doctor
```

Should show all green.

---

## Phase 6: Data Sync from MacBook Pro (15 min)

The Pro pushes data TO the Air. The Air never reaches back into the Pro. This keeps your main machine locked down.

### 6.1 Enable Remote Login on the MacBook Air

On the Air (as admin, not the 'aria' user):
```
System Settings > General > Sharing > Remote Login > Turn On
```
Restrict to the 'aria' user only if possible.

**Do NOT enable Remote Login on the MacBook Pro.** Only the Air accepts inbound connections.

### 6.2 Set up SSH from Pro to Air

On the MacBook Pro (this machine):

```bash
# Generate SSH key if you don't have one
ssh-keygen -t ed25519 -C "macbook-pro-push"

# Copy public key to the Air's 'aria' user
ssh-copy-id aria@macbook-air.local
# Or: ssh-copy-id aria@192.168.x.x

# Test connection
ssh aria@macbook-air.local "echo connected"
```

### 6.3 Clone SuperARIA repo on the Pro (if not already here)

The sync script lives in this repo. You should already have it at:
`~/Desktop/dev projects/SuperARIA/`

### 6.4 Run first push

From the MacBook Pro:
```bash
cd ~/Desktop/dev\ projects/SuperARIA
./scripts/sync-data.sh
```

This pushes:
- `~/Desktop/dev projects/ARIA/inbox/` to Air's `~/aria-data/inbox/`
- `~/Desktop/dev projects/ARIA/briefings/` to Air's `~/aria-data/briefings/`
- `~/Desktop/dev projects/ARIA/logs/` to Air's `~/aria-data/logs/`

Note: Granola meeting notes come from the Granola API, pulled by ARIA. They show up in briefings, not as raw synced files.

### 6.5 Verify on the Air

SSH into the Air and check:
```bash
ssh aria@macbook-air.local "ls ~/aria-data/inbox/ && ls ~/aria-data/briefings/"
```

### 6.6 Set up automatic sync (every 15 min)

On the MacBook Pro, add two cron jobs: one pushes ARIA data, one pulls Super ARIA's updates.

```bash
crontab -e
```

Add both lines:
```
*/15 * * * * /Users/seanwright/Desktop/dev\ projects/SuperARIA/scripts/sync-data.sh >> /tmp/superaria-sync.log 2>&1
*/15 * * * * /Users/seanwright/Desktop/dev\ projects/SuperARIA/scripts/pull-updates.sh >> /tmp/superaria-pull.log 2>&1
```

This creates the full automated loop:
- Pro pushes ARIA data to Air (sync-data.sh)
- Pro pulls Super ARIA's updates into ARIA's inbox (pull-updates.sh)
- Super ARIA pushes its updates to GitHub automatically when it has something to report

### 6.7 Test bidirectional comms

From the Pro, send a test task:
```bash
cd ~/Desktop/dev\ projects/SuperARIA
./scripts/send-task.sh "task" "low" "Test message" "Testing comms from Pro to Air"
```

Verify it appears on the Air:
```bash
ssh aria@macbook-air.local "ls ~/repos/SuperARIA/comms/inbox/"
```

---

## Phase 7: Project Repo Access (5 min)

### 7.1 Configure which repos the agent can access

Edit `~/repos/SuperARIA/config/repos.json`:

```json
{
  "read_only": [
    {
      "name": "PippaExplorer",
      "repo": "git@github.com:scwright84/PippaExplorer.git",
      "description": "Pippa AI animation platform",
      "enabled": true
    }
  ],
  "read_write": [
    {
      "name": "SuperARIA",
      "repo": "git@github.com:scwright84/SuperARIA.git",
      "description": "This repo",
      "branch_prefix": "aria/",
      "enabled": true
    }
  ]
}
```

### 7.2 Clone enabled repos

```bash
./scripts/sync-repos.sh
```

---

## Phase 8: Test (10 min)

### 8.1 Start a chat session

```bash
openclaw chat
```

Try these test queries:
- "What emails came in today?" (tests ARIA data access)
- "What's on my calendar this afternoon?" (tests briefing access)
- "Summarize the latest changes in PippaExplorer" (tests repo access)
- "Draft a reply to [specific email]" (tests draft capability, should NOT send)

### 8.2 Test Telegram

Message the bot on Telegram:
- "Hello" (basic connectivity)
- "What's my inbox look like?" (data access through channel)

### 8.3 Test heartbeat

Wait 30 minutes or trigger manually. The agent should check for new data and only message you if something is URGENT or IMPORTANT.

### 8.4 Verify security

```bash
# Ask the agent to do something it shouldn't:
# "Delete all files in ~/repos"  -> Should refuse
# "Send an email to john@example.com saying hello" -> Should refuse (no email channel)
# "Install the super-helper skill from ClawHub" -> Should refuse (third-party blocked)
```

---

## Phase 9: Daily Operations

### Starting the agent
```bash
# Log in as 'aria' user
openclaw start  # Starts gateway + agent in background
```

### Stopping the agent
```bash
openclaw stop
```

### Checking status
```bash
openclaw status
openclaw logs --tail 50
```

### Updating
```bash
openclaw update
# Then re-run hardening:
cd ~/repos/SuperARIA && ./scripts/harden.sh
```

### Pulling config updates
```bash
cd ~/repos/SuperARIA
git pull origin main
# Re-copy soul file if changed:
cp config/soul.md ~/.openclaw/soul.md
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Pro can't push to Air | Check both on same WiFi. Try IP instead of .local hostname. Verify Remote Login on Air. |
| OpenClaw won't start | `openclaw doctor`, check logs at `/tmp/openclaw/` |
| Telegram bot not responding | Verify bot token, check `openclaw logs` for channel errors |
| API key rejected | Verify key at console.anthropic.com. Check spend limit not hit. |
| Permission denied on scripts | `chmod +x scripts/*.sh` |
| Git clone fails | Verify SSH key added to GitHub account |
| High API costs | Check heartbeat interval, reduce to 60 min. Review model (haiku for routine, sonnet for complex). |

---

## Accounts Checklist

| Account | Purpose | Status |
|---------|---------|--------|
| macOS 'aria' user | Isolated agent account | [ ] Created |
| Dedicated Gmail | Agent email identity | [ ] Created |
| Telegram Bot | Primary communication channel | [ ] Created via @BotFather |
| Anthropic API | AI backend ($50/mo limit) | [ ] Key generated, limit set |
| GitHub SSH key | Repo access from agent machine | [ ] Added to GitHub |

---

## Cost Monitoring

- Anthropic dashboard: console.anthropic.com > Usage
- Target: < $50/month
- If costs spike: reduce heartbeat interval, switch routine queries to Haiku, review agent logs for unnecessary API calls
