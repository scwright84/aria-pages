# ARIA Discovery Questionnaire: Dental Practice

Run through this with the practice owner before hardware arrives. The goal is to scope exactly what ARIA connects to, who gets what access, and where the highest-value workflows are. This shapes the entire deployment.

---

## 1. Communication Channels

### Email Accounts
_ARIA only needs the email accounts where practice-relevant communication happens. Personal email stays out._

- What is the main office email address? (e.g., office@foresthillsprostho.com)
  - Provider: Gmail / Outlook / Other?
  - Who monitors this inbox today?
  - Roughly how many emails per day?

- Does the doctor have a separate practice email?
  - Address:
  - What kind of mail goes there? (referrals, clinical, professional associations?)

- Does anyone else have a practice email that gets important correspondence?
  - Office manager (billing, insurance)?
  - Other?

- Are there any email addresses that receive automated notifications you care about?
  - Insurance EOBs / claim status
  - Lab shipping confirmations
  - Patient portal messages
  - Appointment reminder responses

- Would it be useful to set up a dedicated ARIA email address (e.g., aria@foresthillsprostho.com) that staff can forward important items to?

**Typical dental practice result:** 2-3 email accounts connected. Everything else either forwards to the main inbox or doesn't need ARIA.

### Other Communication
- Do you use any team messaging? (Slack, Teams, group text?)
- How do staff communicate internally today? (in person, phone, sticky notes, shared inbox?)
- Are there important faxes? How are they received? (fax machine, eFax, email?)

---

## 2. Calendar

- What calendar system does the practice use?
  - Google Calendar / Outlook / Dentrix calendar / Other?
- Is the Dentrix schedule the source of truth for patient appointments?
- Does the doctor have a personal/professional calendar separate from the Dentrix schedule?
- Are there non-patient events on the calendar? (staff meetings, vendor visits, CE courses?)

---

## 3. Practice Management (Dentrix)

_ARIA doesn't connect directly to Dentrix. Instead, staff exports reports as CSV files and drops them in a shared folder. This takes 30 seconds and ARIA handles the rest._

### Reports to Export
Which of these would be valuable to have ARIA process daily?

- [ ] Daily patient schedule (who's coming in, what procedures, which operatory)
- [ ] Insurance aging report (claims by 0-30, 31-60, 61-90, 90+ days)
- [ ] Claim status report (pending, denied, paid)
- [ ] Pre-authorization tracking (active, expiring soon, expired)
- [ ] Production report (daily/weekly revenue by provider)
- [ ] Collections report (payments received, outstanding balances)
- [ ] Treatment plans pending acceptance
- [ ] New patient list
- [ ] Recall/recare list (patients overdue for hygiene)
- [ ] Referral source report

### Export Workflow
- Can someone run these exports each morning? Who would that be?
- Does Dentrix have a Report Scheduler that can auto-export? (Check: Reports > Report Scheduler)
- Where would the exported files go? (network shared folder, USB, email to self?)
- What format does Dentrix export? (CSV, PDF, other?)

---

## 4. Insurance Workflow

_Insurance is usually the biggest administrative time sink. Understanding the current workflow helps ARIA add the most value._

- How many insurance claims does the practice process per week?
- Who handles claim submissions? (office manager, billing person, outsourced?)
- How do you currently track claim status? (spreadsheet, Dentrix, memory, nothing?)
- How do you find out about denials? (email, mail, carrier portal, EOB?)
- Who writes appeal letters today? How long does each one take?
- Which insurance carriers do you deal with most? (top 5)
- Do you use any separate insurance verification tool? Which one?
- Do you handle car insurance (trauma) or workers comp claims? How often?
- What's the current collections rate? What's the goal?

---

## 5. Lab Workflow

- How many lab cases are typically in progress at once?
- Which labs do you use? (names, what each does)
- How do you currently track lab case status? (spreadsheet, whiteboard, Dentrix, memory?)
- How do labs communicate with you? (email, phone, portal?)
- How do you know when a case is arriving? (tracking email, lab calls, just shows up?)
- Have you ever had a patient scheduled for a seat with no lab case ready?

---

## 6. Staff and Roles

_Not everyone needs the same level of ARIA access. We'll match access to what each person actually needs._

### Access Tier Definitions
- **Tier 1 (Email Briefing):** Gets a personalized morning email with what's relevant to their role. No login needed.
- **Tier 2 (Dashboard):** Can view the practice dashboard (schedule, claims, lab cases). Read-only.
- **Tier 3 (Interactive AI):** Can ask ARIA questions via Telegram, upload documents for processing, enter notes.
- **Tier 4 (Admin):** Full control over settings, integrations, and user management.

### Staff Roster
_Fill in each person who should have any ARIA access:_

| Name | Role | Tier | Notes |
|------|------|------|-------|
| | Practice owner / lead dentist | 4 | |
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |

### Key Questions
- Who is the "Liz" -- the early adopter who'll help champion this with the team?
- Who currently spends the most time on manual admin work that ARIA could help with?
- Is anyone tech-resistant? (Good to know for rollout pacing)
- Does anyone work remotely or need mobile access outside the office?

---

## 7. Current Software Stack

_We know about Dentrix, but let's get the full picture._

| Software | Purpose | Who Uses It | How Often | Notes |
|----------|---------|------------|-----------|-------|
| Dentrix | Practice management | | | |
| | Imaging / X-rays | | | |
| | Intraoral scanners | | | |
| | Analytics | | | |
| | AI X-ray analysis | | | |
| | Insurance verification | | | |
| | Patient communication | | | |
| | Accounting/billing | | | |
| | Other | | | |

- Are there any tools you wish talked to each other but don't?
- Are there reports you wish existed but nobody has time to create?
- Is there a workflow where smart people are doing dumb work? (converting files, re-entering data, copying between systems)

---

## 8. Pain Points (Ranked)

_From the demo call, we heard about disconnected systems and manual work. Let's rank what hurts most._

Rate 1-5 (5 = biggest pain):

- [ ] Insurance claim denials and follow-up ___
- [ ] Tracking lab cases across multiple labs ___
- [ ] Morning schedule prep and awareness ___
- [ ] Insurance verification before appointments ___
- [ ] Patient communication (reminders, follow-ups) ___
- [ ] Production/collections visibility ___
- [ ] Referral tracking and acknowledgment ___
- [ ] Staff coordination and task handoffs ___
- [ ] Converting reports between formats ___
- [ ] Finding information across disconnected systems ___
- [ ] Other: _____________________________________ ___

---

## 9. Success Metrics

_How will we know ARIA is working? Let's define what "winning" looks like._

- What would save you the most time each day?
- What falls through the cracks most often today?
- If ARIA could only do one thing perfectly, what should it be?
- What does "good enough" look like at Week 2? Week 6?
- Is there a dollar amount you can put on the admin time currently spent on manual work?

---

## 10. Logistics

- Where would the Mac Mini live physically? (front desk, server closet, office?)
- Is there a wired ethernet connection available at that location?
- What's the office WiFi situation? (speed, reliability)
- What are practice hours? (for scheduling briefing timing)
- When does the first person arrive? When does the last person leave?
- Is there a shared network drive or folder all workstations can access?
- Who is the IT contact? (internal or external managed IT?)

---

## After This Questionnaire

The answers shape:
1. **Hardware spec** -- 48GB vs 64GB, based on how many Tier 3 users
2. **Email scope** -- which 2-3 accounts to connect
3. **Dentrix export setup** -- which reports, how often, where they go
4. **Briefing templates** -- what each role sees in their morning email
5. **Dashboard configuration** -- which pages are relevant
6. **Rollout sequence** -- who goes first, who's next, what pace
7. **Success criteria** -- what we measure at each check-in
