# ARIA Product Roadmap: Dental Practice Deployment

**Prepared for:** Dr. Paul Springs, Forest Hills Prosthodontics
**Date:** March 2026
**Version:** 1.0

---

## The Core Idea

ARIA is an AI assistant that runs on a small computer in your office. It reads your email, watches your calendar, ingests your Dentrix exports, tracks your insurance claims, monitors your lab cases, and delivers a daily intelligence briefing before your first patient arrives.

Every person in the practice gets their own version of ARIA, tailored to their role. The doctor sees the full picture. The office manager sees claims and collections. The front desk sees today's schedule and insurance status. Clinical staff sees lab cases and procedure prep. One brain, many interfaces.

**The design principle:** Even simple workflows like "export this report from Dentrix and drop it in a folder" are a massive improvement over the status quo. The workload goes from "manually check 5 disconnected tools" to "drop this file here and AI handles the rest."

---

## Architecture: One Brain, Many Interfaces

ARIA has a central intelligence that ingests all practice data. Each person interacts with their own interface, seeing only what's relevant to their role.

### What ARIA Ingests (Centrally)
- Office email accounts (2-3 accounts, not every employee's personal email)
- Office calendar
- Dentrix exports (CSV files dropped into a shared folder)
- Lab communications (parsed from email)
- Insurance notifications (parsed from email)
- Documents and photos (dropped into folder or sent via Telegram)
- Practice analytics exports (Practice By Numbers, etc.)

### What Each Person Gets (Individually)

**Tier 1: Morning Briefing (email only)**
Gets a personalized email each morning with what's relevant to their role. No login, no app, no learning curve. ARIA generates all briefings in one batch at 6:30 AM. Sending to 1 person or 16 costs the same.

_Best for: Hygienists, dental assistants, part-time staff._

**Tier 2: Dashboard Viewer (web browser)**
Everything in Tier 1, plus access to the practice dashboard showing schedule, claims, lab cases. Read-only. No AI processing needed to view a dashboard.

_Best for: Front desk staff who check the schedule. Clinical staff who check lab status._

**Tier 3: Interactive AI (Telegram app)**
Everything in Tier 2, plus the ability to ask ARIA questions ("What's the status of the Morrison claim?"), upload documents for AI processing, and enter notes ("Patient Chen called to reschedule"). Each question takes 10-30 seconds for the AI to process.

_Best for: Dr. Springs, office manager, lead front desk, lead clinical. Typically 3-4 people._

**Tier 4: Admin (full control)**
Everything in Tier 3, plus the ability to manage integrations, configure settings, and view all data without role filtering.

_Best for: Dr. Springs + Sean (remote support)._

### Email Scoping

ARIA does not need every employee's email. In a dental practice, the signal comes from 2-3 accounts:

1. **Main office email** (office@foresthillsprostho.com): Insurance EOBs, lab confirmations, patient inquiries, referral letters, vendor communications. This is 80% of what matters.
2. **Doctor's practice email**: Clinical correspondence, specialist referrals, professional communications.
3. **Billing email** (if separate): Insurance correspondence, payment notifications.

Everyone else either doesn't have practice email or can forward relevant items to the main inbox. This keeps ARIA focused on signal, not noise.

---

## Hardware Options

ARIA runs on Apple Silicon (Mac Mini or Mac Studio). All AI processing happens locally on this hardware. The only thing that leaves the office is the 10-15% of requests that need cloud AI for complex reasoning (insurance appeal narratives, nuanced patient communications).

### Recommended Configurations

| Configuration | RAM | Storage | Price | Best For |
|--------------|-----|---------|-------|----------|
| **Good** | 48GB | 512GB | $1,799 | 2-3 interactive users. Batch processing. One AI model loaded at a time. |
| **Better (recommended)** | 48GB | 1TB | $1,999 | Same performance, comfortable storage headroom for model updates and data growth. |
| **Best** | 64GB | 1TB | $2,199 | 4-6 interactive users. Two AI models loaded simultaneously. No wait times for document processing. |

_All configurations: Mac Mini M4 Pro, 12-core CPU, 16-core GPU._

### Why These Specs

**RAM determines AI capability.** The AI models that generate briefings, draft letters, and answer questions are 20-35GB each. On 48GB, one model loads at a time with fast swapping (5-10 seconds). On 64GB, two models run simultaneously, which matters when someone asks a question while a document is being processed.

**512GB storage is sufficient.** AI models take ~63GB on disk. A full year of practice data (emails, documents, reports) is ~18GB. The operating system and supporting software need ~40GB. Total: ~170GB. 512GB works. 1TB ($200 upgrade) gives comfortable headroom and is the smart default.

**Why not 24GB ($1,399)?** The AI models that produce quality output (32B parameter models) need most of the 24GB just for themselves, leaving nothing for the operating system. The briefings and draft letters would be noticeably lower quality with the smaller models that fit in 24GB.

### Storage Breakdown

| Component | Disk Space |
|-----------|-----------|
| AI models (4 models, standard quality) | ~63 GB |
| macOS + Docker + supporting software | ~40 GB |
| 12 months of practice data + AI memory | ~18 GB |
| Headroom for updates, logs, temp files | ~50 GB |
| **Total** | **~170 GB** |

### Hardware the Practice Owns

The Mac Mini lives in the office. The practice owns it outright. All patient data, email content, documents, and AI processing stays on this hardware. Nothing is stored in the cloud.

---

## Timeline

### Before Hardware Arrives (Now)

**Discovery call with Sean (1 hour, remote)**
Walk through the Discovery Questionnaire to scope:
- Which 2-3 email accounts to connect
- Which Dentrix reports to export daily
- Who gets which access tier
- Pain point ranking (what to optimize first)
- Physical setup (where the Mac Mini goes, network access)

This shapes the entire deployment. We do this while waiting for hardware.

### Week 1-2: Dr. Springs Goes Live

**What happens:**
- Sean configures the Mac Mini remotely (ARIA stack, AI models, Docker services)
- Connect office email and calendar (guided OAuth flow, 5 minutes each)
- Set up the shared network folder for Dentrix file drops
- Configure Dentrix Report Scheduler for daily auto-export (15-minute screen share with Sean)
- Set up Telegram bot on Dr. Springs' phone

**What Dr. Springs gets immediately:**
- Morning briefing email at 6:30 AM with: today's schedule, insurance items needing attention, lab cases in progress, new patient referrals, action items
- Evening debrief comparing plan vs. what actually happened
- Telegram bot for questions throughout the day ("When is the Thompson bridge arriving?" / "What's the status on the Chang claim?")
- Web dashboard at localhost showing schedule, claims tracker, lab cases

**What someone in the office does:**
- Runs the Dentrix export each morning (30 seconds, or auto-scheduled)
- That is the only manual step. ARIA handles everything else.

### Week 3-4: Core Team Joins

**Who joins:** Liz (early adopter), office manager, lead front desk person.

**What gets added:**
- Multi-user Telegram: ARIA knows who's asking and responds with role-appropriate information
- Per-role morning briefings:
  - Office manager gets: claims aging, denials needing action, collections update, pre-auths expiring
  - Front desk gets: today's schedule, insurance verification status, new patient info, cancellation alerts
- Auto-drafted appeal letters for claim denials (placed in Gmail Drafts for office manager to review and send)
- Document processing: staff can photograph paper documents (faxes, EOBs) via Telegram and ARIA reads them
- Claims dashboard live for office manager with real data from Dentrix exports

### Week 5-6: Full Practice

**Who joins:** Everyone else, at their assigned tier.

**What gets added:**
- All 16 employees receiving role-appropriate morning briefings via email
- Dashboard access for Tier 2+ staff
- Lab case tracking dashboard populated from email parsing and file drops
- Patient communication drafts (follow-up letters, treatment plan reminders, referral acknowledgments)
- Practice By Numbers data ingestion for production/collections visibility
- Bi-weekly check-in cadence established (every 2 weeks with Sean)

### Month 2-3: Intelligence Accumulates

With 6-8 weeks of data history, ARIA starts recognizing patterns:

- "Delta Dental denials for D2740 have increased 40% this quarter. Their documentation requirements may have changed."
- "Lab case delivery times from Marotta have averaged 2 days longer than quoted for the past month."
- "Three patients with treatment plans over $5K were presented this month but did not schedule. Case acceptance rate dropped to 72%."
- "Dr. Patel at Forest Hills Family Dentistry has referred 4 patients this quarter. A thank-you note could strengthen this referral source."

**Additional capabilities:**
- Insurance eligibility verification API connected (checks patient coverage the night before appointments)
- AI memory activated (ask "What happened with the Torres claim?" and get the full history)
- Monthly practice report auto-generates (production trends, collection rates, claim success rates, referral analysis)

### Month 6+: The Learning System

After 6 months of accumulated data:

- **Fine-tuning:** The AI learns the practice's specific patterns. Appeal letters sound like your office manager wrote them. Clinical narratives match Dr. Springs' style. The fine-tuned model is faster and more accurate for this practice than a generic model.
- **Dentrix direct integration** (if Henry Schein developer program approves): No more CSV exports. Real-time data flow.
- **Predictive scheduling:** Based on historical patterns: "You typically see 3 cancellations on Fridays in summer. Consider overbooking one slot."
- **Recall management:** Automated identification of patients overdue for hygiene, follow-ups, annual exams. Draft outreach communications.

---

## What Each Role Gets (Summary)

### Dr. Springs (Tier 4: Admin)

| Feature | Channel | When |
|---------|---------|------|
| Full practice briefing | Email | 6:30 AM daily |
| Evening debrief (plan vs. actual) | Email | 7:00 PM daily |
| Weekly rollup (production, claims, referrals) | Email | Sunday 6:00 PM |
| Ask anything about the practice | Telegram | Anytime |
| Full dashboard (schedule, claims, labs, production) | Web browser | Anytime |
| Manage integrations and settings | Web browser | As needed |

### Office Manager (Tier 3: Interactive)

| Feature | Channel | When |
|---------|---------|------|
| Claims and operations briefing | Email | 6:30 AM daily |
| Auto-drafted appeal letters for denials | Gmail Drafts | When denials arrive |
| Claims aging dashboard | Web browser | Anytime |
| Ask about claim status, patient balances | Telegram | Anytime |
| Upload insurance documents for processing | Telegram | As needed |
| Enter notes ("Called BCBS, claim in review") | Telegram | As needed |

### Front Desk (Tier 2-3: Dashboard + possibly Interactive)

| Feature | Channel | When |
|---------|---------|------|
| Schedule and patient briefing | Email | 6:30 AM daily |
| Today's schedule with insurance status | Web browser | Anytime |
| Cancellation and open slot alerts | Email (real-time) | When they happen |
| Patient communication drafts | Gmail Drafts | As needed |
| Ask about patient insurance status | Telegram (if Tier 3) | Anytime |

### Clinical Staff (Tier 1-2: Briefing + Dashboard)

| Feature | Channel | When |
|---------|---------|------|
| Procedure schedule and prep notes | Email | 6:30 AM daily |
| Lab case status | Web browser (if Tier 2) | Anytime |
| Lab arrival alerts | Email | When cases arrive |

### Hygienists and Assistants (Tier 1: Briefing Only)

| Feature | Channel | When |
|---------|---------|------|
| Today's schedule relevant to their role | Email | 6:30 AM daily |

---

## The "File Drop" Workflow

This is the bridge between Dentrix (Windows) and ARIA (Mac). It replaces what would otherwise require a complex API integration with something anyone can do in 30 seconds.

### How It Works

1. A shared network folder is set up that both Windows workstations and the Mac Mini can access.
2. Dentrix Report Scheduler (or a staff member manually) exports daily reports as CSV files to this folder.
3. ARIA watches the folder. When a new file appears, it automatically parses the data, extracts patient names, procedure codes, insurance status, dollar amounts, and everything else relevant.
4. The parsed data flows into the morning briefing, the dashboard, and the claims tracker.
5. The original file moves to a "processed" archive folder.

### Reports Worth Exporting

| Report | Frequency | What ARIA Does With It |
|--------|-----------|----------------------|
| Daily schedule | Every morning | Powers the schedule dashboard and briefing. Flags cancellations, open slots, new patients, insurance issues. |
| Claims aging | Daily or weekly | Powers the claims tracker. Alerts at 30/60/90 day thresholds. Prioritizes follow-up calls. |
| Pre-authorization list | Weekly | Tracks expiring pre-auths. Alerts before they expire so patients can be scheduled in time. |
| Production report | Daily | Tracks daily/weekly/monthly production against goals. Feeds into the weekly rollup. |
| Collections report | Weekly | Tracks outstanding balances, payment trends, collection rate. |
| Treatment plans pending | Weekly | Identifies patients who received a plan but haven't scheduled. Drafts follow-up outreach. |
| New patient list | Weekly | Tracks referral sources. Drafts acknowledgment letters to referring dentists. |

### The Print-to-PDF Trick

For any software that can print but can't export (which is most dental software), install a PDF virtual printer on one Windows workstation that saves to the ARIA shared folder. Staff "prints" a report, ARIA reads the PDF with its vision model. This works with literally anything that has a print button.

---

## Cost Summary

| Item | One-Time | Monthly | Notes |
|------|----------|---------|-------|
| Mac Mini M4 Pro, 48GB, 1TB | $1,999 | -- | Practice owns the hardware |
| ARIA setup and deployment | $0 | -- | Design partner arrangement: free in exchange for case study and marketing rights |
| ARIA monitoring and support | -- | TBD | Includes remote monitoring, updates, Claude API usage, bi-weekly check-ins |
| Claude API usage (included) | -- | ~$15-30 | 10-15% of AI requests use cloud for complex reasoning |
| Insurance eligibility API (Phase 2+) | -- | ~$50-150 | $0.10-0.75 per eligibility check, volume dependent |

### What's Free Forever
- All local AI processing (runs on the Mac Mini, no per-query cost)
- Data storage (on the Mac Mini, no cloud storage fees)
- Software updates (pushed automatically)

---

## Honest Caveats

**Dentrix is the constraint, not ARIA.** Henry Schein deliberately blocks third-party integrations. The CSV export workflow works great from Day 1, but it requires a human to run the export (30 seconds/day) or Dentrix Report Scheduler to be configured. Direct API access requires applying to the Henry Schein developer program (2-4 months, $2,000-5,000 for the SDK). We'll apply early but don't depend on it.

**HIPAA-friendly, not HIPAA-compliant.** All data is stored locally on hardware the practice owns. 85-90% of AI processing is local. The 10-15% that uses cloud AI sends only the query text (Anthropic does not store API inputs beyond a 30-day safety window and offers BAAs). Full HIPAA compliance requires formal risk assessment, audit logging, encryption at rest, and signed BAAs. This is a future milestone, not a pilot requirement.

**AI quality is excellent for most tasks, not perfect for all.** The local AI models are highly reliable for summarization, classification, and drafting. For reading printed documents and typed forms, accuracy is very high. For handwritten notes or poor-quality fax scans, expect 80-90% accuracy. There is always a human review step for anything clinical or financial.

**Fine-tuning needs data.** The personalized AI model that learns the practice's voice and patterns requires approximately 6 months of accumulated data. This can't be rushed. The generic models are good from Day 1; the fine-tuned model is great from Month 6.

**Carrier portal automation is useful but fragile.** Insurance carrier websites redesign without notice. Each scraper is a simple script that's easy to update, but expect occasional breakage. The system detects failures and alerts within minutes.

---

## What "Winning" Looks Like

**Week 2:** "I can't believe I used to start my day without this." Dr. Springs reads one email before the first patient and knows everything: schedule, claims issues, lab arrivals, new referrals, action items.

**Week 4:** "My office manager is spending half the time on appeals." Claim denials get caught the morning they arrive. Draft appeal letters are ready to review. Nobody is manually tracking aging in a spreadsheet anymore.

**Week 6:** "The whole office runs differently." Everyone gets exactly what they need in the morning. Lab cases never surprise anyone. Insurance pre-auths don't expire because someone forgot. Phone notes go into Telegram instead of sticky notes.

**Month 3:** "It's catching things nobody was watching." Pattern recognition surfaces trends in denials, lab delays, referral sources, and case acceptance that nobody had bandwidth to track.

**Month 6:** "It sounds like us." The fine-tuned model writes appeal letters in the office manager's voice. Clinical narratives match Dr. Springs' style. The system is faster and more accurate because it knows this specific practice.

---

## Next Steps

1. **Order hardware:** Mac Mini M4 Pro, 48GB RAM, 1TB storage ($1,999). Allow 1-2 weeks for delivery.
2. **Discovery call with Sean:** Walk through the questionnaire to scope email accounts, Dentrix exports, staff access tiers, and pain point priorities.
3. **Configure Dentrix exports:** Set up Report Scheduler or identify who will run morning exports. Sean can screen-share to assist.
4. **Week 1 deployment:** Sean configures the Mac Mini and connects accounts. Dr. Springs receives first morning briefing.
