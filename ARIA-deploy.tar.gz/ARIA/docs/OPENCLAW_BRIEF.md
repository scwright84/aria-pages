# OpenClaw Integration Brief for ARIA
**Prepared:** 2026-03-24 | **For:** ARIA build session context

## What Is OpenClaw

OpenClaw is an open-source, self-hosted autonomous AI agent that runs on local hardware and executes real-world tasks. It is NOT a chatbot — it acts on your behalf: shell commands, file operations, email, calendar, messaging, browser automation. Think of it as an AI employee with direct access to your machine.

- **Creator:** Peter Steinberger (Austrian dev, founder of PSPDFKit)
- **License:** MIT / Open Source
- **GitHub Stars:** 165,000+ (one of fastest-growing repos in history)
- **Runtime:** Node.js 22+
- **Config directory:** `~/.openclaw/`
- **Install:** `curl -fsSL https://openclaw.ai/install.sh | bash`
- **Onboarding:** `openclaw onboard` (interactive wizard)
- **Skill registry:** ClawHub (53 official + 13,700+ third-party skills)

## Architecture

### Core Components
- **Gateway:** Local WebSocket server. Handles auth, sessions, config, agent orchestration. Single required component.
- **Agents:** Isolated instances with own memory, session state, tool access. Multiple agents per gateway.
- **Channels:** 50+ messaging integrations (WhatsApp, Telegram, Slack, Discord, iMessage, Signal, Teams, Matrix, etc.)
- **Skills:** Downloadable capability packages from ClawHub or manual install.
- **Nodes:** Companion apps (macOS menu bar, iOS/Android, other machines) that pair via WebSocket.

### Data Storage
- All state stored as Markdown in `~/.openclaw/`
- Memory: per-agent daily diary entries, identity file, to-do list
- Sessions: `~/.openclaw/agents/<agentId>/sessions/*.jsonl`
- Logs: `/tmp/openclaw/openclaw-YYYY-MM-DD.log`
- Credentials: `~/.openclaw/auth-profiles.json` (highly sensitive)

### LLM Backend
- BYOK: supply your own Anthropic or OpenAI API key
- Default model: `anthropic/claude-sonnet-4-5`
- **CRITICAL:** Claude Pro / ChatGPT Plus subscriptions are prohibited by ToS for third-party agents. Must use pay-as-you-go API key.
- Creator explicitly recommends Anthropic models for stronger prompt-injection resistance.

### Heartbeat
- Agent proactively checks for work every ~30 min without being messaged
- Behaves like a background process with its own initiative
- Must be configured intentionally

### Session Compaction
- Context window fills cause compaction — earlier context is lost
- **Golden rule:** If it's important, write it to a file. Mental notes don't survive.

## Security: This Is Serious

OpenClaw has direct access to terminal, filesystem, and network. It inherits full permissions of its OS user. Treat as untrusted code execution with persistent credentials.

### Known CVEs (2026)
| CVE | Severity | Description |
|-----|----------|-------------|
| CVE-2026-25253 | CVSS 8.8 HIGH | One-click RCE via token theft. Patched v2026.1.29 |
| Oasis/ClawJacked | HIGH | Any website could silently hijack agent via WebSocket. Patched v2026.2.25 |
| ClawHavoc Campaign | HIGH | 341+ malicious skills on ClawHub distributing Atomic Stealer (AMOS) macOS malware |

### Threat Surface
- **HIGH:** Shell command execution with full OS user permissions
- **HIGH:** Malicious ClawHub skills (824+ found, 36% have prompt injection per Snyk, VirusTotal doesn't catch it)
- **HIGH:** Prompt injection via web pages, emails, or documents the agent reads
- **HIGH:** Gateway token theft (patched but stay updated)
- **MED:** Messaging channel compromise (can message your contacts as you)
- **MED:** Runaway API costs from misconfigured agents
- **MED:** Session compaction data loss

### Required Hardening (in order)
1. Run under dedicated non-admin macOS user account
2. Enable FileVault full-disk encryption
3. Enable macOS Firewall
4. Set `gateway.bind` to loopback only
5. Verify token auth is enabled
6. Run: `openclaw doctor`
7. Run: `openclaw security audit --deep` then `openclaw security audit --fix`
8. `chmod 700 ~/.openclaw && chmod 600 ~/.openclaw/openclaw.json`
9. Skip ALL third-party skills on first setup — only use 53 official bundled skills
10. Always run v2026.2.25 or later

### Soul File
Each agent has a "Soul" — config file defining identity, rules, permissions. This is the primary behavioral control surface. Must explicitly define:
- What agent is/isn't allowed to do
- Require confirmation before destructive/irreversible actions
- Instruct agent to push back on risky instructions
- Flag security concerns proactively

## How OpenClaw Fits in the ARIA Stack

**These are complementary layers, not competing tools:**

| Layer | Tool | Purpose |
|-------|------|---------|
| 1 | oMLX (local inference) | Cheap, fast, private. Handles 85% of routine processing |
| 2 | ARIA/n8n (deterministic automation) | Scheduled, reliable, zero variance. Presidential briefs, inbox triage, meeting prep |
| 3 | OpenClaw (autonomous agent) | Conversational, ad-hoc, proactive. "Research this," "draft a reply," "code this feature" |
| 4 | Claude API (cloud AI) | High-judgment, customer-facing, complex reasoning. 15% escalation |

**ARIA = the operations backbone (deterministic, scheduled)**
**OpenClaw = the conversational front door (ad-hoc, autonomous)**

Together they're the full package. A dental office manager messages OpenClaw on Telegram: "What did Dr. Smith promise the patient Thursday?" OpenClaw queries ARIA's data and responds. ARIA handles the scheduled briefs and triage. OpenClaw handles the on-demand requests.

## FounderOS / Client Deployment Implications

### Deployment Models
- **On-Prem:** Client buys Mac Mini, data stays local, HIPAA-friendly. Higher hardware cost, lower monthly.
- **Hosted by Wright Advisors:** We own hardware, client connects via Tailscale. $0 hardware to client, higher monthly covers amortization.
- **Hybrid:** Offer both. Privacy-sensitive verticals (dental, legal) go on-prem. Cost-sensitive go hosted.

### Client Deployment Risks
1. **Security is our liability.** We own the update cycle for CVE patches.
2. **Runaway costs.** Must enforce API spend limits at provider level ($20-50/mo ceiling to start).
3. **Skill supply chain.** Whitelist skills only. No client-installed third-party skills.
4. **Autonomy trust gap.** Office managers don't understand shell access. Soul file + permission lockdown must be airtight.
5. **Session compaction.** Must architect around context loss — force-write everything to files.

### Client Rollout Path
- **Starter:** ARIA only (scheduled briefs, triage, meeting prep)
- **Growth:** Add OpenClaw as conversational interface to ARIA data
- **Power:** Local fine-tuning via oMLX LoRA after 6 months of data

## Quick Reference Commands
```bash
# Install
curl -fsSL https://openclaw.ai/install.sh | bash

# Onboard
openclaw onboard

# Security
openclaw doctor
openclaw security audit --deep
openclaw security audit --fix

# Lock down
chmod 700 ~/.openclaw
chmod 600 ~/.openclaw/openclaw.json

# Update (always stay current)
openclaw update

# Logs
/tmp/openclaw/openclaw-YYYY-MM-DD.log

# Agent state
~/.openclaw/agents/<id>/
```

## Minimum Version Requirement
**Always run v2026.2.25 or later.** Two critical full-takeover vulnerabilities were patched in Jan-Feb 2026.

## Sean's Setup Plan (MacBook Air)
1. Create dedicated non-admin macOS user
2. Create dedicated Gmail + Telegram for the agent
3. Install OpenClaw under that user
4. Connect Anthropic API key with spend limit
5. Connect Telegram as primary channel
6. Run full security hardening
7. Configure Soul file with conservative permissions
8. Run as personal test case for 2-3 weeks before any client deployment
9. Document setup time, daily cost, capabilities, failures → becomes FounderOS case study
