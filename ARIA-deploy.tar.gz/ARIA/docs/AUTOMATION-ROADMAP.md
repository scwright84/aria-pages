# Wright Advisors AI Automation Platform: Product Roadmap

Last updated: 2026-03-06
Source spec: ~/Downloads/wright_automation_spec.md

## Guiding Principles

- Human in the loop by default. Sean approves; the system executes.
- Ollama handles the private. Claude API only where local models fall short.
- Slack is the surface. If it doesn't show up in Slack, it gets ignored.
- Compound over time. Log everything. The system gets smarter the longer it runs.
- Minimize paid services. Use free tiers and local AI wherever possible.

## Architecture Layers

| Layer | Tool | Role |
|-------|------|------|
| Local AI | Ollama (qwen3:8b / qwen3:4b) | Triage, classification, summarization, drafting |
| Cloud AI | Claude API (only when needed) | Complex reasoning, client-facing content, financial analysis |
| Orchestration | n8n (self-hosted) | Workflows, API credentials, scheduling |
| Queue/Data | Airtable or Google Sheets | Approval queues, logging, structured data |
| Approval UI | Slack (primary), Next.js (secondary) | Human-in-the-loop decisions |
| Memory | Qdrant (local) | Vector search across all interactions |

---

## ARIA Core (Communications Hub)

Status: **LIVE**

| Feature | Status | Notes |
|---------|--------|-------|
| Notification ingestion (macOS) | LIVE | Saves pre-triaged to inbox |
| Email ingestion (6 Gmail accounts) | LIVE | Cron 7am/9pm |
| Email ingestion (Outlook/WrightAdvisors) | LIVE | Cron 7am/9pm |
| Slack ingestion (Conceivable) | LIVE | Cron 7am/9pm |
| Granola meeting ingestion | LIVE | Webhook from launchd sync |
| Calendly sync | LIVE | Cron 4x/day |
| Google Calendar sync (4 accounts) | LIVE | Cron 4x/day, merged with Calendly |
| Morning briefing (7:30am) | LIVE | All sources, Ollama analysis |
| Evening debrief (9:30pm) | LIVE | Compares morning actions vs outcomes |
| Weekly strategic rollup (Sunday 7pm) | LIVE | Per-client cards, crack detection |
| Meeting prep briefs (30 min before) | LIVE | Invitee context from emails/Granola/Notion |
| Follow-up tracker | LIVE | Commitments from Granola, awaiting files |
| Draft response queue | LIVE | Known contacts only, Gmail Drafts |
| Briefing reply handler | LIVE | Semantic replies via Ollama |
| Notion task integration | LIVE | Auto-create from emails/meetings |

### ARIA Phase 3: Memory Layer (Qdrant)

| Feature | Status | Dependencies | Notes |
|---------|--------|-------------|-------|
| Interaction embedding pipeline | NOT STARTED | Qdrant (deployed), nomic-embed-text model | Embed all inbox data as vectors |
| Contact profiles (relationship memory) | NOT STARTED | Embedding pipeline | Auto-maintained per-person JSON |
| Semantic briefing replies | NOT STARTED | Embedding pipeline | Query Qdrant for historical context |

### ARIA Phase 4: Ambient Intelligence

| Feature | Status | Dependencies | Notes |
|---------|--------|-------------|-------|
| Client engagement scorecard | NOT STARTED | Weekly rollup data | Interaction count, response latency, meeting frequency |
| Time awareness per client | NOT STARTED | Calendar data | Approximate hours from meetings + email volume |
| Proactive outreach suggestions | NOT STARTED | Contact profiles | "Consider reaching out" in morning briefing |
| Deliverable tracker | NOT STARTED | Granola + email data | Detect mentions, track lifecycle |
| Personal life layer | NOT STARTED | iMessage access | Family events in evening debrief |

---

## Module 1: Social Engagement Automation

Status: **NOT STARTED**
Cost: Apify or Phantombuster ($49+/mo), or explore free alternatives

| Feature | Status | AI Layer | Cost | Notes |
|---------|--------|----------|------|-------|
| LinkedIn watchlist monitoring | NOT STARTED | N/A (scraping) | $$$ (Apify) | No free reliable option for feed monitoring |
| Post relevance scoring (0-100) | NOT STARTED | Ollama | Free | Score by topic, relationship tier, timing |
| Comment drafting (2-3 options) | NOT STARTED | Ollama | Free | Voice rules: opinionated, no "great post" |
| Slack approval queue | NOT STARTED | N/A | Free | Daily digest, approve/edit/skip |
| Decision logging | NOT STARTED | N/A | Free (Sheets) | For voice model refinement |
| Instagram pipeline | NOT STARTED | Ollama | $$$ (Apify) | Same pipeline, different source |

**Blocker**: No free way to monitor LinkedIn feeds. Apify is the cheapest option. Consider building only when client pipeline justifies the spend.

---

## Module 2: News and Intelligence Feed

Status: **IN PROGRESS**
Cost: Free (RSS) + NewsAPI free tier (100 req/day)

| Feature | Status | AI Layer | Cost | Notes |
|---------|--------|----------|------|-------|
| RSS feed ingestion | IN PROGRESS | N/A | Free | Food, supply chain, fertility, AI/ML, startups |
| NewsAPI integration | NOT STARTED | N/A | Free tier | Keyword-filtered by vertical |
| Local relevance classification | IN PROGRESS | Ollama (qwen3:4b) | Free | First-pass: relevant to any vertical? |
| Scoring and summarization | IN PROGRESS | Ollama (qwen3:8b) | Free | Tag by vertical, urgency, client relevance |
| Morning briefing integration | IN PROGRESS | Ollama | Free | Top items in daily briefing |
| Client-specific breaking alerts | NOT STARTED | Ollama | Free | Push to Slack when breaking news affects a client |
| Weekly vertical synthesis | NOT STARTED | Ollama | Free | 1-page market intel per vertical for client calls |
| Reddit signal (r/supplychain etc.) | NOT STARTED | N/A | Free (API) | Supplementary signal |
| Twitter/X monitoring | NOT STARTED | N/A | $$$ (API) | Skip for now, API is expensive |

---

## Module 3: Stock Trading and Market Intelligence

Status: **NOT STARTED**
Cost: Alpaca (free paper trading), Polygon.io ($29/mo for full data) or Yahoo Finance (free)

| Feature | Status | AI Layer | Cost | Notes |
|---------|--------|----------|------|-------|
| Morning watchlist briefing | NOT STARTED | Ollama | Free (Yahoo) | OHLCV, pre-market, overnight moves |
| Earnings calendar tracking | NOT STARTED | N/A | Free | Upcoming earnings for watchlist |
| Sentiment monitoring (Reddit/news) | NOT STARTED | Ollama | Free | Score sentiment 0-100 |
| Sentiment vs price divergence alerts | NOT STARTED | Ollama | Free | Flag divergence as signal |
| Earnings call transcript summaries | NOT STARTED | Claude API | $$$ | Quality matters here, Ollama may hallucinate |
| Paper trading (Alpaca) | NOT STARTED | Claude Code | Free | Rule-based entry/exit |
| Supply chain cross-reference alerts | NOT STARTED | Ollama | Free | Sean's consulting intel vs public equities |
| Daily P&L to Slack | NOT STARTED | N/A | Free | Trade log + summary |
| Weekly performance review | NOT STARTED | Ollama | Free | What worked, parameter suggestions |

**Build sequence**: Briefing only (week 1) -> Sentiment (week 2) -> Paper trading (weeks 3-4) -> Live money only after 30 days of paper results

---

## Module 4: Google Sheets and Supply Chain Integrations

Status: **NOT STARTED**
Cost: Free (Apps Script + Claude API calls are the only cost, and can use Ollama for most)

| Feature | Status | AI Layer | Cost | Notes |
|---------|--------|----------|------|-------|
| Lot tracking + batch record PDF | NOT STARTED | Ollama | Free | Wild Monkey Bar use case |
| Distributor readiness scorecard | NOT STARTED | Ollama | Free | Gap analysis from form input |
| Recall readiness drill | NOT STARTED | Ollama | Free | Mock recall response checklist |
| Shipping/logistics tracker | NOT STARTED | Ollama | Free | Carrier performance, cost trends |
| Label compliance checker | NOT STARTED | Claude API | $$$ | FDA requirements, stakes too high for local |
| Financial narrative from assumptions | NOT STARTED | Ollama/Claude | Depends | Board-quality may need Claude API |
| Scenario modeling narratives | NOT STARTED | Ollama/Claude | Depends | Change input, rewrite interpretation |
| Actuals vs forecast variance | NOT STARTED | Ollama | Free | Plain English variance explanation |
| Auto weekly status reports | NOT STARTED | Ollama | Free | Per-client from Sheet data |
| Meeting prep from Sheet data | NOT STARTED | Ollama | Free | Already partially in ARIA meeting prep |
| Invoice trigger on milestone | NOT STARTED | N/A | Free | Draft invoice on completion |

---

## Module 5: Presentation Automation

Status: **NOT STARTED**
Cost: Free (python-pptx + Ollama)

| Feature | Status | AI Layer | Cost | Notes |
|---------|--------|----------|------|-------|
| COO pitch deck template | NOT STARTED | Ollama | Free | Auto-populate with client data |
| Board update deck | NOT STARTED | Ollama/Claude | Depends | Monthly/quarterly, pulls from Sheets |
| QBR deck | NOT STARTED | Ollama | Free | Client-facing from project tracker |
| Investor update deck | NOT STARTED | Claude API | $$$ | Conceivable use case, quality matters |
| Supply chain audit report | NOT STARTED | Ollama | Free | From audit checklist responses |
| Google Drive auto-delivery | NOT STARTED | N/A | Free | Slack notification on delivery |

---

## Module 6: Passive Income Pipelines

Status: **NOT STARTED**
Cost: Beehiiv/Substack (free tier), Gumroad (free + transaction fee)

| Feature | Status | AI Layer | Cost | Notes |
|---------|--------|----------|------|-------|
| Weekly newsletter drafting | NOT STARTED | Ollama | Free | From intelligence feed + anonymized client themes |
| Newsletter approval queue (Slack) | NOT STARTED | N/A | Free | Same pattern as social comments |
| LinkedIn content pipeline (3x/week) | NOT STARTED | Ollama | Free | Frameworks, case studies, hot takes |
| LinkedIn approval queue | NOT STARTED | N/A | Free | Approve in <5 min/week |
| COO audit report (productized) | NOT STARTED | Ollama | Free | Intake form -> PDF |
| Supply chain readiness assessment | NOT STARTED | Ollama | Free | Google Form -> 10-page PDF |
| Financial model starter kits | NOT STARTED | N/A | Free | Pre-built Sheets, sell via Gumroad |
| Pippa marketing automation | NOT STARTED | Ollama | Free | Product updates, release notes, onboarding |
| StartupCFO marketing automation | NOT STARTED | Ollama | Free | Same pattern |

---

## Recommended Build Order (Cost-Optimized)

| Priority | Module | Why Now | Cost |
|----------|--------|---------|------|
| 1 | Module 2: News Intelligence | Plugs into ARIA, free, daily value | Free |
| 2 | ARIA Phase 3: Qdrant Memory | Foundation for everything else | Free |
| 3 | Module 6: LinkedIn Content | Revenue pipeline, Ollama handles it | Free |
| 4 | Module 6: Newsletter | Builds on news intel + LinkedIn | Free |
| 5 | Module 3: Stock Watchlist Briefing | Morning briefing extension | Free |
| 6 | Module 5: Presentation Templates | Client deliverable quality | Free |
| 7 | Module 4: Google Sheets Templates | Wild Monkey Bar immediate use | Free |
| 8 | Module 3: Paper Trading | After 2+ weeks of briefing data | Free |
| 9 | Module 1: Social Engagement | Only when pipeline justifies Apify cost | $49+/mo |
| 10 | Module 4: Label Compliance | Only with Claude API key | API cost |

---

## External API Keys Needed

| Service | Module | Cost | Status |
|---------|--------|------|--------|
| NewsAPI | Module 2 | Free (100 req/day) | NOT SET UP |
| Alpaca | Module 3 | Free (paper trading) | NOT SET UP |
| Apify | Module 1 | $49/mo minimum | NOT SET UP |
| Anthropic API | Modules 3-5 | Pay per token | NOT SET UP |
| Polygon.io | Module 3 | $29/mo (optional) | NOT SET UP |
| Gumroad | Module 6 | Free + transaction fee | NOT SET UP |
