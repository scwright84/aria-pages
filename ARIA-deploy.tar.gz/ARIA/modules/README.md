# ARIA Optional Modules

These modules extend ARIA's base capabilities. They're not required for standard deployments (daily briefings, email sync, Telegram bot, dashboard). They add power-user and multi-machine features.

## Module: openclaw/

**What it does:** Adds an autonomous AI agent (OpenClaw) that can take actions on your behalf: research, draft documents, review code, manage tasks. Think of it as upgrading from a briefing tool to a true AI employee.

**Requires:** OpenClaw installed, Anthropic API key ($50/mo budget), dedicated macOS user account.

**Key files:**
- `soul.md` - Agent identity, permissions, behavioral rules
- `openclaw.example.json` - Template config (real config lives at ~/.openclaw/openclaw.json)
- `repos.json` - Which code repos the agent can access
- `scripts/setup.sh` - Install and configure OpenClaw
- `scripts/harden.sh` - Security hardening checks
- `scripts/sync-repos.sh` - Clone/pull repos the agent can access
- `scripts/verify.sh` - End-to-end verification (runs on either machine)
- `SETUP_RUNBOOK.md` - Complete step-by-step MacBook Air setup guide

**When to enable:** Power users who want conversational AI that takes actions, not just generates reports. Requires comfort with AI autonomy and security hardening.

**Setup:** Follow `SETUP_RUNBOOK.md` for the complete walkthrough. Run `scripts/verify.sh` when done to confirm everything works.

## Module: comms/

**What it does:** Enables communication between two ARIA instances (e.g., MacBook Pro running scheduled automation + MacBook Air running the conversational agent). Uses a GitHub repo as the transport layer.

**Key files:**
- `README.md` - Full protocol spec (message types, priority levels, format)
- `inbox/` - Messages received from the other machine
- `outbox/` - Messages to send to the other machine
- `archived/` - Processed messages
- `scripts/sync-data.sh` - Push ARIA data from primary to secondary machine
- `scripts/send-task.sh` - Send a task to the secondary machine
- `scripts/send-update.sh` - Send an update from secondary back to primary
- `scripts/pull-updates.sh` - Pull updates from secondary into primary's inbox

**When to enable:** Multi-machine setups where scheduled automation runs on one Mac and the conversational agent runs on another.

## Enabling Modules

Modules are enabled through the installer's mode selector:

- **Business mode** (default): Core ARIA only. No modules.
- **Power user mode**: Enables openclaw/ and comms/ modules.

Or manually: follow the setup docs in each module directory.
