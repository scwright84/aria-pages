#!/bin/bash
# Super ARIA - Security Hardening Script
# Run AFTER setup.sh and editing openclaw.json with real credentials.

set -euo pipefail

BOLD='\033[1m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${GREEN}[HARDEN]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
err()  { echo -e "${RED}[ERROR]${NC} $1"; }
step() { echo -e "\n${BOLD}=== $1 ===${NC}"; }
pass() { echo -e "  ${GREEN}[PASS]${NC} $1"; }
fail() { echo -e "  ${RED}[FAIL]${NC} $1"; }

ISSUES=0

# Check non-admin user
step "User Account Check"

CURRENT_USER=$(whoami)
if dscl . -read /Groups/admin GroupMembership 2>/dev/null | grep -q "$CURRENT_USER"; then
    fail "User '$CURRENT_USER' is an admin. Should be non-admin."
    ISSUES=$((ISSUES + 1))
else
    pass "User '$CURRENT_USER' is non-admin"
fi

# Check FileVault
step "Disk Encryption"

FV_STATUS=$(fdesetup status 2>/dev/null || echo "unknown")
if echo "$FV_STATUS" | grep -q "On"; then
    pass "FileVault is enabled"
else
    fail "FileVault is not enabled. Enable in System Settings > Privacy & Security > FileVault"
    ISSUES=$((ISSUES + 1))
fi

# Check macOS Firewall
step "Firewall"

FW_STATUS=$(/usr/libexec/ApplicationFirewall/socketfilterfw --getglobalstate 2>/dev/null || echo "unknown")
if echo "$FW_STATUS" | grep -q "enabled"; then
    pass "macOS Firewall is enabled"
else
    fail "macOS Firewall is disabled. Enable in System Settings > Network > Firewall"
    ISSUES=$((ISSUES + 1))
fi

# Check OpenClaw config
step "OpenClaw Configuration"

if [ ! -f ~/.openclaw/openclaw.json ]; then
    fail "No config file found at ~/.openclaw/openclaw.json"
    ISSUES=$((ISSUES + 1))
else
    # Check gateway binding
    if grep -q '"bind".*"127.0.0.1"' ~/.openclaw/openclaw.json; then
        pass "Gateway bound to loopback only"
    else
        fail "Gateway not bound to 127.0.0.1. External access possible."
        ISSUES=$((ISSUES + 1))
    fi

    # Check auth enabled
    if grep -q '"enabled".*true' ~/.openclaw/openclaw.json; then
        pass "Auth appears enabled"
    else
        warn "Could not confirm auth is enabled. Verify manually."
    fi

    # Check third-party skills disabled
    if grep -q '"allowThirdPartySkills".*false' ~/.openclaw/openclaw.json; then
        pass "Third-party skills disabled"
    else
        fail "Third-party skills not explicitly disabled."
        ISSUES=$((ISSUES + 1))
    fi

    # Check API key is not the placeholder
    if grep -q 'REPLACE_WITH' ~/.openclaw/openclaw.json; then
        fail "Config still has placeholder values. Edit ~/.openclaw/openclaw.json with real keys."
        ISSUES=$((ISSUES + 1))
    fi
fi

# Lock down file permissions
step "File Permissions"

log "Setting permissions on ~/.openclaw/"
chmod 700 ~/.openclaw
find ~/.openclaw -type f -name "*.json" -exec chmod 600 {} \;
if [ -f ~/.openclaw/soul.md ]; then
    chmod 600 ~/.openclaw/soul.md
fi
pass "~/.openclaw/ set to 700, sensitive files to 600"

# Lock down aria-data
if [ -d ~/aria-data ]; then
    chmod 700 ~/aria-data
    pass "~/aria-data/ set to 700"
fi

# Run OpenClaw's built-in checks
step "OpenClaw Security Checks"

if command -v openclaw &> /dev/null; then
    log "Running: openclaw doctor"
    openclaw doctor || { fail "openclaw doctor reported issues"; ISSUES=$((ISSUES + 1)); }

    log "Running: openclaw security audit --deep"
    openclaw security audit --deep || { fail "Security audit found issues"; ISSUES=$((ISSUES + 1)); }

    echo ""
    warn "If audit found fixable issues, run: openclaw security audit --fix"
else
    fail "OpenClaw not found. Run setup.sh first."
    ISSUES=$((ISSUES + 1))
fi

# Summary
step "Summary"

if [ "$ISSUES" -eq 0 ]; then
    log "All checks passed. System is hardened."
else
    warn "$ISSUES issue(s) found. Review above and fix before running the agent."
fi

echo ""
echo "Hardening checklist:"
echo "  [$([ "$ISSUES" -eq 0 ] && echo 'x' || echo ' ')] Non-admin user"
echo "  [ ] FileVault enabled"
echo "  [ ] macOS Firewall enabled"
echo "  [ ] Gateway bound to loopback"
echo "  [ ] Token auth enabled"
echo "  [ ] openclaw doctor passes"
echo "  [ ] openclaw security audit --deep clean"
echo "  [ ] File permissions locked"
echo "  [ ] Only official skills"
echo "  [ ] Running v2026.2.25+"
echo "  [ ] Soul file reviewed"
echo ""
warn "Manually verify items marked [ ] above."
