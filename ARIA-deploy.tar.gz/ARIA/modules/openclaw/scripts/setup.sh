#!/bin/bash
# Super ARIA - OpenClaw Setup Script
# Run this on the MacBook Air under the dedicated 'aria' user account.
# Prerequisites: macOS user 'aria' already created (non-admin), logged in as that user.

set -euo pipefail

BOLD='\033[1m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${GREEN}[SETUP]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
err()  { echo -e "${RED}[ERROR]${NC} $1"; }
step() { echo -e "\n${BOLD}=== $1 ===${NC}"; }

# Preflight checks
step "Preflight Checks"

if [ "$(whoami)" = "root" ]; then
    err "Do not run as root. Run as the dedicated 'aria' user."
    exit 1
fi

CURRENT_USER=$(whoami)
log "Running as user: $CURRENT_USER"

if dscl . -read /Groups/admin GroupMembership 2>/dev/null | grep -q "$CURRENT_USER"; then
    warn "Current user '$CURRENT_USER' is an admin. OpenClaw should run under a non-admin user."
    warn "Continue anyway? (y/N)"
    read -r response
    if [[ ! "$response" =~ ^[Yy]$ ]]; then
        err "Aborting. Create a non-admin user first (see docs/SETUP_RUNBOOK.md)."
        exit 1
    fi
fi

# Check Node.js
if ! command -v node &> /dev/null; then
    step "Installing Node.js via nvm"
    curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash
    export NVM_DIR="$HOME/.nvm"
    [ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh"
    nvm install 22
    nvm use 22
else
    NODE_VERSION=$(node -v)
    log "Node.js found: $NODE_VERSION"
    MAJOR=$(echo "$NODE_VERSION" | sed 's/v//' | cut -d. -f1)
    if [ "$MAJOR" -lt 22 ]; then
        warn "Node.js 22+ required. Current: $NODE_VERSION"
        warn "Upgrade with: nvm install 22 && nvm use 22"
        exit 1
    fi
fi

# Install OpenClaw
step "Installing OpenClaw"

if command -v openclaw &> /dev/null; then
    CURRENT_VERSION=$(openclaw --version 2>/dev/null || echo "unknown")
    log "OpenClaw already installed: $CURRENT_VERSION"
    log "Updating to latest..."
    openclaw update
else
    log "Installing OpenClaw..."
    curl -fsSL https://openclaw.ai/install.sh | bash
fi

# Verify minimum version
step "Verifying Version"
OCVERSION=$(openclaw --version 2>/dev/null || echo "0.0.0")
log "OpenClaw version: $OCVERSION"
warn "Ensure this is v2026.2.25 or later (two critical CVEs patched in Jan-Feb 2026)."

# Create directory structure
step "Creating Directory Structure"

mkdir -p ~/aria-data/inbox
mkdir -p ~/aria-data/briefings
mkdir -p ~/aria-data/logs
mkdir -p ~/aria-data/granola
mkdir -p ~/repos
log "Created ~/aria-data/ and ~/repos/"

# Copy config
step "Configuring OpenClaw"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(dirname "$SCRIPT_DIR")"

if [ ! -f ~/.openclaw/openclaw.json ]; then
    mkdir -p ~/.openclaw
    if [ -f "$REPO_DIR/config/openclaw.example.json" ]; then
        cp "$REPO_DIR/config/openclaw.example.json" ~/.openclaw/openclaw.json
        warn "Copied example config to ~/.openclaw/openclaw.json"
        warn "YOU MUST edit this file and add your API keys before proceeding."
    else
        err "No example config found at $REPO_DIR/config/openclaw.example.json"
        exit 1
    fi
else
    log "Config already exists at ~/.openclaw/openclaw.json (not overwriting)"
fi

# Copy soul file
if [ -f "$REPO_DIR/config/soul.md" ]; then
    cp "$REPO_DIR/config/soul.md" ~/.openclaw/soul.md
    log "Soul file copied to ~/.openclaw/soul.md"
fi

# Run onboarding (interactive)
step "Next Steps"

echo ""
log "Setup complete. Now do the following:"
echo ""
echo "  1. Edit ~/.openclaw/openclaw.json with your real API keys"
echo "  2. Run: openclaw onboard"
echo "  3. Run: ./scripts/harden.sh"
echo "  4. Run: ./scripts/sync-repos.sh"
echo "  5. Set up data sync from MacBook Pro (see docs/SETUP_RUNBOOK.md)"
echo "  6. Test: openclaw chat"
echo ""
warn "Do NOT skip the hardening step."
