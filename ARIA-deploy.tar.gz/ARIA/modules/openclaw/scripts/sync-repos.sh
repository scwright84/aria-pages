#!/bin/bash
# Super ARIA - Project Repo Sync
# Clones/pulls repos defined in config/repos.json.
# Read-only repos are cloned with --bare for safety, then checked out read-only.
# Read-write repos are cloned normally.

set -euo pipefail

GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m'

log()  { echo -e "${GREEN}[REPOS]${NC} $1"; }
warn() { echo -e "${YELLOW}[REPOS]${NC} $1"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(dirname "$SCRIPT_DIR")"
CONFIG="$REPO_DIR/config/repos.json"
REPOS_BASE="$HOME/repos"

if [ ! -f "$CONFIG" ]; then
    echo "No repos.json found at $CONFIG"
    exit 1
fi

if ! command -v jq &> /dev/null; then
    echo "jq is required. Install with: brew install jq"
    exit 1
fi

mkdir -p "$REPOS_BASE"

# Process read-only repos
log "Processing read-only repos..."
echo "$( jq -c '.read_only[] | select(.enabled == true)' "$CONFIG" )" | while IFS= read -r entry; do
    [ -z "$entry" ] && continue
    NAME=$(echo "$entry" | jq -r '.name')
    REPO=$(echo "$entry" | jq -r '.repo')
    DEST="$REPOS_BASE/$NAME"

    if [ -d "$DEST" ]; then
        log "Pulling $NAME (read-only)..."
        cd "$DEST" && git pull --ff-only origin main 2>/dev/null || git pull --ff-only origin master 2>/dev/null || warn "Could not fast-forward $NAME"
        cd "$REPOS_BASE"
    else
        log "Cloning $NAME (read-only)..."
        git clone "$REPO" "$DEST"
        # Make the working tree read-only (git internals stay writable)
        find "$DEST" -maxdepth 1 -not -name '.git' -not -name '.' -exec chmod -R a-w {} \; 2>/dev/null || true
    fi
done

# Process read-write repos
log "Processing read-write repos..."
echo "$( jq -c '.read_write[] | select(.enabled == true)' "$CONFIG" )" | while IFS= read -r entry; do
    [ -z "$entry" ] && continue
    NAME=$(echo "$entry" | jq -r '.name')
    REPO=$(echo "$entry" | jq -r '.repo')
    PREFIX=$(echo "$entry" | jq -r '.branch_prefix // "aria/"')
    DEST="$REPOS_BASE/$NAME"

    if [ -d "$DEST" ]; then
        log "Pulling $NAME (read-write)..."
        cd "$DEST" && git pull --ff-only 2>/dev/null || warn "Could not fast-forward $NAME. May have local changes."
        cd "$REPOS_BASE"
    else
        log "Cloning $NAME (read-write)..."
        git clone "$REPO" "$DEST"
    fi
done

log "Repo sync complete."
log "Repos directory: $REPOS_BASE/"
ls -la "$REPOS_BASE/"
