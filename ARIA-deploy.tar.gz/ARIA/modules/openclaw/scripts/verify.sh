#!/bin/bash
# ARIA OpenClaw Module - End-to-End Verification
# Run this after completing the setup runbook to verify everything works.
# Can be run on either machine. Detects which one it's on and checks accordingly.

set -euo pipefail

BOLD='\033[1m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
NC='\033[0m'

PASS=0
FAIL=0
WARN=0

pass() { echo -e "  ${GREEN}[PASS]${NC} $1"; PASS=$((PASS + 1)); }
fail() { echo -e "  ${RED}[FAIL]${NC} $1"; FAIL=$((FAIL + 1)); }
warn() { echo -e "  ${YELLOW}[WARN]${NC} $1"; WARN=$((WARN + 1)); }
step() { echo -e "\n${BOLD}=== $1 ===${NC}"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OPENCLAW_DIR="$(dirname "$SCRIPT_DIR")"
MODULES_DIR="$(dirname "$OPENCLAW_DIR")"
ARIA_DIR="$(dirname "$MODULES_DIR")"
COMMS_DIR="$MODULES_DIR/comms"

# Detect which machine we're on
CURRENT_USER=$(whoami)
HOSTNAME=$(hostname -s 2>/dev/null || echo "unknown")

echo -e "${BOLD}ARIA OpenClaw Module Verification${NC}"
echo "Machine: $HOSTNAME | User: $CURRENT_USER"
echo "ARIA repo: $ARIA_DIR"

# ============================================================
# CHECKS THAT RUN ON BOTH MACHINES
# ============================================================

step "Repository"

if [ -d "$ARIA_DIR/.git" ]; then
    pass "Git repo exists"
else
    fail "Not a git repo"
fi

if git -C "$ARIA_DIR" fetch origin --dry-run &>/dev/null 2>&1; then
    pass "Can reach GitHub"
else
    fail "Cannot reach GitHub (check SSH key or network)"
fi

step "OpenClaw Module Files"

for f in soul.md openclaw.example.json repos.json \
         scripts/setup.sh scripts/harden.sh scripts/sync-repos.sh scripts/verify.sh; do
    if [ -f "$OPENCLAW_DIR/$f" ]; then
        pass "openclaw/$f exists"
    else
        fail "openclaw/$f missing"
    fi
done

step "Comms Module Files"

for f in README.md scripts/sync-data.sh scripts/send-update.sh \
         scripts/send-task.sh scripts/pull-updates.sh; do
    if [ -f "$COMMS_DIR/$f" ]; then
        pass "comms/$f exists"
    else
        fail "comms/$f missing"
    fi
done

step "Script Permissions"

for f in "$OPENCLAW_DIR"/scripts/*.sh "$COMMS_DIR"/scripts/*.sh; do
    [ -f "$f" ] || continue
    BASENAME=$(basename "$f")
    PARENT=$(basename "$(dirname "$(dirname "$f")")")
    if [ -x "$f" ]; then
        pass "$PARENT/scripts/$BASENAME is executable"
    else
        fail "$PARENT/scripts/$BASENAME is not executable (run: chmod +x $f)"
    fi
done

# ============================================================
# MACBOOK AIR CHECKS (agent machine)
# ============================================================

if [ -d "$HOME/.openclaw" ] || [ "$CURRENT_USER" = "aria" ]; then
    step "MacBook Air: OpenClaw"

    if command -v openclaw &>/dev/null; then
        OCVERSION=$(openclaw --version 2>/dev/null || echo "unknown")
        pass "OpenClaw installed: $OCVERSION"
    else
        fail "OpenClaw not installed"
    fi

    if [ -f "$HOME/.openclaw/openclaw.json" ]; then
        pass "OpenClaw config exists"
        if grep -q 'REPLACE_WITH' "$HOME/.openclaw/openclaw.json" 2>/dev/null; then
            fail "Config still has placeholder values (REPLACE_WITH_*)"
        else
            pass "Config has real values (no placeholders)"
        fi
        if grep -q '"bind".*"127.0.0.1"' "$HOME/.openclaw/openclaw.json" 2>/dev/null; then
            pass "Gateway bound to loopback"
        else
            fail "Gateway not bound to 127.0.0.1"
        fi
    else
        fail "No config at ~/.openclaw/openclaw.json (run setup.sh first)"
    fi

    if [ -f "$HOME/.openclaw/soul.md" ]; then
        pass "Soul file installed"
    else
        fail "Soul file missing at ~/.openclaw/soul.md"
    fi

    step "MacBook Air: Security"

    PERMS=$(stat -f "%Lp" "$HOME/.openclaw" 2>/dev/null || echo "unknown")
    if [ "$PERMS" = "700" ]; then
        pass "~/.openclaw permissions: 700"
    else
        warn "~/.openclaw permissions: $PERMS (should be 700)"
    fi

    if dscl . -read /Groups/admin GroupMembership 2>/dev/null | grep -q "$CURRENT_USER"; then
        warn "User '$CURRENT_USER' is an admin (should be non-admin for production)"
    else
        pass "User '$CURRENT_USER' is non-admin"
    fi

    step "MacBook Air: ARIA Data"

    for dir in inbox briefings logs config; do
        if [ -d "$HOME/aria-data/$dir" ]; then
            COUNT=$(ls "$HOME/aria-data/$dir/" 2>/dev/null | wc -l | tr -d ' ')
            if [ "$COUNT" -gt 0 ]; then
                pass "~/aria-data/$dir/ has $COUNT files"
            else
                warn "~/aria-data/$dir/ exists but is empty (data not synced yet?)"
            fi
        else
            fail "~/aria-data/$dir/ does not exist"
        fi
    done

    # Check for today's data
    TODAY=$(date '+%Y-%m-%d')
    if ls "$HOME/aria-data/inbox/"*"$TODAY"* &>/dev/null 2>&1; then
        pass "Today's inbox data present ($TODAY)"
    else
        warn "No inbox data for today ($TODAY) - sync may not have run yet"
    fi

    if [ -f "$HOME/aria-data/briefings/$TODAY.json" ]; then
        pass "Today's briefing JSON present"
    else
        warn "No briefing for today (may not have been generated yet)"
    fi

    step "MacBook Air: Project Repos"

    if [ -d "$HOME/repos" ]; then
        REPO_COUNT=$(ls -d "$HOME/repos"/*/ 2>/dev/null | wc -l | tr -d ' ')
        pass "~/repos/ exists with $REPO_COUNT repos"
    else
        warn "~/repos/ does not exist (run sync-repos.sh)"
    fi

    step "MacBook Air: Telegram"

    if command -v openclaw &>/dev/null; then
        if openclaw status 2>/dev/null | grep -qi "telegram\|channel\|running"; then
            pass "OpenClaw appears to be running with channels"
        else
            warn "Could not verify Telegram connection (check: openclaw status)"
        fi
    fi
fi

# ============================================================
# MACBOOK PRO CHECKS (boss machine)
# ============================================================

if [ -d "$ARIA_DIR/inbox" ] && [ -d "$ARIA_DIR/briefings" ]; then
    step "MacBook Pro: ARIA Data Source"

    for dir in inbox briefings logs config; do
        if [ -d "$ARIA_DIR/$dir" ]; then
            COUNT=$(ls "$ARIA_DIR/$dir/" 2>/dev/null | wc -l | tr -d ' ')
            pass "ARIA $dir/ has $COUNT files"
        else
            fail "ARIA $dir/ does not exist at $ARIA_DIR/$dir/"
        fi
    done

    if [ -f "$ARIA_DIR/config/aria.json" ]; then
        pass "aria.json config exists"
    else
        fail "aria.json missing"
    fi

    if [ -f "$ARIA_DIR/config/credentials.json" ]; then
        pass "credentials.json exists (will be excluded from sync)"
    fi

    step "MacBook Pro: SSH to Air"

    SUPERARIA_HOST="${SUPERARIA_HOST:-aria@macbook-air.local}"
    if ssh -o ConnectTimeout=5 -o BatchMode=yes "$SUPERARIA_HOST" "echo ok" &>/dev/null; then
        pass "SSH to Air ($SUPERARIA_HOST) works"
    else
        warn "Cannot SSH to Air ($SUPERARIA_HOST) - check network, Remote Login on Air, and SSH key"
    fi

    step "MacBook Pro: Cron Jobs"

    if crontab -l 2>/dev/null | grep -q "sync-data.sh"; then
        pass "sync-data.sh cron job exists"
    else
        warn "No cron job for sync-data.sh (set up per runbook Phase 6.6)"
    fi

    if crontab -l 2>/dev/null | grep -q "pull-updates.sh"; then
        pass "pull-updates.sh cron job exists"
    else
        warn "No cron job for pull-updates.sh (set up per runbook Phase 6.6)"
    fi
fi

# ============================================================
# SUMMARY
# ============================================================

step "Summary"

echo ""
echo -e "  ${GREEN}Passed: $PASS${NC}"
echo -e "  ${YELLOW}Warnings: $WARN${NC}"
echo -e "  ${RED}Failed: $FAIL${NC}"
echo ""

if [ "$FAIL" -eq 0 ] && [ "$WARN" -eq 0 ]; then
    echo -e "${GREEN}Everything looks good. OpenClaw module is ready.${NC}"
elif [ "$FAIL" -eq 0 ]; then
    echo -e "${YELLOW}No failures, but $WARN warnings to review.${NC}"
else
    echo -e "${RED}$FAIL issue(s) need to be fixed before OpenClaw module is operational.${NC}"
fi
