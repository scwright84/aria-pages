#!/usr/bin/env python3
"""
Super ARIA Presidential Brief Generator
Generates a comprehensive brief from ARIA data and sends it from
Super ARIA's dedicated email to Sean.

This is the core feedback loop:
  1. Super ARIA reads all ARIA data (pushed from Pro)
  2. Generates a presidential brief with its own analysis
  3. Sends it from its dedicated email to Sean
  4. Sean replies with instructions
  5. Super ARIA acts on those instructions

Different from ARIA's morning brief because Super ARIA:
  - Adds its own analysis and recommendations
  - Can cross-reference with project code it has access to
  - Has the full context of what it's been working on
  - Asks Sean questions when it needs direction

Runs on the MacBook Air. Reads from ~/aria-data/ (pushed by Pro).
Sends via Super ARIA's Gmail account (SMTP or Gmail API).
"""

import json
import smtplib
import sys
from datetime import datetime, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

# On the Air, ARIA data lives in ~/aria-data (pushed from Pro)
# When testing on the Pro, fall back to the project's own data
HOME = Path.home()
ARIA_DATA = HOME / "aria-data"
if not ARIA_DATA.exists():
    # Fallback for testing on Pro
    ARIA_DATA = Path(__file__).parent.parent.parent

INBOX_DIR = ARIA_DATA / "inbox"
BRIEFINGS_DIR = ARIA_DATA / "briefings"
CONFIG_DIR = ARIA_DATA / "config"
LOG_DIR = Path(__file__).parent.parent / "logs" if (Path(__file__).parent.parent / "logs").exists() else ARIA_DATA / "logs"
LOG_FILE = LOG_DIR / "super-brief.log"


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_json(path):
    if Path(path).exists():
        try:
            with open(path) as f:
                return json.load(f)
        except Exception:
            pass
    return None


def load_latest_briefing(suffix):
    for d in range(3):
        date = datetime.now() - timedelta(days=d)
        path = BRIEFINGS_DIR / f"{date.strftime('%Y-%m-%d')}-{suffix}.json"
        if path.exists():
            return load_json(path)
    return None


def load_inbox_today(prefix):
    date_str = datetime.now().strftime("%Y-%m-%d")
    path = INBOX_DIR / f"{prefix}-{date_str}.json"
    if path.exists():
        return load_json(path) or []
    return []


def gather_intelligence():
    """Gather all available intelligence for the brief."""
    intel = {}

    # Today's ARIA briefing (if available)
    date_str = datetime.now().strftime("%Y-%m-%d")
    aria_brief = load_json(BRIEFINGS_DIR / f"{date_str}.json")
    if aria_brief:
        intel["aria_brief"] = aria_brief.get("sections", aria_brief)

    # Today's emails
    emails = load_inbox_today("emails")
    intel["email_count"] = len(emails)
    intel["emails_needing_action"] = [
        {"subject": e.get("subject", ""), "from": e.get("from", ""), "project": e.get("detected_project")}
        for e in emails if e.get("action_needed")
    ]

    # Scorecard
    scorecard = load_latest_briefing("scorecard")
    if scorecard:
        intel["project_health"] = {
            name: {"grade": m.get("health_grade"), "flags": m.get("health_flags", [])}
            for name, m in scorecard.items()
            if m.get("tier") in ("active", "product")
        }

    # Tasks
    tasks = load_json(CONFIG_DIR / "tasks.json")
    if tasks:
        open_tasks = [t for t in tasks.get("tasks", []) if t.get("status") == "open"]
        intel["open_tasks"] = len(open_tasks)
        intel["high_priority_tasks"] = [
            t.get("title", "")[:80] for t in open_tasks
            if t.get("priority") in ("high", "urgent")
        ]

    # Outreach alerts
    outreach = load_latest_briefing("outreach")
    if outreach:
        intel["outreach_alerts"] = [
            {"project": a["project"], "days_silent": a["days_silent"]}
            for a in outreach.get("project_alerts", [])
        ]

    # Follow-up reminders
    followups = load_latest_briefing("followups")
    if followups:
        intel["followups"] = [
            {"task": f["task"][:60], "status": f["status"], "project": f.get("project")}
            for f in (followups if isinstance(followups, list) else [])
            if f.get("urgency") in ("high", "medium")
        ]

    # Goals
    goals = load_json(CONFIG_DIR / "goals.json")
    if goals:
        active = [g for g in goals.get("goals", []) if g.get("status") == "active"]
        intel["goals"] = [
            {"title": g["title"], "progress": g.get("progress", 0), "signals": g.get("signals", [])}
            for g in active
        ]

    # Comms digest
    digest = load_latest_briefing("digest")
    if digest:
        intel["comms_headline"] = digest.get("headline", "")
        intel["anomalies"] = digest.get("anomalies", [])

    return intel


def build_brief_html(intel):
    """Build the presidential brief HTML email."""
    now = datetime.now()
    date_display = now.strftime("%A, %B %d, %Y")

    # BLUF (Bottom Line Up Front)
    bluf_parts = []
    if intel.get("email_count"):
        action_count = len(intel.get("emails_needing_action", []))
        bluf_parts.append(f"{intel['email_count']} emails, {action_count} need action")
    if intel.get("open_tasks"):
        hp = len(intel.get("high_priority_tasks", []))
        bluf_parts.append(f"{intel['open_tasks']} open tasks" + (f" ({hp} high priority)" if hp else ""))
    if intel.get("outreach_alerts"):
        bluf_parts.append(f"{len(intel['outreach_alerts'])} client(s) going silent")
    if intel.get("anomalies"):
        bluf_parts.append(intel["anomalies"][0])

    bluf = ". ".join(bluf_parts) + "." if bluf_parts else "No urgent items this morning."

    # Project health
    project_html = ""
    for project, health in intel.get("project_health", {}).items():
        grade = health.get("grade", "?")
        flags = ", ".join(health.get("flags", [])) or "OK"
        color = {"A": "#22c55e", "B": "#84cc16", "C": "#eab308", "D": "#f97316", "F": "#ef4444"}.get(grade, "#6b7280")
        project_html += f'<tr><td style="font-weight:600">{project}</td><td style="color:{color};font-weight:700;font-size:18px;text-align:center">{grade}</td><td style="font-size:13px;color:#6b7280">{flags}</td></tr>'

    # Action items
    action_html = ""
    for email in intel.get("emails_needing_action", [])[:5]:
        action_html += f'<li><strong>{email["subject"][:60]}</strong> from {email["from"][:30]}</li>'

    # High priority tasks
    task_html = ""
    for task in intel.get("high_priority_tasks", [])[:5]:
        task_html += f'<li>{task}</li>'

    # Goals
    goals_html = ""
    for goal in intel.get("goals", []):
        bar_width = max(3, goal["progress"])
        color = "#22c55e" if goal["progress"] >= 50 else "#f97316" if goal["progress"] >= 20 else "#ef4444"
        goals_html += f'''<div style="margin:4px 0">
            <span style="font-size:13px">{goal["title"][:50]}</span>
            <div style="background:#e5e7eb;height:8px;border-radius:4px;margin-top:2px">
                <div style="background:{color};width:{bar_width}%;height:8px;border-radius:4px"></div>
            </div>
        </div>'''

    html = f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"></head>
<body style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;max-width:640px;margin:0 auto;padding:16px;background:#f9fafb">
<div style="background:#0f172a;color:white;padding:20px;border-radius:10px 10px 0 0;text-align:center">
    <h1 style="font-size:18px;margin:0">Presidential Brief</h1>
    <p style="font-size:13px;color:#94a3b8;margin:4px 0 0">{date_display} | From Super ARIA</p>
</div>
<div style="background:white;padding:20px;border-radius:0 0 10px 10px;box-shadow:0 2px 8px rgba(0,0,0,0.08)">

<div style="background:#eff6ff;border-left:4px solid #3b82f6;padding:12px 16px;border-radius:4px;margin-bottom:20px">
    <strong style="font-size:13px;color:#1e40af;text-transform:uppercase">Bottom Line</strong>
    <p style="font-size:15px;color:#111827;margin:4px 0 0">{bluf}</p>
</div>

{'<h2 style="font-size:14px;color:#6b7280;text-transform:uppercase;letter-spacing:0.5px;margin:16px 0 8px">Emails Needing Action</h2><ul style="font-size:14px;line-height:1.8;padding-left:20px">' + action_html + '</ul>' if action_html else ''}

{'<h2 style="font-size:14px;color:#6b7280;text-transform:uppercase;letter-spacing:0.5px;margin:16px 0 8px">High Priority Tasks</h2><ul style="font-size:14px;line-height:1.8;padding-left:20px">' + task_html + '</ul>' if task_html else ''}

{'<h2 style="font-size:14px;color:#6b7280;text-transform:uppercase;letter-spacing:0.5px;margin:16px 0 8px">Project Health</h2><table style="width:100%;border-collapse:collapse"><thead><tr><th style="text-align:left;font-size:12px;color:#6b7280;padding:4px">Project</th><th style="text-align:center;font-size:12px;color:#6b7280;padding:4px">Grade</th><th style="text-align:left;font-size:12px;color:#6b7280;padding:4px">Status</th></tr></thead><tbody>' + project_html + '</tbody></table>' if project_html else ''}

{'<h2 style="font-size:14px;color:#6b7280;text-transform:uppercase;letter-spacing:0.5px;margin:16px 0 8px">Goal Progress</h2>' + goals_html if goals_html else ''}

<div style="margin-top:20px;padding-top:16px;border-top:1px solid #e5e7eb">
    <p style="font-size:13px;color:#6b7280;text-align:center">
        Reply to this email with instructions. I'll act on them.<br>
        Examples: "Follow up with Jac" | "Draft a response to the USPS email" | "Remind me Thursday about the deck"
    </p>
</div>

</div>
</body>
</html>"""
    return html


def send_email(to_email, subject, html_body, from_email, smtp_server, smtp_port, smtp_user, smtp_password):
    """Send the brief via SMTP."""
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = f"Super ARIA <{from_email}>"
    msg["To"] = to_email
    msg["Reply-To"] = from_email

    # Plain text fallback
    plain = "Your Presidential Brief is ready. View in an HTML-capable email client."
    msg.attach(MIMEText(plain, "plain"))
    msg.attach(MIMEText(html_body, "html"))

    try:
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(smtp_user, smtp_password)
            server.sendmail(from_email, to_email, msg.as_string())
        return True
    except Exception as e:
        log(f"Email send failed: {e}")
        return False


def main():
    log("Generating Super ARIA Presidential Brief")

    intel = gather_intelligence()
    log(f"Intelligence gathered: {len(intel)} sections")
    log(f"  Emails: {intel.get('email_count', 0)}, Actions: {len(intel.get('emails_needing_action', []))}")
    log(f"  Tasks: {intel.get('open_tasks', 0)}, High priority: {len(intel.get('high_priority_tasks', []))}")

    html = build_brief_html(intel)

    # Save locally
    date_str = datetime.now().strftime("%Y-%m-%d")
    output_dir = Path(__file__).parent.parent / "briefings"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / f"{date_str}-super-brief.html"
    with open(output_path, "w") as f:
        f.write(html)
    log(f"Saved: {output_path}")

    # Also save JSON
    json_path = output_dir / f"{date_str}-super-brief.json"
    with open(json_path, "w") as f:
        json.dump(intel, f, indent=2, default=str)

    # Try to send via email
    # Config comes from environment or a local config file
    import os
    smtp_user = os.environ.get("SUPER_ARIA_EMAIL")
    smtp_password = os.environ.get("SUPER_ARIA_EMAIL_PASSWORD")
    to_email = os.environ.get("SUPER_ARIA_SEND_TO", "scwright84@gmail.com")

    if smtp_user and smtp_password:
        subject = f"Presidential Brief - {datetime.now().strftime('%A, %b %d')}"
        sent = send_email(
            to_email=to_email,
            subject=subject,
            html_body=html,
            from_email=smtp_user,
            smtp_server="smtp.gmail.com",
            smtp_port=587,
            smtp_user=smtp_user,
            smtp_password=smtp_password,
        )
        if sent:
            log(f"Brief sent to {to_email}")
        else:
            log(f"Failed to send. Brief saved locally at {output_path}")
    else:
        log("Email not configured (set SUPER_ARIA_EMAIL and SUPER_ARIA_EMAIL_PASSWORD)")
        log(f"Brief saved locally: {output_path}")

    log("Super ARIA brief generation complete")


if __name__ == "__main__":
    main()
