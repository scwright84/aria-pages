#!/usr/bin/env python3
"""
Super ARIA Email Reply Processor
Parses Sean's replies to presidential briefs and executes instructions.

Sean replies to the brief email with plain text instructions like:
  "Follow up with Jac about the proposal"
  "Draft a response to the insurance email"
  "Remind me Thursday about the deck"
  "Approve all drafts"
  "Schedule a call with Kirsten next week"

This script:
  1. Checks Super ARIA's email inbox for replies to sent briefs
  2. Uses AI to parse the instructions into structured actions
  3. Executes each action (draft email, create task, set reminder, etc.)
  4. Reports back what was done

Runs every 15 minutes on the MacBook Air, or when triggered.
"""

import json
import os
import re
import sys
from datetime import datetime, timedelta
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
# Navigate up to the ARIA project root: openclaw/scripts -> openclaw -> modules -> ARIA
ARIA_ROOT = SCRIPT_DIR.parent.parent.parent
ARIA_SCRIPTS = ARIA_ROOT / "scripts"
sys.path.insert(0, str(SCRIPT_DIR))
sys.path.insert(0, str(ARIA_SCRIPTS))

PROJECT_DIR = Path(__file__).parent.parent  # modules/openclaw
LOG_FILE = PROJECT_DIR / "logs" / "reply-processor.log"

# On the Air, data is at ~/aria-data. On Pro for testing, use ARIA project root.
HOME = Path.home()
ARIA_DATA = HOME / "aria-data"
if not ARIA_DATA.exists():
    ARIA_DATA = ARIA_ROOT  # Fall back to ARIA project root


def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def parse_instructions(reply_text):
    """Use AI to parse natural language instructions into structured actions."""
    try:
        import aria_ai

        prompt = """Parse this email reply into a list of actions. The user is replying to their morning briefing with instructions for their AI assistant.

Return ONLY a JSON array of actions:
[
  {
    "action": "draft_email",
    "to": "person or description",
    "subject": "about what",
    "context": "any additional context"
  },
  {
    "action": "follow_up",
    "with": "person name",
    "about": "topic",
    "deadline": "when (or null)"
  },
  {
    "action": "create_task",
    "title": "task description",
    "priority": "high/normal/low",
    "deadline": "when (or null)"
  },
  {
    "action": "remind",
    "about": "what to remember",
    "when": "date/time"
  },
  {
    "action": "approve_drafts",
    "which": "all or specific IDs"
  },
  {
    "action": "search",
    "query": "what to look up"
  }
]

Only return actions that are clearly requested. Don't invent actions."""

        result = aria_ai.chat_json(prompt, reply_text, escalate=True, timeout=30)
        if result and isinstance(result, list):
            return result
        return []
    except Exception as e:
        log(f"AI parsing failed: {e}")
        return []


def execute_action(action):
    """Execute a single parsed action."""
    action_type = action.get("action", "")
    result = {"action": action_type, "status": "unknown", "detail": ""}

    try:
        if action_type == "draft_email":
            # Add to draft queue
            try:
                sys.path.insert(0, str(ARIA_SCRIPTS))
                import draft_manager
                draft = draft_manager.add_draft(
                    to=action.get("to", ""),
                    subject=action.get("subject", "Follow-up"),
                    body=action.get("context", f"Following up on {action.get('subject', 'our conversation')}"),
                    project=action.get("project"),
                )
                result["status"] = "done"
                result["detail"] = f"Draft created: {draft.get('subject', '')[:50]}"
            except Exception as e:
                result["status"] = "failed"
                result["detail"] = str(e)

        elif action_type == "follow_up":
            # Create a follow-up task
            try:
                tasks_file = ARIA_DATA / "config" / "tasks.json"
                tasks = {"tasks": [], "completed": []}
                if tasks_file.exists():
                    with open(tasks_file) as f:
                        tasks = json.load(f)

                import hashlib
                task = {
                    "id": hashlib.md5(f"reply:{action.get('with','')}:{datetime.now()}".encode()).hexdigest()[:12],
                    "source": "reply",
                    "action": "follow_up",
                    "title": f"Follow up with {action.get('with', '?')} about {action.get('about', '?')}",
                    "project": action.get("project"),
                    "priority": "high",
                    "status": "open",
                    "deadline": action.get("deadline"),
                    "date": datetime.now().isoformat(),
                }
                tasks["tasks"].append(task)
                with open(tasks_file, "w") as f:
                    json.dump(tasks, f, indent=2, default=str)

                result["status"] = "done"
                result["detail"] = f"Task created: {task['title'][:50]}"
            except Exception as e:
                result["status"] = "failed"
                result["detail"] = str(e)

        elif action_type == "create_task":
            try:
                tasks_file = ARIA_DATA / "config" / "tasks.json"
                tasks = {"tasks": [], "completed": []}
                if tasks_file.exists():
                    with open(tasks_file) as f:
                        tasks = json.load(f)

                import hashlib
                task = {
                    "id": hashlib.md5(f"reply:{action.get('title','')}:{datetime.now()}".encode()).hexdigest()[:12],
                    "source": "reply",
                    "action": "do",
                    "title": action.get("title", ""),
                    "priority": action.get("priority", "normal"),
                    "status": "open",
                    "deadline": action.get("deadline"),
                    "date": datetime.now().isoformat(),
                }
                tasks["tasks"].append(task)
                with open(tasks_file, "w") as f:
                    json.dump(tasks, f, indent=2, default=str)

                result["status"] = "done"
                result["detail"] = f"Task created: {task['title'][:50]}"
            except Exception as e:
                result["status"] = "failed"
                result["detail"] = str(e)

        elif action_type == "remind":
            # Create a reminder task with a future deadline
            try:
                tasks_file = ARIA_DATA / "config" / "tasks.json"
                tasks = {"tasks": [], "completed": []}
                if tasks_file.exists():
                    with open(tasks_file) as f:
                        tasks = json.load(f)

                import hashlib
                task = {
                    "id": hashlib.md5(f"reminder:{action.get('about','')}:{datetime.now()}".encode()).hexdigest()[:12],
                    "source": "reply",
                    "action": "remind",
                    "title": f"Reminder: {action.get('about', '?')}",
                    "priority": "normal",
                    "status": "open",
                    "deadline": action.get("when"),
                    "date": datetime.now().isoformat(),
                }
                tasks["tasks"].append(task)
                with open(tasks_file, "w") as f:
                    json.dump(tasks, f, indent=2, default=str)

                result["status"] = "done"
                result["detail"] = f"Reminder set: {action.get('about', '')[:50]} for {action.get('when', 'TBD')}"
            except Exception as e:
                result["status"] = "failed"
                result["detail"] = str(e)

        elif action_type == "approve_drafts":
            try:
                sys.path.insert(0, str(ARIA_SCRIPTS))
                import draft_manager
                which = action.get("which", "all")
                if which == "all":
                    approved = draft_manager.approve_all()
                    result["status"] = "done"
                    result["detail"] = f"Approved {len(approved)} draft(s)"
                else:
                    draft_id = int(which)
                    draft_manager.approve_draft(draft_id)
                    result["status"] = "done"
                    result["detail"] = f"Approved draft #{draft_id}"
            except Exception as e:
                result["status"] = "failed"
                result["detail"] = str(e)

        elif action_type == "search":
            try:
                sys.path.insert(0, str(ARIA_SCRIPTS))
                import aria_memory
                results = aria_memory.search(action.get("query", ""), limit=3)
                if results:
                    summaries = [f"{r['source']}: {r.get('subject', r.get('text', '')[:40])}" for r in results]
                    result["status"] = "done"
                    result["detail"] = f"Found {len(results)} results: {'; '.join(summaries)}"
                else:
                    result["status"] = "done"
                    result["detail"] = "No results found"
            except Exception as e:
                result["status"] = "failed"
                result["detail"] = str(e)

        else:
            result["status"] = "skipped"
            result["detail"] = f"Unknown action type: {action_type}"

    except Exception as e:
        result["status"] = "failed"
        result["detail"] = str(e)

    return result


def process_reply(reply_text):
    """Full pipeline: parse instructions and execute each one."""
    log(f"Processing reply ({len(reply_text)} chars)")

    actions = parse_instructions(reply_text)
    log(f"Parsed {len(actions)} actions")

    results = []
    for action in actions:
        log(f"  Executing: {action.get('action', '?')} - {json.dumps(action, default=str)[:80]}")
        result = execute_action(action)
        results.append(result)
        log(f"    Result: {result['status']} - {result['detail'][:60]}")

    return results


def main():
    """Process a reply from stdin, file, or manual input."""
    import argparse
    parser = argparse.ArgumentParser(description="Process reply to presidential brief")
    parser.add_argument("--text", help="Reply text to process")
    parser.add_argument("--file", help="File containing reply text")
    args = parser.parse_args()

    if args.text:
        reply_text = args.text
    elif args.file:
        with open(args.file) as f:
            reply_text = f.read()
    else:
        print("Enter reply text (Ctrl+D when done):")
        reply_text = sys.stdin.read()

    if not reply_text.strip():
        log("Empty reply. Nothing to process.")
        return

    results = process_reply(reply_text)

    log(f"Processed {len(results)} actions:")
    for r in results:
        log(f"  [{r['status']}] {r['action']}: {r['detail']}")


if __name__ == "__main__":
    main()
