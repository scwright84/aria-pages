# Comms: Bidirectional Communication Channel

This directory is how ARIA (Pro) and Super ARIA (Air) talk to each other.
GitHub is the transport layer. Both machines push and pull this repo.

## How It Works

```
Super ARIA (Air)                          ARIA (Pro)
  writes to comms/outbox/     ──git push──>  ──git pull──>  ingests into ARIA inbox
  reads from comms/inbox/     <──git pull──  <──git push──  writes to comms/inbox/
```

## Directories

### outbox/ (Super ARIA writes, ARIA reads)
Super ARIA drops structured JSON messages here when it:
- Completes a task
- Has findings to report
- Needs a decision or input
- Discovers something urgent
- Has a status update

ARIA's pull script on the Pro picks these up, ingests them into the ARIA inbox,
and moves the processed files to an `archived/` folder.

### inbox/ (ARIA writes, Super ARIA reads)
ARIA can drop tasks, instructions, or context here for Super ARIA to pick up.
This is how ARIA assigns work or provides additional context beyond the
regular data sync.

## Message Format

All messages are JSON files named with timestamp: `YYYY-MM-DD_HHMMSS_<slug>.json`

```json
{
  "id": "2026-03-24_143022_task-complete",
  "timestamp": "2026-03-24T14:30:22Z",
  "from": "super-aria",
  "priority": "normal",
  "type": "task_complete",
  "subject": "PippaExplorer code review complete",
  "body": "Reviewed the authentication flow in PippaExplorer...",
  "metadata": {
    "related_repo": "PippaExplorer",
    "related_pr": null,
    "time_spent_minutes": 12
  }
}
```

### Message Types
| Type | When |
|------|------|
| `task_complete` | Super ARIA finished an assigned task |
| `finding` | Discovered something noteworthy (code issue, pattern, insight) |
| `question` | Needs input or a decision from Sean/ARIA |
| `status_update` | Periodic progress on longer work |
| `urgent` | Something time-sensitive that needs attention now |
| `pr_opened` | Opened a pull request for review |
| `error` | Something went wrong, needs help |

### Priority Levels
| Priority | Meaning |
|----------|---------|
| `urgent` | Needs attention within the hour |
| `normal` | Include in next briefing cycle |
| `low` | Informational, no action needed |
