#!/bin/bash
# ARIA - Send Task to Super ARIA (runs on MacBook Pro)
# Writes a task/instruction to comms/inbox/ and pushes to GitHub.
# Super ARIA picks it up on next repo pull.
#
# Usage:
#   ./scripts/send-task.sh "task" "normal" "Review PippaExplorer auth flow" "Look at src/auth/..."
#   ./scripts/send-task.sh "context" "low" "Client meeting notes" "Met with Conceivable today..."
#
# Arguments:
#   $1 - type: task, context, instruction, question
#   $2 - priority: urgent, normal, low
#   $3 - subject: short summary
#   $4 - body: full message (optional)

set -euo pipefail

TYPE="${1:?Usage: send-task.sh <type> <priority> <subject> [body]}"
PRIORITY="${2:?Usage: send-task.sh <type> <priority> <subject> [body]}"
SUBJECT="${3:?Usage: send-task.sh <type> <priority> <subject> [body]}"
BODY="${4:-$SUBJECT}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(dirname "$SCRIPT_DIR")"
INBOX="$REPO_DIR/comms/inbox"

TIMESTAMP=$(date -u '+%Y-%m-%dT%H:%M:%SZ')
SLUG=$(echo "$SUBJECT" | tr '[:upper:]' '[:lower:]' | tr ' ' '-' | tr -cd 'a-z0-9-' | head -c 40)
FILENAME="$(date '+%Y-%m-%d_%H%M%S')_${SLUG}.json"

mkdir -p "$INBOX"

cat > "$INBOX/$FILENAME" << JSONEOF
{
  "id": "$(date '+%Y-%m-%d_%H%M%S')_${SLUG}",
  "timestamp": "$TIMESTAMP",
  "from": "aria",
  "priority": "$PRIORITY",
  "type": "$TYPE",
  "subject": "$SUBJECT",
  "body": $(echo "$BODY" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read().strip()))'),
  "metadata": {}
}
JSONEOF

echo "[SEND] Written: $INBOX/$FILENAME"

cd "$REPO_DIR"
git add "comms/inbox/$FILENAME"
git commit -m "comms: task for Super ARIA - $SUBJECT" --quiet
git push origin main --quiet

echo "[SEND] Pushed to GitHub. Super ARIA will pick this up on next pull."
