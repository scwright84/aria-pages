#!/bin/bash
# Super ARIA - Send Update to ARIA (via GitHub)
# Run on the MacBook Air. Writes a structured message to comms/outbox/ and pushes.
#
# Usage:
#   ./scripts/send-update.sh "task_complete" "normal" "Finished code review" "Details here..."
#   ./scripts/send-update.sh "urgent" "urgent" "API key expiring" "Anthropic key expires in 3 days"
#   ./scripts/send-update.sh "question" "normal" "Which auth pattern?" "Found two approaches..."
#
# Arguments:
#   $1 - type: task_complete, finding, question, status_update, urgent, pr_opened, error
#   $2 - priority: urgent, normal, low
#   $3 - subject: short summary
#   $4 - body: full message (optional, defaults to subject)

set -euo pipefail

TYPE="${1:?Usage: send-update.sh <type> <priority> <subject> [body]}"
PRIORITY="${2:?Usage: send-update.sh <type> <priority> <subject> [body]}"
SUBJECT="${3:?Usage: send-update.sh <type> <priority> <subject> [body]}"
BODY="${4:-$SUBJECT}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(dirname "$SCRIPT_DIR")"
OUTBOX="$REPO_DIR/comms/outbox"

TIMESTAMP=$(date -u '+%Y-%m-%dT%H:%M:%SZ')
SLUG=$(echo "$SUBJECT" | tr '[:upper:]' '[:lower:]' | tr ' ' '-' | tr -cd 'a-z0-9-' | head -c 40)
FILENAME="$(date '+%Y-%m-%d_%H%M%S')_${SLUG}.json"

mkdir -p "$OUTBOX"

cat > "$OUTBOX/$FILENAME" << JSONEOF
{
  "id": "$(date '+%Y-%m-%d_%H%M%S')_${SLUG}",
  "timestamp": "$TIMESTAMP",
  "from": "super-aria",
  "priority": "$PRIORITY",
  "type": "$TYPE",
  "subject": "$SUBJECT",
  "body": $(echo "$BODY" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read().strip()))'),
  "metadata": {}
}
JSONEOF

echo "[SEND] Written: $OUTBOX/$FILENAME"

# Commit and push
cd "$REPO_DIR"
git add "comms/outbox/$FILENAME"
git commit -m "comms: $TYPE - $SUBJECT" --quiet
git push origin main --quiet

echo "[SEND] Pushed to GitHub. ARIA will pick this up on next pull."
