#!/bin/bash
# Super ARIA - Push ARIA Data to MacBook Air
# Runs on the MacBook PRO. Pushes inbox, briefings, logs, and read-only config TO the Air.
# The Pro is the boss. The Air receives what the Pro decides to send.
#
# Prerequisites:
#   1. Remote Login enabled on MacBook Air (System Settings > General > Sharing > Remote Login)
#   2. SSH key from this Mac added to the Air: ssh-copy-id aria@<MACBOOK_AIR_IP>
#   3. Update MACBOOK_AIR_HOST below with the correct IP or hostname
#
# Run manually: ./scripts/sync-data.sh
# Or via cron:  */15 * * * * /path/to/SuperARIA/scripts/sync-data.sh >> /tmp/superaria-sync.log 2>&1

set -euo pipefail

# ============================================================
# CONFIGURATION - Update these for your network
# ============================================================
MACBOOK_AIR_HOST="${SUPERARIA_HOST:-aria@macbook-air.local}"
REMOTE_ARIA_BASE="/Users/aria/aria-data"

# Local paths (on this MacBook Pro, where ARIA data actually lives)
LOCAL_ARIA="/Users/seanwright/Desktop/dev projects/ARIA"
LOCAL_INBOX="$LOCAL_ARIA/inbox/"
LOCAL_BRIEFINGS="$LOCAL_ARIA/briefings/"
LOCAL_LOGS="$LOCAL_ARIA/logs/"
LOCAL_CONFIG="$LOCAL_ARIA/config/"

# ============================================================

GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${GREEN}[PUSH $(date '+%H:%M:%S')]${NC} $1"; }
warn() { echo -e "${YELLOW}[PUSH $(date '+%H:%M:%S')]${NC} $1"; }
err()  { echo -e "${RED}[PUSH $(date '+%H:%M:%S')]${NC} $1"; }

# Test connectivity
log "Testing connection to $MACBOOK_AIR_HOST..."
if ! ssh -o ConnectTimeout=5 -o BatchMode=yes "$MACBOOK_AIR_HOST" "echo ok" &>/dev/null; then
    err "Cannot reach $MACBOOK_AIR_HOST. Is the MacBook Air on the network?"
    err "If first time, run: ssh-copy-id $MACBOOK_AIR_HOST"
    exit 1
fi
log "Connected."

# Ensure remote directories exist
ssh "$MACBOOK_AIR_HOST" "mkdir -p $REMOTE_ARIA_BASE/{inbox,briefings,logs,config}"

# Push each data source
RSYNC_OPTS="-az --delete --timeout=30"

log "Pushing inbox (emails, slack, calendar, awaiting, notifications)..."
rsync $RSYNC_OPTS "$LOCAL_INBOX" "$MACBOOK_AIR_HOST:$REMOTE_ARIA_BASE/inbox/"

log "Pushing briefings (JSON + HTML)..."
rsync $RSYNC_OPTS "$LOCAL_BRIEFINGS" "$MACBOOK_AIR_HOST:$REMOTE_ARIA_BASE/briefings/"

log "Pushing logs and state files..."
rsync $RSYNC_OPTS "$LOCAL_LOGS" "$MACBOOK_AIR_HOST:$REMOTE_ARIA_BASE/logs/"

# Push config (read-only context: known projects, schedules, client tiers)
# Excludes credentials.json - never send secrets to the Air
log "Pushing config (aria.json, model-tracker.json - excluding credentials)..."
rsync $RSYNC_OPTS --exclude='credentials.json' --exclude='.env' "$LOCAL_CONFIG" "$MACBOOK_AIR_HOST:$REMOTE_ARIA_BASE/config/"

log "Push complete. Data sent to $MACBOOK_AIR_HOST:$REMOTE_ARIA_BASE/"
