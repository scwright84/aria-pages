#!/bin/bash
# Super ARIA - Pull Updates from Air (runs on MacBook Pro)
# Pulls the SuperARIA repo, reads new messages from comms/outbox/,
# copies them into ARIA's inbox for ingestion, then archives them.
#
# Run manually: ./scripts/pull-updates.sh
# Or via cron (pair with sync-data.sh):
#   */15 * * * * /Users/seanwright/Desktop/dev\ projects/SuperARIA/scripts/pull-updates.sh >> /tmp/superaria-pull.log 2>&1

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(dirname "$SCRIPT_DIR")"
OUTBOX="$REPO_DIR/comms/outbox"
ARCHIVED="$REPO_DIR/comms/archived"
ARIA_INBOX="/Users/seanwright/Desktop/dev projects/ARIA/inbox"

GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m'

log()  { echo -e "${GREEN}[PULL $(date '+%H:%M:%S')]${NC} $1"; }
warn() { echo -e "${YELLOW}[PULL $(date '+%H:%M:%S')]${NC} $1"; }

# Pull latest from GitHub
cd "$REPO_DIR"
log "Pulling SuperARIA repo..."
git pull --ff-only origin main --quiet 2>/dev/null || {
    warn "Could not fast-forward. May have local changes. Trying merge..."
    git pull origin main --quiet
}

# Check for new outbox messages
if [ ! -d "$OUTBOX" ] || [ -z "$(ls -A "$OUTBOX" 2>/dev/null)" ]; then
    log "No new messages from Super ARIA."
    exit 0
fi

# Process each message
mkdir -p "$ARCHIVED"
mkdir -p "$ARIA_INBOX"

COUNT=0
for msg in "$OUTBOX"/*.json; do
    [ -f "$msg" ] || continue
    FILENAME=$(basename "$msg")

    # Copy to ARIA inbox with a prefix so ARIA knows the source
    cp "$msg" "$ARIA_INBOX/superaria_${FILENAME}"
    log "Ingested: $FILENAME"

    # Move to archived
    mv "$msg" "$ARCHIVED/$FILENAME"
    COUNT=$((COUNT + 1))
done

if [ "$COUNT" -gt 0 ]; then
    # Commit the archive move
    cd "$REPO_DIR"
    git add comms/outbox/ comms/archived/
    git commit -m "comms: archived $COUNT message(s) from Super ARIA" --quiet
    git push origin main --quiet
    log "Processed $COUNT message(s). Archived and pushed."
else
    log "No new messages."
fi
