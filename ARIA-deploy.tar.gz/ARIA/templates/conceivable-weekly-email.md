# Conceivable Weekly Team Email Template

## Format Rules
- Plain text email with proper HTML bullet points (not markdown dashes)
- Short, direct, builder tone
- No em dashes or en dashes
- Sean's sign-off style: "Talk soon," or "Let me know if priorities need to shift."

## Structure

1. **Subject**: Conceivable Weekly Update: [date range]
2. **Short intro**: 1-2 sentences, casual but professional
3. **Where we stand**: 3-5 bullets on the executive state of things
4. **Accomplishments this week**: 5-8 bullets of concrete deliverables
5. **Goals this week**: Bulleted with owner names, specific and actionable
6. **Close out**: 1 sentence + "Sean"

## Example (approved March 22, 2026)

Subject: Conceivable Weekly Update: March 17-22

Team,

Hope everyone had a productive week. Wanted to share a quick recap and what's ahead.

Where we stand

- App is close to internal testing. OAuth nearly done, database encryption shipped, backend observability fully live.
- Fundraising locked: $1M raise, take $750K initially with $250K tranche. Peter updating deck, targeting 12 angel networks.
- Quiz conversion needs urgent attention: 91 completions, zero purchases. Report page is the likely blocker.
- Privacy policy confirmation is blocking app store submission.

Accomplishments this week

- Database encryption shipped to staging (HIPAA readiness milestone)
- Backend observability fully shipped (Sentry, PostHog, slow query logging)
- Paywall screen design started, using native Apple/Google subscription flow
- Command center and data room live
- 50 early access signups in 3 days, 4-5 supplement orders without ad spend
- First $500 consultation booked

Goals this week (March 23-28)

- Kirsten: Verify privacy policy covers the app (blocks app store submission), queue 5 beta testers
- Lakshmi: Complete OAuth setup, scope personalized supplement recommendations
- Andrew: Finish password change screens, React Native Sentry integration
- Maria: Add privacy messaging to website, finalize mockups with animations
- Sean: Investor deck feedback, HSA eligibility research
- All: Review $10M deck and share investor contacts for CRM pipeline
- Test removing the report page from quiz flow to fix conversion

Talk soon,
Sean
