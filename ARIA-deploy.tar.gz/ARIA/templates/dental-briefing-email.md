# ARIA Daily Brief Template: Dental Practice

## Design Principles
- Scannable in under 2 minutes before the first patient arrives
- Focus on what the practice owner NEEDS to know, not what happened
- Patient-facing items first, administrative second
- Empty sections are good signal ("No patient issues flagged" = smooth day ahead)
- Consistent format daily so the owner builds muscle memory

## Format Rules
- HTML email with proper bullet points
- Direct, clear language. No jargon, no AI-speak.
- No em dashes or en dashes
- Bold section headers
- Each bullet is one clear sentence with context
- BLUF (summary) uses heavier styling to stand out

## Triage Filter (what makes something briefing-worthy)
1. Does it affect patient care or scheduling? -> Today's Schedule
2. Does it require the owner's decision? -> Decisions Needed
3. Is there a financial or insurance issue? -> Practice Business
4. Did someone commit to something that isn't done? -> Follow-ups
5. Is there a staff or operations issue? -> Team & Operations
6. None of the above? -> Don't include it

## Structure

### 1. Good Morning Summary
2-3 sentences max. How many patients today, any urgent issues, one highlight or heads-up.
Example: "14 patients on the schedule today. Dr. Chen's 2pm root canal was rescheduled to Thursday. Insurance pre-auth for Mrs. Garcia's crown came through."

### 2. Today's Schedule at a Glance
Patient count, key procedures, any schedule gaps or double-bookings. Flag new patients (need extra time). Flag patients with outstanding balances or insurance issues.
Not a full calendar dump. Just what's unusual or needs attention.

### 3. Decisions Needed
Only items requiring the owner's call. Could be: treatment plan approvals, equipment purchases, staffing decisions, policy questions. If none, say "No decisions needed today."

### 4. Follow-ups
- **You owe:** Callbacks, referral letters, treatment plan follow-ups, insurance appeals
- **They owe you:** Lab work pending, specialist reports, insurance pre-auths, patient documents

### 5. Practice Business
Financial and operational items: insurance claims status, accounts receivable flags, supply orders, vendor communications, marketing responses. Only items that changed or need attention.

### 6. Team & Operations
Staff communications, schedule change requests, training reminders, equipment maintenance. Only if actionable.

### 7. Messages Needing Your Attention
Emails, voicemails, or team chat messages that passed the triage filter. Grouped by urgency:
- **Respond today:** Patient concerns, referring dentist requests, urgent vendor issues
- **This week:** Non-urgent but needs your input
- **FYI:** Informational only, no action needed

## Tone Guide
- Write like a smart office manager, not a robot
- "Mrs. Johnson called about her bite guard" not "Incoming communication detected from patient entity"
- Use patient names naturally
- Be concise but warm
- Flag problems directly: "The sterilizer maintenance is 2 weeks overdue" not "Equipment status: attention recommended"
