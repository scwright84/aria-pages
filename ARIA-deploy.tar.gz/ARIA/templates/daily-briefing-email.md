# ARIA Presidential Daily Brief Template

## Design Principles
- Scannable in under 3 minutes (~1 printed page of dense content)
- Every item has a "so what" - not just what happened, but why it matters
- Decisions first, FYI last - ordered by "what needs your brain"
- Empty sections are good signal ("No decisions needed" = execution day)
- Consistent format daily - reader builds muscle memory for where to look
- The difference between a task list and a brief: a brief tells you what MATTERS, why, and what happens if you ignore it

## Format Rules
- HTML email with proper bullet points
- Direct, builder tone. No fluff, no filler.
- No em dashes or en dashes
- Bold section headers
- Each bullet is one clear sentence with context
- BLUF uses a heavier weight or distinct styling to stand out

## Triage Filter (what makes something briefing-worthy)
1. Does it require Sean's decision or action? -> Decisions Needed
2. Did Sean promise something that isn't done? -> Commitments Tracker
3. Is someone else's delay blocking progress? -> Waiting On Others
4. Does it change the status of a project? -> Project Pulse
5. Is there a meeting today that needs prep? -> Today's Schedule
6. None of the above? -> Don't include it

## Structure

### 1. BLUF (Bottom Line Up Front)
2-3 sentences max. The single most important thing today. Sets the cognitive frame for the day.
Example: "Today is meeting-heavy (4 calls). Conceivable needs a pricing decision by EOD. MasterFi proposal revision is 2 days overdue. Nothing is on fire."

### 2. Decisions Needed
Only items requiring Sean's call. Each item: what the decision is, deadline, context for why it matters, suggested action if possible. If none needed, say "No decisions needed today" (that itself is useful signal).

### 3. Today's Schedule + Meeting Prep
Chronological. Each meeting: time, who, what you last discussed with them, what they'll likely bring up, any open commitments between you and them. This is strategic context, not just a calendar dump.

### 4. Commitments Tracker (You Owe Them)
Promises Sean made in meetings or emails that aren't done yet. Sorted by deadline urgency. Include: what was promised, to whom, when it was promised, days elapsed. Flag anything overdue.

### 5. Waiting On Others (They Owe You)
What's outstanding from other people, grouped by project. How long it's been. Whether it's blocking anything downstream.

### 6. Project Pulse
One line per active project. Status: on track / needs attention / blocked. Only expand on projects that changed status since yesterday. Keep this tight.

### 7. Overnight Comms
Only items that passed the triage filter. Grouped by project, not by channel. Each item: source, one-line summary, whether it needs action or is FYI. This is not an inbox dump.

### 8. Strategic Radar (optional)
Only include when there's actual signal. Patterns across projects, emerging themes, important-but-not-urgent items. The Eisenhower "important but not urgent" quadrant. 2-3 sentences max. Omit entirely if nothing to flag.

## Closing
One line. "Have a good one." or similar.

## Example (approved style)

Subject: ARIA Daily Brief: Monday, March 24

BLUF: Three meetings today, all Conceivable-focused. Privacy policy verification is now 4 days overdue and blocks app store submission. Investor deck feedback is your top deliverable this week.

Decisions Needed

- Conceivable quiz flow: approve removing the report page to test direct-to-cart conversion? 91 completions, zero purchases. Lakshmi is waiting on your call to proceed.
- Fundraising: Peter's deck shows $1M raise. Confirm you're aligned before he starts outreach to 12 angel networks this week.

Today's Schedule + Prep

- 10:00am: Conceivable UX Review (Lakshmi, Maria, Andrew). Last session: paywall screens started, OAuth nearly done. Expect: privacy policy status from Kirsten, password change screen designs from Maria. Your open item: 2FA email investigation.
- 2:00pm: Conceivable Sync (Lakshmi, Peter). Last session: agreed on $1M raise structure. Expect: Peter to present updated deck narrative. Your open item: deck feedback.

Commitments Tracker (You Owe)

- Review investor deck and provide feedback to Peter and Maria (promised Mar 19, 4 days ago)
- Investigate 2FA email sending issues (promised Mar 17 UX review, 6 days ago)
- Research HSA eligibility for app purchases (promised Mar 17 UX review)

Waiting On Others

- Conceivable: Kirsten owes privacy policy verification (blocks app store submission, promised Mar 20)
- Conceivable: Lakshmi owes OAuth setup completion and questionnaire scoring fix
- Conceivable: Peter owes finalized content automation system (promised end of day Mar 19)

Project Pulse

- Conceivable: Needs attention. Privacy policy blocking submission. Quiz conversion at zero. But engineering momentum is strong (encryption shipped, observability live).
- Pippa: On track. Prompt engineering bugs fixed. Animation system consolidated.
- Wild Monkey Bar: On track. Post-investment pace accelerated. Expo West connections made.
- MasterFi: Quiet. No activity in last 7 days.
- Wright Advisors: On track. Trademark engagement cleared.

Overnight Comms

- Conceivable #team-engineering: Backend observability fully shipped. Railway deploy incident resolved with $5 plan upgrade.
- Conceivable #all-conceivable: Outcomes deck shared for review. Command center data room live.
- Conceivable #team-ux: Website mockups in progress. Shopify collaborator access needed (code 7176).

Have a good one.
