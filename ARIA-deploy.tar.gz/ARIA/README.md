# ARIA: AI Operating System for Business

An AI executive assistant that runs on local hardware. Ingests email, calendar, team chat, and meeting notes. Delivers a Presidential Daily Brief every morning, tracks commitments, drafts responses, and provides mobile AI access via Telegram.

Your data stays on your hardware. The AI runs locally. No per-user subscriptions.

## Quick Start (New Deployment)

### Prerequisites
- macOS (Apple Silicon: M1 or later)
- Internet connection for initial setup

### One-Command Setup
```bash
./scripts/setup-client.sh
```

This installs Homebrew, Docker, Python, Ollama, pulls AI models, creates the project structure, and sets up scheduled health checks.

### Configure for Your Business
```bash
python3 scripts/generate-client-config.py
```

Interactive wizard that creates `config/aria.json` and `.env` with your business details, email accounts, calendar, Telegram bot, and schedule preferences.

### Manual Setup Steps (after script/wizard)
1. **Create Telegram bot:** Message @BotFather on Telegram, create a bot, paste token into `.env`
2. **Connect email:** Set up Gmail/Outlook OAuth credentials in n8n (http://localhost:5678)
3. **Connect calendar:** Set up Google Calendar OAuth in n8n
4. **Verify:** Run `python3 scripts/health-check.py` to confirm everything is working

## What You Get

### Daily Intelligence
- **Morning Brief** (configurable time): Triaged emails, today's schedule with prep notes, commitments tracker, project pulse
- **Evening Debrief**: What got done vs. what was planned
- **Weekly Rollup**: Per-project summary, decisions made, things falling through cracks
- **Meeting Prep**: 30 minutes before each meeting, context on attendees and open items

### Mobile AI Access
- **Telegram bot**: Ask anything on the go
- `/brief` - Today's briefing summary
- `/status` - Quick project status
- `/commitments` - What you owe vs. what others owe you
- Free-form questions answered with full context from your data

### Communication Management
- **Draft responses**: AI drafts replies for known contacts (you approve before sending)
- **Commitment tracking**: Auto-extracts who owes what from meetings
- **Follow-up alerts**: Surfaces slipped commitments in briefings

## Architecture

```
Your Channels (Email, Calendar, Chat, Meetings)
  → Sync scripts pull data on schedule
  → Saved as dated JSON in inbox/
  → AI analyzes, triages, extracts commitments
  → Outputs: briefing email, Telegram responses, draft queue
  → All data stored locally on your hardware
```

## Project Structure

```
ARIA/
  config/aria.json        # Your business configuration
  .env                    # Secrets (Telegram token, SMTP credentials)
  scripts/
    aria_ai.py            # Shared AI client (all scripts use this)
    aria_email.py         # Email sender with SMTP fallback
    generate-briefing.py  # Morning presidential brief
    generate-debrief.py   # Evening debrief
    generate-weekly.py    # Weekly rollup
    meeting-prep.py       # Pre-meeting context briefs
    aria-telegram-bot.py  # Mobile AI access
    health-check.py       # System health monitoring
    setup-client.sh       # One-command setup
  workflows/              # n8n workflow JSON files
  templates/              # Briefing email templates
  inbox/                  # Triaged data (dated JSON files)
  briefings/              # Generated briefings (HTML + JSON)
  logs/                   # Execution logs and state files
```

## Hardware Requirements

| Tier | Hardware | Price | Capacity |
|------|----------|-------|----------|
| Starter | Mac Mini M4, 24GB | $999 | Solo practitioner |
| Professional | Mac Mini M4 Pro, 48GB | $1,599 | Small practice (5-30 people) |
| Enterprise | Mac Mini M4 Pro, 64GB | $2,199 | Multi-location |

## Health Monitoring

Health checks run every 5 minutes and alert via Telegram if any service is down:
- Inference engine (AI)
- n8n (workflow automation)
- Docker containers
- Morning briefing generation
- Telegram bot process

## Documentation

| Document | Purpose |
|----------|---------|
| [PRODUCT_SPEC.md](docs/PRODUCT_SPEC.md) | Product definition, personas, GTM |
| [ARCHITECTURE.md](docs/ARCHITECTURE.md) | Technical architecture and decisions |
| [BUG_TRACKER.md](docs/BUG_TRACKER.md) | Bugs, features, infrastructure |
| [QA_CHECKLIST.md](docs/QA_CHECKLIST.md) | Pre-deployment validation |
