#!/bin/bash
#
# ARIA Installer
# Double-click this file to install ARIA on your Mac.
#
# What this does:
#   1. Checks your Mac is compatible
#   2. Downloads and installs required software
#   3. Opens a setup wizard in your browser
#   4. You connect your email, calendar, and Telegram
#   5. ARIA starts sending you daily briefings
#
# Your data stays on this computer. Nothing is sent to the cloud.
#

set -e

# --- Colors and formatting ---
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'

clear

echo ""
echo -e "${BLUE}${BOLD}"
echo "  ╔══════════════════════════════════════════╗"
echo "  ║                                          ║"
echo "  ║          ARIA Installation               ║"
echo "  ║    AI Operating System for Business      ║"
echo "  ║                                          ║"
echo "  ╚══════════════════════════════════════════╝"
echo -e "${NC}"
echo ""
echo "  This will set up ARIA on your Mac."
echo "  It takes about 10-15 minutes (mostly downloading)."
echo ""
echo "  Your data stays on this computer. Nothing leaves."
echo ""
echo "  Starting installation..."
echo ""

# --- Logging ---
INSTALL_LOG="$HOME/ARIA-install.log"
exec > >(tee -a "$INSTALL_LOG") 2>&1

progress() {
    echo ""
    echo -e "  ${BLUE}${BOLD}[$1/7]${NC} ${BOLD}$2${NC}"
    echo -e "  ${YELLOW}$3${NC}"
    echo ""
}

success() {
    echo -e "  ${GREEN}✓${NC} $1"
}

warn() {
    echo -e "  ${YELLOW}!${NC} $1"
}

fail() {
    echo ""
    echo -e "  ${RED}${BOLD}Installation failed:${NC} $1"
    echo ""
    echo "  The install log is at: $INSTALL_LOG"
    echo "  Send this file to your ARIA administrator for help."
    echo ""
    read -p "  Press Enter to close..."
    exit 1
}

# --- Step 1: Check compatibility ---
progress 1 "Checking your Mac" "Making sure everything is compatible..."

# Check macOS
if [[ "$(uname)" != "Darwin" ]]; then
    fail "ARIA requires macOS. This doesn't appear to be a Mac."
fi

# Check Apple Silicon
ARCH=$(uname -m)
if [[ "$ARCH" != "arm64" ]]; then
    warn "ARIA works best on Apple Silicon (M1/M2/M3/M4)."
    warn "Your Mac has a $ARCH processor. Performance may be limited."
    read -p "  Continue anyway? (y/n): " cont
    [[ "$cont" != "y" && "$cont" != "Y" ]] && exit 0
fi

# Check macOS version
MACOS_VERSION=$(sw_vers -productVersion)
success "macOS $MACOS_VERSION on $ARCH"

# Check disk space (need at least 15GB)
FREE_SPACE_GB=$(df -g "$HOME" | awk 'NR==2{print $4}')
if [[ "$FREE_SPACE_GB" -lt 15 ]]; then
    fail "Need at least 15GB free disk space. You have ${FREE_SPACE_GB}GB."
fi
success "${FREE_SPACE_GB}GB free disk space"

# Check RAM
RAM_GB=$(sysctl -n hw.memsize | awk '{printf "%.0f", $1/1073741824}')
success "${RAM_GB}GB RAM"

# --- Step 2: Install Homebrew ---
progress 2 "Installing Homebrew" "This is the Mac package manager. It helps install other software."

if command -v brew &>/dev/null; then
    success "Homebrew already installed"
else
    echo "  Downloading Homebrew (this may take a minute)..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" || fail "Homebrew installation failed"
    # Add to PATH for Apple Silicon
    if [[ -f /opt/homebrew/bin/brew ]]; then
        eval "$(/opt/homebrew/bin/brew shellenv)"
        echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> "$HOME/.zprofile" 2>/dev/null || true
    fi
    success "Homebrew installed"
fi

# --- Step 3: Install Docker ---
progress 3 "Setting up Docker" "This runs the workflow engine. It's like a container for the automation."

if command -v docker &>/dev/null && docker info &>/dev/null 2>&1; then
    success "Docker is running"
else
    if command -v docker &>/dev/null; then
        echo "  Docker is installed but not running."
        echo "  Opening Docker Desktop..."
        open /Applications/Docker.app 2>/dev/null || true
        echo "  Waiting for Docker to start (this can take 30-60 seconds)..."
        for i in $(seq 1 60); do
            if docker info &>/dev/null 2>&1; then
                success "Docker is now running"
                break
            fi
            sleep 2
            echo -n "."
        done
        echo ""
        docker info &>/dev/null 2>&1 || fail "Docker didn't start. Please open Docker Desktop manually and run this installer again."
    else
        echo "  Installing Docker Desktop..."
        brew install --cask docker || fail "Docker installation failed"
        echo ""
        echo -e "  ${YELLOW}${BOLD}Docker Desktop needs to be opened once to complete setup.${NC}"
        echo "  Opening it now..."
        open /Applications/Docker.app
        echo ""
        echo "  Please wait for Docker to finish starting (you'll see the whale icon in your menu bar)."
        echo "  Then press Enter to continue."
        read -p "  Press Enter when Docker is ready..."
        docker info &>/dev/null 2>&1 || fail "Docker isn't running yet. Please wait for it to fully start, then run this installer again."
        success "Docker is running"
    fi
fi

# --- Step 4: Install Python & AI Engine ---
progress 4 "Installing AI components" "Setting up the local AI engine and Python environment."

# Python
if command -v python3 &>/dev/null; then
    PY_VER=$(python3 --version 2>&1)
    success "Python: $PY_VER"
else
    echo "  Installing Python..."
    brew install python3 || fail "Python installation failed"
    success "Python installed"
fi

# oMLX (Apple-native AI inference engine)
if pip3 show mlx-lm &>/dev/null 2>&1; then
    success "oMLX already installed"
else
    echo "  Installing oMLX (local AI engine, optimized for Apple Silicon)..."
    pip3 install mlx-lm omlx 2>/dev/null || {
        # Will be installed in venv later if system install fails
        warn "System oMLX install skipped (will install in venv)"
    }
fi

# Download AI models via MLX
echo ""
echo "  Downloading AI models (this may take a few minutes)..."
echo ""
echo "  Downloading main model (Qwen3-8B)..."
python3 -c "from mlx_lm import load; load('mlx-community/Qwen3-8B-4bit')" 2>/dev/null && success "Main model ready" || warn "Model download failed (will retry after venv setup)"

echo "  Downloading fast model (Qwen3-4B)..."
python3 -c "from mlx_lm import load; load('mlx-community/Qwen3-4B-4bit')" 2>/dev/null && success "Fast model ready" || warn "Model download failed (will retry after venv setup)"

# --- Step 4b: Install Remote Support (silent) ---
if ! command -v tailscale &>/dev/null; then
    brew install --cask tailscale 2>/dev/null && success "Remote support tools installed" || true
else
    success "Remote support tools ready"
fi

# --- Step 5: Install ARIA ---
progress 5 "Installing ARIA" "Setting up the ARIA software."

ARIA_DIR="$HOME/ARIA"

# Detect if we're running from inside a deploy package (tar.gz extract)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PACKAGE_DIR="$(dirname "$SCRIPT_DIR")"

if [[ -d "$ARIA_DIR" && -f "$ARIA_DIR/scripts/aria-command-center.py" ]]; then
    success "ARIA is already installed at $ARIA_DIR"
elif [[ -f "$PACKAGE_DIR/scripts/aria-command-center.py" ]]; then
    # Running from extracted package — copy to home directory
    echo "  Installing from package..."
    if [[ "$PACKAGE_DIR" != "$ARIA_DIR" ]]; then
        mkdir -p "$ARIA_DIR"
        cp -R "$PACKAGE_DIR"/* "$ARIA_DIR"/ 2>/dev/null
        cp -R "$PACKAGE_DIR"/.[!.]* "$ARIA_DIR"/ 2>/dev/null
    fi
    success "ARIA installed to $ARIA_DIR"
else
    # Download from the internet
    echo "  Downloading ARIA..."
    mkdir -p "$ARIA_DIR"
    curl -fsSL "https://scwright84.github.io/aria-pages/ARIA-deploy.tar.gz" | tar xz -C "$ARIA_DIR" --strip-components=1 2>/dev/null || {
        fail "Could not download ARIA. Check your internet connection or contact your administrator."
    }
    success "ARIA downloaded to $ARIA_DIR"
fi

# Create directories
mkdir -p "$ARIA_DIR"/{inbox,briefings,logs,config}

# --- Step 6: Set up Python environment ---
progress 6 "Configuring ARIA" "Setting up the Python environment and scheduled jobs."

VENV_DIR="$ARIA_DIR/.venv"
if [[ ! -d "$VENV_DIR" ]]; then
    python3 -m venv "$VENV_DIR"
fi

"$VENV_DIR/bin/pip" install --quiet --upgrade pip
"$VENV_DIR/bin/pip" install --quiet requests python-telegram-bot flask rumps qdrant-client google-auth google-auth-oauthlib google-auth-httplib2 google-api-python-client
success "Python dependencies installed"

# Set up launchd jobs
AGENTS_DIR="$HOME/Library/LaunchAgents"
mkdir -p "$AGENTS_DIR"

# Health check (every 5 minutes)
cat > "$AGENTS_DIR/com.aria.health-check.plist" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.aria.health-check</string>
    <key>ProgramArguments</key>
    <array>
        <string>${VENV_DIR}/bin/python3</string>
        <string>${ARIA_DIR}/scripts/health-check.py</string>
    </array>
    <key>StartInterval</key>
    <integer>300</integer>
    <key>RunAtLoad</key>
    <true/>
    <key>StandardOutPath</key>
    <string>${ARIA_DIR}/logs/launchd-health-check.log</string>
    <key>StandardErrorPath</key>
    <string>${ARIA_DIR}/logs/launchd-health-check.log</string>
</dict>
</plist>
EOF

# Telegram bot (persistent)
cat > "$AGENTS_DIR/com.aria.telegram-bot.plist" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.aria.telegram-bot</string>
    <key>ProgramArguments</key>
    <array>
        <string>${VENV_DIR}/bin/python3</string>
        <string>${ARIA_DIR}/scripts/aria-telegram-bot.py</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>${ARIA_DIR}/logs/launchd-telegram-bot.log</string>
    <key>StandardErrorPath</key>
    <string>${ARIA_DIR}/logs/launchd-telegram-bot.log</string>
</dict>
</plist>
EOF

# Command Center (persistent web UI — replaces dashboard + onboarding)
cat > "$AGENTS_DIR/com.aria.command-center.plist" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.aria.command-center</string>
    <key>ProgramArguments</key>
    <array>
        <string>${VENV_DIR}/bin/python3</string>
        <string>${ARIA_DIR}/scripts/aria-command-center.py</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>WorkingDirectory</key>
    <string>${ARIA_DIR}</string>
    <key>StandardOutPath</key>
    <string>${ARIA_DIR}/logs/launchd-command-center.log</string>
    <key>StandardErrorPath</key>
    <string>${ARIA_DIR}/logs/launchd-command-center.log</string>
</dict>
</plist>
EOF

# Daily maintenance (midnight)
cat > "$AGENTS_DIR/com.aria.maintenance.plist" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.aria.maintenance</string>
    <key>ProgramArguments</key>
    <array>
        <string>${VENV_DIR}/bin/python3</string>
        <string>${ARIA_DIR}/scripts/maintenance.py</string>
    </array>
    <key>StartCalendarInterval</key>
    <dict>
        <key>Hour</key><integer>0</integer>
        <key>Minute</key><integer>0</integer>
    </dict>
    <key>StandardOutPath</key>
    <string>${ARIA_DIR}/logs/launchd-maintenance.log</string>
    <key>StandardErrorPath</key>
    <string>${ARIA_DIR}/logs/launchd-maintenance.log</string>
</dict>
</plist>
EOF

# Heartbeat (hourly status ping to admin)
cat > "$AGENTS_DIR/com.aria.heartbeat.plist" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.aria.heartbeat</string>
    <key>ProgramArguments</key>
    <array>
        <string>${VENV_DIR}/bin/python3</string>
        <string>${ARIA_DIR}/scripts/heartbeat.py</string>
    </array>
    <key>StartInterval</key>
    <integer>3600</integer>
    <key>StandardOutPath</key>
    <string>${ARIA_DIR}/logs/launchd-heartbeat.log</string>
    <key>StandardErrorPath</key>
    <string>${ARIA_DIR}/logs/launchd-heartbeat.log</string>
</dict>
</plist>
EOF

for job in health-check telegram-bot command-center maintenance heartbeat; do
    launchctl bootstrap gui/$(id -u) "$AGENTS_DIR/com.aria.${job}.plist" 2>/dev/null || true
done
success "Scheduled jobs configured (health check, Telegram bot, dashboard, maintenance)"

# --- Step 7: Launch setup wizard ---
progress 7 "Opening Setup Wizard" "Almost done! Connect your accounts in the browser."

echo ""
echo -e "  ${GREEN}${BOLD}╔══════════════════════════════════════════╗${NC}"
echo -e "  ${GREEN}${BOLD}║      Installation Complete!               ║${NC}"
echo -e "  ${GREEN}${BOLD}╚══════════════════════════════════════════╝${NC}"
echo ""
echo "  ARIA is installed at: $ARIA_DIR"
echo "  Install log saved to: $INSTALL_LOG"
echo ""
echo -e "  ${BOLD}Opening the setup wizard in your browser now.${NC}"
echo "  Use it to:"
echo "    1. Set up your Google OAuth credentials"
echo "    2. Connect your Gmail account(s)"
echo "    3. Connect your Google Calendar"
echo "    4. Configure your Telegram bot"
echo ""
echo "  Close the wizard when you're done."
echo "  Your first morning briefing will arrive tomorrow."
echo ""

"$VENV_DIR/bin/python3" "$ARIA_DIR/scripts/aria-command-center.py"

echo ""
echo -e "  ${GREEN}Setup wizard closed.${NC}"
echo ""
echo "  ARIA is now running in the background:"
echo ""
echo -e "  ${BOLD}Command Center:${NC} http://localhost:8642"
echo -e "  ${BOLD}Telegram:${NC}     Message your bot anytime"
echo -e "  ${BOLD}Briefings:${NC}    Arrive at your configured time"
echo -e "  ${BOLD}Health:${NC}       Checked every 5 minutes"
echo ""
echo "  Bookmark http://localhost:8642 for daily access."
echo ""

# Open dashboard
open "http://localhost:8642/setup/interview" 2>/dev/null || true

read -p "  Press Enter to close this window..."
