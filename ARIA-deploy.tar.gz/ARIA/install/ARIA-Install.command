#!/bin/bash
#
# ARIA Installer v2
# Zero-touch installation. No questions. No prompts. No Terminal knowledge needed.
#
# What this does:
#   1. Checks compatibility
#   2. Installs prerequisites (Homebrew, Python, Docker)
#   3. Installs ARIA and all dependencies
#   4. Starts ARIA and opens the browser
#
# Your data stays on this computer. Nothing is sent to the cloud.
#

set -e

# --- Colors ---
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'

clear

echo ""
echo -e "${BLUE}${BOLD}"
echo "  ╔══════════════════════════════════════════╗"
echo "  ║                                          ║"
echo "  ║          ARIA Installation               ║"
echo "  ║    AI Operating System for Business      ║"
echo "  ║                                          ║"
echo "  ╚══════════════════════════════════════════╝"
echo -e "${NC}"
echo ""
echo "  Setting up ARIA on your Mac."
echo "  This takes about 5-10 minutes. No action needed from you."
echo ""
echo "  Your data stays on this computer. Nothing leaves."
echo ""

# --- Logging ---
INSTALL_LOG="$HOME/ARIA-install.log"
exec > >(tee -a "$INSTALL_LOG") 2>&1

step() {
    echo ""
    echo -e "  ${BLUE}${BOLD}[$1/6]${NC} ${BOLD}$2${NC}"
    echo ""
}

ok() { echo -e "  ${GREEN}✓${NC} $1"; }
skip() { echo -e "  ${YELLOW}-${NC} $1 (skipped)"; }

fail() {
    echo ""
    echo -e "  ${RED}${BOLD}Installation failed:${NC} $1"
    echo ""
    echo "  Log saved to: $INSTALL_LOG"
    echo "  Contact your ARIA administrator for help."
    echo ""
    exit 1
}

# --- Variables ---
ARIA_DIR="$HOME/ARIA"
VENV_DIR="$ARIA_DIR/.venv"
AGENTS_DIR="$HOME/Library/LaunchAgents"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PACKAGE_DIR="$(dirname "$SCRIPT_DIR")"

# ============================================================
# Step 1: Check compatibility
# ============================================================
step 1 "Checking compatibility"

[[ "$(uname)" != "Darwin" ]] && fail "ARIA requires macOS."

ARCH=$(uname -m)
MACOS_VERSION=$(sw_vers -productVersion)
RAM_GB=$(sysctl -n hw.memsize | awk '{printf "%.0f", $1/1073741824}')
FREE_SPACE_GB=$(df -g "$HOME" | awk 'NR==2{print $4}')

ok "macOS $MACOS_VERSION on $ARCH"
ok "${RAM_GB}GB RAM, ${FREE_SPACE_GB}GB free"

[[ "$FREE_SPACE_GB" -lt 10 ]] && fail "Need at least 10GB free disk space."

# ============================================================
# Step 2: Install prerequisites (all silent, no prompts)
# ============================================================
step 2 "Installing prerequisites"

# Homebrew
if command -v brew &>/dev/null; then
    ok "Homebrew ready"
else
    echo "  Installing Homebrew..."
    NONINTERACTIVE=1 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" </dev/null || fail "Homebrew installation failed"
    [[ -f /opt/homebrew/bin/brew ]] && eval "$(/opt/homebrew/bin/brew shellenv)" && echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> "$HOME/.zprofile" 2>/dev/null || true
    ok "Homebrew installed"
fi

# Python
if command -v python3 &>/dev/null; then
    ok "Python ready"
else
    echo "  Installing Python..."
    brew install python3 || fail "Python installation failed"
    ok "Python installed"
fi

# Docker (silent — don't wait, don't prompt)
if command -v docker &>/dev/null; then
    ok "Docker ready"
    docker info &>/dev/null 2>&1 || { open /Applications/Docker.app 2>/dev/null; skip "Docker starting in background"; }
else
    echo "  Installing Docker..."
    brew install --cask docker 2>/dev/null && { open /Applications/Docker.app 2>/dev/null; ok "Docker installed (starting in background)"; } || skip "Docker install failed (non-critical)"
fi

# Tailscale (fully silent)
if ! command -v tailscale &>/dev/null; then
    brew install --cask tailscale 2>/dev/null && ok "Remote support ready" || true
else
    ok "Remote support ready"
fi

# ============================================================
# Step 3: Install ARIA files
# ============================================================
step 3 "Installing ARIA"

if [[ -d "$ARIA_DIR" && -f "$ARIA_DIR/scripts/aria-command-center.py" ]]; then
    ok "ARIA already installed"
elif [[ -f "$PACKAGE_DIR/scripts/aria-command-center.py" ]]; then
    echo "  Copying ARIA to $ARIA_DIR..."
    mkdir -p "$ARIA_DIR"
    [[ "$PACKAGE_DIR" != "$ARIA_DIR" ]] && cp -R "$PACKAGE_DIR"/* "$ARIA_DIR"/ 2>/dev/null && cp -R "$PACKAGE_DIR"/.[!.]* "$ARIA_DIR"/ 2>/dev/null || true
    ok "ARIA installed"
else
    echo "  Downloading ARIA..."
    mkdir -p "$ARIA_DIR"
    curl -fsSL "https://scwright84.github.io/aria-pages/ARIA-deploy.tar.gz" | tar xz -C "$ARIA_DIR" --strip-components=1 2>/dev/null || fail "Download failed. Check your internet connection."
    ok "ARIA downloaded"
fi

mkdir -p "$ARIA_DIR"/{inbox,briefings,logs,config}

# Create default aria.json if it doesn't exist
if [[ ! -f "$ARIA_DIR/config/aria.json" ]]; then
    cat > "$ARIA_DIR/config/aria.json" << 'ARIAJSON'
{
  "timezone": "America/Chicago",
  "ai": {
    "inference_url": "http://localhost:11434/v1/chat/completions",
    "default_model": "qwen3:8b",
    "fast_model": "qwen3:4b",
    "timeout": 120,
    "cloud_model": "claude-sonnet-4-5-20241022",
    "cloud_url": "https://api.anthropic.com/v1/messages",
    "cloud_api_key_env": "ANTHROPIC_API_KEY",
    "cloud_timeout": 180,
    "cloud_max_tokens": 4096
  },
  "schedules": {
    "morning_briefing": "07:30",
    "evening_debrief": "21:30",
    "weekly_rollup": "Sunday 19:00"
  },
  "retention": {
    "inbox_days": 30,
    "briefings_days": 14
  }
}
ARIAJSON
    ok "Default config created"
fi

# Create .env template if it doesn't exist
if [[ ! -f "$ARIA_DIR/.env" ]]; then
    cat > "$ARIA_DIR/.env" << 'ENVEOF'
# ARIA Environment Variables
ARIA_TELEGRAM_TOKEN=CHANGE_ME
ENVEOF
    ok "Environment file created"
fi

# ============================================================
# Step 4: Python environment and dependencies
# ============================================================
step 4 "Installing dependencies"

if [[ ! -d "$VENV_DIR" ]]; then
    echo "  Creating Python environment..."
    python3 -m venv "$VENV_DIR"
fi

echo "  Installing Python packages..."
"$VENV_DIR/bin/pip" install --quiet --upgrade pip

if [[ -f "$ARIA_DIR/requirements.txt" ]]; then
    "$VENV_DIR/bin/pip" install --quiet -r "$ARIA_DIR/requirements.txt" || {
        echo "  Retrying with individual packages..."
        "$VENV_DIR/bin/pip" install --quiet flask msal requests httpx google-api-python-client google-auth google-auth-oauthlib google-auth-httplib2 rumps qdrant-client beautifulsoup4 lxml python-telegram-bot
    }
else
    "$VENV_DIR/bin/pip" install --quiet flask msal requests httpx google-api-python-client google-auth google-auth-oauthlib google-auth-httplib2 rumps qdrant-client beautifulsoup4 lxml python-telegram-bot
fi

# Verify critical packages
"$VENV_DIR/bin/python3" -c "import flask, msal, requests" 2>/dev/null || fail "Critical Python packages failed to install."
ok "All dependencies installed"

# ============================================================
# Step 5: Configure scheduled services
# ============================================================
step 5 "Configuring services"

mkdir -p "$AGENTS_DIR"

# Remove old plists to start clean
rm -f "$AGENTS_DIR"/com.aria.*.plist 2>/dev/null

# Command Center (the main app — auto-starts, auto-restarts)
cat > "$AGENTS_DIR/com.aria.command-center.plist" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.aria.command-center</string>
    <key>ProgramArguments</key>
    <array>
        <string>${VENV_DIR}/bin/python3</string>
        <string>${ARIA_DIR}/scripts/aria-command-center.py</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>WorkingDirectory</key>
    <string>${ARIA_DIR}</string>
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>${VENV_DIR}/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin</string>
    </dict>
    <key>StandardOutPath</key>
    <string>${ARIA_DIR}/logs/command-center.log</string>
    <key>StandardErrorPath</key>
    <string>${ARIA_DIR}/logs/command-center.log</string>
</dict>
</plist>
EOF

# Health check (every 5 min)
cat > "$AGENTS_DIR/com.aria.health-check.plist" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.aria.health-check</string>
    <key>ProgramArguments</key>
    <array>
        <string>${VENV_DIR}/bin/python3</string>
        <string>${ARIA_DIR}/scripts/health-check.py</string>
    </array>
    <key>StartInterval</key>
    <integer>300</integer>
    <key>WorkingDirectory</key>
    <string>${ARIA_DIR}</string>
    <key>StandardOutPath</key>
    <string>${ARIA_DIR}/logs/health-check.log</string>
    <key>StandardErrorPath</key>
    <string>${ARIA_DIR}/logs/health-check.log</string>
</dict>
</plist>
EOF

# Heartbeat (hourly)
cat > "$AGENTS_DIR/com.aria.heartbeat.plist" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.aria.heartbeat</string>
    <key>ProgramArguments</key>
    <array>
        <string>${VENV_DIR}/bin/python3</string>
        <string>${ARIA_DIR}/scripts/heartbeat.py</string>
    </array>
    <key>StartInterval</key>
    <integer>3600</integer>
    <key>WorkingDirectory</key>
    <string>${ARIA_DIR}</string>
    <key>StandardOutPath</key>
    <string>${ARIA_DIR}/logs/heartbeat.log</string>
    <key>StandardErrorPath</key>
    <string>${ARIA_DIR}/logs/heartbeat.log</string>
</dict>
</plist>
EOF

# Maintenance (daily at midnight)
cat > "$AGENTS_DIR/com.aria.maintenance.plist" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.aria.maintenance</string>
    <key>ProgramArguments</key>
    <array>
        <string>${VENV_DIR}/bin/python3</string>
        <string>${ARIA_DIR}/scripts/maintenance.py</string>
    </array>
    <key>StartCalendarInterval</key>
    <dict>
        <key>Hour</key><integer>0</integer>
        <key>Minute</key><integer>0</integer>
    </dict>
    <key>WorkingDirectory</key>
    <string>${ARIA_DIR}</string>
    <key>StandardOutPath</key>
    <string>${ARIA_DIR}/logs/maintenance.log</string>
    <key>StandardErrorPath</key>
    <string>${ARIA_DIR}/logs/maintenance.log</string>
</dict>
</plist>
EOF

# Bootstrap all services
for job in command-center health-check heartbeat maintenance; do
    launchctl bootout "gui/$(id -u)/com.aria.${job}" 2>/dev/null || true
    launchctl bootstrap "gui/$(id -u)" "$AGENTS_DIR/com.aria.${job}.plist" 2>/dev/null || true
done
ok "All services configured and started"

# ============================================================
# Step 6: Launch
# ============================================================
step 6 "Launching ARIA"

# Wait for command center to start (launchd is starting it)
echo "  Waiting for ARIA to start..."
for i in $(seq 1 15); do
    if curl -s -o /dev/null http://localhost:8642 2>/dev/null; then
        break
    fi
    sleep 2
done

# Check if it's running
if curl -s -o /dev/null http://localhost:8642 2>/dev/null; then
    ok "ARIA is running at http://localhost:8642"
else
    # Try starting it directly as fallback
    echo "  Starting ARIA directly..."
    "$VENV_DIR/bin/python3" "$ARIA_DIR/scripts/aria-command-center.py" &
    sleep 3
    if curl -s -o /dev/null http://localhost:8642 2>/dev/null; then
        ok "ARIA is running"
    else
        echo -e "  ${YELLOW}ARIA may still be starting. Open http://localhost:8642 in a minute.${NC}"
    fi
fi

echo ""
echo -e "  ${GREEN}${BOLD}╔══════════════════════════════════════════╗${NC}"
echo -e "  ${GREEN}${BOLD}║      Installation Complete!               ║${NC}"
echo -e "  ${GREEN}${BOLD}╚══════════════════════════════════════════╝${NC}"
echo ""
echo "  ARIA is installed at: $ARIA_DIR"
echo ""
echo "  Opening your browser now..."
echo ""
echo "  Bookmark this: http://localhost:8642"
echo ""

# Open browser
open "http://localhost:8642" 2>/dev/null || true

echo "  ARIA runs automatically. It will:"
echo "    • Start when your Mac boots"
echo "    • Restart if it ever stops"
echo "    • Deliver briefings at your configured time"
echo ""
echo "  Log saved to: $INSTALL_LOG"
echo ""
