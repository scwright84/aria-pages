#!/bin/bash
#
# ARIA Quick Start Installer
# Double-click this file to install ARIA on your Mac.
#
# This is the only file you need. It downloads everything else automatically.
#
# What happens:
#   1. Checks your Mac is compatible
#   2. Downloads ARIA (~400KB)
#   3. Installs all required software (~10 min, mostly downloading)
#   4. Opens a setup wizard in your browser
#   5. You connect your email and calendar
#   6. ARIA starts sending you daily intelligence briefings
#
# Your data stays on this computer. Nothing is sent to the cloud.
# Questions? Reply to the email that sent you this file.
#

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'

clear

echo ""
echo -e "${BLUE}${BOLD}"
echo "  ╔══════════════════════════════════════════╗"
echo "  ║                                          ║"
echo "  ║       Welcome to ARIA                    ║"
echo "  ║    Your AI Operating System              ║"
echo "  ║                                          ║"
echo "  ╚══════════════════════════════════════════╝"
echo -e "${NC}"
echo ""
echo "  This will set up ARIA on your Mac."
echo "  It takes about 10-15 minutes."
echo "  Your data never leaves this computer."
echo ""

read -p "  Ready to start? (y/n): " confirm
if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
    echo "  No problem. Run this file again when you're ready."
    exit 0
fi

echo ""

# Logging
LOG="$HOME/ARIA-install.log"
exec > >(tee -a "$LOG") 2>&1

step() {
    echo ""
    echo -e "  ${BLUE}${BOLD}[$1]${NC} ${BOLD}$2${NC}"
    echo -e "  ${YELLOW}$3${NC}"
    echo ""
}

ok() { echo -e "  ${GREEN}✓${NC} $1"; }
warn() { echo -e "  ${YELLOW}!${NC} $1"; }
fail() {
    echo ""
    echo -e "  ${RED}${BOLD}Something went wrong:${NC} $1"
    echo ""
    echo "  The install log is at: $LOG"
    echo "  Reply to the email that sent you this file"
    echo "  and attach the log. We'll help you fix it."
    echo ""
    read -p "  Press Enter to close..."
    exit 1
}

# ============================================================
step "1/6" "Checking your Mac" "Making sure everything looks good..."
# ============================================================

[[ "$(uname)" == "Darwin" ]] || fail "This installer is for Mac only."

ARCH=$(uname -m)
if [[ "$ARCH" != "arm64" ]]; then
    warn "ARIA works best on Apple Silicon (M1/M2/M3/M4)."
    warn "Your Mac uses $ARCH. Some features may be slower."
fi
ok "macOS $(sw_vers -productVersion) on $ARCH"

FREE_GB=$(df -g "$HOME" | awk 'NR==2{print $4}')
[[ "$FREE_GB" -ge 10 ]] || fail "Need at least 10GB free. You have ${FREE_GB}GB."
ok "${FREE_GB}GB free disk space"

RAM_GB=$(sysctl -n hw.memsize | awk '{printf "%.0f", $1/1073741824}')
ok "${RAM_GB}GB RAM"

# ============================================================
step "2/6" "Installing tools" "This takes a few minutes..."
# ============================================================

# Homebrew
if command -v brew &>/dev/null; then
    ok "Homebrew already installed"
else
    echo "  Installing Homebrew (the Mac package manager)..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" || fail "Homebrew install failed"
    [[ -f /opt/homebrew/bin/brew ]] && eval "$(/opt/homebrew/bin/brew shellenv)" && echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> "$HOME/.zprofile" 2>/dev/null
    ok "Homebrew installed"
fi

# Docker
if command -v docker &>/dev/null && docker info &>/dev/null 2>&1; then
    ok "Docker is running"
else
    if ! command -v docker &>/dev/null; then
        echo "  Installing Docker Desktop..."
        brew install --cask docker || fail "Docker install failed"
    fi
    echo "  Starting Docker (this can take 30 seconds)..."
    open /Applications/Docker.app 2>/dev/null
    for i in $(seq 1 60); do
        docker info &>/dev/null 2>&1 && break
        sleep 2
        echo -n "."
    done
    echo ""
    docker info &>/dev/null 2>&1 || fail "Docker didn't start. Open Docker Desktop manually, wait for it to finish, then run this installer again."
    ok "Docker is running"
fi

# Python
command -v python3 &>/dev/null && ok "Python $(python3 --version 2>&1 | cut -d' ' -f2)" || { brew install python3 || fail "Python install failed"; ok "Python installed"; }

# Tailscale (for remote support)
if ! command -v tailscale &>/dev/null; then
    echo "  Installing Tailscale (secure remote support)..."
    brew install --cask tailscale 2>/dev/null && ok "Tailscale installed" || warn "Tailscale install skipped (optional)"
fi

# ============================================================
step "3/6" "Downloading ARIA" "Getting the latest version..."
# ============================================================

ARIA_DIR="$HOME/ARIA"

# Download URL - CHANGE THIS to your actual hosting location
# Options: Cloudflare R2, S3, your own server, or even a GitHub release
DOWNLOAD_URL="${ARIA_DOWNLOAD_URL:-https://wrightadvisors.com/aria/ARIA-deploy.tar.gz}"

if [[ -d "$ARIA_DIR/scripts" ]]; then
    ok "ARIA already installed. Updating..."
fi

echo "  Downloading ARIA..."
mkdir -p "$ARIA_DIR"

# Try download URL first
if curl -fsSL "$DOWNLOAD_URL" -o /tmp/ARIA-deploy.tar.gz 2>/dev/null; then
    tar xzf /tmp/ARIA-deploy.tar.gz -C "$ARIA_DIR" --strip-components=1 2>/dev/null
    rm -f /tmp/ARIA-deploy.tar.gz
    ok "ARIA downloaded"
else
    # Fallback: check if the installer was sent alongside the archive
    SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
    if [[ -f "$SCRIPT_DIR/ARIA-deploy.tar.gz" ]]; then
        tar xzf "$SCRIPT_DIR/ARIA-deploy.tar.gz" -C "$ARIA_DIR" --strip-components=1
        ok "ARIA installed from local package"
    elif [[ -f "$HOME/Downloads/ARIA-deploy.tar.gz" ]]; then
        tar xzf "$HOME/Downloads/ARIA-deploy.tar.gz" -C "$ARIA_DIR" --strip-components=1
        ok "ARIA installed from Downloads"
    else
        warn "Could not download ARIA. Trying alternate methods..."
        # Could also try GitHub releases, direct file copy, etc.
        fail "Could not download ARIA. Please contact your administrator."
    fi
fi

mkdir -p "$ARIA_DIR"/{inbox,briefings,logs,config,exports}

# ============================================================
step "4/6" "Setting up AI" "Downloading AI models (this is the longest step)..."
# ============================================================

# Install Ollama (for initial setup - MLX migration happens later)
if command -v ollama &>/dev/null; then
    ok "Ollama installed"
else
    brew install ollama || fail "Ollama install failed"
    ok "Ollama installed"
fi

if ! curl -s http://localhost:11434/v1/models &>/dev/null; then
    ollama serve &>/dev/null &
    sleep 3
fi

echo "  Downloading AI models (~8GB total, please be patient)..."
echo ""
echo "  Model 1/3: Main AI (qwen3:8b, ~5GB)..."
ollama pull qwen3:8b || fail "Model download failed"
ok "Main model ready"

echo "  Model 2/3: Fast AI (qwen3:4b, ~2.5GB)..."
ollama pull qwen3:4b || fail "Fast model download failed"
ok "Fast model ready"

echo "  Model 3/3: Search AI (nomic-embed-text, ~275MB)..."
ollama pull nomic-embed-text || warn "Search model skipped (optional)"
ok "Search model ready"

# ============================================================
step "5/6" "Configuring ARIA" "Almost there..."
# ============================================================

# Python environment
VENV="$ARIA_DIR/.venv"
[[ -d "$VENV" ]] || python3 -m venv "$VENV"
"$VENV/bin/pip" install --quiet --upgrade pip
"$VENV/bin/pip" install --quiet requests python-telegram-bot flask rumps qdrant-client \
    google-auth google-auth-oauthlib google-auth-httplib2 google-api-python-client \
    sentence-transformers einops 2>/dev/null
ok "Python packages installed"

# Docker stack
echo "  Starting workflow engine..."
if [[ -f "$ARIA_DIR/config/docker-compose.production.yml" ]]; then
    cd "$HOME" && mkdir -p aria-docker
    cp "$ARIA_DIR/config/docker-compose.production.yml" aria-docker/docker-compose.yml
    # Generate .env for Docker if not exists
    if [[ ! -f aria-docker/.env ]]; then
        cat > aria-docker/.env << 'DENV'
POSTGRES_USER=aria
POSTGRES_PASSWORD=aria2026
POSTGRES_DB=aria
N8N_ENCRYPTION_KEY=aria-encryption-key-2026
N8N_USER_MANAGEMENT_JWT_SECRET=aria-jwt-secret-2026
N8N_API_KEY=aria-api-key-2026
ARIA_DATA_PATH=$HOME/ARIA
DENV
        sed -i '' "s|\$HOME|$HOME|g" aria-docker/.env 2>/dev/null || true
    fi
    cd aria-docker && docker compose up -d 2>/dev/null && cd "$HOME"
    ok "Workflow engine started"
else
    warn "Docker config not found. Workflow engine will be set up during onboarding."
fi

# Install launchd services
if [[ -x "$ARIA_DIR/scripts/aria-services.sh" ]]; then
    "$ARIA_DIR/scripts/aria-services.sh" install >/dev/null 2>&1
    ok "Background services configured"
fi

# ============================================================
step "6/6" "Opening Setup Wizard" "Connect your accounts..."
# ============================================================

echo ""
echo -e "  ${GREEN}${BOLD}╔══════════════════════════════════════════╗${NC}"
echo -e "  ${GREEN}${BOLD}║      ARIA is installed!                   ║${NC}"
echo -e "  ${GREEN}${BOLD}╚══════════════════════════════════════════╝${NC}"
echo ""
echo "  Now let's connect your email and calendar."
echo "  A browser window will open with the setup wizard."
echo ""
echo "  After connecting your accounts, close the wizard."
echo "  Your first briefing arrives tomorrow morning."
echo ""

# Open Tailscale if installed (for remote support)
if [[ -d "/Applications/Tailscale.app" ]]; then
    open -a Tailscale 2>/dev/null
    echo -e "  ${YELLOW}Tailscale is running. Your administrator can now"
    echo -e "  connect remotely to help you finish setup.${NC}"
    echo ""
fi

# Start onboarding wizard
"$VENV/bin/python3" "$ARIA_DIR/scripts/onboarding-server.py" 2>/dev/null &
WIZARD_PID=$!
sleep 2
open "http://localhost:8642" 2>/dev/null

echo "  Setup wizard is open in your browser."
echo "  When you're done, come back here and press Enter."
echo ""
read -p "  Press Enter when you've finished the setup wizard..."

kill $WIZARD_PID 2>/dev/null

# Start all services
echo ""
echo "  Starting ARIA services..."
"$ARIA_DIR/scripts/aria-services.sh" start >/dev/null 2>&1
ok "All services started"

echo ""
echo -e "  ${GREEN}${BOLD}You're all set!${NC}"
echo ""
echo "  ARIA is now running in the background."
echo ""
echo -e "  ${BOLD}Dashboard:${NC}    http://localhost:8643"
echo -e "  ${BOLD}Status:${NC}       http://localhost:8644"
echo -e "  ${BOLD}Telegram:${NC}     Message your bot anytime"
echo -e "  ${BOLD}Briefings:${NC}    Every morning at your configured time"
echo ""
echo "  Bookmark http://localhost:8643 for daily access."
echo ""
echo "  Your data stays on this computer. Always."
echo ""

open "http://localhost:8643" 2>/dev/null

echo "  Install log: $LOG"
echo ""
read -p "  Press Enter to close this window..."
