ARIA Install Package for Super ARIA (MacBook Air)
Generated: 2026-03-24 21:09

Client: Sean Wright (scwright84@gmail.com)
Business: Super ARIA (MacBook Air)

Files to send:
  1. email.html - Open in browser, copy/paste into email body
  2. ARIA-QuickStart.command - Attach to the email
  3. ARIA-deploy.tar.gz - Attach to the email

The client saves both attachments to their Desktop,
right-clicks the .command file, and follows the steps.

Total attachment size: ~400KB (well under email limits)
